# Deploy Tarombo PTSBI — Ubuntu 24.04

Paket ini berisi aplikasi lengkap + PostgreSQL 16 via Docker. Cocok untuk server Ubuntu 24 LTS.

## Isi paket

| Komponen | Keterangan |
|----------|------------|
| `app.py` + `services/` | Aplikasi Flask (silsilah, admin, approve, pohon) |
| `schema.sql` | Skema PostgreSQL |
| `data/uploads/` | Logo kustom PNG (persisten, volume Docker) |
| `docker-compose.yml` | PostgreSQL + web (Gunicorn) |
| `deploy/nginx-tarombo.conf.example` | Contoh reverse proxy |

## Prasyarat server

```bash
sudo apt update
sudo apt install -y docker.io docker-compose-plugin
sudo usermod -aG docker $USER
# logout/login ulang agar grup docker aktif
```

## Langkah deploy

```bash
# 1. Upload tarombo-app.zip ke server, lalu:
sudo mkdir -p /opt
sudo chown $USER:$USER /opt
unzip -o tarombo-app.zip -d /opt
# Hasil: /opt/tarombo-app/ (app.py, docker-compose.yml, ...)

cd /opt/tarombo-app

# 2. Environment
cp .env.example .env
nano .env
# Wajib ganti: POSTGRES_PASSWORD, SECRET_KEY

# 3. Build & jalankan
docker compose up -d --build

# 4. Cek log
docker compose logs -f web
```

Buka: `http://IP-SERVER:5000` (atau lewat Nginx di bawah).

## Akun awal (seed)

| Peran | Email | Password |
|-------|-------|----------|
| Admin | admin@ptsbi.org | admin123 |
| Member | member@ptsbi.org | member123 |

**Ganti password admin segera setelah login pertama.**

## Logo situs (PNG)

1. Login admin → **Logo Situs** (atau `/admin/logo`)
2. Unggah berkas **PNG** (maks. 2 MB)
3. Logo disimpan di `data/uploads/site-logo.png` (volume `./data` — tidak hilang saat rebuild container)

## Nginx + HTTPS (opsional)

```bash
sudo cp deploy/nginx-tarombo.conf.example /etc/nginx/sites-available/tarombo
sudo ln -s /etc/nginx/sites-available/tarombo /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
sudo certbot --nginx -d tarombo.ptsbi.org
```

`docker-compose.yml` mengikat `127.0.0.1:5000` — hanya Nginx yang terpapar publik.

## Backup database

```bash
docker exec tarombo-postgres pg_dump -U tarombo tarombo_ptsbi > backup_$(date +%F).sql
```

Backup logo + uploads:

```bash
tar czf tarombo-data_$(date +%F).tar.gz data/
```

## Panel admin — sinkron pohon

Admin → **Sinkron Tarombo** / **Gabung & Bersihkan Pohon**

## Troubleshooting

| Gejala | Solusi |
|--------|--------|
| web restart loop | `docker compose logs web` — cek `DATABASE_URL` di `.env` |
| /tarombo error 500 | Admin → Sinkron Tarombo |
| logo tidak berubah | Hard refresh browser (Ctrl+F5); cek `data/uploads/site-logo.png` |
| port 5000 tertutup | `ss -lntp \| grep 5000` |

## Bangun ulang paket (dari Windows dev)

Jalankan `PACK-UBUNTU.bat` di folder pengembangan — menghasilkan folder siap upload.
