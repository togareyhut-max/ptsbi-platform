<?php
/**
 * Admin settings page: tabs + sanitize + render.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PTPRM_Settings {

    const PAGE  = 'ptprm-settings';
    const GROUP = 'ptprm_group';

    public function __construct() {
        add_action( 'admin_menu', [ $this, 'menu' ] );
        add_action( 'admin_init', [ $this, 'register' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'assets' ] );
        add_filter( 'plugin_action_links_' . plugin_basename( PTPRM_FILE ), [ $this, 'action_links' ] );
    }

    public function menu() {
        add_menu_page(
            __( 'Premium Plugin', 'ptsbi-premium' ),
            __( 'Premium Plugin', 'ptsbi-premium' ),
            'manage_options',
            self::PAGE,
            [ $this, 'render' ],
            'data:image/svg+xml;base64,' . base64_encode(
                '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.4"><rect x="2.5" y="2.5" width="15" height="15" rx="2"/><path d="M10 5l1.3 3 3.2.2-2.5 2 .8 3.2L10 11.7 7.2 13.4l.8-3.2-2.5-2 3.2-.2z"/></svg>'
            ),
            58
        );
    }

    public function action_links( $links ) {
        $url = admin_url( 'admin.php?page=' . self::PAGE );
        array_unshift( $links, '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Pengaturan', 'ptsbi-premium' ) . '</a>' );
        return $links;
    }

    public function assets( $hook ) {
        if ( 'toplevel_page_' . self::PAGE !== $hook ) return;
        wp_enqueue_media();
        wp_enqueue_style( 'wp-color-picker' );
        wp_enqueue_script( 'wp-color-picker' );
        wp_enqueue_style( 'ptprm-admin', PTPRM_URL . 'assets/css/admin.css', [], PTPRM_VERSION );
        wp_enqueue_script( 'ptprm-admin', PTPRM_URL . 'assets/js/admin.js', [ 'jquery', 'wp-color-picker', 'jquery-ui-sortable' ], PTPRM_VERSION, true );
        wp_localize_script( 'ptprm-admin', 'PTPRM_ADMIN', [
            'pluginUrl' => PTPRM_URL,
        ] );
    }

    public function register() {
        register_setting( self::GROUP, PTPRM_OPTION, [
            'type'              => 'array',
            'sanitize_callback' => [ $this, 'sanitize' ],
            'default'           => ptprm_defaults(),
        ] );
    }

    public function sanitize( $input ) {
        if ( ! is_array( $input ) ) $input = [];
        $d = ptprm_defaults();
        $c = [];

        $bools = [
            'enabled',
            'hero_show', 'hero_eyebrow_show', 'hero_title_show', 'hero_sub_show',
            'hero_overlay_gradient',
            'hero_eyebrow_shadow', 'hero_title_shadow', 'hero_sub_shadow',
            'cta1_show', 'cta2_show',
            'about_show', 'values_show', 'activities_show', 'stats_show', 'visit_show',
            'visit_show_address', 'visit_show_hours', 'visit_show_wa',
            'stats_animate',
            'footer_show', 'footer_show_social',
            'subpage_hero_show', 'subpage_breadcrumb', 'subpage_ornament', 'subpage_gorga', 'subpage_eyebrow_auto',
            'team_show', 'gallery_show', 'gallery_lightbox',
            'gallery_arrows', 'gallery_dots', 'gallery_pause',
            'banner_show', 'banner_cta2_show',
            'faq_show',
            'popup_enabled', 'popup_show_home', 'popup_show_subpage', 'popup_show_close',
            'sticky_header', 'enable_tarombo_page_button',
        ];
        foreach ( $bools as $k ) {
            $c[ $k ] = ! empty( $input[ $k ] ) ? 1 : 0;
        }

        $text_fields = [
            'org_name', 'whatsapp', 'hours',
            'hero_eyebrow_text', 'hero_title_text',
            'hero_height_mode', 'hero_text_align_h', 'hero_text_align_v', 'hero_animation', 'hero_img_position',
            'hero_eyebrow_weight', 'hero_eyebrow_style',
            'hero_title_weight', 'hero_title_style',
            'hero_sub_weight', 'hero_sub_style',
            'font_heading', 'font_body',
            'hero_eyebrow_font', 'hero_title_font', 'hero_sub_font',
            'cta1_label', 'cta1_target', 'cta1_icon', 'cta1_style', 'cta1_size',
            'cta2_label', 'cta2_target', 'cta2_icon', 'cta2_style', 'cta2_size', 'cta2_mode',
            'cta2_inquiry_title', 'cta2_inquiry_submit',
            'tarombo_page_button_label', 'tarombo_page_slug',
            'about_eyebrow', 'about_title', 'about_layout', 'about_cta_label',
            'values_eyebrow', 'values_title',
            'values_1_icon', 'values_1_title', 'values_2_icon', 'values_2_title',
            'values_3_icon', 'values_3_title', 'values_4_icon', 'values_4_title',
            'activities_eyebrow', 'activities_title', 'activities_more_label',
            'stats_eyebrow', 'stats_title',
            'stats_a_num', 'stats_a_label', 'stats_b_num', 'stats_b_label',
            'stats_c_num', 'stats_c_label', 'stats_d_num', 'stats_d_label',
            'visit_eyebrow', 'visit_title',
            'footer_col1_label', 'footer_col2_label', 'footer_copyright',
            'team_eyebrow', 'team_title', 'team_more_label',
            'team_1_name', 'team_1_role',
            'team_2_name', 'team_2_role',
            'team_3_name', 'team_3_role',
            'team_4_name', 'team_4_role',
            'team_5_name', 'team_5_role',
            'team_6_name', 'team_6_role',
            'team_7_name', 'team_7_role',
            'team_8_name', 'team_8_role',
            'gallery_eyebrow', 'gallery_title',
            'banner_eyebrow', 'banner_title',
            'banner_cta_label', 'banner_cta2_label',
            'faq_eyebrow', 'faq_title',
            'faq_1_q', 'faq_2_q', 'faq_3_q', 'faq_4_q', 'faq_5_q',
            'faq_6_q', 'faq_7_q', 'faq_8_q', 'faq_9_q', 'faq_10_q',
            'gallery_layout',
            'popup_orientation', 'popup_frequency',
            'popup_eyebrow', 'popup_title', 'popup_cta_label', 'popup_cta_target', 'popup_close_text',
        ];
        foreach ( $text_fields as $k ) {
            $c[ $k ] = isset( $input[ $k ] ) ? sanitize_text_field( (string) $input[ $k ] ) : ( $d[ $k ] ?? '' );
        }
        if ( isset( $c['cta2_mode'] ) && ! in_array( $c['cta2_mode'], [ 'link', 'inquiry' ], true ) ) {
            $c['cta2_mode'] = 'inquiry';
        }
        if ( isset( $c['tarombo_page_slug'] ) ) {
            $c['tarombo_page_slug'] = sanitize_title( $c['tarombo_page_slug'] ?: 'tarombo' );
        }

        $textarea_fields = [
            'address', 'hero_sub_text', 'about_body', 'values_subtitle',
            'values_1_desc', 'values_2_desc', 'values_3_desc', 'values_4_desc',
            'activities_subtitle', 'visit_intro',
            'footer_tagline', 'footer_col1_links', 'footer_col2_links',
            'subpage_default_intro',
            'team_subtitle',
            'gallery_subtitle', 'gallery_ids',
            'banner_subtitle',
            'faq_subtitle',
            'faq_1_a', 'faq_2_a', 'faq_3_a', 'faq_4_a', 'faq_5_a',
            'faq_6_a', 'faq_7_a', 'faq_8_a', 'faq_9_a', 'faq_10_a',
            'popup_body',
            'cta2_inquiry_default', 'cta2_inquiry_hint',
        ];
        foreach ( $textarea_fields as $k ) {
            $c[ $k ] = isset( $input[ $k ] ) ? sanitize_textarea_field( (string) $input[ $k ] ) : ( $d[ $k ] ?? '' );
        }

        // Google Maps URL — terima iframe penuh atau URL embed-nya saja
        $c['visit_map_url'] = ptprm_extract_map_src( $input['visit_map_url'] ?? '' );

        $url_fields = [
            'fb_url', 'ig_url', 'yt_url', 'tt_url',
            'cta1_url', 'cta2_url', 'about_cta_url', 'activities_more_url',
            'hero_img_desktop', 'hero_img_tablet', 'hero_img_mobile', 'about_image',
            'team_more_url',
            'team_1_image', 'team_1_url',
            'team_2_image', 'team_2_url',
            'team_3_image', 'team_3_url',
            'team_4_image', 'team_4_url',
            'team_5_image', 'team_5_url',
            'team_6_image', 'team_6_url',
            'team_7_image', 'team_7_url',
            'team_8_image', 'team_8_url',
            'banner_image',
            'banner_cta_url', 'banner_cta2_url',
            'tarombo_app_url',
            'popup_image', 'popup_image_2', 'popup_image_3', 'popup_cta_url',
            'popup_link_1', 'popup_link_2', 'popup_link_3',
        ];
        foreach ( $url_fields as $k ) {
            $v = isset( $input[ $k ] ) ? trim( (string) $input[ $k ] ) : '';
            if ( $v === '' ) {
                $c[ $k ] = '';
            } elseif ( ctype_digit( $v ) ) {
                $c[ $k ] = (int) $v;
            } else {
                $c[ $k ] = esc_url_raw( $v );
            }
        }

        $color_fields = [
            'color_primary', 'color_accent', 'color_text', 'color_text_soft', 'color_cream',
            'hero_overlay_color',
            'hero_eyebrow_color', 'hero_title_color', 'hero_sub_color',
            'cta1_bg', 'cta1_color', 'cta1_bg_hover', 'cta1_color_hover',
            'cta2_bg', 'cta2_color', 'cta2_bg_hover', 'cta2_color_hover',
        ];
        foreach ( $color_fields as $k ) {
            $v = isset( $input[ $k ] ) ? trim( (string) $input[ $k ] ) : '';
            if ( $v === 'transparent' ) {
                $c[ $k ] = 'transparent';
            } else {
                $hex = sanitize_hex_color( $v );
                $c[ $k ] = $hex ? $hex : ( $d[ $k ] ?? '' );
            }
        }

        $int_fields = [
            'container_max'              => [ 600, 1600 ],
            'hero_overlay_opacity'       => [ 0, 100 ],
            'hero_height_desktop'        => [ 320, 1400 ],
            'hero_height_mobile'         => [ 320, 1200 ],
            'hero_text_max_width'        => [ 240, 1200 ],
            'hero_text_gap'              => [ 0, 80 ],
            'hero_eyebrow_size'          => [ 8, 60 ],
            'hero_eyebrow_size_mobile'   => [ 8, 60 ],
            'hero_eyebrow_letter_spacing'=> [ 0, 80 ],
            'hero_title_size'            => [ 20, 160 ],
            'hero_title_size_mobile'     => [ 16, 120 ],
            'hero_title_letter_spacing'  => [ -10, 30 ],
            'hero_title_line_height'     => [ 80, 200 ],
            'hero_sub_size'              => [ 10, 40 ],
            'hero_sub_size_mobile'       => [ 10, 36 ],
            'hero_sub_letter_spacing'    => [ -10, 30 ],
            'hero_sub_line_height'       => [ 100, 240 ],
            'cta1_radius'                => [ 0, 60 ],
            'cta2_radius'                => [ 0, 60 ],
            'activities_count'           => [ 1, 12 ],
            'activities_category'        => [ 0, 99999 ],
            'subpage_overlay'            => [ 0, 100 ],
            'team_columns'               => [ 2, 6 ],
            'gallery_columns'            => [ 2, 6 ],
            'gallery_autoplay'           => [ 1000, 10000 ],
            'gallery_speed'              => [ 10, 120 ],
            'banner_overlay'             => [ 0, 100 ],
            'popup_delay'                => [ 0, 60000 ],
            'popup_slide_interval'       => [ 1500, 15000 ],
            'popup_overlay_opacity'      => [ 0, 100 ],
            // Tipografi global
            'type_h2_size'        => [ 18, 80 ],
            'type_h2_size_m'      => [ 16, 64 ],
            'type_h2_lh'          => [ 90, 200 ],
            'type_lead_size'      => [ 12, 32 ],
            'type_lead_size_m'    => [ 12, 28 ],
            'type_lead_lh'        => [ 110, 220 ],
            'type_eyebrow_size'   => [ 8, 30 ],
            'type_eyebrow_size_m' => [ 8, 26 ],
            'type_body_size'      => [ 12, 26 ],
            'type_body_size_m'    => [ 12, 24 ],
            'type_body_lh'        => [ 120, 220 ],
            'type_li_size'        => [ 12, 26 ],
            'type_li_size_m'      => [ 12, 24 ],
            'type_sub_h2_size'    => [ 18, 60 ],
            'type_sub_h2_size_m'  => [ 16, 48 ],
            'type_sub_h3_size'    => [ 16, 48 ],
            'type_sub_h3_size_m'  => [ 14, 36 ],
            'type_sub_body_size'  => [ 12, 26 ],
            'type_sub_body_size_m'=> [ 12, 24 ],
            'type_sub_body_lh'    => [ 120, 220 ],
            'type_sub_li_size'    => [ 12, 26 ],
            'type_sub_li_size_m'  => [ 12, 24 ],
        ];
        foreach ( $int_fields as $k => $range ) {
            $v = isset( $input[ $k ] ) ? (int) $input[ $k ] : (int) ( $d[ $k ] ?? 0 );
            $c[ $k ] = max( $range[0], min( $range[1], $v ) );
        }

        return $c;
    }

    /* ===================================================================== */
    /* RENDER                                                                */
    /* ===================================================================== */

    public function render() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        $o   = ptprm_options();
        $opt = PTPRM_OPTION;
        $tabs = [
            'umum'      => 'Umum',
            'tipografi' => 'Tipografi',
            'hero'      => 'Hero',
            'beranda'   => 'Beranda',
            'sections'  => 'Section Tambahan',
            'popup'     => 'Pop-up Iklan',
            'subpage'   => 'Sub-halaman',
            'footer'    => 'Footer',
        ];
        ?>
        <div class="wrap ptprm-wrap">
            <div class="ptprm-topbar">
                <div class="ptprm-brand">
                    <strong>Premium Plugin</strong>
                    <span class="ptprm-ver">v<?php echo esc_html( PTPRM_VERSION ); ?></span>
                </div>
                <div class="ptprm-topbar-actions">
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank" class="button button-secondary">Buka Beranda</a>
                </div>
            </div>

            <form method="post" action="options.php" class="ptprm-form" id="ptprm-form">
                <?php settings_fields( self::GROUP ); ?>

                <div class="ptprm-layout">
                    <aside class="ptprm-sidebar">
                        <ul class="ptprm-tabs">
                            <?php foreach ( $tabs as $slug => $label ) : ?>
                                <li><a href="#tab-<?php echo esc_attr( $slug ); ?>" data-tab="<?php echo esc_attr( $slug ); ?>" class="<?php echo 'umum' === $slug ? 'is-active' : ''; ?>"><?php echo esc_html( $label ); ?></a></li>
                            <?php endforeach; ?>
                        </ul>
                        <div class="ptprm-save-box">
                            <?php submit_button( 'Simpan Perubahan', 'primary', 'submit', false ); ?>
                        </div>
                    </aside>

                    <main class="ptprm-main">
                        <?php $this->panel_umum( $o, $opt ); ?>
                        <?php $this->panel_tipografi( $o, $opt ); ?>
                        <?php $this->panel_hero( $o, $opt ); ?>
                        <?php $this->panel_beranda( $o, $opt ); ?>
                        <?php $this->panel_sections( $o, $opt ); ?>
                        <?php $this->panel_popup( $o, $opt ); ?>
                        <?php $this->panel_subpage( $o, $opt ); ?>
                        <?php $this->panel_footer( $o, $opt ); ?>
                    </main>
                </div>
            </form>
        </div>
        <?php
    }

    /* -- PANEL: UMUM -- */

    private function panel_umum( $o, $opt ) {
        ?>
        <section class="ptprm-panel" id="tab-umum" data-panel="umum">
            <h2>Pengaturan Umum</h2>
            <p class="ptprm-help">Identitas organisasi, warna, font, dan kontak global.</p>

            <div class="ptprm-card">
                <h3>Identitas</h3>
                <?php $this->t( 'Nama organisasi', 'org_name', $o, $opt ); ?>
            </div>

            <div class="ptprm-grid-2">
                <div class="ptprm-card">
                    <h3>Warna Brand</h3>
                    <?php
                    $this->color( 'Warna Primer (navy)',  'color_primary',   $o, $opt );
                    $this->color( 'Warna Aksen (emas)',   'color_accent',    $o, $opt );
                    $this->color( 'Warna Teks Utama',     'color_text',      $o, $opt );
                    $this->color( 'Warna Teks Halus',     'color_text_soft', $o, $opt );
                    $this->color( 'Warna Krem (BG soft)', 'color_cream',     $o, $opt );
                    ?>
                    <div class="ptprm-presets">
                        <span>Preset:</span>
                        <button type="button" class="button button-secondary ptprm-preset" data-primary="#0A1F3D" data-accent="#C9A44C">Navy + Emas</button>
                        <button type="button" class="button button-secondary ptprm-preset" data-primary="#0E3B2E" data-accent="#D4AF37">Hijau + Emas</button>
                        <button type="button" class="button button-secondary ptprm-preset" data-primary="#1A1A1A" data-accent="#C9A44C">Hitam + Emas</button>
                    </div>
                </div>
                <div class="ptprm-card">
                    <h3>Font Default</h3>
                    <?php
                    $this->select( 'Font Heading', 'font_heading', $o, $opt, ptprm_font_choices() );
                    $this->select( 'Font Body',    'font_body',    $o, $opt, ptprm_font_choices() );
                    $this->number( 'Lebar konten maks. (px)', 'container_max', $o, $opt, 600, 1600 );
                    ?>
                </div>
            </div>

            <div class="ptprm-grid-2">
                <div class="ptprm-card">
                    <h3>Kontak & Alamat</h3>
                    <?php
                    $this->t( 'Nomor WhatsApp (mis. +6281xxxx)', 'whatsapp', $o, $opt );
                    $this->ta( 'Alamat lengkap', 'address', $o, $opt, 3 );
                    $this->t( 'Jam operasional', 'hours', $o, $opt );
                    ?>
                </div>
                <div class="ptprm-card">
                    <h3>Sosial Media</h3>
                    <?php
                    $this->url( 'Facebook',  'fb_url', $o, $opt );
                    $this->url( 'Instagram', 'ig_url', $o, $opt );
                    $this->url( 'YouTube',   'yt_url', $o, $opt );
                    $this->url( 'TikTok',    'tt_url', $o, $opt );
                    ?>
                </div>
            </div>

            <div class="ptprm-card">
                <h3>Header &amp; Halaman Tarombo</h3>
                <?php
                $this->bool( 'Header tetap di atas saat scroll (semua halaman)', 'sticky_header', $o, $opt );
                $this->bool( 'Tombol <strong>Lihat Tarombo Kami</strong> di halaman penjelasan Tarombo', 'enable_tarombo_page_button', $o, $opt );
                $this->url( 'URL aplikasi Tarombo', 'tarombo_app_url', $o, $opt );
                $this->t( 'Label tombol', 'tarombo_page_button_label', $o, $opt );
                $this->t( 'Slug halaman penjelasan (mis. tarombo)', 'tarombo_page_slug', $o, $opt );
                ?>
                <p class="ptprm-help">Halaman <code>/<?php echo esc_html( $o['tarombo_page_slug'] ?: 'tarombo' ); ?>/</code> di WordPress akan otomatis menampilkan tombol menuju aplikasi Tarombo.</p>
            </div>
        </section>
        <?php
    }

    /* -- PANEL: TIPOGRAFI -- */

    private function panel_tipografi( $o, $opt ) {
        ?>
        <section class="ptprm-panel" id="tab-tipografi" data-panel="tipografi" hidden>
            <h2>Tipografi Global</h2>
            <p class="ptprm-help">Atur ukuran font (desktop &amp; mobile) untuk seluruh teks di Beranda dan Sub-halaman. Hero punya kontrol sendiri di tab Hero — jadi yang di sini berpengaruh ke Tentang, Nilai, Kegiatan, Statistik, Kunjungi, Pengurus, FAQ, dll. plus seluruh isi Sub-halaman (Program Kerja, Tarombo, dll.).</p>

            <div class="ptprm-card">
                <h3>Beranda — Section Umum</h3>
                <div class="ptprm-grid-3">
                    <?php
                    $this->number( 'Eyebrow desktop (px)',  'type_eyebrow_size',   $o, $opt, 8, 30 );
                    $this->number( 'Eyebrow mobile (px)',   'type_eyebrow_size_m', $o, $opt, 8, 26 );
                    $this->number( 'Judul H2 desktop (px)', 'type_h2_size',        $o, $opt, 18, 80 );
                    $this->number( 'Judul H2 mobile (px)',  'type_h2_size_m',      $o, $opt, 16, 64 );
                    $this->number( 'Line-height H2 (×0.01)','type_h2_lh',          $o, $opt, 90, 200 );
                    $this->number( 'Lead/subjudul desktop', 'type_lead_size',      $o, $opt, 12, 32 );
                    $this->number( 'Lead/subjudul mobile',  'type_lead_size_m',    $o, $opt, 12, 28 );
                    $this->number( 'Line-height lead (×0.01)','type_lead_lh',      $o, $opt, 110, 220 );
                    $this->number( 'Paragraf desktop',      'type_body_size',      $o, $opt, 12, 26 );
                    $this->number( 'Paragraf mobile',       'type_body_size_m',    $o, $opt, 12, 24 );
                    $this->number( 'Line-height body (×0.01)','type_body_lh',      $o, $opt, 120, 220 );
                    $this->number( 'List/li desktop',       'type_li_size',        $o, $opt, 12, 26 );
                    $this->number( 'List/li mobile',        'type_li_size_m',      $o, $opt, 12, 24 );
                    ?>
                </div>
            </div>

            <div class="ptprm-card">
                <h3>Sub-halaman — Konten</h3>
                <p class="ptprm-help">Ukuran untuk teks yang Anda tulis di editor halaman (Program Kerja, Tarombo, dll.).</p>
                <div class="ptprm-grid-3">
                    <?php
                    $this->number( 'H2 desktop (px)',       'type_sub_h2_size',     $o, $opt, 18, 60 );
                    $this->number( 'H2 mobile (px)',        'type_sub_h2_size_m',   $o, $opt, 16, 48 );
                    $this->number( 'H3 desktop (px)',       'type_sub_h3_size',     $o, $opt, 16, 48 );
                    $this->number( 'H3 mobile (px)',        'type_sub_h3_size_m',   $o, $opt, 14, 36 );
                    $this->number( 'Paragraf desktop',      'type_sub_body_size',   $o, $opt, 12, 26 );
                    $this->number( 'Paragraf mobile',       'type_sub_body_size_m', $o, $opt, 12, 24 );
                    $this->number( 'Line-height body (×0.01)','type_sub_body_lh',   $o, $opt, 120, 220 );
                    $this->number( 'List/li desktop',       'type_sub_li_size',     $o, $opt, 12, 26 );
                    $this->number( 'List/li mobile',        'type_sub_li_size_m',   $o, $opt, 12, 24 );
                    ?>
                </div>
            </div>
        </section>
        <?php
    }

    /* -- PANEL: POP-UP IKLAN -- */

    private function panel_popup( $o, $opt ) {
        ?>
        <section class="ptprm-panel" id="tab-popup" data-panel="popup" hidden>
            <h2>Pop-up Iklan</h2>
            <p class="ptprm-help">Pop-up muncul setelah delay tertentu. Bisa diatur tampil sekali per session, sehari sekali, atau setiap kunjungan. Gambar bisa portrait (vertikal) atau landscape (horizontal).</p>

            <div class="ptprm-card">
                <h3>Aktivasi &amp; Perilaku</h3>
                <div class="ptprm-grid-2">
                    <div>
                        <?php
                        $this->bool( 'Aktifkan pop-up',                'popup_enabled',     $o, $opt );
                        $this->bool( 'Tampilkan di Beranda',           'popup_show_home',   $o, $opt );
                        $this->bool( 'Tampilkan di Sub-halaman',       'popup_show_subpage',$o, $opt );
                        $this->select( 'Frekuensi tampil', 'popup_frequency', $o, $opt, [
                            'session' => 'Sekali per session (sampai tutup browser)',
                            'day'     => 'Sekali sehari per perangkat',
                            'always'  => 'Setiap kunjungan halaman',
                        ] );
                        ?>
                    </div>
                    <div>
                        <?php
                        $this->number( 'Delay sebelum muncul (ms, 0–60000)', 'popup_delay', $o, $opt, 0, 60000 );
                        $this->range(  'Opasitas overlay gelap (0–100%)',    'popup_overlay_opacity', $o, $opt, 0, 100 );
                        $this->bool(   'Tampilkan tombol "Tidak sekarang"',  'popup_show_close', $o, $opt );
                        $this->t(      'Teks tombol "tidak sekarang"',       'popup_close_text', $o, $opt );
                        ?>
                    </div>
                </div>
            </div>

            <div class="ptprm-card">
                <h3>Orientasi &amp; Auto-slide</h3>
                <div class="ptprm-grid-2">
                    <div>
                        <?php
                        $this->select( 'Orientasi pop-up', 'popup_orientation', $o, $opt, [
                            'portrait'  => 'Portrait (vertikal) — gambar 3:4 di kiri, teks di kanan',
                            'landscape' => 'Landscape (horizontal) — gambar 16:9 di atas, teks di bawah',
                        ] );
                        ?>
                    </div>
                    <div>
                        <?php
                        $this->number( 'Interval rotasi foto (ms)', 'popup_slide_interval', $o, $opt, 1500, 15000 );
                        ?>
                        <p class="ptprm-help" style="margin: 4px 0 0;">Hanya berlaku jika Anda mengisi lebih dari 1 foto.</p>
                    </div>
                </div>
            </div>

            <div class="ptprm-card">
                <h3>Foto Iklan (sampai 3 foto)</h3>
                <p class="ptprm-help">Isi 1–3 foto. Jika lebih dari 1, foto akan berotasi otomatis. Setiap foto bisa punya link sendiri (opsional) — klik foto akan membuka link tersebut. Disarankan: portrait min. <strong>900×1200px</strong>, landscape min. <strong>1280×720px</strong>.</p>
                <div class="ptprm-grid-3">
                    <div class="ptprm-mini-card">
                        <strong>Foto 1</strong>
                        <?php $this->image( 'Gambar', 'popup_image',   $o, $opt ); ?>
                        <?php $this->url(   'Link saat foto diklik (opsional)', 'popup_link_1', $o, $opt ); ?>
                    </div>
                    <div class="ptprm-mini-card">
                        <strong>Foto 2 (opsional)</strong>
                        <?php $this->image( 'Gambar', 'popup_image_2', $o, $opt ); ?>
                        <?php $this->url(   'Link saat foto diklik (opsional)', 'popup_link_2', $o, $opt ); ?>
                    </div>
                    <div class="ptprm-mini-card">
                        <strong>Foto 3 (opsional)</strong>
                        <?php $this->image( 'Gambar', 'popup_image_3', $o, $opt ); ?>
                        <?php $this->url(   'Link saat foto diklik (opsional)', 'popup_link_3', $o, $opt ); ?>
                    </div>
                </div>
            </div>

            <div class="ptprm-card">
                <h3>Teks &amp; Tombol</h3>
                <div class="ptprm-grid-2">
                    <div>
                        <?php
                        $this->t(  'Eyebrow',   'popup_eyebrow', $o, $opt );
                        $this->t(  'Judul',     'popup_title',   $o, $opt );
                        $this->ta( 'Paragraf',  'popup_body',    $o, $opt, 4 );
                        ?>
                    </div>
                    <div>
                        <?php
                        $this->t(  'Label tombol utama', 'popup_cta_label', $o, $opt );
                        $this->url( 'URL tombol',        'popup_cta_url',   $o, $opt );
                        $this->select( 'Target',         'popup_cta_target', $o, $opt, [
                            '_self'  => 'Tab sama',
                            '_blank' => 'Tab baru',
                        ] );
                        ?>
                    </div>
                </div>
            </div>
        </section>
        <?php
    }

    /* -- PANEL: HERO -- */

    private function panel_hero( $o, $opt ) {
        ?>
        <section class="ptprm-panel" id="tab-hero" data-panel="hero" hidden>
            <h2>Hero & Tombol CTA</h2>
            <p class="ptprm-help">Atur gambar, teks, dan 2 tombol. Preview di bawah update otomatis saat Anda mengetik.</p>

            <?php $this->section_toggle( 'hero_show', 'Tampilkan section Hero', $o, $opt ); ?>

            <!-- LIVE PREVIEW -->
            <div class="ptprm-preview-card">
                <div class="ptprm-preview-bar">
                    <strong>Preview</strong>
                    <span class="ptprm-preview-help">Tidak persis 1:1 dengan situs; tujuan untuk gambaran cepat saat mengedit.</span>
                </div>
                <div class="ptprm-preview-frame" id="ptprm-hero-preview">
                    <div class="pv-media"><img src="" alt="" id="pv-img"><div class="pv-overlay" id="pv-overlay"></div></div>
                    <div class="pv-inner" id="pv-inner">
                        <span class="pv-eyebrow" id="pv-eyebrow"></span>
                        <h1 class="pv-title" id="pv-title"></h1>
                        <p class="pv-sub" id="pv-sub"></p>
                        <div class="pv-cta-row">
                            <a class="pv-cta pv-cta1" id="pv-cta1"><span class="pv-cta-icon" id="pv-cta1-icon"></span><span id="pv-cta1-label"></span></a>
                            <a class="pv-cta pv-cta2" id="pv-cta2"><span class="pv-cta-icon" id="pv-cta2-icon"></span><span id="pv-cta2-label"></span></a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="ptprm-grid-2">
                <div class="ptprm-card">
                    <h3>Gambar Latar (responsif)</h3>
                    <?php
                    $this->image( 'Gambar Desktop (≥1920×900)', 'hero_img_desktop', $o, $opt );
                    $this->image( 'Gambar Tablet (opsional)',    'hero_img_tablet',  $o, $opt );
                    $this->image( 'Gambar Mobile (opsional)',    'hero_img_mobile',  $o, $opt );
                    $this->select( 'Posisi fokus gambar', 'hero_img_position', $o, $opt, [
                        'center 35%' => 'Tengah-atas (rekomendasi wajah)',
                        'center center' => 'Tengah',
                        'center top'    => 'Atas',
                        'center bottom' => 'Bawah',
                        'left center'   => 'Kiri',
                        'right center'  => 'Kanan',
                    ] );
                    ?>
                </div>
                <div class="ptprm-card">
                    <h3>Overlay & Tinggi</h3>
                    <?php
                    $this->color( 'Warna overlay',          'hero_overlay_color',   $o, $opt );
                    $this->range( 'Opasitas overlay (0–100%)', 'hero_overlay_opacity', $o, $opt, 0, 100 );
                    $this->bool(  'Gradient overlay (kiri lebih gelap)', 'hero_overlay_gradient', $o, $opt );
                    $this->select( 'Tinggi hero', 'hero_height_mode', $o, $opt, [
                        'small'    => 'Kecil (≈60vh)',
                        'standard' => 'Standar (80vh) — rekomendasi',
                        'tall'     => 'Tinggi (90vh)',
                        'full'     => 'Penuh layar (100vh)',
                        'custom'   => 'Custom (px)',
                    ] );
                    $this->number( 'Tinggi custom desktop (px)', 'hero_height_desktop', $o, $opt, 320, 1400 );
                    $this->number( 'Tinggi custom mobile (px)',  'hero_height_mobile',  $o, $opt, 320, 1200 );
                    ?>
                </div>
            </div>

            <div class="ptprm-card">
                <h3>Layout Teks</h3>
                <div class="ptprm-grid-3">
                    <?php
                    $this->select( 'Posisi horizontal', 'hero_text_align_h', $o, $opt, [
                        'left' => 'Kiri', 'center' => 'Tengah', 'right' => 'Kanan',
                    ] );
                    $this->select( 'Posisi vertikal', 'hero_text_align_v', $o, $opt, [
                        'top' => 'Atas', 'middle' => 'Tengah', 'bottom' => 'Bawah',
                    ] );
                    $this->select( 'Animasi muncul', 'hero_animation', $o, $opt, [
                        'none' => 'Tidak ada', 'fade' => 'Fade', 'fade-up' => 'Fade-up', 'slide-in' => 'Slide-in',
                    ] );
                    $this->number( 'Lebar maks. teks (px)', 'hero_text_max_width', $o, $opt, 240, 1200 );
                    $this->number( 'Jarak antar elemen (px)', 'hero_text_gap', $o, $opt, 0, 80 );
                    ?>
                </div>
            </div>

            <?php $this->hero_text_card( 'Eyebrow (label kecil)', 'hero_eyebrow', $o, $opt, false ); ?>
            <?php $this->hero_text_card( 'Judul utama (H1)',      'hero_title',   $o, $opt, true  ); ?>
            <?php $this->hero_text_card( 'Subjudul (paragraf)',   'hero_sub',     $o, $opt, true  ); ?>

            <?php $this->cta_card( 'Tombol 1 (Primer)', 1, $o, $opt ); ?>
            <?php $this->cta_card( 'Tombol 2 (Sekunder)', 2, $o, $opt ); ?>
        </section>
        <?php
    }

    private function hero_text_card( $title, $prefix, $o, $opt, $with_line_height = false ) {
        ?>
        <div class="ptprm-card">
            <h3><?php echo esc_html( $title ); ?></h3>
            <?php $this->bool( 'Tampilkan', $prefix . '_show', $o, $opt ); ?>
            <?php
            if ( $prefix === 'hero_sub' ) {
                $this->ta( 'Teks', $prefix . '_text', $o, $opt, 3 );
            } else {
                $this->t( 'Teks', $prefix . '_text', $o, $opt );
            }
            ?>
            <div class="ptprm-grid-3">
                <?php
                $this->select( 'Font', $prefix . '_font', $o, $opt, ptprm_font_choices() );
                $this->select( 'Bobot', $prefix . '_weight', $o, $opt, [
                    '300' => '300 Light', '400' => '400 Regular', '500' => '500 Medium',
                    '600' => '600 Semi-bold', '700' => '700 Bold', '800' => '800 Extra-bold',
                ] );
                $this->select( 'Style', $prefix . '_style', $o, $opt, [
                    'normal' => 'Normal', 'italic' => 'Italic', 'uppercase' => 'UPPERCASE', 'capitalize' => 'Capitalize',
                ] );
                $this->color( 'Warna', $prefix . '_color', $o, $opt );
                $this->number( 'Ukuran desktop (px)', $prefix . '_size',        $o, $opt, 8, 200 );
                $this->number( 'Ukuran mobile (px)',  $prefix . '_size_mobile', $o, $opt, 8, 160 );
                $this->number( 'Letter spacing (×0.01em)', $prefix . '_letter_spacing', $o, $opt, -10, 80 );
                if ( $with_line_height ) {
                    $this->number( 'Line height (×0.01)', $prefix . '_line_height', $o, $opt, 80, 240 );
                }
                $this->bool( 'Bayangan teks', $prefix . '_shadow', $o, $opt );
                ?>
            </div>
        </div>
        <?php
    }

    private function cta_card( $title, $i, $o, $opt ) {
        ?>
        <div class="ptprm-card">
            <h3><?php echo esc_html( $title ); ?></h3>
            <?php $this->bool( 'Tampilkan', "cta{$i}_show", $o, $opt ); ?>
            <div class="ptprm-grid-3">
                <?php
                $this->t(   'Label tombol', "cta{$i}_label", $o, $opt );
                $this->url( 'URL tujuan',   "cta{$i}_url",   $o, $opt );
                $this->select( 'Target',    "cta{$i}_target", $o, $opt, [
                    '_self' => 'Tab sama', '_blank' => 'Tab baru',
                ] );
                $this->select( 'Ikon',      "cta{$i}_icon",  $o, $opt, ptprm_icon_choices() );
                $this->select( 'Style',     "cta{$i}_style", $o, $opt, [
                    'solid'   => 'Solid',
                    'outline' => 'Outline',
                    'ghost'   => 'Ghost',
                ] );
                $this->select( 'Ukuran',    "cta{$i}_size",  $o, $opt, [
                    'small' => 'Kecil', 'medium' => 'Sedang', 'large' => 'Besar',
                ] );
                $this->color( 'BG',           "cta{$i}_bg",          $o, $opt );
                $this->color( 'Teks',         "cta{$i}_color",       $o, $opt );
                $this->color( 'BG hover',     "cta{$i}_bg_hover",    $o, $opt );
                $this->color( 'Teks hover',   "cta{$i}_color_hover", $o, $opt );
                $this->number( 'Radius (px)', "cta{$i}_radius",      $o, $opt, 0, 60 );
                if ( $i === 2 ) {
                    $this->select( 'Mode tombol', 'cta2_mode', $o, $opt, [
                        'inquiry' => 'Form masukan → WhatsApp',
                        'link'    => 'Link langsung (URL di atas)',
                    ] );
                    $this->t( 'Judul form', 'cta2_inquiry_title', $o, $opt );
                    $this->ta( 'Petunjuk singkat', 'cta2_inquiry_hint', $o, $opt, 2 );
                    $this->ta( 'Teks awal (contoh pertanyaan)', 'cta2_inquiry_default', $o, $opt, 3 );
                    $this->t( 'Label tombol kirim', 'cta2_inquiry_submit', $o, $opt );
                    echo '<p class="ptprm-help">Mode <strong>Form masukan</strong> membuka popup; pesan dikirim ke nomor WhatsApp di tab Umum.</p>';
                }
                ?>
            </div>
        </div>
        <?php
    }

    /* -- PANEL: BERANDA (selain Hero) -- */

    private function panel_beranda( $o, $opt ) {
        ?>
        <section class="ptprm-panel" id="tab-beranda" data-panel="beranda" hidden>
            <h2>Section Beranda</h2>
            <p class="ptprm-help">Urutan: Hero → Tentang → Nilai-Nilai → Kegiatan → Statistik → Kunjungi. Setiap section punya toggle Tampilkan.</p>

            <!-- ABOUT -->
            <div class="ptprm-card">
                <h3>Tentang Kami</h3>
                <?php $this->bool( 'Tampilkan section', 'about_show', $o, $opt ); ?>
                <div class="ptprm-grid-2">
                    <div>
                        <?php
                        $this->t( 'Eyebrow', 'about_eyebrow', $o, $opt );
                        $this->t( 'Judul',  'about_title',   $o, $opt );
                        $this->ta( 'Isi paragraf', 'about_body', $o, $opt, 6 );
                        $this->t( 'Label tombol (opsional)', 'about_cta_label', $o, $opt );
                        $this->url( 'URL tombol (opsional)',  'about_cta_url',  $o, $opt );
                        ?>
                    </div>
                    <div>
                        <?php
                        $this->image( 'Gambar (opsional)', 'about_image', $o, $opt );
                        $this->select( 'Layout', 'about_layout', $o, $opt, [
                            'image-left'  => 'Gambar kiri, teks kanan',
                            'image-right' => 'Gambar kanan, teks kiri',
                            'text-only'   => 'Teks saja',
                        ] );
                        ?>
                    </div>
                </div>
            </div>

            <!-- VALUES -->
            <div class="ptprm-card">
                <h3>Nilai-Nilai Kami</h3>
                <?php
                $this->bool( 'Tampilkan section', 'values_show', $o, $opt );
                $this->t(  'Eyebrow',  'values_eyebrow',  $o, $opt );
                $this->t(  'Judul',    'values_title',    $o, $opt );
                $this->ta( 'Subjudul', 'values_subtitle', $o, $opt, 2 );
                ?>
                <div class="ptprm-grid-2">
                    <?php for ( $i = 1; $i <= 4; $i++ ) : ?>
                        <div class="ptprm-mini-card">
                            <strong>Nilai <?php echo $i; ?></strong>
                            <?php
                            $this->select( 'Ikon',     "values_{$i}_icon",  $o, $opt, ptprm_icon_choices() );
                            $this->t(      'Judul',    "values_{$i}_title", $o, $opt );
                            $this->ta(     'Deskripsi','values_{$i}_desc',  $o, $opt, 2 );
                            ?>
                        </div>
                    <?php endfor; ?>
                </div>
            </div>

            <!-- ACTIVITIES -->
            <div class="ptprm-card">
                <h3>Kegiatan Kami</h3>
                <?php $this->bool( 'Tampilkan section', 'activities_show', $o, $opt ); ?>
                <div class="ptprm-grid-2">
                    <div>
                        <?php
                        $this->t(  'Eyebrow',  'activities_eyebrow',  $o, $opt );
                        $this->t(  'Judul',    'activities_title',    $o, $opt );
                        $this->ta( 'Subjudul', 'activities_subtitle', $o, $opt, 2 );
                        ?>
                    </div>
                    <div>
                        <?php
                        $this->number( 'Jumlah kartu', 'activities_count', $o, $opt, 1, 12 );
                        $this->category_select( 'Kategori', 'activities_category', $o, $opt );
                        $this->t(   'Label tombol "lihat semua"', 'activities_more_label', $o, $opt );
                        $this->url( 'URL halaman semua kegiatan', 'activities_more_url',   $o, $opt );
                        ?>
                    </div>
                </div>
                <p class="ptprm-help">Data diambil otomatis dari post WordPress terbaru. Pastikan post punya gambar utama (featured image).</p>
            </div>

            <!-- STATS -->
            <div class="ptprm-card">
                <h3>Statistik</h3>
                <?php
                $this->bool( 'Tampilkan section', 'stats_show', $o, $opt );
                $this->t( 'Eyebrow', 'stats_eyebrow', $o, $opt );
                $this->t( 'Judul',   'stats_title',   $o, $opt );
                $this->bool( 'Animasi naik angka saat scroll', 'stats_animate', $o, $opt );
                ?>
                <div class="ptprm-grid-2">
                    <?php foreach ( [ 'a', 'b', 'c', 'd' ] as $k ) : ?>
                        <div class="ptprm-mini-card">
                            <strong>Statistik <?php echo strtoupper( $k ); ?></strong>
                            <?php
                            $this->t( 'Angka (mis. 10+)',  "stats_{$k}_num",   $o, $opt );
                            $this->t( 'Label',             "stats_{$k}_label", $o, $opt );
                            ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- VISIT -->
            <div class="ptprm-card">
                <h3>Kunjungi Kami</h3>
                <?php $this->bool( 'Tampilkan section', 'visit_show', $o, $opt ); ?>
                <div class="ptprm-grid-2">
                    <div>
                        <?php
                        $this->t(  'Eyebrow',  'visit_eyebrow', $o, $opt );
                        $this->t(  'Judul',    'visit_title',   $o, $opt );
                        $this->ta( 'Paragraf', 'visit_intro',   $o, $opt, 3 );
                        ?>
                    </div>
                    <div>
                        <?php
                        $this->bool( 'Tampilkan alamat',  'visit_show_address', $o, $opt );
                        $this->bool( 'Tampilkan jam',     'visit_show_hours',   $o, $opt );
                        $this->bool( 'Tampilkan WA',      'visit_show_wa',      $o, $opt );
                        $this->ta(   'Google Maps (paste seluruh iframe ATAU URL embed)', 'visit_map_url',  $o, $opt, 4 );
                        ?>
                    </div>
                </div>
                <p class="ptprm-help">Cara mudah: di Google Maps → <strong>Bagikan</strong> → <strong>Sematkan peta</strong> → klik <strong>Salin HTML</strong>, lalu tempel di sini. Plugin akan ambil URL secara otomatis. Disimpan hanya jika domain Google Maps yang dikenal.</p>
            </div>
        </section>
        <?php
    }

    /* -- PANEL: SECTION TAMBAHAN -- */

    private function panel_sections( $o, $opt ) {
        ?>
        <section class="ptprm-panel" id="tab-sections" data-panel="sections" hidden>
            <h2>Section Tambahan</h2>
            <p class="ptprm-help">Empat section opsional yang umum dipakai organisasi. Semua <strong>default mati</strong> — aktifkan yang Anda perlukan.</p>

            <!-- TEAM -->
            <div class="ptprm-card">
                <h3>Pengurus / Tim <span class="ptprm-tag">posisi: setelah Nilai</span></h3>
                <?php $this->bool( 'Tampilkan section', 'team_show', $o, $opt ); ?>
                <div class="ptprm-grid-2">
                    <div>
                        <?php
                        $this->t(  'Eyebrow',  'team_eyebrow',  $o, $opt );
                        $this->t(  'Judul',    'team_title',    $o, $opt );
                        $this->ta( 'Subjudul', 'team_subtitle', $o, $opt, 2 );
                        ?>
                    </div>
                    <div>
                        <?php
                        $this->number( 'Jumlah kolom (2–6)', 'team_columns', $o, $opt, 2, 6 );
                        $this->t(  'Label tombol "lihat semua" (opsional)', 'team_more_label', $o, $opt );
                        $this->url( 'URL tombol (opsional)',                'team_more_url',   $o, $opt );
                        ?>
                    </div>
                </div>

                <p class="ptprm-help">Isi maksimal 8 pengurus. Kosongkan slot yang tidak dipakai (yang nama kosong tidak akan tampil).</p>
                <div class="ptprm-grid-2">
                    <?php for ( $i = 1; $i <= 8; $i++ ) : ?>
                        <div class="ptprm-mini-card">
                            <strong>Pengurus <?php echo $i; ?></strong>
                            <?php
                            $this->image( 'Foto', "team_{$i}_image", $o, $opt );
                            $this->t(  'Nama',                "team_{$i}_name", $o, $opt );
                            $this->t(  'Jabatan',             "team_{$i}_role", $o, $opt );
                            $this->url( 'Link profil/sosmed', "team_{$i}_url",  $o, $opt );
                            ?>
                        </div>
                    <?php endfor; ?>
                </div>
            </div>

            <!-- GALLERY -->
            <div class="ptprm-card">
                <h3>Galeri Foto <span class="ptprm-tag">posisi: setelah Kegiatan</span></h3>
                <?php $this->bool( 'Tampilkan section', 'gallery_show', $o, $opt ); ?>
                <div class="ptprm-grid-2">
                    <div>
                        <?php
                        $this->t(  'Eyebrow',  'gallery_eyebrow',  $o, $opt );
                        $this->t(  'Judul',    'gallery_title',    $o, $opt );
                        $this->ta( 'Subjudul', 'gallery_subtitle', $o, $opt, 2 );
                        ?>
                    </div>
                    <div>
                        <?php
                        $this->select( 'Tampilan galeri', 'gallery_layout', $o, $opt, [
                            'grid'    => 'Grid statis (kotak rapi)',
                            'slider'  => 'Slider otomatis (tombol kiri/kanan + dots)',
                            'marquee' => 'Marquee bergerak terus (tanpa berhenti)',
                        ] );
                        $this->number( 'Foto per layar (desktop, 2–6)', 'gallery_columns',  $o, $opt, 2, 6 );
                        $this->bool(   'Aktifkan lightbox saat foto diklik', 'gallery_lightbox', $o, $opt );
                        ?>
                    </div>
                </div>

                <div class="ptprm-grid-2">
                    <div class="ptprm-mini-card">
                        <strong>Pengaturan Slider (jika dipilih)</strong>
                        <?php
                        $this->number( 'Auto-play (ms, 1000–10000)', 'gallery_autoplay', $o, $opt, 1000, 10000 );
                        $this->bool(   'Tampilkan tombol panah',     'gallery_arrows',   $o, $opt );
                        $this->bool(   'Tampilkan dots indikator',   'gallery_dots',     $o, $opt );
                        $this->bool(   'Pause saat hover',           'gallery_pause',    $o, $opt );
                        ?>
                    </div>
                    <div class="ptprm-mini-card">
                        <strong>Pengaturan Marquee (jika dipilih)</strong>
                        <?php
                        $this->number( 'Durasi loop penuh (detik, 10–120)', 'gallery_speed', $o, $opt, 10, 120 );
                        ?>
                        <p class="ptprm-help" style="margin: 6px 0 0;">Angka lebih besar = gerakan lebih pelan. Marquee juga ikut pengaturan "Pause saat hover" di samping.</p>
                    </div>
                </div>

                <?php $this->gallery_picker( 'Foto galeri (pilih banyak sekaligus)', 'gallery_ids', $o, $opt ); ?>
            </div>

            <!-- BANNER CTA -->
            <div class="ptprm-card">
                <h3>Banner Ajakan <span class="ptprm-tag">posisi: setelah Statistik</span></h3>
                <?php $this->bool( 'Tampilkan section', 'banner_show', $o, $opt ); ?>
                <div class="ptprm-grid-2">
                    <div>
                        <?php
                        $this->t(  'Eyebrow',  'banner_eyebrow',  $o, $opt );
                        $this->t(  'Judul',    'banner_title',    $o, $opt );
                        $this->ta( 'Subjudul', 'banner_subtitle', $o, $opt, 3 );
                        ?>
                    </div>
                    <div>
                        <?php
                        $this->image( 'Gambar latar', 'banner_image', $o, $opt );
                        $this->range( 'Opasitas overlay gelap (0–100%)', 'banner_overlay', $o, $opt, 0, 100 );
                        ?>
                    </div>
                </div>
                <div class="ptprm-grid-2">
                    <div class="ptprm-mini-card">
                        <strong>Tombol Utama</strong>
                        <?php
                        $this->t(  'Label', 'banner_cta_label', $o, $opt );
                        $this->url( 'URL',   'banner_cta_url',   $o, $opt );
                        ?>
                    </div>
                    <div class="ptprm-mini-card">
                        <strong>Tombol Sekunder (opsional)</strong>
                        <?php
                        $this->bool( 'Tampilkan tombol kedua', 'banner_cta2_show', $o, $opt );
                        $this->t(  'Label', 'banner_cta2_label', $o, $opt );
                        $this->url( 'URL (kosongkan = pakai WhatsApp)', 'banner_cta2_url',   $o, $opt );
                        ?>
                    </div>
                </div>
            </div>

            <!-- FAQ -->
            <div class="ptprm-card">
                <h3>Pertanyaan Umum (FAQ) <span class="ptprm-tag">posisi: setelah Kunjungi</span></h3>
                <?php $this->bool( 'Tampilkan section', 'faq_show', $o, $opt ); ?>
                <div class="ptprm-grid-2">
                    <?php
                    $this->t(  'Eyebrow',  'faq_eyebrow',  $o, $opt );
                    $this->t(  'Judul',    'faq_title',    $o, $opt );
                    ?>
                </div>
                <?php $this->ta( 'Subjudul', 'faq_subtitle', $o, $opt, 2 ); ?>

                <p class="ptprm-help">Isi maksimal 10 tanya–jawab. Slot dengan pertanyaan kosong tidak ditampilkan. HTML sederhana diizinkan di jawaban.</p>
                <?php for ( $i = 1; $i <= 10; $i++ ) : ?>
                    <div class="ptprm-mini-card">
                        <strong>Q&amp;A <?php echo $i; ?></strong>
                        <?php
                        $this->t(  'Pertanyaan', "faq_{$i}_q", $o, $opt );
                        $this->ta( 'Jawaban',    "faq_{$i}_a", $o, $opt, 3 );
                        ?>
                    </div>
                <?php endfor; ?>
            </div>
        </section>
        <?php
    }

    private function gallery_picker( $label, $key, $o, $opt ) {
        $val = (string) $this->v( $key, $o );
        $ids = array_filter( array_map( 'intval', explode( ',', $val ) ) );
        ?>
        <div class="ptprm-field ptprm-gallery-field" data-ptprm-gallery>
            <span class="ptprm-label"><?php echo esc_html( $label ); ?></span>
            <input type="hidden" name="<?php echo $this->n( $key, $opt ); ?>" value="<?php echo esc_attr( $val ); ?>" class="ptprm-gallery-value" data-ptprm="<?php echo esc_attr( $key ); ?>">
            <div class="ptprm-gallery-thumbs">
                <?php foreach ( $ids as $id ) :
                    $u = wp_get_attachment_image_url( (int) $id, 'thumbnail' );
                    if ( ! $u ) continue;
                    ?>
                    <span class="ptprm-gallery-thumb" data-id="<?php echo (int) $id; ?>" style="background-image:url('<?php echo esc_url( $u ); ?>');">
                        <button type="button" class="ptprm-gallery-remove" aria-label="Hapus">&times;</button>
                    </span>
                <?php endforeach; ?>
            </div>
            <div class="ptprm-gallery-actions">
                <button type="button" class="button ptprm-gallery-add">Tambah / Pilih foto</button>
                <button type="button" class="button ptprm-gallery-clear">Kosongkan</button>
            </div>
            <p class="ptprm-help">Pilih beberapa foto sekaligus dari Media Library. Anda bisa men-drag untuk mengubah urutan.</p>
        </div>
        <?php
    }

    /* -- PANEL: SUBPAGE -- */

    private function panel_subpage( $o, $opt ) {
        ?>
        <section class="ptprm-panel" id="tab-subpage" data-panel="subpage" hidden>
            <h2>Header Sub-halaman</h2>
            <p class="ptprm-help">Hero ini muncul di semua sub-halaman (Program Kerja, Tarombo, dll.) dengan gaya seragam. Gambar header memakai featured image halaman; kalau tidak ada, pakai pola Gorga di atas warna primer.</p>

            <div class="ptprm-card">
                <?php
                $this->bool( 'Tampilkan hero sub-halaman',    'subpage_hero_show',  $o, $opt );
                $this->bool( 'Tampilkan breadcrumb',          'subpage_breadcrumb', $o, $opt );
                $this->bool( 'Tampilkan ornamen emas',        'subpage_ornament',   $o, $opt );
                $this->bool( 'Tampilkan corak Gorga Batak',   'subpage_gorga',      $o, $opt );
                $this->bool( 'Eyebrow otomatis (= judul kapital)', 'subpage_eyebrow_auto', $o, $opt );
                $this->range( 'Opasitas overlay (0–100%)',    'subpage_overlay',    $o, $opt, 0, 100 );
                $this->ta(    'Intro default (jika halaman tidak punya)', 'subpage_default_intro', $o, $opt, 3 );
                ?>
            </div>
        </section>
        <?php
    }

    /* -- PANEL: FOOTER -- */

    private function panel_footer( $o, $opt ) {
        ?>
        <section class="ptprm-panel" id="tab-footer" data-panel="footer" hidden>
            <h2>Footer</h2>
            <p class="ptprm-help">Footer plugin akan menggantikan footer tema otomatis.</p>

            <div class="ptprm-card">
                <?php
                $this->bool( 'Tampilkan footer plugin', 'footer_show', $o, $opt );
                $this->ta(   'Tagline (paragraf brand)', 'footer_tagline', $o, $opt, 3 );
                ?>
            </div>

            <div class="ptprm-grid-2">
                <div class="ptprm-card">
                    <h3>Kolom Tautan 1</h3>
                    <?php
                    $this->t(  'Judul kolom', 'footer_col1_label', $o, $opt );
                    $this->ta( 'Tautan (satu per baris, format: Teks|URL)', 'footer_col1_links', $o, $opt, 6 );
                    ?>
                </div>
                <div class="ptprm-card">
                    <h3>Kolom Tautan 2</h3>
                    <?php
                    $this->t(  'Judul kolom', 'footer_col2_label', $o, $opt );
                    $this->ta( 'Tautan (satu per baris, format: Teks|URL)', 'footer_col2_links', $o, $opt, 6 );
                    ?>
                </div>
            </div>

            <div class="ptprm-card">
                <?php
                $this->bool( 'Tampilkan ikon sosial media', 'footer_show_social', $o, $opt );
                $this->t( 'Baris copyright (gunakan {year} dan {org})', 'footer_copyright', $o, $opt );
                ?>
            </div>
        </section>
        <?php
    }

    /* ===================================================================== */
    /* FIELDS                                                                */
    /* ===================================================================== */

    private function n( $key, $opt ) { return esc_attr( $opt . '[' . $key . ']' ); }
    private function v( $key, $o )   { return isset( $o[ $key ] ) ? $o[ $key ] : ''; }

    private function t( $label, $key, $o, $opt ) {
        ?>
        <label class="ptprm-field">
            <span class="ptprm-label"><?php echo esc_html( $label ); ?></span>
            <input type="text" class="regular-text" name="<?php echo $this->n( $key, $opt ); ?>" value="<?php echo esc_attr( $this->v( $key, $o ) ); ?>" data-ptprm="<?php echo esc_attr( $key ); ?>">
        </label>
        <?php
    }

    private function ta( $label, $key, $o, $opt, $rows = 4 ) {
        ?>
        <label class="ptprm-field">
            <span class="ptprm-label"><?php echo esc_html( $label ); ?></span>
            <textarea rows="<?php echo (int) $rows; ?>" class="large-text" name="<?php echo $this->n( $key, $opt ); ?>" data-ptprm="<?php echo esc_attr( $key ); ?>"><?php echo esc_textarea( $this->v( $key, $o ) ); ?></textarea>
        </label>
        <?php
    }

    private function url( $label, $key, $o, $opt ) {
        ?>
        <label class="ptprm-field">
            <span class="ptprm-label"><?php echo esc_html( $label ); ?></span>
            <input type="url" class="regular-text" name="<?php echo $this->n( $key, $opt ); ?>" value="<?php echo esc_attr( $this->v( $key, $o ) ); ?>" placeholder="https://" data-ptprm="<?php echo esc_attr( $key ); ?>">
        </label>
        <?php
    }

    private function number( $label, $key, $o, $opt, $min = 0, $max = 1000 ) {
        ?>
        <label class="ptprm-field">
            <span class="ptprm-label"><?php echo esc_html( $label ); ?></span>
            <input type="number" min="<?php echo (int) $min; ?>" max="<?php echo (int) $max; ?>" name="<?php echo $this->n( $key, $opt ); ?>" value="<?php echo esc_attr( $this->v( $key, $o ) ); ?>" data-ptprm="<?php echo esc_attr( $key ); ?>">
        </label>
        <?php
    }

    private function range( $label, $key, $o, $opt, $min = 0, $max = 100 ) {
        $val = (int) $this->v( $key, $o );
        ?>
        <label class="ptprm-field ptprm-range">
            <span class="ptprm-label"><?php echo esc_html( $label ); ?> <span class="ptprm-range-val"><?php echo $val; ?></span></span>
            <input type="range" min="<?php echo (int) $min; ?>" max="<?php echo (int) $max; ?>" name="<?php echo $this->n( $key, $opt ); ?>" value="<?php echo (int) $val; ?>" data-ptprm="<?php echo esc_attr( $key ); ?>">
        </label>
        <?php
    }

    private function color( $label, $key, $o, $opt ) {
        ?>
        <label class="ptprm-field">
            <span class="ptprm-label"><?php echo esc_html( $label ); ?></span>
            <input type="text" class="ptprm-color regular-text" name="<?php echo $this->n( $key, $opt ); ?>" value="<?php echo esc_attr( $this->v( $key, $o ) ); ?>" data-ptprm="<?php echo esc_attr( $key ); ?>" data-default-color="<?php echo esc_attr( $this->v( $key, $o ) ); ?>">
        </label>
        <?php
    }

    private function bool( $label, $key, $o, $opt ) {
        ?>
        <label class="ptprm-switch">
            <input type="checkbox" name="<?php echo $this->n( $key, $opt ); ?>" value="1" <?php checked( 1, (int) $this->v( $key, $o ) ); ?> data-ptprm="<?php echo esc_attr( $key ); ?>">
            <span><?php echo esc_html( $label ); ?></span>
        </label>
        <?php
    }

    private function section_toggle( $key, $label, $o, $opt ) {
        echo '<div class="ptprm-card ptprm-card-toggle">';
        $this->bool( $label, $key, $o, $opt );
        echo '</div>';
    }

    private function select( $label, $key, $o, $opt, $options ) {
        $val = (string) $this->v( $key, $o );
        ?>
        <label class="ptprm-field">
            <span class="ptprm-label"><?php echo esc_html( $label ); ?></span>
            <select name="<?php echo $this->n( $key, $opt ); ?>" data-ptprm="<?php echo esc_attr( $key ); ?>">
                <?php foreach ( $options as $k => $lab ) : ?>
                    <option value="<?php echo esc_attr( $k ); ?>" <?php selected( $val, (string) $k ); ?>><?php echo esc_html( $lab ); ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <?php
    }

    private function image( $label, $key, $o, $opt ) {
        $val = $this->v( $key, $o );
        $url = ptprm_image_url( $val );
        ?>
        <div class="ptprm-field ptprm-image-field">
            <span class="ptprm-label"><?php echo esc_html( $label ); ?></span>
            <div class="ptprm-image-control">
                <div class="ptprm-image-preview" style="<?php echo $url ? 'background-image:url(' . esc_url( $url ) . ');' : ''; ?>"></div>
                <input type="hidden" name="<?php echo $this->n( $key, $opt ); ?>" value="<?php echo esc_attr( $val ); ?>" class="ptprm-image-value" data-ptprm="<?php echo esc_attr( $key ); ?>">
                <button type="button" class="button ptprm-image-pick">Pilih gambar</button>
                <button type="button" class="button ptprm-image-clear">Hapus</button>
            </div>
        </div>
        <?php
    }

    private function category_select( $label, $key, $o, $opt ) {
        $val   = (int) $this->v( $key, $o );
        $terms = get_categories( [ 'hide_empty' => false ] );
        ?>
        <label class="ptprm-field">
            <span class="ptprm-label"><?php echo esc_html( $label ); ?></span>
            <select name="<?php echo $this->n( $key, $opt ); ?>" data-ptprm="<?php echo esc_attr( $key ); ?>">
                <option value="0" <?php selected( 0, $val ); ?>>— semua kategori —</option>
                <?php foreach ( $terms as $term ) : ?>
                    <option value="<?php echo (int) $term->term_id; ?>" <?php selected( $val, (int) $term->term_id ); ?>><?php echo esc_html( $term->name ); ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <?php
    }
}
