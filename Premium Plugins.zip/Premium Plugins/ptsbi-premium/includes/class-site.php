<?php
/**
 * Fitur situs: header sticky, tombol halaman Tarombo.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PTPRM_Site {

    public function __construct() {
        add_filter( 'body_class', [ $this, 'body_class' ] );
        add_filter( 'the_content', [ $this, 'append_tarombo_page_button' ], 20 );
        add_shortcode( 'ptprm_tarombo_button', [ $this, 'shortcode_tarombo_button' ] );
    }

    public function body_class( $classes ) {
        if ( ! is_admin() && ! empty( ptprm_get( 'sticky_header', 1 ) ) ) {
            $classes[] = 'ptprm-sticky-header';
        }
        return $classes;
    }

    public static function is_tarombo_page(): bool {
        if ( ! is_page() ) {
            return false;
        }
        $slug = sanitize_title( ptprm_get( 'tarombo_page_slug', 'tarombo' ) ?: 'tarombo' );
        $post = get_queried_object();
        return $post instanceof WP_Post && $post->post_name === $slug;
    }

    public static function render_tarombo_page_button( $app_url = '' ): string {
        $o = ptprm_options();
        if ( empty( $o['enable_tarombo_page_button'] ) ) {
            return '';
        }
        $app_url = $app_url ?: ( $o['tarombo_app_url'] ?: 'https://tarombo.ptsbi.org' );
        $label   = $o['tarombo_page_button_label'] ?: 'Lihat Tarombo Kami';

        ob_start();
        ?>
        <div class="ptprm-tarombo-cta-wrap">
            <section class="ptprm-tarombo-cta" aria-label="Akses aplikasi Tarombo">
                <div class="ptprm-tarombo-cta__inner">
                    <h2 class="ptprm-tarombo-cta__title">Pohon Tarombo PTSBI</h2>
                    <p class="ptprm-tarombo-cta__lead">Lihat silsilah keluarga besar marga Samosir melalui aplikasi Tarombo.</p>
                    <div class="ptprm-tarombo-cta__actions">
                        <a class="ptprm-cta ptprm-cta-1 ptprm-cta-solid ptprm-cta-size-medium" href="<?php echo esc_url( $app_url ); ?>" target="_blank" rel="noopener noreferrer">
                            <span class="ptprm-cta-label"><?php echo esc_html( $label ); ?></span>
                        </a>
                    </div>
                </div>
            </section>
        </div>
        <?php
        return (string) ob_get_clean();
    }

    public function append_tarombo_page_button( $content ) {
        if ( ! self::is_tarombo_page() ) {
            return $content;
        }
        if ( strpos( $content, 'ptprm-tarombo-cta-wrap' ) !== false ) {
            return $content;
        }
        return $content . self::render_tarombo_page_button();
    }

    public function shortcode_tarombo_button( $atts ) {
        $atts = shortcode_atts(
            [ 'url' => '' ],
            $atts,
            'ptprm_tarombo_button'
        );
        return self::render_tarombo_page_button( $atts['url'] );
    }
}
