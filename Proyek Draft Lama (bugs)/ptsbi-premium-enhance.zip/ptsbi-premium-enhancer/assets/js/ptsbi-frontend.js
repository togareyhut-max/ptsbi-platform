/* global STUDIO_PE */
/* Section Studio - Frontend (v2.0)
 * NON-DESTRUCTIVE: We only tag existing Elementor sections with data attributes
 * and lightly augment buttons / text. We do NOT inject duplicate sections.
 */
(function () {
    'use strict';

    var data = window.STUDIO_PE || {};
    var meta = readMeta();

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    function init() {
        document.body.classList.add('studio-ready');

        // Apply CSS variables from JS settings (for things that can't be done from PHP options).
        applyCssVars();

        // 1. Detect & tag the major sections on the home page.
        if (meta.isHome) {
            tagHomeSections();
        }

        // 2. Hero: ensure 2 CTAs are rendered correctly.
        if (meta.isHome) {
            normaliseHeroCTAs();
        }

        // 3. Convert "Selengkapnya" big gold button into small text link.
        styleSelengkapnya();

        // 4. Translate static English labels (Address:, Mon-Fri ...).
        applyTextReplacements();

        // 5. News card layout tweaks (in addition to CSS).
        if (data.fixes && data.fixes.newsCard) {
            sanitizeNewsCards();
        }

        // 6. Animate stat counters.
        if (data.stats && data.stats.animate) {
            animateCounters();
        }

        // 7. Back-to-top button.
        if (data.showBackToTop) {
            mountBackToTop();
        }
    }

    /* -------------------------------------------------------------------- */
    /* META & helpers                                                        */
    /* -------------------------------------------------------------------- */

    function readMeta() {
        try {
            var el = document.getElementById('studio-pe-page-meta');
            if (el) return JSON.parse(el.textContent.trim());
        } catch (e) {}
        return { isHome: true, isPage: false, slug: '', title: '' };
    }

    function applyCssVars() {
        var root = document.documentElement;
        if (data.news) {
            root.style.setProperty('--studio-news-img-h', (data.news.imgHeight || 200) + 'px');
            root.style.setProperty('--studio-news-overlay', (data.news.overlayOpacity || 0));
        }
        // CTA color overrides (used by .studio-cta variant rules)
        if (data.cta1 && data.cta1.bg) root.style.setProperty('--studio-cta1-bg', data.cta1.bg);
        if (data.cta1 && data.cta1.fg) root.style.setProperty('--studio-cta1-fg', data.cta1.fg);
        if (data.cta2 && data.cta2.bg) root.style.setProperty('--studio-cta2-bg', data.cta2.bg);
        if (data.cta2 && data.cta2.fg) root.style.setProperty('--studio-cta2-fg', data.cta2.fg);
    }

    function textOf(el) {
        return (el && el.textContent ? el.textContent.trim() : '').toLowerCase();
    }

    function findSectionByHeading(needle, level) {
        var headings = document.querySelectorAll(level || 'h1, h2, h3, h4');
        for (var i = 0; i < headings.length; i++) {
            if (textOf(headings[i]).indexOf(needle) !== -1) {
                return closestSection(headings[i]);
            }
        }
        return null;
    }

    function closestSection(el) {
        var n = el;
        while (n && n !== document.body) {
            if (n.tagName === 'SECTION' ||
                (n.classList && (n.classList.contains('elementor-section') ||
                                 n.classList.contains('elementor-top-section') ||
                                 n.classList.contains('elementor-section-wrap')))) {
                return n;
            }
            n = n.parentNode;
        }
        return null;
    }

    function tagSection(node, kind) {
        if (node && !node.hasAttribute('data-studio-section')) {
            node.setAttribute('data-studio-section', kind);
        }
    }

    /* -------------------------------------------------------------------- */
    /* 1. SECTION DETECTION                                                  */
    /* -------------------------------------------------------------------- */

    function tagHomeSections() {
        // Hero = the first Elementor section on the home page.
        var firstSection =
            document.querySelector('.elementor-section.elementor-top-section') ||
            document.querySelector('section.elementor-section') ||
            document.querySelector('main .elementor-element-edit-mode') ||
            document.querySelector('main section');
        if (firstSection) tagSection(firstSection, 'hero');

        // About = section that contains the phrase "Menyatukan Keturunan" or "TENTANG"
        tagSection(findSectionByHeading('menyatukan keturunan', 'h1, h2'), 'about');
        var aboutEyebrow = findEyebrow(['tentang ptsbi', 'tentang kami']);
        if (aboutEyebrow) tagSection(closestSection(aboutEyebrow), 'about');

        // Values = section that contains heading "Nilai-Nilai Kami" / eyebrow text
        tagSection(findSectionByHeading('nilai', 'h1, h2, h3'), 'values');
        var valuesEyebrow = findEyebrow(['nilai-nilai kami']);
        if (valuesEyebrow) tagSection(closestSection(valuesEyebrow), 'values');

        // News = section with The Post Grid OR with the heading "Kegiatan Kami"
        var postGrid = document.querySelector('.rt-tpg-container, .rt-tpg-isotope-buttons, .post-grid-container');
        if (postGrid) tagSection(closestSection(postGrid), 'news');
        tagSection(findSectionByHeading('kegiatan kami', 'h1, h2'), 'news');
        tagSection(findSectionByHeading('kebersamaan dalam setiap momen', 'h1, h2'), 'news');

        // Stats = section that contains digits like 10+/500+ as counter widgets
        var counter = document.querySelector('.elementor-counter, .elementor-counter-number');
        if (counter) tagSection(closestSection(counter), 'stats');
        var statsH = findSectionByHeading('cabang wilayah', 'h2, h3, h4, p, span');
        if (statsH) tagSection(statsH, 'stats');

        // Contact = section with "Kunjungi Kami" or "Address:" or a Google Maps iframe
        tagSection(findSectionByHeading('kunjungi kami', 'h1, h2'), 'contact');
        var iframe = document.querySelector('iframe[src*="google.com/maps"], iframe[src*="maps.google"]');
        if (iframe) tagSection(closestSection(iframe), 'contact');

        // Footer = native theme footer
        var footer = document.querySelector('footer.site-footer, #colophon, footer.elementor-location-footer');
        if (footer) tagSection(footer, 'footer');
    }

    function findEyebrow(targets) {
        var nodes = document.querySelectorAll('span, p, h6, .elementor-heading-title, .elementor-widget-text-editor');
        for (var i = 0; i < nodes.length; i++) {
            var t = textOf(nodes[i]);
            for (var j = 0; j < targets.length; j++) {
                if (t === targets[j]) return nodes[i];
            }
        }
        return null;
    }

    /* -------------------------------------------------------------------- */
    /* 2. HERO CTAs                                                          */
    /* -------------------------------------------------------------------- */

    function normaliseHeroCTAs() {
        var hero = document.querySelector('[data-studio-section="hero"]');
        if (!hero) return;

        // Collect ALL anchor elements inside the hero.
        var anchors = Array.prototype.slice.call(hero.querySelectorAll('a'));

        var primaryEl   = null;
        var secondaryEl = null;

        // Try to find existing CTAs by text.
        anchors.forEach(function (a) {
            var t = textOf(a);
            if (!primaryEl && /bergabung/.test(t)) primaryEl = a;
            else if (!secondaryEl && /(hubungi|kontak|wa\b|whatsapp)/.test(t)) secondaryEl = a;
        });

        // === Primary CTA ===
        if (data.cta1 && data.cta1.show) {
            if (!primaryEl) {
                primaryEl = createCTAAnchor();
                placeCTAInHero(hero, primaryEl);
            }
            decorateCTA(primaryEl, data.cta1, 1);
        } else if (primaryEl) {
            primaryEl.setAttribute('data-studio-cta-hidden', 'true');
        }

        // === Secondary CTA ===
        if (data.cta2 && data.cta2.show) {
            if (!secondaryEl) {
                secondaryEl = createCTAAnchor();
                placeCTAInHero(hero, secondaryEl);
            }
            decorateCTA(secondaryEl, data.cta2, 2);
        } else if (secondaryEl) {
            secondaryEl.setAttribute('data-studio-cta-hidden', 'true');
        }

        // Wrap the CTAs in a .studio-cta-row if they're sitting in distinct widgets.
        wrapHeroCTAs(hero, primaryEl, secondaryEl);
    }

    function createCTAAnchor() {
        var a = document.createElement('a');
        a.setAttribute('data-studio-created', 'true');
        return a;
    }

    function placeCTAInHero(hero, anchor) {
        // Try to place after the first paragraph / text editor widget.
        var container =
            hero.querySelector('.elementor-widget-text-editor') ||
            hero.querySelector('.elementor-widget-button') ||
            hero.querySelector('.elementor-container') ||
            hero;
        var row = container.querySelector('.studio-cta-row');
        if (!row) {
            row = document.createElement('div');
            row.className = 'studio-cta-row';
            container.appendChild(row);
        }
        row.appendChild(anchor);
    }

    function wrapHeroCTAs(hero, p, s) {
        if (!p && !s) return;
        var row = hero.querySelector('.studio-cta-row');
        if (!row) {
            row = document.createElement('div');
            row.className = 'studio-cta-row';
            // Insert near the primary one's grandparent.
            var anchor = p || s;
            if (anchor && anchor.parentNode) {
                anchor.parentNode.appendChild(row);
            }
        }
        if (p && !row.contains(p)) row.appendChild(p);
        if (s && !row.contains(s)) row.appendChild(s);
    }

    function decorateCTA(el, cfg, idx) {
        if (!el) return;

        // Set href.
        if (cfg.url) {
            el.setAttribute('href', cfg.url);
            if (isExternal(cfg.url)) {
                el.setAttribute('target', '_blank');
                el.setAttribute('rel', 'noopener noreferrer');
            }
        } else if (!el.getAttribute('href')) {
            el.setAttribute('href', '#');
        }

        // Set inner content (icon + label).
        var iconHtml = cfg.icon ? svgIcon(cfg.icon) : '';
        var labelHtml = '<span class="studio-cta-label">' + escapeHtml(cfg.label || '') + '</span>';
        el.innerHTML = iconHtml + labelHtml;

        // Classes.
        el.classList.add('studio-cta');
        el.classList.remove('studio-cta-filled', 'studio-cta-outline', 'studio-cta-ghost', 'studio-cta-ghost-light', 'studio-cta-ghost-dark');
        el.classList.add('studio-cta-' + (cfg.style || 'filled'));

        // Inline style overrides for color.
        if (cfg.bg) el.style.setProperty('--studio-cta-bg', cfg.bg);
        if (cfg.fg) el.style.setProperty('--studio-cta-fg', cfg.fg);

        // Remove conflicting elementor button classes (without nuking the element).
        ['elementor-button-link', 'elementor-button', 'elementor-button-primary', 'elementor-size-md',
         'elementor-size-sm', 'elementor-size-lg', 'elementor-animation-grow', 'elementor-button-icon'].forEach(function (c) {
            el.classList.remove(c);
        });
    }

    function isExternal(url) {
        try {
            return (new URL(url, window.location.origin)).origin !== window.location.origin;
        } catch (e) {
            return false;
        }
    }

    /* -------------------------------------------------------------------- */
    /* 3. SELENGKAPNYA -> small link                                         */
    /* -------------------------------------------------------------------- */

    function styleSelengkapnya() {
        var anchors = document.querySelectorAll('a');
        for (var i = 0; i < anchors.length; i++) {
            var a = anchors[i];
            if (/selengkapnya/i.test(textOf(a))) {
                a.classList.add('studio-link-cta');
                // Remove elementor button classes so it stops looking like a CTA.
                ['elementor-button-link', 'elementor-button', 'elementor-button-primary', 'elementor-size-md',
                 'elementor-size-sm', 'elementor-size-lg', 'elementor-animation-grow'].forEach(function (c) {
                    a.classList.remove(c);
                });
                break;
            }
        }
    }

    /* -------------------------------------------------------------------- */
    /* 4. TEXT REPLACEMENTS                                                  */
    /* -------------------------------------------------------------------- */

    function applyTextReplacements() {
        var rules = data.textRules || [];
        if (!rules.length) return;
        walkText(document.body, function (node) {
            var t = node.nodeValue;
            for (var i = 0; i < rules.length; i++) {
                if (t.indexOf(rules[i].find) !== -1) {
                    t = t.split(rules[i].find).join(rules[i].replace);
                }
            }
            if (t !== node.nodeValue) node.nodeValue = t;
        });
    }

    function walkText(root, cb) {
        var skip = { SCRIPT: 1, STYLE: 1, TEXTAREA: 1, INPUT: 1, NOSCRIPT: 1 };
        var stack = [root];
        while (stack.length) {
            var n = stack.pop();
            if (!n || !n.childNodes) continue;
            for (var i = 0; i < n.childNodes.length; i++) {
                var c = n.childNodes[i];
                if (c.nodeType === 3) {
                    cb(c);
                } else if (c.nodeType === 1 && !skip[c.tagName]) {
                    stack.push(c);
                }
            }
        }
    }

    /* -------------------------------------------------------------------- */
    /* 5. NEWS CARDS sanitize                                                */
    /* -------------------------------------------------------------------- */

    function sanitizeNewsCards() {
        // Force overlay layer (if rendered) to user-configured opacity.
        var newsSec = document.querySelector('[data-studio-section="news"]');
        if (!newsSec) return;

        var overlays = newsSec.querySelectorAll('.overlay, .post-image .overlay, .rt-img-holder .overlay');
        overlays.forEach(function (o) {
            o.style.background = 'rgba(0, 0, 0, ' + ((data.news.overlayOpacity || 0) / 100) + ')';
        });

        // Some Post Grid templates absolute-position the title over image.
        // Move it after the image element.
        var holders = newsSec.querySelectorAll('.rt-holder, .post-grid-item');
        holders.forEach(function (holder) {
            var img = holder.querySelector('.rt-img-holder, .post-image, img');
            var detail = holder.querySelector('.rt-detail, .post-content');
            if (img && detail && detail.compareDocumentPosition(img) & Node.DOCUMENT_POSITION_FOLLOWING) {
                holder.insertBefore(detail, img.nextSibling);
            }
        });
    }

    /* -------------------------------------------------------------------- */
    /* 6. COUNTERS                                                           */
    /* -------------------------------------------------------------------- */

    function animateCounters() {
        if (!('IntersectionObserver' in window)) return;

        var statsSec = document.querySelector('[data-studio-section="stats"]');
        if (!statsSec) return;

        var candidates = statsSec.querySelectorAll('h2, h3, .elementor-counter-number, .elementor-heading-title');
        var targets = [];
        for (var i = 0; i < candidates.length; i++) {
            var raw = (candidates[i].textContent || '').trim();
            if (/^\d+\+?$/.test(raw) || /^\d+/.test(raw)) {
                targets.push(candidates[i]);
            }
        }

        var io = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (!entry.isIntersecting) return;
                var el = entry.target;
                var raw = (el.textContent || '').trim();
                var m = raw.match(/(\d+)(.*)/);
                if (!m) return;
                var num = parseInt(m[1], 10);
                var suffix = m[2] || '';
                var start = 0;
                var duration = 1200;
                var startTime = null;
                function step(ts) {
                    if (!startTime) startTime = ts;
                    var p = Math.min(1, (ts - startTime) / duration);
                    var eased = 1 - Math.pow(1 - p, 3);
                    el.textContent = Math.floor(start + (num - start) * eased) + suffix;
                    if (p < 1) requestAnimationFrame(step);
                }
                requestAnimationFrame(step);
                io.unobserve(el);
            });
        }, { threshold: 0.4 });

        targets.forEach(function (el) { io.observe(el); });
    }

    /* -------------------------------------------------------------------- */
    /* 7. BACK TO TOP                                                        */
    /* -------------------------------------------------------------------- */

    function mountBackToTop() {
        if (document.querySelector('.studio-totop')) return; // already
        var btn = document.createElement('button');
        btn.className = 'studio-totop';
        btn.setAttribute('aria-label', 'Kembali ke atas');
        btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="18 15 12 9 6 15"/></svg>';
        btn.addEventListener('click', function () {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
        document.body.appendChild(btn);
        window.addEventListener('scroll', function () {
            btn.classList.toggle('is-visible', (window.scrollY || window.pageYOffset) > 360);
        }, { passive: true });
    }

    /* -------------------------------------------------------------------- */
    /* UTIL                                                                  */
    /* -------------------------------------------------------------------- */

    function escapeHtml(s) {
        return (s + '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    function svgIcon(name) {
        var icons = {
            whatsapp: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M.057 24l1.687-6.163a11.867 11.867 0 0 1-1.587-5.946C.16 5.335 5.495 0 12.05 0a11.82 11.82 0 0 1 8.413 3.488 11.82 11.82 0 0 1 3.48 8.414c-.003 6.554-5.338 11.892-11.893 11.892a11.9 11.9 0 0 1-5.688-1.45L.057 24zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.89 9.884a9.86 9.86 0 0 0 1.51 5.26l-.999 3.648 3.979-1.607zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.521.149-.174.198-.298.297-.497.099-.198.05-.372-.025-.521-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51l-.57-.01c-.198 0-.521.074-.793.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.227 1.36.195 1.872.118.571-.085 1.758-.719 2.006-1.413.247-.694.247-1.289.173-1.413z"/></svg>',
            phone:    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>',
            mail:     '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>',
            arrow:    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>'
        };
        return icons[name] || '';
    }
})();
