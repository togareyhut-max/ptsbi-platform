<?php
/**
 * Enqueue frontend assets and inject dynamic CSS (built from settings).
 * Priority 999 ensures we come AFTER Astra & Elementor so our base stylesheet
 * can be safely overridden by Elementor inline styles.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PTSBI_PE_Assets {

    public function __construct() {
        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue' ], 999 );
    }

    public function enqueue() {
        if ( ! ptsbi_pe_is_enabled() ) {
            return;
        }

        $opts = ptsbi_pe_get_options();

        // Load Google Fonts only for fonts that are actually selected.
        $font_keys = array_unique( array_filter( [
            $opts['font_heading'],
            $opts['font_body'],
        ], function ( $k ) { return $k && $k !== 'theme-default'; } ) );

        // Add per-section fonts too.
        foreach ( array_keys( ptsbi_pe_section_types() ) as $slug ) {
            $hf = $opts[ "sec_{$slug}_heading_font" ] ?? '';
            $bf = $opts[ "sec_{$slug}_body_font" ] ?? '';
            if ( $hf && $hf !== 'theme-default' ) $font_keys[] = $hf;
            if ( $bf && $bf !== 'theme-default' ) $font_keys[] = $bf;
        }
        $font_keys = array_unique( $font_keys );

        if ( $font_keys ) {
            $parts = [];
            foreach ( $font_keys as $f ) {
                $parts[] = str_replace( ' ', '+', $f ) . ':wght@300;400;500;600;700;800';
            }
            $url = 'https://fonts.googleapis.com/css2?family=' . implode( '&family=', $parts ) . '&display=swap';
            wp_enqueue_style( 'studio-fonts', $url, [], null );
        }

        wp_enqueue_style(
            'studio-frontend',
            PTSBI_PE_URL . 'assets/css/ptsbi-frontend.css',
            $font_keys ? [ 'studio-fonts' ] : [],
            PTSBI_PE_VERSION
        );

        // Inline CSS built from settings.
        $builder = new PTSBI_PE_CSS_Builder();
        $inline = $builder->build();
        if ( $inline ) {
            wp_add_inline_style( 'studio-frontend', $inline );
        }

        wp_enqueue_script(
            'studio-frontend',
            PTSBI_PE_URL . 'assets/js/ptsbi-frontend.js',
            [],
            PTSBI_PE_VERSION,
            true
        );

        $cta1_url = $opts['cta1_url'];
        $cta2_url = $opts['cta2_url'];
        if ( ! $cta2_url && (int) $opts['cta2_use_whatsapp'] === 1 && $opts['whatsapp_number'] ) {
            $cta2_url = ptsbi_pe_wa_link( $opts['whatsapp_number'] );
        }

        $replacer = new PTSBI_PE_Text_Replacer();

        wp_localize_script( 'studio-frontend', 'STUDIO_PE', [
            'home'        => home_url( '/' ),
            'pluginUrl'   => PTSBI_PE_URL,
            'fixes'       => [
                'heroContrast'  => (int) $opts['fix_hero_contrast'],
                'heroOverlay'   => (int) $opts['fix_hero_overlay'],
                'dupSections'   => (int) $opts['fix_dup_sections'],
                'doubleFooter'  => (int) $opts['fix_double_footer'],
                'newsCard'      => (int) $opts['fix_news_card'],
            ],
            'cta1'        => [
                'show'   => (int) $opts['cta1_show'],
                'label'  => $opts['cta1_label'],
                'url'    => $cta1_url,
                'style'  => $opts['cta1_style'],
                'bg'     => $opts['cta1_color_bg'],
                'fg'     => $opts['cta1_color_text'],
            ],
            'cta2'        => [
                'show'   => (int) $opts['cta2_show'],
                'label'  => $opts['cta2_label'],
                'url'    => $cta2_url,
                'style'  => $opts['cta2_style'],
                'icon'   => $opts['cta2_icon'],
                'bg'     => $opts['cta2_color_bg'],
                'fg'     => $opts['cta2_color_text'],
            ],
            'news'        => [
                'imgHeight'      => (int) $opts['news_image_height'],
                'overlayOpacity' => (int) $opts['news_overlay_opacity'],
            ],
            'stats'       => [
                'animate' => (int) $opts['stats_animate'],
            ],
            'showBackToTop' => (int) $opts['show_back_to_top'],
            'textRules'   => $replacer->rules(),
        ] );
    }
}
