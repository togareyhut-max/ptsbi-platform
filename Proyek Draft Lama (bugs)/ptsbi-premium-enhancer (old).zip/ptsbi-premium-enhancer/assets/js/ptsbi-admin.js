/* PTSBI Premium Enhancer - Admin JS */
(function ($) {
    'use strict';

    $(function () {
        if ($.fn && $.fn.wpColorPicker) {
            $('.ptsbi-pe-color').wpColorPicker({
                change: function () {},
                clear:  function () {}
            });
        }
    });
})(window.jQuery);
