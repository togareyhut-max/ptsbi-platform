/* global PTSBI_PE */
(function () {
    'use strict';

    var data = window.PTSBI_PE || {};
    var meta = readMeta();

    document.addEventListener('DOMContentLoaded', init);

    function init() {
        document.body.classList.add('ptsbi-pe-ready');

        applyHeroSingleCTA();
        scrollHeaderEffect();
        enhanceValuesSection();
        enhanceStatsSection();
        injectVisitSection();
        injectPremiumFooter();

        if (meta.isPage && !meta.isHome) {
            injectSubHero();
            decorateSubpage();
        }

        smoothScrollAnchors();
        animateCounters();

        if (data.showBackToTop) {
            mountBackToTop();
        }
    }

    /* -----------------------------------------------------------------------
     * Read meta JSON injected by PHP (page slug, title, isHome, etc.)
     * --------------------------------------------------------------------- */
    function readMeta() {
        try {
            var el = document.getElementById('ptsbi-pe-page-meta');
            if (el) {
                return JSON.parse(el.textContent.trim());
            }
        } catch (e) {}
        return { isHome: true, isPage: false, slug: '', title: '' };
    }

    /* -----------------------------------------------------------------------
     * 1. HERO: keep only ONE CTA on homepage; replace its label & URL
     * --------------------------------------------------------------------- */
    function applyHeroSingleCTA() {
        if (!meta.isHome) return;

        var allLinks = Array.prototype.slice.call(
            document.querySelectorAll('a, .elementor-button-link, .elementor-button')
        );

        var primary = null;
        var secondary = null;
        var selengkapnya = null;

        allLinks.forEach(function (a) {
            var txt = (a.textContent || '').trim().toLowerCase();
            if (!primary && /bergabung/.test(txt)) {
                primary = a;
            } else if (!secondary && /hubungi/.test(txt)) {
                secondary = a;
            } else if (!selengkapnya && /selengkapnya/.test(txt)) {
                selengkapnya = a;
            }
        });

        if (secondary) {
            // Mark and hide the second CTA in hero.
            secondary.setAttribute('data-ptsbi-hide', 'true');
            var wrap = secondary.closest('.elementor-button-wrapper, .elementor-widget-button, .ast-button-wrapper');
            if (wrap) {
                wrap.classList.add('ptsbi-pe-hidden-cta');
            } else {
                secondary.classList.add('ptsbi-pe-hidden-cta');
            }
        }

        if (primary) {
            if (data.ctaLabel) {
                // Replace inner text safely without nuking icons.
                var span = primary.querySelector('.elementor-button-text') || primary;
                span.textContent = data.ctaLabel;
            }
            if (data.ctaUrl) {
                primary.setAttribute('href', data.ctaUrl);
                primary.setAttribute('target', isExternal(data.ctaUrl) ? '_blank' : '_self');
                if (isExternal(data.ctaUrl)) primary.setAttribute('rel', 'noopener noreferrer');
            }
        }

        if (selengkapnya) {
            // Make "Selengkapnya" a refined link instead of a bold CTA so the
            // hero "Bergabung Sekarang" remains the only true CTA.
            selengkapnya.classList.add('ptsbi-pe-link-cta');
            var wrap2 = selengkapnya.closest('.elementor-button-wrapper, .elementor-widget-button, .wp-block-button');
            if (wrap2) wrap2.classList.add('ptsbi-pe-link-cta-wrap');
        }
    }

    function isExternal(url) {
        try {
            var u = new URL(url, window.location.origin);
            return u.origin !== window.location.origin;
        } catch (e) {
            return false;
        }
    }

    /* -----------------------------------------------------------------------
     * 2. Header scroll effect (glass on scroll)
     * --------------------------------------------------------------------- */
    function scrollHeaderEffect() {
        var lastY = 0;
        var ticking = false;

        function onScroll() {
            var y = window.scrollY || window.pageYOffset;
            if (!ticking) {
                window.requestAnimationFrame(function () {
                    document.body.classList.toggle('ptsbi-scrolled', y > 24);
                    lastY = y;
                    ticking = false;
                });
                ticking = true;
            }
        }
        window.addEventListener('scroll', onScroll, { passive: true });
        onScroll();
    }

    /* -----------------------------------------------------------------------
     * 3. VALUE CARDS: detect "Kebersamaan / Kasih / Pelestarian Budaya / Saling Mendukung"
     *    and wrap them into a premium grid with icons.
     * --------------------------------------------------------------------- */
    function enhanceValuesSection() {
        if (!meta.isHome) return;

        var headings = Array.prototype.slice.call(document.querySelectorAll('h2, h3'));
        var titleEl = null;
        headings.forEach(function (h) {
            var t = (h.textContent || '').trim().toLowerCase();
            if (!titleEl && (/nilai[- ]nilai kami/.test(t))) {
                titleEl = h;
            }
        });
        if (!titleEl) return;

        // Detect the 4 cards by their headings.
        var wanted = ['kebersamaan', 'kasih', 'pelestarian budaya', 'saling mendukung'];
        var cardHeadings = [];
        headings.forEach(function (h) {
            var t = (h.textContent || '').trim().toLowerCase();
            if (wanted.indexOf(t) !== -1) cardHeadings.push(h);
        });
        if (cardHeadings.length < 4) return;

        var icons = {
            'kebersamaan':        svgIcon('users'),
            'kasih':              svgIcon('heart'),
            'pelestarian budaya': svgIcon('feather'),
            'saling mendukung':   svgIcon('hands')
        };

        // Build replacement section.
        var section = document.createElement('section');
        section.className = 'ptsbi-values';

        var eyebrow = document.createElement('span');
        eyebrow.className = 'ptsbi-eyebrow';
        eyebrow.textContent = 'NILAI-NILAI KAMI';

        var h2 = document.createElement('h2');
        h2.className = 'ptsbi-values-title';
        h2.textContent = 'Fondasi yang Kami Pegang Bersama';

        var sub = document.createElement('p');
        sub.className = 'ptsbi-values-subtitle';
        sub.textContent = 'Empat nilai inti yang menuntun setiap langkah PTSBI dalam menjaga kebersamaan keluarga besar Toga Samosir.';

        var grid = document.createElement('div');
        grid.className = 'ptsbi-values-grid';

        cardHeadings.forEach(function (h) {
            var name = (h.textContent || '').trim();
            var key = name.toLowerCase();
            var descEl = nextParagraph(h);
            var desc = descEl ? (descEl.textContent || '').trim() : '';

            var card = document.createElement('article');
            card.className = 'ptsbi-value-card';
            card.innerHTML =
                '<div class="ptsbi-value-icon">' + (icons[key] || svgIcon('star')) + '</div>' +
                '<h3>' + escapeHtml(name) + '</h3>' +
                '<p>' + escapeHtml(desc) + '</p>';
            grid.appendChild(card);
        });

        section.appendChild(eyebrow);
        section.appendChild(h2);
        section.appendChild(sub);
        section.appendChild(grid);

        // Insert before the first card heading's section container.
        var targetSection = findCommonAncestorSection(cardHeadings, titleEl);
        if (targetSection && targetSection.parentNode) {
            targetSection.parentNode.insertBefore(section, targetSection);
            targetSection.style.display = 'none';
        } else if (titleEl.parentNode) {
            titleEl.parentNode.insertBefore(section, titleEl);
            titleEl.style.display = 'none';
        }
    }

    function nextParagraph(node) {
        var n = node.nextElementSibling;
        while (n) {
            if (n.tagName && n.tagName.toLowerCase() === 'p') return n;
            n = n.nextElementSibling;
        }
        // Sometimes the description sits inside next wrapper.
        var p = node.parentNode && node.parentNode.querySelector('p');
        return p;
    }

    function findCommonAncestorSection(nodes, titleNode) {
        var candidates = [titleNode].concat(nodes);
        var first = candidates[0];
        var parent = first;
        while (parent && parent !== document.body) {
            var ok = candidates.every(function (n) { return parent.contains(n); });
            if (ok && (parent.tagName === 'SECTION' || parent.classList.contains('elementor-section') || parent.classList.contains('elementor-top-section'))) {
                return parent;
            }
            parent = parent.parentNode;
        }
        return null;
    }

    /* -----------------------------------------------------------------------
     * 4. STATS section
     * --------------------------------------------------------------------- */
    function enhanceStatsSection() {
        if (!meta.isHome) return;

        var labels = ['cabang wilayah', 'kepala keluarga', 'anggota', 'tahun kebersamaan'];
        var headings = Array.prototype.slice.call(document.querySelectorAll('h2, h3, .elementor-counter-title, .elementor-counter-number'));
        var found = headings.filter(function (h) {
            var t = (h.textContent || '').trim().toLowerCase();
            return labels.indexOf(t) !== -1;
        });
        if (found.length < 3) return; // tolerate missing one

        var stats = data.stats || {};
        var section = document.createElement('section');
        section.className = 'ptsbi-stats';

        var grid = document.createElement('div');
        grid.className = 'ptsbi-stats-grid';

        [
            { num: stats.cabang  || '10+',   label: 'Cabang Wilayah' },
            { num: stats.kk      || '500+',  label: 'Kepala Keluarga' },
            { num: stats.anggota || '1000+', label: 'Anggota' },
            { num: stats.tahun   || '20+',   label: 'Tahun Kebersamaan' }
        ].forEach(function (s) {
            var item = document.createElement('div');
            item.className = 'ptsbi-stat';
            item.innerHTML =
                '<div class="ptsbi-stat-number" data-target="' + escapeAttr(s.num) + '">' + escapeHtml(s.num) + '</div>' +
                '<div class="ptsbi-stat-label">' + escapeHtml(s.label) + '</div>';
            grid.appendChild(item);
        });

        section.appendChild(grid);

        var targetSection = findCommonAncestorSection(found, found[0]);
        if (targetSection && targetSection.parentNode) {
            targetSection.parentNode.insertBefore(section, targetSection);
            targetSection.style.display = 'none';
        }
    }

    /* -----------------------------------------------------------------------
     * 5. Visit Us / Contact pre-footer
     * --------------------------------------------------------------------- */
    function injectVisitSection() {
        if (!meta.isHome) return;

        var headings = Array.prototype.slice.call(document.querySelectorAll('h2, h3, h4'));
        var visit = null;
        headings.forEach(function (h) {
            var t = (h.textContent || '').trim().toLowerCase();
            if (!visit && /kunjungi kami/.test(t)) visit = h;
        });
        if (!visit) return;

        // Try to extract address text.
        var section = visit.closest('section, .elementor-section, .elementor-top-section') || visit.parentNode;
        var addressText = '';
        if (section) {
            var ps = section.querySelectorAll('p');
            if (ps && ps.length) {
                addressText = (ps[ps.length - 1].textContent || '').trim();
            }
        }
        if (!addressText) {
            addressText = 'Ruko Harapan Mulya Regency Blok BG 1-09, Jl. Harapan Mulya Regency, Setia Mulya, Tarumajaya, Kab. Bekasi, Jawa Barat.';
        }

        var newSection = document.createElement('section');
        newSection.className = 'ptsbi-visit';
        newSection.innerHTML =
            '<div class="ptsbi-visit-inner">' +
                '<div class="ptsbi-visit-text">' +
                    '<span class="ptsbi-eyebrow" style="color:var(--ptsbi-accent)">KUNJUNGI KAMI</span>' +
                    '<h2>Mari Terhubung &amp; Bertemu Bersama Keluarga Besar PTSBI</h2>' +
                    '<p>Kami terbuka untuk silaturahmi, koordinasi kegiatan, maupun masukan dari seluruh anggota keluarga besar Toga Samosir Boru Bere Ibebere.</p>' +
                '</div>' +
                '<div class="ptsbi-visit-card">' +
                    '<div class="ptsbi-visit-line">' + svgIcon('pin') + '<span><strong style="color:var(--ptsbi-primary)">Alamat:</strong><br>' + escapeHtml(addressText) + '</span></div>' +
                    '<div class="ptsbi-visit-line">' + svgIcon('clock') + '<span><strong style="color:var(--ptsbi-primary)">Jam Operasional:</strong><br>Senin&ndash;Jumat, 09.00&ndash;17.00 WIB</span></div>' +
                    (data.whatsapp
                        ? '<div class="ptsbi-visit-line">' + svgIcon('whatsapp') + '<span><strong style="color:var(--ptsbi-primary)">WhatsApp:</strong><br><a href="https://wa.me/' + encodeURIComponent(data.whatsapp.replace(/\D/g, '')) + '" target="_blank" rel="noopener">' + escapeHtml(data.whatsapp) + '</a></span></div>'
                        : '') +
                '</div>' +
            '</div>';

        if (section && section.parentNode) {
            section.parentNode.insertBefore(newSection, section);
            section.style.display = 'none';
        }
    }

    /* -----------------------------------------------------------------------
     * 6. SUB-PAGE HERO
     * --------------------------------------------------------------------- */
    function injectSubHero() {
        if (!data.showSubpageHero) return;
        if (!meta.slug) return;

        // Pages that should use a photo background (per user preference).
        var photoSlugs = { 'tarombo': true, 'tentang-kami': true };

        var eyebrows = {
            'program-kerja':        'PROGRAM KERJA',
            'informasi-kegiatan':   'INFORMASI KEGIATAN',
            'tarombo':              'WARISAN BUDAYA',
            'struktur-organisasi':  'STRUKTUR ORGANISASI',
            'tentang-kami':         'PROFIL ORGANISASI'
        };
        var subs = {
            'program-kerja':        'Pedoman kegiatan dan langkah strategis PTSBI dalam mempererat hubungan kekeluargaan, melestarikan adat, dan memberi manfaat bagi seluruh anggota.',
            'informasi-kegiatan':   'Beragam kegiatan rutin keluarga besar PTSBI: pesta bona taon, pertemuan, kegiatan sosial, adat & budaya, hingga program generasi muda.',
            'tarombo':              'Tarombo adalah silsilah keturunan dalam budaya Batak. Halaman ini menjelaskan makna, fungsi, dan komitmen PTSBI terhadap pelestariannya.',
            'struktur-organisasi':  'Susunan kepengurusan dan bidang/seksi kegiatan PTSBI yang menopang keberlangsungan organisasi.',
            'tentang-kami':         'Punguan Toga Samosir Boru Bere Ibebere — wadah kebersamaan keturunan Toga Samosir, baik laki-laki, boru, bere, maupun ibebere.'
        };

        var hero = document.createElement('section');
        hero.className = 'ptsbi-subhero ' + (photoSlugs[meta.slug] ? '-photo' : '-pattern');

        if (photoSlugs[meta.slug]) {
            // Use a soft built-in gradient overlay; admin can later set a featured image.
            var thumb = document.querySelector('meta[property="og:image"]');
            if (thumb && thumb.content) {
                hero.style.backgroundImage = "url('" + thumb.content + "')";
            }
        }

        var inner = document.createElement('div');
        inner.className = 'ptsbi-subhero-inner';

        inner.innerHTML =
            '<nav class="ptsbi-breadcrumb" aria-label="Breadcrumb">' +
                '<a href="' + escapeAttr(data.home || '/') + '">Beranda</a>' +
                '<span class="sep">/</span>' +
                '<span>' + escapeHtml(meta.title || '') + '</span>' +
            '</nav>' +
            '<span class="ptsbi-subhero-eyebrow">' + escapeHtml(eyebrows[meta.slug] || (meta.title || '').toUpperCase()) + '</span>' +
            '<h1>' + escapeHtml(meta.title || '') + '</h1>' +
            '<p class="ptsbi-subhero-sub">' + escapeHtml(subs[meta.slug] || '') + '</p>' +
            '<div class="ptsbi-subhero-ornament" aria-hidden="true">' + svgOrnament() + '</div>';

        hero.appendChild(inner);

        // Insert hero before main content area.
        var mountTarget =
            document.querySelector('#main') ||
            document.querySelector('main') ||
            document.querySelector('.site-content') ||
            document.querySelector('.ast-container');

        if (mountTarget && mountTarget.parentNode) {
            mountTarget.parentNode.insertBefore(hero, mountTarget);
            document.body.classList.add('ptsbi-subhero-injected');
        }
    }

    /* -----------------------------------------------------------------------
     * 7. Decorate sub-page content (numbered cards for "1. xxx" headings)
     * --------------------------------------------------------------------- */
    function decorateSubpage() {
        var content = document.querySelector('.entry-content') || document.querySelector('main .entry-content');
        if (!content) return;

        var nodes = Array.prototype.slice.call(content.querySelectorAll('h2, h3'));
        nodes.forEach(function (h) {
            var txt = (h.textContent || '').trim();
            var m = txt.match(/^(\d+)\.\s*(.+)/);
            if (!m) return;

            // Gather siblings until next heading of same level.
            var card = document.createElement('div');
            card.className = 'ptsbi-numbered-card';
            card.setAttribute('data-num', m[1]);

            var newHeading = document.createElement(h.tagName.toLowerCase());
            newHeading.textContent = m[2];
            newHeading.style.marginTop = '8px';

            card.appendChild(newHeading);

            var node = h.nextSibling;
            var collected = [];
            while (node) {
                if (node.nodeType === 1) {
                    var tag = node.tagName.toLowerCase();
                    if (tag === h.tagName.toLowerCase() || tag === 'hr') break;
                    if (tag === 'h2' || tag === 'h3') break;
                }
                collected.push(node);
                node = node.nextSibling;
            }
            collected.forEach(function (n) {
                if (n.parentNode) n.parentNode.removeChild(n);
                card.appendChild(n);
            });

            h.parentNode.insertBefore(card, h);
            h.parentNode.removeChild(h);
        });

        // Tarombo: insert illustration after first paragraph.
        if (meta.slug === 'tarombo') {
            var firstP = content.querySelector('p');
            if (firstP) {
                var fig = document.createElement('figure');
                fig.innerHTML =
                    '<img class="ptsbi-tarombo-illustration" alt="Ilustrasi Tarombo - silsilah keturunan Toga Samosir" src="' + escapeAttr(data.pluginUrl + 'assets/img/tarombo-illustration.svg') + '">' +
                    '<figcaption class="ptsbi-tarombo-caption">Ilustrasi sederhana tarombo (silsilah keturunan) sebagai gambaran visual.</figcaption>';
                firstP.parentNode.insertBefore(fig, firstP.nextSibling);
            }
        }

        // Struktur Organisasi: wrap numbered cards into a 2-column grid.
        if (meta.slug === 'struktur-organisasi') {
            var cards = content.querySelectorAll('.ptsbi-numbered-card');
            if (cards.length) {
                var grid = document.createElement('div');
                grid.className = 'ptsbi-struktur-grid';
                cards[0].parentNode.insertBefore(grid, cards[0]);
                cards.forEach(function (c) { grid.appendChild(c); });
            }
        }
    }

    /* -----------------------------------------------------------------------
     * 8. Smooth scroll for in-page anchors
     * --------------------------------------------------------------------- */
    function smoothScrollAnchors() {
        document.addEventListener('click', function (e) {
            var a = e.target.closest && e.target.closest('a[href^="#"]');
            if (!a) return;
            var hash = a.getAttribute('href');
            if (!hash || hash === '#') return;
            var target = document.querySelector(hash);
            if (!target) return;
            e.preventDefault();
            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
    }

    /* -----------------------------------------------------------------------
     * 9. Counter animation for stat numbers
     * --------------------------------------------------------------------- */
    function animateCounters() {
        if (!('IntersectionObserver' in window)) return;
        var els = document.querySelectorAll('.ptsbi-stat-number');
        if (!els.length) return;

        var io = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (!entry.isIntersecting) return;
                var el = entry.target;
                var raw = el.getAttribute('data-target') || el.textContent;
                var match = raw.match(/(\d+)(.*)/);
                if (!match) return;
                var num = parseInt(match[1], 10);
                var suffix = match[2] || '';
                var start = 0;
                var duration = 1400;
                var startTime = null;

                function step(ts) {
                    if (!startTime) startTime = ts;
                    var p = Math.min(1, (ts - startTime) / duration);
                    var eased = 1 - Math.pow(1 - p, 3);
                    var current = Math.floor(start + (num - start) * eased);
                    el.textContent = current + suffix;
                    if (p < 1) window.requestAnimationFrame(step);
                }
                window.requestAnimationFrame(step);
                io.unobserve(el);
            });
        }, { threshold: 0.4 });

        els.forEach(function (el) { io.observe(el); });
    }

    /* -----------------------------------------------------------------------
     * 10. Premium footer (replaces Astra footer)
     * --------------------------------------------------------------------- */
    function injectPremiumFooter() {
        var footerEl = document.createElement('footer');
        footerEl.className = 'ptsbi-footer';
        footerEl.setAttribute('role', 'contentinfo');

        var social = data.social || {};
        var socialHtml = '';
        if (social.facebook)  socialHtml += '<a href="' + escapeAttr(social.facebook)  + '" target="_blank" rel="noopener" aria-label="Facebook">' + svgIcon('facebook')  + '</a>';
        if (social.instagram) socialHtml += '<a href="' + escapeAttr(social.instagram) + '" target="_blank" rel="noopener" aria-label="Instagram">' + svgIcon('instagram') + '</a>';
        if (social.youtube)   socialHtml += '<a href="' + escapeAttr(social.youtube)   + '" target="_blank" rel="noopener" aria-label="YouTube">'   + svgIcon('youtube')   + '</a>';
        if (social.tiktok)    socialHtml += '<a href="' + escapeAttr(social.tiktok)    + '" target="_blank" rel="noopener" aria-label="TikTok">'    + svgIcon('tiktok')    + '</a>';
        if (data.whatsapp) {
            socialHtml += '<a href="https://wa.me/' + encodeURIComponent(data.whatsapp.replace(/\D/g, '')) + '" target="_blank" rel="noopener" aria-label="WhatsApp">' + svgIcon('whatsapp') + '</a>';
        }

        var year = new Date().getFullYear();

        footerEl.innerHTML =
            '<div class="ptsbi-footer-grid">' +
                '<div class="ptsbi-footer-brand">' +
                    '<h4>PTSBI</h4>' +
                    '<p>Punguan Toga Samosir Boru Bere Ibebere. Wadah kebersamaan keluarga besar Toga Samosir untuk mempererat persaudaraan, melestarikan budaya, dan saling mendukung.</p>' +
                    (socialHtml ? '<div class="ptsbi-footer-social">' + socialHtml + '</div>' : '') +
                '</div>' +
                '<div>' +
                    '<h4>Tautan Cepat</h4>' +
                    '<ul>' +
                        '<li><a href="' + escapeAttr(data.home) + '">Beranda</a></li>' +
                        '<li><a href="' + escapeAttr(data.home) + 'tentang-kami/">Tentang Kami</a></li>' +
                        '<li><a href="' + escapeAttr(data.home) + 'program-kerja/">Program Kerja</a></li>' +
                        '<li><a href="' + escapeAttr(data.home) + 'informasi-kegiatan/">Informasi Kegiatan</a></li>' +
                    '</ul>' +
                '</div>' +
                '<div>' +
                    '<h4>Organisasi</h4>' +
                    '<ul>' +
                        '<li><a href="' + escapeAttr(data.home) + 'tarombo/">Tarombo</a></li>' +
                        '<li><a href="' + escapeAttr(data.home) + 'struktur-organisasi/">Struktur Organisasi</a></li>' +
                    '</ul>' +
                '</div>' +
                '<div>' +
                    '<h4>Kontak</h4>' +
                    '<p>Ruko Harapan Mulya Regency Blok BG 1-09<br>Jl. Harapan Mulya Regency, Setia Mulya<br>Tarumajaya, Kab. Bekasi, Jawa Barat</p>' +
                    '<p>Senin&ndash;Jumat, 09.00&ndash;17.00 WIB</p>' +
                    (data.whatsapp ? '<p><a href="https://wa.me/' + encodeURIComponent(data.whatsapp.replace(/\D/g, '')) + '" target="_blank" rel="noopener">WhatsApp: ' + escapeHtml(data.whatsapp) + '</a></p>' : '') +
                '</div>' +
            '</div>' +
            '<div class="ptsbi-footer-bottom">' +
                '&copy; ' + year + ' PTSBI &mdash; Punguan Toga Samosir Boru Bere Ibebere. Seluruh hak cipta dilindungi.' +
            '</div>';

        document.body.appendChild(footerEl);
        document.body.classList.add('ptsbi-footer-injected');
    }

    /* -----------------------------------------------------------------------
     * 11. Back-to-top button
     * --------------------------------------------------------------------- */
    function mountBackToTop() {
        var btn = document.createElement('button');
        btn.className = 'ptsbi-pe-totop';
        btn.setAttribute('aria-label', 'Kembali ke atas');
        btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="18 15 12 9 6 15"></polyline></svg>';
        btn.addEventListener('click', function () {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
        document.body.appendChild(btn);

        window.addEventListener('scroll', function () {
            var y = window.scrollY || window.pageYOffset;
            btn.classList.toggle('is-visible', y > 360);
        }, { passive: true });
    }

    /* -----------------------------------------------------------------------
     * Utility: HTML escaping & SVG icon set
     * --------------------------------------------------------------------- */
    function escapeHtml(s) {
        return (s + '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }
    function escapeAttr(s) { return escapeHtml(s); }

    function svgIcon(name) {
        var icons = {
            'users':    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
            'heart':    '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>',
            'feather':  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20.24 12.24a6 6 0 0 0-8.49-8.49L5 10.5V19h8.5z"/><line x1="16" y1="8" x2="2" y2="22"/><line x1="17.5" y1="15" x2="9" y2="15"/></svg>',
            'hands':    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 11V6a2 2 0 1 1 4 0v5"/><path d="M13 11V4a2 2 0 1 1 4 0v8"/><path d="M17 12v-2a2 2 0 1 1 4 0v5a7 7 0 0 1-7 7H8a7 7 0 0 1-7-7v-2a2 2 0 1 1 4 0v2"/></svg>',
            'star':     '<svg viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>',
            'pin':      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>',
            'clock':    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',
            'whatsapp': '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M.057 24l1.687-6.163a11.867 11.867 0 0 1-1.587-5.946C.16 5.335 5.495 0 12.05 0a11.82 11.82 0 0 1 8.413 3.488 11.82 11.82 0 0 1 3.48 8.414c-.003 6.554-5.338 11.892-11.893 11.892a11.9 11.9 0 0 1-5.688-1.45L.057 24zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.89 9.884a9.86 9.86 0 0 0 1.51 5.26l-.999 3.648 3.979-1.607zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.521.149-.174.198-.298.297-.497.099-.198.05-.372-.025-.521-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51l-.57-.01c-.198 0-.521.074-.793.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.227 1.36.195 1.872.118.571-.085 1.758-.719 2.006-1.413.247-.694.247-1.289.173-1.413z"/></svg>',
            'facebook': '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M22.675 0H1.325C.593 0 0 .593 0 1.325v21.351C0 23.407.593 24 1.325 24H12.82V14.706h-3.131v-3.622h3.131V8.413c0-3.1 1.894-4.788 4.659-4.788 1.325 0 2.464.099 2.795.143v3.24h-1.918c-1.504 0-1.796.715-1.796 1.762v2.31h3.587l-.467 3.622h-3.12V24h6.116c.731 0 1.324-.593 1.324-1.324V1.325C24 .593 23.407 0 22.675 0z"/></svg>',
            'instagram':'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 1.366.062 2.633.336 3.608 1.311.975.975 1.249 2.242 1.311 3.608.058 1.266.07 1.646.07 4.85s-.012 3.584-.07 4.85c-.062 1.366-.336 2.633-1.311 3.608-.975.975-2.242 1.249-3.608 1.311-1.266.058-1.646.07-4.85.07s-3.584-.012-4.85-.07c-1.366-.062-2.633-.336-3.608-1.311-.975-.975-1.249-2.242-1.311-3.608-.058-1.266-.07-1.646-.07-4.85s.012-3.584.07-4.85c.062-1.366.336-2.633 1.311-3.608.975-.975 2.242-1.249 3.608-1.311 1.266-.058 1.646-.07 4.85-.07zM12 0C8.741 0 8.332.014 7.052.072 5.775.13 4.602.405 3.635 1.372 2.668 2.339 2.393 3.512 2.335 4.789 2.277 6.069 2.263 6.478 2.263 9.737c0 3.259.014 3.668.072 4.948.058 1.277.333 2.45 1.3 3.417.967.967 2.14 1.242 3.417 1.3 1.28.058 1.689.072 4.948.072s3.668-.014 4.948-.072c1.277-.058 2.45-.333 3.417-1.3.967-.967 1.242-2.14 1.3-3.417.058-1.28.072-1.689.072-4.948s-.014-3.668-.072-4.948c-.058-1.277-.333-2.45-1.3-3.417C19.398.405 18.225.13 16.948.072 15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 1 0 0 12.324 6.162 6.162 0 0 0 0-12.324zM12 16a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm6.406-11.845a1.44 1.44 0 1 0 0 2.881 1.44 1.44 0 0 0 0-2.881z"/></svg>',
            'youtube':  '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>',
            'tiktok':   '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5.8 20.1a6.34 6.34 0 0 0 10.86-4.43V8.62a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.84 4.84 0 0 1-1.84-.05z"/></svg>'
        };
        return icons[name] || '';
    }

    function svgOrnament() {
        return '<svg viewBox="0 0 200 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid meet">' +
            '<line x1="0" y1="12" x2="80" y2="12" stroke="#C9A44C" stroke-width="1.2"/>' +
            '<line x1="120" y1="12" x2="200" y2="12" stroke="#C9A44C" stroke-width="1.2"/>' +
            '<path d="M85 12 L100 4 L115 12 L100 20 Z" fill="none" stroke="#C9A44C" stroke-width="1.4"/>' +
            '<circle cx="100" cy="12" r="2" fill="#E0BC65"/>' +
            '</svg>';
    }
})();
