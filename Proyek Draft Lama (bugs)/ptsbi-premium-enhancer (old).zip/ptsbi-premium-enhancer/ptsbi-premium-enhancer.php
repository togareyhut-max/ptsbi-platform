<?php
/**
 * Plugin Name:       PTSBI Premium Enhancer
 * Plugin URI:        https://ptsbi.org/
 * Description:       Memberikan tampilan premium & elegan, responsif penuh (PC/Tab/HP), dan menyempurnakan semua sub-halaman PTSBI. Hero hanya menampilkan satu CTA "Bergabung Sekarang". Halaman Tarombo tetap sebagai penjelasan saja.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            PTSBI Tech
 * Author URI:        https://ptsbi.org/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       ptsbi-premium-enhancer
 * Domain Path:       /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'PTSBI_PE_VERSION', '1.0.0' );
define( 'PTSBI_PE_FILE', __FILE__ );
define( 'PTSBI_PE_DIR', plugin_dir_path( __FILE__ ) );
define( 'PTSBI_PE_URL', plugin_dir_url( __FILE__ ) );
define( 'PTSBI_PE_OPTION', 'ptsbi_pe_options' );

require_once PTSBI_PE_DIR . 'includes/helpers.php';
require_once PTSBI_PE_DIR . 'includes/class-settings.php';
require_once PTSBI_PE_DIR . 'includes/class-assets.php';
require_once PTSBI_PE_DIR . 'includes/class-frontend.php';
require_once PTSBI_PE_DIR . 'includes/class-plugin.php';

register_activation_hook( __FILE__, [ 'PTSBI_PE_Plugin', 'on_activate' ] );
register_deactivation_hook( __FILE__, [ 'PTSBI_PE_Plugin', 'on_deactivate' ] );

add_action( 'plugins_loaded', function () {
    PTSBI_PE_Plugin::instance();
} );
