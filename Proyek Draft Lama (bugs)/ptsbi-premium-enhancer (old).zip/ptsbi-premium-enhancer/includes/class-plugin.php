<?php
/**
 * Main bootstrap class.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PTSBI_PE_Plugin {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        new PTSBI_PE_Settings();
        new PTSBI_PE_Assets();
        new PTSBI_PE_Frontend();
    }

    public static function on_activate() {
        $existing = get_option( PTSBI_PE_OPTION );
        if ( false === $existing ) {
            add_option( PTSBI_PE_OPTION, ptsbi_pe_defaults() );
        }
    }

    public static function on_deactivate() {
        // Intentionally keep options so users do not lose configuration.
    }
}
