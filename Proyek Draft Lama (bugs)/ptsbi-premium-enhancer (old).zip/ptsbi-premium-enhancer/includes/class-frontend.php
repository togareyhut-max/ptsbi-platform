<?php
/**
 * Frontend body-class injection, page-specific data attributes,
 * and footer markup printer (used by JS to construct premium footer & back-to-top).
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PTSBI_PE_Frontend {

    public function __construct() {
        add_filter( 'body_class', [ $this, 'body_class' ] );
        add_action( 'wp_footer',  [ $this, 'print_footer_markup' ], 5 );
    }

    public function body_class( $classes ) {
        if ( ! ptsbi_pe_is_enabled() ) {
            return $classes;
        }
        $classes[] = 'ptsbi-pe-active';

        if ( is_front_page() || is_home() ) {
            $classes[] = 'ptsbi-pe-home';
        }

        if ( is_page() ) {
            $slug = get_post_field( 'post_name', get_queried_object_id() );
            if ( $slug ) {
                $classes[] = 'ptsbi-pe-page-' . sanitize_html_class( $slug );
            }
        }

        return $classes;
    }

    /**
     * Print a hidden data island used by the JS to build the premium footer,
     * back-to-top button and sub-page hero banners on the client without
     * fighting Astra's template hooks.
     */
    public function print_footer_markup() {
        if ( ! ptsbi_pe_is_enabled() ) {
            return;
        }

        $opts = ptsbi_pe_get_options();

        $page_meta = [
            'isHome'  => ( is_front_page() || is_home() ),
            'isPage'  => is_page(),
            'slug'    => is_page() ? get_post_field( 'post_name', get_queried_object_id() ) : '',
            'title'   => is_page() ? get_the_title( get_queried_object_id() ) : '',
        ];

        ?>
        <script type="application/json" id="ptsbi-pe-page-meta">
            <?php echo wp_json_encode( $page_meta ); ?>
        </script>
        <?php
    }
}
