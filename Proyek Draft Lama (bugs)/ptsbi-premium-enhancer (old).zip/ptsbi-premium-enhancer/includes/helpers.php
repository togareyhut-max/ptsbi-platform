<?php
/**
 * Helper utilities for PTSBI Premium Enhancer.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function ptsbi_pe_defaults() {
    return [
        'enabled'           => 1,
        'cta_url'           => '',
        'cta_label'         => 'Bergabung Sekarang',
        'whatsapp_number'   => '',
        'fb_url'            => '',
        'ig_url'            => '',
        'yt_url'            => '',
        'tt_url'            => '',
        'stat_cabang'       => '10+',
        'stat_kk'           => '500+',
        'stat_anggota'      => '1000+',
        'stat_tahun'        => '20+',
        'color_primary'     => '#0A1F3D',
        'color_accent'      => '#C9A44C',
        'show_subpage_hero' => 1,
        'show_back_to_top'  => 1,
    ];
}

function ptsbi_pe_get_options() {
    $saved = get_option( PTSBI_PE_OPTION, [] );
    if ( ! is_array( $saved ) ) {
        $saved = [];
    }
    return wp_parse_args( $saved, ptsbi_pe_defaults() );
}

function ptsbi_pe_get( $key, $default = '' ) {
    $opts = ptsbi_pe_get_options();
    return isset( $opts[ $key ] ) ? $opts[ $key ] : $default;
}

function ptsbi_pe_is_enabled() {
    return (int) ptsbi_pe_get( 'enabled', 1 ) === 1;
}
