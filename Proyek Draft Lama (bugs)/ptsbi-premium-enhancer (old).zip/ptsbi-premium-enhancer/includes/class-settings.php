<?php
/**
 * Admin settings page.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PTSBI_PE_Settings {

    const PAGE_SLUG  = 'ptsbi-premium-enhancer';
    const GROUP_SLUG = 'ptsbi_pe_group';

    public function __construct() {
        add_action( 'admin_menu',         [ $this, 'register_menu' ] );
        add_action( 'admin_init',         [ $this, 'register_settings' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue' ] );
        add_filter( 'plugin_action_links_' . plugin_basename( PTSBI_PE_FILE ), [ $this, 'action_links' ] );
    }

    public function register_menu() {
        add_options_page(
            __( 'PTSBI Enhancer', 'ptsbi-premium-enhancer' ),
            __( 'PTSBI Enhancer', 'ptsbi-premium-enhancer' ),
            'manage_options',
            self::PAGE_SLUG,
            [ $this, 'render_page' ]
        );
    }

    public function register_settings() {
        register_setting( self::GROUP_SLUG, PTSBI_PE_OPTION, [
            'type'              => 'array',
            'sanitize_callback' => [ $this, 'sanitize' ],
            'default'           => ptsbi_pe_defaults(),
        ] );
    }

    public function sanitize( $input ) {
        $defaults = ptsbi_pe_defaults();
        $clean    = [];

        $clean['enabled']           = ! empty( $input['enabled'] ) ? 1 : 0;
        $clean['show_subpage_hero'] = ! empty( $input['show_subpage_hero'] ) ? 1 : 0;
        $clean['show_back_to_top']  = ! empty( $input['show_back_to_top'] ) ? 1 : 0;

        $clean['cta_url']         = isset( $input['cta_url'] ) ? esc_url_raw( trim( $input['cta_url'] ) ) : '';
        $clean['cta_label']       = isset( $input['cta_label'] ) ? sanitize_text_field( $input['cta_label'] ) : $defaults['cta_label'];
        $clean['whatsapp_number'] = isset( $input['whatsapp_number'] ) ? preg_replace( '/[^0-9+]/', '', $input['whatsapp_number'] ) : '';

        foreach ( [ 'fb_url', 'ig_url', 'yt_url', 'tt_url' ] as $k ) {
            $clean[ $k ] = isset( $input[ $k ] ) ? esc_url_raw( trim( $input[ $k ] ) ) : '';
        }

        foreach ( [ 'stat_cabang', 'stat_kk', 'stat_anggota', 'stat_tahun' ] as $k ) {
            $clean[ $k ] = isset( $input[ $k ] ) ? sanitize_text_field( $input[ $k ] ) : $defaults[ $k ];
        }

        foreach ( [ 'color_primary', 'color_accent' ] as $k ) {
            $val = isset( $input[ $k ] ) ? sanitize_hex_color( $input[ $k ] ) : '';
            $clean[ $k ] = $val ? $val : $defaults[ $k ];
        }

        return $clean;
    }

    public function enqueue( $hook ) {
        if ( 'settings_page_' . self::PAGE_SLUG !== $hook ) {
            return;
        }
        wp_enqueue_style( 'wp-color-picker' );
        wp_enqueue_script( 'wp-color-picker' );
        wp_enqueue_style(
            'ptsbi-pe-admin',
            PTSBI_PE_URL . 'assets/css/ptsbi-admin.css',
            [],
            PTSBI_PE_VERSION
        );
        wp_enqueue_script(
            'ptsbi-pe-admin',
            PTSBI_PE_URL . 'assets/js/ptsbi-admin.js',
            [ 'jquery', 'wp-color-picker' ],
            PTSBI_PE_VERSION,
            true
        );
    }

    public function action_links( $links ) {
        $url        = admin_url( 'options-general.php?page=' . self::PAGE_SLUG );
        $settings   = '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Settings', 'ptsbi-premium-enhancer' ) . '</a>';
        array_unshift( $links, $settings );
        return $links;
    }

    public function render_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        $o = ptsbi_pe_get_options();
        ?>
        <div class="wrap ptsbi-pe-wrap">
            <h1><span class="ptsbi-pe-logo">PTSBI</span> Premium Enhancer</h1>
            <p class="ptsbi-pe-lead">
                Atur tampilan premium situs PTSBI di sini. Semua perubahan langsung diterapkan ke front-end tanpa
                mengubah tema atau Elementor. Anda bisa menonaktifkan plugin kapan saja.
            </p>

            <form method="post" action="options.php" class="ptsbi-pe-form">
                <?php settings_fields( self::GROUP_SLUG ); ?>

                <div class="ptsbi-pe-cards">

                    <div class="ptsbi-pe-card">
                        <h2>Status</h2>
                        <label class="ptsbi-pe-switch">
                            <input type="checkbox" name="<?php echo esc_attr( PTSBI_PE_OPTION ); ?>[enabled]" value="1" <?php checked( 1, $o['enabled'] ); ?>>
                            <span>Aktifkan tampilan premium</span>
                        </label>
                        <p class="description">Matikan untuk kembali ke tampilan asli tema Astra/Elementor.</p>

                        <label class="ptsbi-pe-switch" style="margin-top:14px">
                            <input type="checkbox" name="<?php echo esc_attr( PTSBI_PE_OPTION ); ?>[show_subpage_hero]" value="1" <?php checked( 1, $o['show_subpage_hero'] ); ?>>
                            <span>Tampilkan hero banner di sub-halaman</span>
                        </label>

                        <label class="ptsbi-pe-switch" style="margin-top:8px">
                            <input type="checkbox" name="<?php echo esc_attr( PTSBI_PE_OPTION ); ?>[show_back_to_top]" value="1" <?php checked( 1, $o['show_back_to_top'] ); ?>>
                            <span>Tampilkan tombol "Kembali ke atas"</span>
                        </label>
                    </div>

                    <div class="ptsbi-pe-card">
                        <h2>Tombol CTA Hero</h2>
                        <p class="description">Hanya satu CTA yang ditampilkan di hero Beranda.</p>

                        <label>Label tombol</label>
                        <input type="text" name="<?php echo esc_attr( PTSBI_PE_OPTION ); ?>[cta_label]" value="<?php echo esc_attr( $o['cta_label'] ); ?>" placeholder="Bergabung Sekarang">

                        <label style="margin-top:12px">URL tujuan tombol</label>
                        <input type="url" name="<?php echo esc_attr( PTSBI_PE_OPTION ); ?>[cta_url]" value="<?php echo esc_attr( $o['cta_url'] ); ?>" placeholder="https://...">
                        <p class="description">Bisa berupa link WhatsApp (https://wa.me/62xxx), Google Form, atau halaman pendaftaran.</p>

                        <label style="margin-top:12px">Nomor WhatsApp (opsional, dipakai di footer)</label>
                        <input type="text" name="<?php echo esc_attr( PTSBI_PE_OPTION ); ?>[whatsapp_number]" value="<?php echo esc_attr( $o['whatsapp_number'] ); ?>" placeholder="+62 812 3456 7890">
                    </div>

                    <div class="ptsbi-pe-card">
                        <h2>Statistik Beranda</h2>
                        <div class="ptsbi-pe-grid-2">
                            <div>
                                <label>Cabang Wilayah</label>
                                <input type="text" name="<?php echo esc_attr( PTSBI_PE_OPTION ); ?>[stat_cabang]" value="<?php echo esc_attr( $o['stat_cabang'] ); ?>">
                            </div>
                            <div>
                                <label>Kepala Keluarga</label>
                                <input type="text" name="<?php echo esc_attr( PTSBI_PE_OPTION ); ?>[stat_kk]" value="<?php echo esc_attr( $o['stat_kk'] ); ?>">
                            </div>
                            <div>
                                <label>Anggota</label>
                                <input type="text" name="<?php echo esc_attr( PTSBI_PE_OPTION ); ?>[stat_anggota]" value="<?php echo esc_attr( $o['stat_anggota'] ); ?>">
                            </div>
                            <div>
                                <label>Tahun Kebersamaan</label>
                                <input type="text" name="<?php echo esc_attr( PTSBI_PE_OPTION ); ?>[stat_tahun]" value="<?php echo esc_attr( $o['stat_tahun'] ); ?>">
                            </div>
                        </div>
                    </div>

                    <div class="ptsbi-pe-card">
                        <h2>Sosial Media (Footer)</h2>
                        <label>Facebook URL</label>
                        <input type="url" name="<?php echo esc_attr( PTSBI_PE_OPTION ); ?>[fb_url]" value="<?php echo esc_attr( $o['fb_url'] ); ?>" placeholder="https://facebook.com/...">
                        <label style="margin-top:10px">Instagram URL</label>
                        <input type="url" name="<?php echo esc_attr( PTSBI_PE_OPTION ); ?>[ig_url]" value="<?php echo esc_attr( $o['ig_url'] ); ?>" placeholder="https://instagram.com/...">
                        <label style="margin-top:10px">YouTube URL</label>
                        <input type="url" name="<?php echo esc_attr( PTSBI_PE_OPTION ); ?>[yt_url]" value="<?php echo esc_attr( $o['yt_url'] ); ?>" placeholder="https://youtube.com/@...">
                        <label style="margin-top:10px">TikTok URL</label>
                        <input type="url" name="<?php echo esc_attr( PTSBI_PE_OPTION ); ?>[tt_url]" value="<?php echo esc_attr( $o['tt_url'] ); ?>" placeholder="https://tiktok.com/@...">
                    </div>

                    <div class="ptsbi-pe-card">
                        <h2>Warna</h2>
                        <p class="description">Default: Navy + Emas Antik (elegan klasik).</p>
                        <label>Warna Primer (Navy)</label>
                        <input type="text" class="ptsbi-pe-color" name="<?php echo esc_attr( PTSBI_PE_OPTION ); ?>[color_primary]" value="<?php echo esc_attr( $o['color_primary'] ); ?>" data-default="#0A1F3D">
                        <label style="margin-top:12px">Warna Aksen (Emas)</label>
                        <input type="text" class="ptsbi-pe-color" name="<?php echo esc_attr( PTSBI_PE_OPTION ); ?>[color_accent]" value="<?php echo esc_attr( $o['color_accent'] ); ?>" data-default="#C9A44C">
                    </div>
                </div>

                <?php submit_button( 'Simpan Perubahan', 'primary ptsbi-pe-save' ); ?>
            </form>

            <div class="ptsbi-pe-tips">
                <h3>Tips singkat</h3>
                <ul>
                    <li>Setelah menyimpan, buka <a href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank">halaman beranda</a> di tab baru.</li>
                    <li>Jika tampilan belum berubah, tekan <kbd>Ctrl</kbd>+<kbd>F5</kbd> untuk muat ulang tanpa cache.</li>
                    <li>Plugin ini tidak menyentuh konten halaman Anda, sehingga aman dinonaktifkan kapan saja.</li>
                </ul>
            </div>
        </div>
        <?php
    }
}
