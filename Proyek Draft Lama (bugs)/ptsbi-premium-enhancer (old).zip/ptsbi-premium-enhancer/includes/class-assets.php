<?php
/**
 * Enqueue frontend assets and inject dynamic CSS variables.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PTSBI_PE_Assets {

    public function __construct() {
        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue' ], 100 );
    }

    public function enqueue() {
        if ( ! ptsbi_pe_is_enabled() ) {
            return;
        }

        // Google Fonts - load efficiently with display=swap.
        wp_enqueue_style(
            'ptsbi-pe-fonts',
            'https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;600;700;800&family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap',
            [],
            null
        );

        wp_enqueue_style(
            'ptsbi-pe-frontend',
            PTSBI_PE_URL . 'assets/css/ptsbi-frontend.css',
            [ 'ptsbi-pe-fonts' ],
            PTSBI_PE_VERSION
        );

        $opts = ptsbi_pe_get_options();
        $primary = $opts['color_primary'] ?: '#0A1F3D';
        $accent  = $opts['color_accent']  ?: '#C9A44C';

        $inline_css = sprintf(
            ':root{--ptsbi-primary:%s;--ptsbi-primary-2:%s;--ptsbi-accent:%s;--ptsbi-accent-2:%s;}',
            esc_html( $primary ),
            esc_html( $this->shade( $primary, -15 ) ),
            esc_html( $accent ),
            esc_html( $this->shade( $accent, 20 ) )
        );
        wp_add_inline_style( 'ptsbi-pe-frontend', $inline_css );

        wp_enqueue_script(
            'ptsbi-pe-frontend',
            PTSBI_PE_URL . 'assets/js/ptsbi-frontend.js',
            [],
            PTSBI_PE_VERSION,
            true
        );

        wp_localize_script( 'ptsbi-pe-frontend', 'PTSBI_PE', [
            'home'            => home_url( '/' ),
            'pluginUrl'       => PTSBI_PE_URL,
            'ctaUrl'          => $opts['cta_url'],
            'ctaLabel'        => $opts['cta_label'] ?: 'Bergabung Sekarang',
            'whatsapp'        => $opts['whatsapp_number'],
            'social'          => [
                'facebook'  => $opts['fb_url'],
                'instagram' => $opts['ig_url'],
                'youtube'   => $opts['yt_url'],
                'tiktok'    => $opts['tt_url'],
            ],
            'stats'           => [
                'cabang'   => $opts['stat_cabang'],
                'kk'       => $opts['stat_kk'],
                'anggota'  => $opts['stat_anggota'],
                'tahun'    => $opts['stat_tahun'],
            ],
            'showSubpageHero' => (int) $opts['show_subpage_hero'],
            'showBackToTop'   => (int) $opts['show_back_to_top'],
        ] );
    }

    /**
     * Lighten/darken a hex color by a percent (-100..100).
     */
    private function shade( $hex, $percent ) {
        $hex = ltrim( $hex, '#' );
        if ( strlen( $hex ) === 3 ) {
            $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
        }
        if ( strlen( $hex ) !== 6 ) {
            return '#' . $hex;
        }
        $r = hexdec( substr( $hex, 0, 2 ) );
        $g = hexdec( substr( $hex, 2, 2 ) );
        $b = hexdec( substr( $hex, 4, 2 ) );
        $adj = function ( $c ) use ( $percent ) {
            $c = $c + ( $c * ( $percent / 100 ) );
            return max( 0, min( 255, (int) round( $c ) ) );
        };
        return sprintf( '#%02X%02X%02X', $adj( $r ), $adj( $g ), $adj( $b ) );
    }
}
