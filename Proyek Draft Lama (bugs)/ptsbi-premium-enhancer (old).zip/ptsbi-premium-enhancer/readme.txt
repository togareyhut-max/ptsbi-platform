=== PTSBI Premium Enhancer ===
Contributors:      ptsbitech
Tags:              ptsbi, premium, elegant, responsive, astra, elementor
Requires at least: 5.8
Tested up to:      6.7
Requires PHP:      7.4
Stable tag:        1.0.0
License:           GPLv2 or later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

Memberikan tampilan premium, elegan, dan responsif penuh untuk situs PTSBI.ORG. Dapat dinonaktifkan kapan saja tanpa kehilangan konten.

== Description ==

PTSBI Premium Enhancer adalah plugin khusus untuk situs Punguan Toga Samosir Boru Bere Ibebere (https://ptsbi.org). Plugin ini secara otomatis:

* Menyempurnakan tampilan Beranda menjadi elegan dengan palet Navy + Emas Antik.
* Menyisakan hanya satu CTA utama di Hero ("Bergabung Sekarang"), tombol lain disembunyikan.
* Menambahkan hero banner premium di setiap sub-halaman (Program Kerja, Informasi Kegiatan, Tarombo, Struktur Organisasi, Tentang Kami).
* Mempercantik tampilan daftar bullet, statistik beranda (dengan animasi count-up), kartu nilai-nilai, kartu berita.
* Membuat footer premium dengan 4 kolom (Brand, Tautan Cepat, Organisasi, Kontak) + ikon sosial media.
* Menjamin tampilan responsif sempurna di PC, tablet/iPad, dan HP.
* Menambah tombol "Kembali ke atas" yang elegan.
* Halaman setting di Settings > PTSBI Enhancer untuk kustomisasi URL CTA, nomor WhatsApp, sosial media, statistik, dan warna.

Plugin tidak mengubah konten halaman Anda. Semua perubahan visual dilakukan melalui CSS dan sedikit JavaScript pada saat halaman dimuat.

== Installation ==

1. Login ke WP Admin Anda.
2. Buka **Plugins > Add New > Upload Plugin**.
3. Pilih file `ptsbi-premium-enhancer.zip` yang Anda terima, lalu klik **Install Now**.
4. Klik **Activate Plugin**.
5. Buka **Settings > PTSBI Enhancer** dan isi pengaturan sesuai kebutuhan (URL tombol Bergabung Sekarang, nomor WhatsApp, sosial media).
6. Buka beranda website untuk melihat hasilnya. Tekan `Ctrl + F5` jika perlu menyegarkan cache.

== Frequently Asked Questions ==

= Apakah plugin ini mengubah konten halaman saya? =
Tidak. Plugin hanya menambahkan tampilan visual (CSS & JS). Konten halaman Anda tidak diubah. Jika plugin dinonaktifkan, tampilan akan kembali seperti semula.

= Apakah saya bisa mengubah warna? =
Bisa. Buka Settings > PTSBI Enhancer dan ubah Warna Primer (Navy) atau Warna Aksen (Emas).

= Apakah aman untuk Astra & Elementor? =
Ya. Plugin dirancang khusus agar kompatibel dengan tema Astra dan Elementor yang sudah Anda gunakan.

== Changelog ==

= 1.0.0 =
* Rilis pertama. Tampilan premium beranda, hero banner sub-halaman, footer premium, halaman setting admin.

== Upgrade Notice ==

= 1.0.0 =
Rilis pertama plugin.
