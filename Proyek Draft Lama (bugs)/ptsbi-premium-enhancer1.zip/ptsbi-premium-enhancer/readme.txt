=== Section Studio — Elementor Companion ===
Contributors:      sectionstudio
Tags:              elementor, sections, premium, responsive, customizer
Requires at least: 5.8
Tested up to:      6.7
Requires PHP:      7.4
Stable tag:        2.0.0
License:           GPLv2 or later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

Companion plugin yang non-destructive untuk Elementor. Memberikan panel setting per-section (warna, tipografi, spacing) untuk Beranda website organisasi, tanpa melawan setting Elementor Anda.

== Description ==

Section Studio menambahkan satu menu **Section Studio** di sidebar WP Admin yang memungkinkan Anda mengatur tampilan section utama Beranda (Hero, Tentang, Nilai-Nilai, Berita, Statistik, Kontak, Footer) dengan kontrol:

* Warna background per section
* Tipografi heading & body (font, ukuran, warna) per section, dengan ukuran terpisah desktop & mobile
* Padding atas & bawah per section (desktop & mobile)
* 2 tombol CTA di Hero yang bisa di-konfigurasi sendiri (Bergabung Sekarang + Hubungi WA)
* Perbaikan otomatis (toggle): kontras Hero, overlay Hero, label "Address/Mon-Fri", duplikasi section, kartu berita

Plugin ini dirancang **non-destructive**: setting di Elementor selalu menang. Plugin hanya menambah lapisan styling lewat CSS variables dan kelas data-attribute. Anda bisa terus customize via Elementor secara normal.

Dirancang generic agar bisa digunakan untuk website organisasi mana pun, tidak hardcoded ke satu domain.

== Installation ==

1. Login ke WP Admin.
2. Plugins → Add New → Upload Plugin → pilih ZIP `ptsbi-premium-enhancer.zip` → Install Now → Activate.
3. Klik menu **Section Studio** di sidebar WP Admin.
4. Atur tab Global terlebih dulu (warna brand, font default, nomor WhatsApp), lalu tab Hero (URL tombol Bergabung & Hubungi WA), lalu tab per-section lainnya sesuai kebutuhan.
5. Klik **Simpan Perubahan**. Buka beranda → tekan Ctrl+F5 jika perlu refresh.

== Changelog ==

= 2.0.0 =
* Rewrite total: arsitektur non-destructive, panel setting per-section, 2 CTA Hero, perbaikan duplikasi v1.

= 1.0.0 =
* Rilis pertama.
