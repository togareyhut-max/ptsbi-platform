<?php
/**
 * Plugin Name:       Premium Organization
 * Plugin URI:        https://wordpress.org/
 * Description:       Plugin premium untuk situs organisasi: Beranda lengkap (Hero, CTA, section, footer) dan sub-halaman seragam. Universal — pengaturan per website (tidak terkunci domain tertentu).
 * Version:           1.9.9
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Premium Plugins
 * License:           GPL-2.0-or-later
 * Text Domain:       ptsbi-premium
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'PTPRM_VERSION', '1.9.9' );
define( 'PTPRM_FILE',    __FILE__ );
define( 'PTPRM_DIR',     plugin_dir_path( __FILE__ ) );
define( 'PTPRM_URL',     plugin_dir_url( __FILE__ ) );
define( 'PTPRM_OPTION',  'ptprm_options' );

require_once PTPRM_DIR . 'includes/helpers.php';
require_once PTPRM_DIR . 'includes/class-bootstrap.php';
require_once PTPRM_DIR . 'includes/class-pages.php';
require_once PTPRM_DIR . 'includes/demo-content.php';
require_once PTPRM_DIR . 'includes/class-assets.php';
require_once PTPRM_DIR . 'includes/class-renderer.php';
require_once PTPRM_DIR . 'includes/class-home.php';
require_once PTPRM_DIR . 'includes/class-subpage.php';
require_once PTPRM_DIR . 'includes/class-site.php';
require_once PTPRM_DIR . 'includes/class-header.php';
require_once PTPRM_DIR . 'includes/class-settings.php';

register_activation_hook( __FILE__, [ 'PTPRM_Bootstrap', 'activate' ] );

add_action( 'plugins_loaded', function () {
    PTPRM_Bootstrap::init();
    new PTPRM_Assets();
    new PTPRM_Home();
    new PTPRM_Subpage();
    new PTPRM_Site();
    new PTPRM_Header();
    if ( is_admin() ) {
        new PTPRM_Settings();
    }
} );
