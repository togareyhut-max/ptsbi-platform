/**
 * Build per-province postal code maps from cahyadsn/wilayah_kodepos (Kepmendagri 2025).
 * Source: scripts/source/wilayah_kodepos.sql
 * Output: assets/data/indonesia-regions/postal/{provinceCode}.json
 */
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.join(__dirname, '..');
const sqlPath = path.join(root, 'scripts/source/wilayah_kodepos.sql');
const outDir = path.join(root, 'assets/data/indonesia-regions/postal');

if (!fs.existsSync(sqlPath)) {
    console.error('Missing', sqlPath);
    process.exit(1);
}

const sql = fs.readFileSync(sqlPath, 'utf8');
const byProvince = {};
const re = /\('([\d.]+)',\s*'(\d{5})'\)/g;
let m;
let count = 0;
while ((m = re.exec(sql)) !== null) {
    const code = m[1];
    const pos = m[2];
    const prov = code.split('.')[0];
    if (!byProvince[prov]) byProvince[prov] = {};
    byProvince[prov][code] = pos;
    count++;
}

fs.mkdirSync(outDir, { recursive: true });
const provinces = Object.keys(byProvince).sort();
for (const prov of provinces) {
    const file = path.join(outDir, prov + '.json');
    fs.writeFileSync(file, JSON.stringify(byProvince[prov]));
}
const meta = {
    version: 1,
    source: 'cahyadsn/wilayah_kodepos (Kepmendagri 2025)',
    note: 'Sinkron kode pos per kode wilayah kelurahan/desa. Regenerate: node scripts/build-postal-codes.mjs',
    provinces: provinces.length,
    entries: count,
};
fs.writeFileSync(path.join(outDir, 'index.json'), JSON.stringify(meta, null, 2));
console.log('Wrote', provinces.length, 'province files,', count, 'postal mappings');
