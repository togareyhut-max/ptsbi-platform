(function () {
  var harianWrap = document.getElementById('ptprm-org-harian-wrap');
  var bidangWrap = document.getElementById('ptprm-org-bidang-wrap');
  var tplHarian = document.getElementById('ptprm-tpl-harian-row');
  var regionSelect = document.getElementById('ptprm-org-region-select');

  if (regionSelect) {
    regionSelect.addEventListener('change', function () {
      var url = new URL(window.location.href);
      url.searchParams.set('tab', 'struktur');
      url.searchParams.set('org_region', regionSelect.value);
      window.location.href = url.toString();
    });
  }

  document.addEventListener('click', function (e) {
    if (e.target.closest('.ptprm-org-add-harian') && harianWrap && tplHarian) {
      harianWrap.appendChild(tplHarian.content.cloneNode(true));
      return;
    }
    if (e.target.closest('.ptprm-org-remove-row')) {
      var row = e.target.closest('.ptprm-org-repeater-row');
      if (row) row.remove();
      return;
    }
    if (e.target.closest('.ptprm-org-add-bidang') && bidangWrap) {
      var idx = bidangWrap.querySelectorAll('.ptprm-org-bidang-section').length;
      var sec = document.createElement('div');
      sec.className = 'ptprm-org-bidang-section';
      sec.setAttribute('data-bidang-index', String(idx));
      sec.innerHTML =
        '<p><input type="text" name="bidang_title[]" class="large-text" placeholder="Nama bidang"></p>' +
        '<div class="ptprm-org-bidang-members">' +
        '<div class="ptprm-org-repeater-row">' +
        '<input type="text" name="bidang_role[' +
        idx +
        '][]" placeholder="Jabatan" value="Ketua"> ' +
        '<input type="text" name="bidang_name[' +
        idx +
        '][]" placeholder="Nama" class="regular-text"> ' +
        '<button type="button" class="button-link-delete ptprm-org-remove-row">&times;</button>' +
        '</div></div>' +
        '<p><button type="button" class="button ptprm-org-add-bidang-member" data-bidang-index="' +
        idx +
        '">+ Anggota bidang</button></p>';
      bidangWrap.appendChild(sec);
      return;
    }
    var addMember = e.target.closest('.ptprm-org-add-bidang-member');
    if (addMember) {
      var bi = addMember.getAttribute('data-bidang-index');
      var members = addMember.closest('.ptprm-org-bidang-section');
      if (!members || bi === null) return;
      var box = members.querySelector('.ptprm-org-bidang-members');
      if (!box) return;
      var row = document.createElement('div');
      row.className = 'ptprm-org-repeater-row';
      row.innerHTML =
        '<input type="text" name="bidang_role[' +
        bi +
        '][]" placeholder="Jabatan" value="Ketua"> ' +
        '<input type="text" name="bidang_name[' +
        bi +
        '][]" placeholder="Nama" class="regular-text"> ' +
        '<button type="button" class="button-link-delete ptprm-org-remove-row">&times;</button>';
      box.appendChild(row);
    }
  });
})();
