<?php
/**
 * Panel pengurus per bidang + sekretariat.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PTPRM_Bidang_Portal {

    private const NONCE_CONTENT   = 'ptprm_bidang_content';
    private const NONCE_POST        = 'ptprm_bidang_post';
    private const NONCE_PUBLIKASI   = 'ptprm_bidang_publikasi';
    private const NONCE_PRINT       = 'ptprm_sekretariat_print';

    public static function init(): void {
        add_shortcode( 'ptprm_bidang_portal', [ __CLASS__, 'shortcode_portal' ] );
        add_action( 'init', [ __CLASS__, 'handle_forms' ], 12 );
        add_action( 'template_redirect', [ __CLASS__, 'handle_print_export' ] );
    }

    public static function is_bidang_manager( $user = null ): bool {
        $user = $user ?: wp_get_current_user();
        if ( ! $user instanceof WP_User || ! $user->exists() ) {
            return false;
        }
        if ( PTPRM_Access::is_org_admin( $user ) || PTPRM_Access::is_site_admin( $user ) ) {
            return false;
        }
        $slug = PTPRM_Bidang_Registry::user_bidang_slug( $user );
        return $slug !== '' && PTPRM_Bidang_Registry::get( $slug ) !== null;
    }

    public static function current_panel_slug(): string {
        if ( ! is_page() ) {
            return '';
        }
        return (string) get_post_field( 'post_name', get_queried_object_id() );
    }

    public static function current_bidang_from_panel(): ?array {
        return PTPRM_Bidang_Registry::get_by_panel_slug( self::current_panel_slug() );
    }

    /**
     * @return array<string,mixed>|null
     */
    public static function resolve_bidang_def(): ?array {
        $slug = '';
        if ( ! empty( $_POST['ptprm_bidang_slug'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $slug = sanitize_key( wp_unslash( (string) $_POST['ptprm_bidang_slug'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        }
        if ( $slug !== '' ) {
            $def = PTPRM_Bidang_Registry::get( $slug );
            if ( $def ) {
                return $def;
            }
        }
        return self::current_bidang_from_panel();
    }

    public static function can_access_bidang( array $def, $user = null ): bool {
        $user = $user ?: wp_get_current_user();
        if ( ! $user instanceof WP_User || ! $user->exists() ) {
            return false;
        }
        if ( PTPRM_Access::is_site_admin( $user ) ) {
            return true;
        }
        if ( ! PTPRM_Access::can_manage( $user ) ) {
            return false;
        }
        return PTPRM_Bidang_Registry::user_bidang_slug( $user ) === (string) ( $def['slug'] ?? '' );
    }

    public static function can_access_current_panel( $user = null ): bool {
        $def = self::current_bidang_from_panel();
        if ( ! $def ) {
            return false;
        }
        return self::can_access_bidang( $def, $user );
    }

    public static function portal_url( string $tab = '', array $args = [] ): string {
        $def = self::current_bidang_from_panel();
        if ( ! $def ) {
            $slug = PTPRM_Bidang_Registry::user_bidang_slug();
            return PTPRM_Bidang_Registry::panel_url( $slug, $tab, $args );
        }
        return PTPRM_Bidang_Registry::panel_url( (string) $def['slug'], $tab, $args );
    }

    public static function portal_url_for_slug( string $slug, string $tab = '', array $args = [] ): string {
        return PTPRM_Bidang_Registry::panel_url( $slug, $tab, $args );
    }

    /**
     * @param array<string,mixed> $def
     */
    private static function form_action_attr( array $def, string $ajax_action ): string {
        if ( ! class_exists( 'PTPRM_Portal_Persistence' ) ) {
            return '';
        }
        return ' action="' . esc_url( PTPRM_Portal_Persistence::ajax_action_url( $ajax_action ) ) . '"';
    }

    /**
     * @param array<string,mixed> $def
     */
    private static function hidden_bidang_slug( array $def ): void {
        echo '<input type="hidden" name="ptprm_bidang_slug" value="' . esc_attr( (string) ( $def['slug'] ?? '' ) ) . '">';
    }

    public static function login_url( string $redirect = '' ): string {
        return class_exists( 'PTPRM_Login_Portal' )
            ? PTPRM_Login_Portal::login_url( $redirect )
            : wp_login_url( $redirect );
    }

    public static function handle_forms(): void {
        if ( empty( $_POST['ptprm_bidang_action'] ) ) {
            return;
        }
        if ( ! is_user_logged_in() ) {
            return;
        }

        $def = self::resolve_bidang_def();
        if ( ! $def || ! self::can_access_bidang( $def ) ) {
            wp_safe_redirect(
                add_query_arg(
                    'ptprm_save_error',
                    rawurlencode( __( 'Akses ditolak atau sesi tidak valid.', 'ptsbi-premium' ) ),
                    self::portal_url_for_slug( PTPRM_Bidang_Registry::user_bidang_slug(), 'ringkasan' )
                )
            );
            exit;
        }

        $slug = (string) $def['slug'];
        $action = sanitize_key( wp_unslash( (string) $_POST['ptprm_bidang_action'] ) );

        if ( $action === 'save_content' ) {
            if ( ! isset( $_POST[ self::NONCE_CONTENT ] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( (string) $_POST[ self::NONCE_CONTENT ] ) ), 'ptprm_bidang_save' ) ) {
                wp_safe_redirect( add_query_arg( 'ptprm_save_error', rawurlencode( __( 'Sesi kedaluwarsa. Muat ulang lalu simpan lagi.', 'ptsbi-premium' ) ), self::portal_url_for_slug( $slug, 'konten' ) ) );
                exit;
            }
            $programs = [];
            if ( ! empty( $_POST['program_judul'] ) && is_array( $_POST['program_judul'] ) ) {
                $juduls   = wp_unslash( $_POST['program_judul'] );
                $tujuans  = isset( $_POST['program_tujuan'] ) ? wp_unslash( $_POST['program_tujuan'] ) : [];
                $sasarans = isset( $_POST['program_sasaran'] ) ? wp_unslash( $_POST['program_sasaran'] ) : [];
                $waktus   = isset( $_POST['program_waktu'] ) ? wp_unslash( $_POST['program_waktu'] ) : [];
                foreach ( $juduls as $i => $judul ) {
                    $programs[] = [
                        'judul'   => $judul,
                        'tujuan'  => $tujuans[ $i ] ?? '',
                        'sasaran' => $sasarans[ $i ] ?? '',
                        'waktu'   => $waktus[ $i ] ?? '',
                    ];
                }
            }
            if ( ! PTPRM_Bidang_Data::save(
                $slug,
                [
                    'visi'     => wp_unslash( (string) ( $_POST['visi'] ?? '' ) ),
                    'misi'     => wp_unslash( (string) ( $_POST['misi'] ?? '' ) ),
                    'programs' => $programs,
                ]
            ) ) {
                wp_safe_redirect( add_query_arg( 'ptprm_save_error', rawurlencode( __( 'Gagal menyimpan konten.', 'ptsbi-premium' ) ), self::portal_url_for_slug( $slug, 'konten' ) ) );
                exit;
            }
            wp_safe_redirect( add_query_arg( 'ptprm_saved', '1', self::portal_url_for_slug( $slug, 'konten' ) ) );
            exit;
        }

        if ( $action === 'save_post' ) {
            if ( ! isset( $_POST[ self::NONCE_POST ] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( (string) $_POST[ self::NONCE_POST ] ) ), 'ptprm_bidang_post' ) ) {
                wp_safe_redirect( add_query_arg( 'ptprm_save_error', rawurlencode( __( 'Sesi kedaluwarsa.', 'ptsbi-premium' ) ), self::portal_url_for_slug( $slug, 'berita' ) ) );
                exit;
            }
            self::save_bidang_post( $slug );
        }

        if ( $action === 'save_publikasi' ) {
            if ( ! isset( $_POST[ self::NONCE_PUBLIKASI ] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( (string) $_POST[ self::NONCE_PUBLIKASI ] ) ), 'ptprm_bidang_pub' ) ) {
                wp_safe_redirect( add_query_arg( 'ptprm_save_error', rawurlencode( __( 'Sesi kedaluwarsa.', 'ptsbi-premium' ) ), self::portal_url_for_slug( $slug, 'publikasi' ) ) );
                exit;
            }
            $ok = class_exists( 'PTPRM_Publikasi' ) && PTPRM_Publikasi::save_from_panel( $slug, $_POST, $_FILES );
            $arg = $ok ? 'ptprm_pub_ok' : 'ptprm_pub_err';
            wp_safe_redirect( add_query_arg( $arg, '1', self::portal_url_for_slug( $slug, 'publikasi' ) ) );
            exit;
        }

        if ( $action === 'delete_publikasi' ) {
            if ( ! isset( $_POST[ self::NONCE_PUBLIKASI ] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( (string) $_POST[ self::NONCE_PUBLIKASI ] ) ), 'ptprm_bidang_pub' ) ) {
                wp_safe_redirect( self::portal_url_for_slug( $slug, 'publikasi' ) );
                exit;
            }
            $pid = (int) ( $_POST['pub_delete_id'] ?? 0 );
            if ( class_exists( 'PTPRM_Publikasi' ) ) {
                PTPRM_Publikasi::delete_item( $pid, $slug );
            }
            wp_safe_redirect( self::portal_url_for_slug( $slug, 'publikasi' ) );
            exit;
        }
    }

    private static function save_bidang_post( string $slug ): void {
        $post_id = (int) ( $_POST['post_id'] ?? 0 );
        $title   = sanitize_text_field( wp_unslash( (string) ( $_POST['post_title'] ?? '' ) ) );
        $content = wp_kses_post( wp_unslash( (string) ( $_POST['post_content'] ?? '' ) ) );
        $status  = ( $_POST['post_status'] ?? 'draft' ) === 'publish' ? 'publish' : 'draft';
        if ( $title === '' ) {
            wp_safe_redirect( add_query_arg( 'ptprm_post_error', rawurlencode( __( 'Judul wajib diisi.', 'ptsbi-premium' ) ), self::portal_url_for_slug( $slug, 'berita' ) ) );
            exit;
        }
        $data = [
            'post_title'   => $title,
            'post_content' => $content,
            'post_status'  => $status,
            'post_type'    => 'post',
            'post_author'  => get_current_user_id(),
        ];
        if ( $post_id > 0 ) {
            $data['ID'] = $post_id;
            $result     = wp_update_post( $data, true );
        } else {
            $result = wp_insert_post( $data, true );
        }
        if ( is_wp_error( $result ) ) {
            wp_safe_redirect( add_query_arg( 'ptprm_post_error', rawurlencode( $result->get_error_message() ), self::portal_url_for_slug( $slug, 'berita' ) ) );
            exit;
        }
        $cat_id = PTPRM_Bidang_Registry::category_id_for_bidang( $slug );
        if ( $cat_id > 0 ) {
            wp_set_post_categories( (int) $result, [ $cat_id ] );
        }
        wp_safe_redirect( add_query_arg( 'ptprm_post_ok', '1', self::portal_url_for_slug( $slug, 'berita', [ 'edit' => (int) $result ] ) ) );
        exit;
    }

    public static function handle_print_export(): void {
        if ( ! isset( $_GET['ptprm_sekretariat_print'] ) || $_GET['ptprm_sekretariat_print'] !== '1' ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            return;
        }
        if ( ! is_user_logged_in() || ! PTPRM_Bidang_Registry::is_sekretariat_user() ) {
            wp_die( esc_html__( 'Akses ditolak.', 'ptsbi-premium' ), 403 );
        }
        if ( ! isset( $_GET['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( (string) $_GET['_wpnonce'] ) ), self::NONCE_PRINT ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            wp_die( esc_html__( 'Tautan tidak valid.', 'ptsbi-premium' ), 403 );
        }
        self::render_printable_directory();
        exit;
    }

    private static function render_printable_directory(): void {
        $members = new PTPRM_Members();
        $wilayah = sanitize_key( (string) ( $_GET['wilayah'] ?? 'jabodetabek' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if ( ! in_array( $wilayah, [ 'jabodetabek', 'all' ], true ) ) {
            $wilayah = 'jabodetabek';
        }
        $filters = [
            'nama'      => sanitize_text_field( wp_unslash( (string) ( $_GET['nama'] ?? '' ) ) ), // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            'status'    => sanitize_key( (string) ( $_GET['status'] ?? '' ) ), // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            'oppu'      => sanitize_text_field( wp_unslash( (string) ( $_GET['oppu'] ?? '' ) ) ), // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            'wilayah'   => $wilayah,
            'provinsi'  => sanitize_text_field( wp_unslash( (string) ( $_GET['provinsi'] ?? '' ) ) ), // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            'kota'      => sanitize_text_field( wp_unslash( (string) ( $_GET['kota'] ?? '' ) ) ), // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            'kecamatan' => sanitize_text_field( wp_unslash( (string) ( $_GET['kecamatan'] ?? '' ) ) ), // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            'kelurahan' => sanitize_text_field( wp_unslash( (string) ( $_GET['kelurahan'] ?? '' ) ) ), // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        ];
        $result = $members->search_directory( $filters, 1, 500, true );
        $rows   = $result['rows'];
        header( 'Content-Type: text/html; charset=utf-8' );
        echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>' . esc_html__( 'Hasil Pencarian Anggota', 'ptsbi-premium' ) . '</title>';
        echo '<style>body{font-family:sans-serif;padding:1rem}table{width:100%;border-collapse:collapse}th,td{border:1px solid #ccc;padding:6px;font-size:12px}</style>';
        echo '</head><body onload="window.print()">';
        echo '<h1>' . esc_html__( 'Hasil Pencarian Anggota — Sekretariat', 'ptsbi-premium' ) . '</h1>';
        echo '<p>' . esc_html( gmdate( 'Y-m-d H:i' ) ) . ' UTC</p>';
        echo '<table><thead><tr><th>Nama</th><th>Status</th><th>Ompu</th><th>Sundut</th><th>Alamat</th><th>HP</th></tr></thead><tbody>';
        foreach ( $rows as $row ) {
            $status = PTPRM_Members::compute_marga_status(
                (string) ( $row['kepala_keluarga'] ?? '' ),
                (string) ( $row['nama_istri'] ?? '' )
            );
            echo '<tr>';
            echo '<td>' . esc_html( (string) ( $row['kepala_keluarga'] ?? '' ) ) . '</td>';
            echo '<td>' . esc_html( $status ) . '</td>';
            echo '<td>' . esc_html( (string) ( $row['oppu'] ?? '' ) ) . '</td>';
            echo '<td>' . esc_html( (string) ( $row['nomor_sundut'] ?? '' ) ) . '</td>';
            echo '<td>' . esc_html( PTPRM_Members::format_directory_address( $row, true ) ) . '</td>';
            echo '<td>' . esc_html( (string) ( $row['phone'] ?? '' ) ) . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table></body></html>';
    }

    /**
     * @return array<string, string>
     */
    private static function tabs_for_bidang( array $def ): array {
        $tabs = [
            'ringkasan' => __( 'Ringkasan', 'ptsbi-premium' ),
            'konten'    => __( 'Visi & Program', 'ptsbi-premium' ),
            'berita'    => __( 'Berita Program', 'ptsbi-premium' ),
            'publikasi' => __( 'Publikasi', 'ptsbi-premium' ),
        ];
        if ( ! empty( $def['is_sekretariat'] ) ) {
            $tabs['anggota'] = __( 'Pencarian Anggota', 'ptsbi-premium' );
        }
        return $tabs;
    }

    private static function render_save_notice(): void {
        if ( isset( $_GET['ptprm_saved'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            echo '<p class="ptprm-member-alert ptprm-member-alert-ok">' . esc_html__( 'Berhasil disimpan.', 'ptsbi-premium' ) . '</p>';
        }
        if ( isset( $_GET['ptprm_save_error'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $err = sanitize_text_field( wp_unslash( (string) $_GET['ptprm_save_error'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            if ( $err !== '' ) {
                echo '<p class="ptprm-member-alert ptprm-member-alert-error">' . esc_html( $err ) . '</p>';
            }
        }
    }

    public static function shortcode_portal(): string {
        $def = self::current_bidang_from_panel();
        if ( ! $def ) {
            return '<p>' . esc_html__( 'Panel bidang tidak dikenali.', 'ptsbi-premium' ) . '</p>';
        }

        if ( ! is_user_logged_in() || ! self::can_access_bidang( $def ) ) {
            ob_start();
            echo '<div class="ptprm-member-card ptprm-portal-card">';
            echo '<p>' . esc_html__( 'Silakan masuk dengan akun pengurus bidang ini.', 'ptsbi-premium' ) . '</p>';
            echo '<a class="ptprm-cta ptprm-cta-1 ptprm-cta-size-medium" href="' . esc_url( self::login_url( self::portal_url() ) ) . '">';
            echo '<span class="ptprm-cta-label">' . esc_html__( 'Masuk', 'ptsbi-premium' ) . '</span></a>';
            echo '</div>';
            return (string) ob_get_clean();
        }

        $tabs = self::tabs_for_bidang( $def );
        $tab  = sanitize_key( (string) ( $_GET['tab'] ?? 'ringkasan' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if ( ! isset( $tabs[ $tab ] ) ) {
            $tab = 'ringkasan';
        }

        $instance = new self();
        ob_start();
        self::render_save_notice();
        $user = wp_get_current_user();
        echo '<div class="ptprm-portal-wrap ptprm-bidang-portal-wrap">';
        echo '<header class="ptprm-portal-head">';
        echo '<h2 class="ptprm-portal-title">' . esc_html( sprintf( __( 'Panel %s', 'ptsbi-premium' ), (string) $def['title'] ) ) . '</h2>';
        echo '<p class="ptprm-portal-greet">' . esc_html( sprintf( __( 'Halo, %s', 'ptsbi-premium' ), $user->display_name ?: $user->user_login ) ) . '</p>';
        echo '<p class="ptprm-portal-help"><a href="' . esc_url( PTPRM_Bidang_Registry::public_url( (string) $def['slug'] ) ) . '">' . esc_html__( 'Lihat halaman publik bidang', 'ptsbi-premium' ) . '</a></p>';
        echo '</header>';

        echo '<nav class="ptprm-portal-tabs">';
        foreach ( $tabs as $key => $label ) {
            $active = $tab === $key ? ' is-active' : '';
            echo '<a class="ptprm-portal-tab' . esc_attr( $active ) . '" href="' . esc_url( self::portal_url( $key ) ) . '">' . esc_html( $label ) . '</a>';
        }
        echo '</nav>';

        echo '<div class="ptprm-portal-panel">';
        switch ( $tab ) {
            case 'anggota':
                $instance->render_tab_anggota();
                break;
            case 'konten':
                $instance->render_tab_konten( $def );
                break;
            case 'berita':
                $instance->render_tab_berita( $def );
                break;
            case 'publikasi':
                $instance->render_tab_publikasi( $def );
                break;
            default:
                $instance->render_tab_ringkasan( (string) $def['slug'] );
        }
        echo '</div>';

        echo '<footer class="ptprm-portal-footbar">';
        PTPRM_Access::render_logout_link();
        echo '</footer></div>';
        return (string) ob_get_clean();
    }

    private function render_tab_ringkasan( string $slug ): void {
        $cat_id = PTPRM_Bidang_Registry::category_id_for_bidang( $slug );
        $count  = 0;
        if ( $cat_id > 0 ) {
            $q = new WP_Query(
                [
                    'post_type'      => 'post',
                    'post_status'    => 'publish',
                    'posts_per_page' => 1,
                    'cat'            => $cat_id,
                    'fields'         => 'ids',
                ]
            );
            $count = (int) $q->found_posts;
            wp_reset_postdata();
        }
        $pubs = class_exists( 'PTPRM_Publikasi' ) ? count( PTPRM_Publikasi::list_for_bidang( $slug, 99 ) ) : 0;
        echo '<div class="ptprm-admin-stat-grid">';
        echo '<div class="ptprm-admin-stat"><span class="ptprm-admin-stat-num">' . (int) $count . '</span><span class="ptprm-admin-stat-label">' . esc_html__( 'Berita dipublikasi', 'ptsbi-premium' ) . '</span></div>';
        echo '<div class="ptprm-admin-stat"><span class="ptprm-admin-stat-num">' . (int) $pubs . '</span><span class="ptprm-admin-stat-label">' . esc_html__( 'Publikasi', 'ptsbi-premium' ) . '</span></div>';
        echo '</div>';
    }

    /**
     * @param array<string,mixed> $def
     */
    private function render_tab_konten( array $def ): void {
        $slug = (string) $def['slug'];
        $data = PTPRM_Bidang_Data::get( $slug );
        echo '<form method="post" class="ptprm-member-form"' . self::form_action_attr( $def, 'ptprm_bidang_save' ) . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        wp_nonce_field( 'ptprm_bidang_save', self::NONCE_CONTENT );
        echo '<input type="hidden" name="ptprm_bidang_action" value="save_content">';
        self::hidden_bidang_slug( $def );
        echo '<p><label><strong>' . esc_html__( 'Visi', 'ptsbi-premium' ) . '</strong><br><textarea name="visi" rows="4" class="large-text">' . esc_textarea( $data['visi'] ) . '</textarea></label></p>';
        echo '<p><label><strong>' . esc_html__( 'Misi', 'ptsbi-premium' ) . '</strong><br><textarea name="misi" rows="4" class="large-text">' . esc_textarea( $data['misi'] ) . '</textarea></label></p>';
        echo '<h3 class="ptprm-admin-h3">' . esc_html__( 'Program Unggulan', 'ptsbi-premium' ) . '</h3>';
        echo '<div id="ptprm-program-rows">';
        $programs = $data['programs'] ?: [ [ 'judul' => '', 'tujuan' => '', 'sasaran' => '', 'waktu' => '' ] ];
        foreach ( $programs as $p ) {
            echo '<fieldset class="ptprm-program-row" style="margin-bottom:1rem;padding:1rem;border:1px solid #ddd">';
            echo '<p><label>Judul<br><input type="text" name="program_judul[]" value="' . esc_attr( (string) $p['judul'] ) . '" class="regular-text"></label></p>';
            echo '<p><label>Tujuan<br><textarea name="program_tujuan[]" rows="2" class="large-text">' . esc_textarea( (string) $p['tujuan'] ) . '</textarea></label></p>';
            echo '<p><label>Sasaran<br><textarea name="program_sasaran[]" rows="2" class="large-text">' . esc_textarea( (string) $p['sasaran'] ) . '</textarea></label></p>';
            echo '<p><label>Waktu pengerjaan<br><input type="text" name="program_waktu[]" value="' . esc_attr( (string) $p['waktu'] ) . '" class="regular-text" placeholder="mis. 6 bulan"></label></p>';
            echo '</fieldset>';
        }
        echo '</div>';
        echo '<button type="submit" class="ptprm-cta ptprm-cta-1 ptprm-cta-size-medium"><span class="ptprm-cta-label">' . esc_html__( 'Simpan', 'ptsbi-premium' ) . '</span></button>';
        echo '</form>';
    }

    /**
     * @param array<string,mixed> $def
     */
    private function render_tab_berita( array $def ): void {
        $slug    = (string) $def['slug'];
        $edit_id = (int) ( $_GET['edit'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $cat_id  = PTPRM_Bidang_Registry::category_id_for_bidang( $slug );
        $post    = $edit_id ? get_post( $edit_id ) : null;
        if ( $post && $cat_id > 0 ) {
            $cats = wp_get_post_categories( $edit_id );
            if ( ! in_array( $cat_id, $cats, true ) ) {
                $post    = null;
                $edit_id = 0;
            }
        }

        if ( isset( $_GET['ptprm_post_ok'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            echo '<p class="ptprm-member-alert ptprm-member-alert-ok">' . esc_html__( 'Berita disimpan.', 'ptsbi-premium' ) . '</p>';
        }

        echo '<div class="ptprm-member-card">';
        echo '<form method="post"' . self::form_action_attr( $def, 'ptprm_bidang_save' ) . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        wp_nonce_field( 'ptprm_bidang_post', self::NONCE_POST );
        echo '<input type="hidden" name="ptprm_bidang_action" value="save_post">';
        self::hidden_bidang_slug( $def );
        echo '<input type="hidden" name="post_id" value="' . esc_attr( (string) $edit_id ) . '">';
        echo '<p><label>Judul<br><input type="text" name="post_title" class="regular-text" required value="' . esc_attr( $post ? $post->post_title : '' ) . '"></label></p>';
        echo '<p><label>Isi<br><textarea name="post_content" rows="8" class="large-text">' . esc_textarea( $post ? $post->post_content : '' ) . '</textarea></label></p>';
        echo '<p><label>Status ';
        echo '<select name="post_status"><option value="draft"' . selected( $post && $post->post_status === 'draft', true, false ) . '>Draft</option>';
        echo '<option value="publish"' . selected( $post && $post->post_status === 'publish', true, false ) . '>Publikasi</option></select></label></p>';
        echo '<button type="submit" class="ptprm-cta ptprm-cta-1 ptprm-cta-size-medium"><span class="ptprm-cta-label">' . esc_html__( 'Simpan berita', 'ptsbi-premium' ) . '</span></button>';
        echo '</form></div>';

        $q = new WP_Query(
            [
                'post_type'      => 'post',
                'post_status'    => [ 'publish', 'draft', 'pending' ],
                'posts_per_page' => 20,
                'cat'            => $cat_id > 0 ? $cat_id : 0,
            ]
        );
        echo '<h3 class="ptprm-admin-h3">' . esc_html__( 'Daftar berita bidang', 'ptsbi-premium' ) . '</h3><ul>';
        while ( $q->have_posts() ) {
            $q->the_post();
            echo '<li><a href="' . esc_url( self::portal_url( 'berita', [ 'edit' => get_the_ID() ] ) ) . '">' . esc_html( get_the_title() ) . '</a> — ' . esc_html( get_post_status() ) . '</li>';
        }
        wp_reset_postdata();
        echo '</ul>';
    }

    /**
     * @param array<string,mixed> $def
     */
    private function render_tab_publikasi( array $def ): void {
        $slug = (string) $def['slug'];
        if ( isset( $_GET['ptprm_pub_ok'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            echo '<p class="ptprm-member-alert ptprm-member-alert-ok">' . esc_html__( 'Publikasi disimpan.', 'ptsbi-premium' ) . '</p>';
        }
        echo '<div class="ptprm-member-card">';
        echo '<form method="post" enctype="multipart/form-data"' . self::form_action_attr( $def, 'ptprm_bidang_save' ) . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        wp_nonce_field( 'ptprm_bidang_pub', self::NONCE_PUBLIKASI );
        echo '<input type="hidden" name="ptprm_bidang_action" value="save_publikasi">';
        self::hidden_bidang_slug( $def );
        echo '<p><label>Judul<br><input type="text" name="pub_title" class="regular-text" required></label></p>';
        echo '<p><label>Keterangan singkat<br><textarea name="pub_desc" rows="3" class="large-text"></textarea></label></p>';
        echo '<p><label>Gambar atau PDF<br><input type="file" name="pub_file" accept="image/*,application/pdf" required></label></p>';
        echo '<button type="submit" class="ptprm-cta ptprm-cta-1 ptprm-cta-size-medium"><span class="ptprm-cta-label">' . esc_html__( 'Tambah publikasi', 'ptsbi-premium' ) . '</span></button>';
        echo '</form></div>';

        $items = class_exists( 'PTPRM_Publikasi' ) ? PTPRM_Publikasi::list_for_bidang( $slug, 50 ) : [];
        if ( $items ) {
            echo '<ul>';
            foreach ( $items as $item ) {
                echo '<li>' . esc_html( $item['title'] );
                echo ' <form method="post" style="display:inline"' . self::form_action_attr( $def, 'ptprm_bidang_save' ) . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                wp_nonce_field( 'ptprm_bidang_pub', self::NONCE_PUBLIKASI );
                echo '<input type="hidden" name="ptprm_bidang_action" value="delete_publikasi">';
                self::hidden_bidang_slug( $def );
                echo '<input type="hidden" name="pub_delete_id" value="' . esc_attr( (string) $item['id'] ) . '">';
                echo '<button type="submit" class="button-link-delete" onclick="return confirm(\'' . esc_js( __( 'Hapus?', 'ptsbi-premium' ) ) . '\')">' . esc_html__( 'Hapus', 'ptsbi-premium' ) . '</button></form></li>';
            }
            echo '</ul>';
        }
    }

    private function render_tab_anggota(): void {
        echo '<div class="ptprm-sekretariat-print-actions" style="margin-bottom:1rem">';
        $print_args = array_merge(
            [ 'ptprm_sekretariat_print' => '1', '_wpnonce' => wp_create_nonce( self::NONCE_PRINT ) ],
            array_intersect_key(
                wp_unslash( $_GET ), // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                array_flip( [ 'nama', 'status', 'oppu', 'provinsi', 'kota', 'kecamatan', 'kelurahan', 'wilayah' ] )
            )
        );
        echo '<a class="ptprm-cta ptprm-cta-outline ptprm-cta-size-small" target="_blank" rel="noopener" href="' . esc_url( add_query_arg( $print_args, home_url( '/' ) ) ) . '">';
        echo '<span class="ptprm-cta-label">' . esc_html__( 'Cetak / PDF hasil pencarian', 'ptsbi-premium' ) . '</span></a>';
        echo '<p class="ptprm-portal-help">' . esc_html__( 'Hanya hasil filter saat ini yang dicetak — bukan seluruh database.', 'ptsbi-premium' ) . '</p>';
        echo '</div>';
        $members = new PTPRM_Members();
        echo $members->shortcode_directory();
    }
}
