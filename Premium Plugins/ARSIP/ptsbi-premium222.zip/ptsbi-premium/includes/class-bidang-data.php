<?php
/**
 * Penyimpanan konten bidang (visi, misi, program unggulan).
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PTPRM_Bidang_Data {

    /**
     * @return array{visi:string,misi:string,programs:array<int,array{judul:string,tujuan:string,sasaran:string,waktu:string}>}
     */
    public static function get( string $slug ): array {
        $slug = sanitize_key( $slug );
        $all  = get_option( PTPRM_Bidang_Registry::OPTION_DATA, [] );
        if ( ! is_array( $all ) ) {
            $all = [];
        }
        $row = $all[ $slug ] ?? [];
        if ( ! is_array( $row ) ) {
            $row = [];
        }
        return self::sanitize_row( $row );
    }

    /**
     * @param array<string,mixed> $row
     */
    public static function save( string $slug, array $row ): bool {
        $slug = sanitize_key( $slug );
        if ( ! PTPRM_Bidang_Registry::get( $slug ) ) {
            return false;
        }
        $all         = get_option( PTPRM_Bidang_Registry::OPTION_DATA, [] );
        if ( ! is_array( $all ) ) {
            $all = [];
        }
        $all[ $slug ] = self::sanitize_row( $row );
        update_option( PTPRM_Bidang_Registry::OPTION_DATA, $all, false );
        ptprm_flush_option_cache( PTPRM_Bidang_Registry::OPTION_DATA );
        return true;
    }

    /**
     * @param array<string,mixed> $row
     * @return array{visi:string,misi:string,programs:array<int,array{judul:string,tujuan:string,sasaran:string,waktu:string}>}
     */
    public static function sanitize_row( array $row ): array {
        $programs = [];
        if ( ! empty( $row['programs'] ) && is_array( $row['programs'] ) ) {
            foreach ( $row['programs'] as $p ) {
                if ( ! is_array( $p ) ) {
                    continue;
                }
                $judul = sanitize_text_field( (string) ( $p['judul'] ?? '' ) );
                if ( $judul === '' ) {
                    continue;
                }
                $programs[] = [
                    'judul'   => $judul,
                    'tujuan'  => sanitize_textarea_field( (string) ( $p['tujuan'] ?? '' ) ),
                    'sasaran' => sanitize_textarea_field( (string) ( $p['sasaran'] ?? '' ) ),
                    'waktu'   => sanitize_text_field( (string) ( $p['waktu'] ?? '' ) ),
                ];
                if ( count( $programs ) >= 30 ) {
                    break;
                }
            }
        }
        return [
            'visi'      => sanitize_textarea_field( (string) ( $row['visi'] ?? '' ) ),
            'misi'      => sanitize_textarea_field( (string) ( $row['misi'] ?? '' ) ),
            'programs'  => $programs,
        ];
    }
}
