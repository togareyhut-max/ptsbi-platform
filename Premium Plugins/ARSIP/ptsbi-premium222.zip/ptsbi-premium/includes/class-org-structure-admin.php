<?php
/**
 * Input struktur organisasi di panel admin organisasi.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PTPRM_Org_Structure_Admin {

    private const NONCE = 'ptprm_org_structure_save';

    public static function init(): void {
        add_action( 'init', [ __CLASS__, 'handle_save' ], 15 );
        add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue' ] );
    }

    public static function can_manage(): bool {
        return PTPRM_Access::can_manage_org_settings();
    }

    public static function enqueue(): void {
        if ( ! is_user_logged_in() || ! self::can_manage() ) {
            return;
        }
        if ( ! class_exists( 'PTPRM_Admin_Portal' ) || ! PTPRM_Admin_Portal::is_admin_page() ) {
            return;
        }
        $tab = sanitize_key( (string) ( $_GET['tab'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if ( $tab !== 'struktur' ) {
            return;
        }
        wp_enqueue_script(
            'ptprm-org-structure-admin',
            PTPRM_URL . 'assets/js/org-structure-admin.js',
            [],
            PTPRM_VERSION,
            true
        );
    }

    public static function handle_save(): void {
        if ( empty( $_POST['ptprm_org_structure_save'] ) || ! self::can_manage() ) {
            return;
        }
        if ( ! isset( $_POST[ self::NONCE ] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( (string) $_POST[ self::NONCE ] ) ), 'ptprm_org_structure' ) ) {
            wp_safe_redirect(
                add_query_arg(
                    'ptprm_save_error',
                    rawurlencode( __( 'Sesi kedaluwarsa. Muat ulang halaman lalu simpan lagi.', 'ptsbi-premium' ) ),
                    PTPRM_Admin_Portal::portal_url( 'struktur' )
                )
            );
            exit;
        }

        $slug = sanitize_key( (string) ( $_POST['org_region'] ?? 'pusat' ) );
        if ( $slug === '' ) {
            wp_safe_redirect(
                add_query_arg(
                    'ptprm_save_error',
                    rawurlencode( __( 'Wilayah tidak valid.', 'ptsbi-premium' ) ),
                    PTPRM_Admin_Portal::portal_url( 'struktur' )
                )
            );
            exit;
        }

        $row = self::parse_post_data( $slug );
        $row = self::merge_photo_uploads( $slug, $row );

        if ( ! PTPRM_Org_Structure::save( $slug, $row ) ) {
            wp_safe_redirect(
                add_query_arg(
                    [
                        'tab'             => 'struktur',
                        'org_region'      => $slug,
                        'ptprm_save_error' => rawurlencode( __( 'Gagal menyimpan ke database. Hubungi pengelola hosting.', 'ptsbi-premium' ) ),
                    ],
                    PTPRM_Admin_Portal::portal_url( 'struktur' )
                )
            );
            exit;
        }

        wp_safe_redirect(
            add_query_arg(
                [
                    'tab'             => 'struktur',
                    'org_region'      => $slug,
                    'ptprm_org_saved' => '1',
                ],
                PTPRM_Admin_Portal::portal_url( 'struktur' )
            )
        );
        exit;
    }

    /**
     * @return array<string, mixed>
     */
    private static function parse_post_data( string $slug ): array {
        unset( $slug );
        $harian = [];
        $roles  = isset( $_POST['harian_role'] ) && is_array( $_POST['harian_role'] ) ? wp_unslash( $_POST['harian_role'] ) : [];
        $names  = isset( $_POST['harian_name'] ) && is_array( $_POST['harian_name'] ) ? wp_unslash( $_POST['harian_name'] ) : [];
        foreach ( $roles as $i => $role ) {
            $harian[] = [
                'role' => sanitize_text_field( (string) $role ),
                'name' => sanitize_text_field( (string) ( $names[ $i ] ?? '' ) ),
            ];
        }

        $bidang  = [];
        $btitles = isset( $_POST['bidang_title'] ) && is_array( $_POST['bidang_title'] ) ? wp_unslash( $_POST['bidang_title'] ) : [];
        $broles  = isset( $_POST['bidang_role'] ) && is_array( $_POST['bidang_role'] ) ? wp_unslash( $_POST['bidang_role'] ) : [];
        $bnames  = isset( $_POST['bidang_name'] ) && is_array( $_POST['bidang_name'] ) ? wp_unslash( $_POST['bidang_name'] ) : [];

        foreach ( $btitles as $si => $title ) {
            $members = [];
            $roles   = is_array( $broles[ $si ] ?? null ) ? $broles[ $si ] : [];
            $names   = is_array( $bnames[ $si ] ?? null ) ? $bnames[ $si ] : [];
            foreach ( $roles as $mi => $role ) {
                $members[] = [
                    'role' => sanitize_text_field( (string) $role ),
                    'name' => sanitize_text_field( (string) ( $names[ $mi ] ?? '' ) ),
                ];
            }
            $bidang[] = [
                'title'   => sanitize_text_field( (string) $title ),
                'members' => $members,
            ];
        }

        $lines = static function ( string $field ): array {
            $raw = isset( $_POST[ $field ] ) ? (string) wp_unslash( $_POST[ $field ] ) : '';
            return array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', $raw ) ?: [] ) );
        };

        $pimpinan = [];
        foreach ( [ 'center', 'left', 'right' ] as $pos ) {
            $role = sanitize_text_field( wp_unslash( (string) ( $_POST[ 'pimpinan_' . $pos . '_role' ] ?? '' ) ) );
            $name = sanitize_text_field( wp_unslash( (string) ( $_POST[ 'pimpinan_' . $pos . '_name' ] ?? '' ) ) );
            if ( $name === '' && $role === '' ) {
                continue;
            }
            $pimpinan[] = [
                'pos'   => $pos,
                'role'  => $role,
                'name'  => $name,
                'photo' => max( 0, (int) ( $_POST[ 'pimpinan_' . $pos . '_photo' ] ?? 0 ) ),
            ];
        }

        $layout = ! empty( $_POST['layout_ladder'] ) ? 'ladder' : 'auto';

        return [
            'title'     => sanitize_text_field( wp_unslash( (string) ( $_POST['org_title'] ?? '' ) ) ),
            'layout'    => $layout,
            'pimpinan'  => $pimpinan,
            'harian'    => $harian,
            'bidang'    => $bidang,
            'penasehat' => array_map( 'sanitize_text_field', $lines( 'penasehat' ) ),
            'pakar'     => array_map( 'sanitize_text_field', $lines( 'pakar' ) ),
        ];
    }

    /**
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    private static function merge_photo_uploads( string $slug, array $row ): array {
        unset( $slug );
        if ( ! function_exists( 'media_handle_upload' ) ) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
        }

        foreach ( [ 'center', 'left', 'right' ] as $pos ) {
            $file_key = 'pimpinan_' . $pos . '_photo_file';
            if ( empty( $_FILES[ $file_key ]['name'] ) ) {
                continue;
            }
            $att = media_handle_upload( $file_key, 0 );
            if ( is_wp_error( $att ) ) {
                continue;
            }
            foreach ( $row['pimpinan'] as $i => $p ) {
                if ( (string) ( $p['pos'] ?? '' ) === $pos ) {
                    $row['pimpinan'][ $i ]['photo'] = (int) $att;
                }
            }
        }

        return $row;
    }

    public static function render_tab(): void {
        if ( ! self::can_manage() ) {
            echo '<p>' . esc_html__( 'Hanya admin organisasi yang dapat mengelola struktur kepengurusan.', 'ptsbi-premium' ) . '</p>';
            return;
        }

        if ( isset( $_GET['ptprm_org_saved'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            echo '<p class="ptprm-member-alert ptprm-member-alert-ok">' . esc_html__( 'Struktur organisasi disimpan.', 'ptsbi-premium' ) . '</p>';
        }
        if ( isset( $_GET['ptprm_save_error'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $err = sanitize_text_field( wp_unslash( (string) $_GET['ptprm_save_error'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            if ( $err !== '' ) {
                echo '<p class="ptprm-member-alert ptprm-member-alert-error">' . esc_html( $err ) . '</p>';
            }
        }

        $region = sanitize_key( (string) ( $_GET['org_region'] ?? 'pusat' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $regions = PTPRM_Org_Structure::region_registry();
        if ( ! isset( $regions[ $region ] ) ) {
            $region = 'pusat';
        }
        $data = PTPRM_Org_Structure::get( $region );

        echo '<div class="ptprm-member-card ptprm-portal-card ptprm-org-admin">';
        $form_action = class_exists( 'PTPRM_Portal_Persistence' )
            ? PTPRM_Portal_Persistence::ajax_action_url( 'ptprm_save_org_structure' )
            : '';
        echo '<form method="post" enctype="multipart/form-data" class="ptprm-org-admin-form"' . ( $form_action !== '' ? ' action="' . esc_url( $form_action ) . '"' : '' ) . '>';
        wp_nonce_field( 'ptprm_org_structure', self::NONCE );
        echo '<input type="hidden" name="ptprm_org_structure_save" value="1">';

        echo '<p><label class="ptprm-org-admin-label"><strong>' . esc_html__( 'Wilayah / tingkat', 'ptsbi-premium' ) . '</strong><br>';
        echo '<select name="org_region" id="ptprm-org-region-select" class="regular-text">';
        foreach ( $regions as $slug => $def ) {
            echo '<option value="' . esc_attr( $slug ) . '"' . selected( $region, $slug, false ) . '>' . esc_html( (string) $def['title'] ) . '</option>';
        }
        echo '</select></label></p>';
        echo '<p class="ptprm-portal-help">' . esc_html__( 'Gunakan istilah jabatan setempat (mis. Ketua, Sekretaris, Bendahara — bukan wajib "Umum"). Kosongkan jabatan yang tidak ada.', 'ptsbi-premium' ) . '</p>';

        echo '<p><label>' . esc_html__( 'Judul tampilan halaman', 'ptsbi-premium' ) . '<br>';
        echo '<input type="text" name="org_title" class="large-text" value="' . esc_attr( (string) $data['title'] ) . '"></label></p>';

        $is_ladder = ( $data['layout'] ?? '' ) === 'ladder';
        echo '<p><label><input type="checkbox" name="layout_ladder" value="1"' . checked( $is_ladder, true, false ) . '> ';
        echo esc_html__( 'Tampilan daftar berjenjang (tanpa diagram tiga jabatan di atas)', 'ptsbi-premium' ) . '</label></p>';

        echo '<h3 class="ptprm-admin-h3">' . esc_html__( 'Pimpinan (diagram atas)', 'ptsbi-premium' ) . '</h3>';
        echo '<p class="ptprm-portal-help">' . esc_html__( 'Isi hanya jabatan yang ada. Tengah = pimpinan utama; kiri/kanan opsional.', 'ptsbi-premium' ) . '</p>';
        self::render_pimpinan_fields( 'center', __( 'Tengah (atas)', 'ptsbi-premium' ), $data );
        self::render_pimpinan_fields( 'left', __( 'Kiri', 'ptsbi-premium' ), $data );
        self::render_pimpinan_fields( 'right', __( 'Kanan', 'ptsbi-premium' ), $data );

        echo '<h3 class="ptprm-admin-h3">' . esc_html__( 'Daftar pengurus (berjenjang)', 'ptsbi-premium' ) . '</h3>';
        echo '<p class="ptprm-portal-help">' . esc_html__( 'Urutan dari atas ke bawah. Untuk mode berjenjang, isi semua nama di sini.', 'ptsbi-premium' ) . '</p>';
        echo '<div id="ptprm-org-harian-wrap" class="ptprm-org-repeater-wrap">';
        $harian = $data['harian'] ?? [];
        if ( ! $harian ) {
            $harian = [ [ 'role' => '', 'name' => '' ] ];
        }
        foreach ( $harian as $item ) {
            self::render_harian_row( $item );
        }
        echo '</div>';
        echo '<p><button type="button" class="button ptprm-org-add-harian">' . esc_html__( '+ Tambah baris', 'ptsbi-premium' ) . '</button></p>';

        echo '<h3 class="ptprm-admin-h3">' . esc_html__( 'Bidang Kerja', 'ptsbi-premium' ) . '</h3>';
        echo '<div id="ptprm-org-bidang-wrap">';
        $bidang = $data['bidang'] ?? [];
        if ( ! $bidang ) {
            $bidang = [ [ 'title' => '', 'members' => [ [ 'role' => 'Ketua', 'name' => '' ] ] ] ];
        }
        foreach ( $bidang as $si => $sec ) {
            self::render_bidang_section( (int) $si, $sec );
        }
        echo '</div>';
        echo '<p><button type="button" class="button ptprm-org-add-bidang">' . esc_html__( '+ Tambah bidang', 'ptsbi-premium' ) . '</button></p>';

        echo '<h3 class="ptprm-admin-h3">' . esc_html__( 'Dewan Penasehat', 'ptsbi-premium' ) . '</h3>';
        echo '<p><textarea name="penasehat" rows="5" class="large-text" placeholder="' . esc_attr__( 'Satu nama per baris', 'ptsbi-premium' ) . '">' . esc_textarea( implode( "\n", $data['penasehat'] ?? [] ) ) . '</textarea></p>';

        echo '<h3 class="ptprm-admin-h3">' . esc_html__( 'Dewan Pakar', 'ptsbi-premium' ) . '</h3>';
        echo '<p><textarea name="pakar" rows="4" class="large-text" placeholder="' . esc_attr__( 'Satu nama per baris', 'ptsbi-premium' ) . '">' . esc_textarea( implode( "\n", $data['pakar'] ?? [] ) ) . '</textarea></p>';

        $preview = home_url( '/' . ( $regions[ $region ]['page_slug'] ?? '' ) . '/' );
        echo '<p class="ptprm-portal-help"><a href="' . esc_url( $preview ) . '" target="_blank" rel="noopener">' . esc_html__( 'Lihat halaman publik', 'ptsbi-premium' ) . '</a></p>';

        echo '<button type="submit" class="ptprm-cta ptprm-cta-1 ptprm-cta-size-medium"><span class="ptprm-cta-label">' . esc_html__( 'Simpan struktur', 'ptsbi-premium' ) . '</span></button>';
        echo '</form></div>';

        echo '<template id="ptprm-tpl-harian-row">';
        self::render_harian_row( [ 'role' => '', 'name' => '' ] );
        echo '</template>';
    }

    /**
     * @param array<string, mixed> $data
     */
    private static function render_pimpinan_fields( string $pos, string $pos_label, array $data ): void {
        $person = null;
        foreach ( PTPRM_Org_Structure::pimpinan_list( $data ) as $p ) {
            if ( (string) $p['pos'] === $pos ) {
                $person = $p;
                break;
            }
        }
        if ( ! $person ) {
            $person = [ 'role' => '', 'name' => '', 'photo' => 0 ];
        }
        $photo = (int) ( $person['photo'] ?? 0 );
        echo '<fieldset class="ptprm-org-exec-field"><legend><strong>' . esc_html( $pos_label ) . '</strong></legend>';
        echo '<input type="hidden" name="pimpinan_' . esc_attr( $pos ) . '_photo" value="' . esc_attr( (string) $photo ) . '">';
        echo '<p><label>' . esc_html__( 'Jabatan', 'ptsbi-premium' ) . '<br><input type="text" name="pimpinan_' . esc_attr( $pos ) . '_role" class="regular-text" value="' . esc_attr( (string) ( $person['role'] ?? '' ) ) . '" placeholder="' . esc_attr__( 'mis. Ketua', 'ptsbi-premium' ) . '"></label></p>';
        echo '<p><label>' . esc_html__( 'Nama', 'ptsbi-premium' ) . '<br><input type="text" name="pimpinan_' . esc_attr( $pos ) . '_name" class="regular-text" value="' . esc_attr( (string) ( $person['name'] ?? '' ) ) . '"></label></p>';
        if ( $photo > 0 ) {
            echo '<p class="ptprm-org-photo-preview">' . wp_get_attachment_image( $photo, 'thumbnail' ) . '</p>';
        }
        if ( $pos === 'center' ) {
            echo '<p><label>' . esc_html__( 'Foto (opsional)', 'ptsbi-premium' ) . '<br><input type="file" name="pimpinan_' . esc_attr( $pos ) . '_photo_file" accept="image/*"></label></p>';
        } else {
            echo '<p><label>' . esc_html__( 'Foto (opsional)', 'ptsbi-premium' ) . '<br><input type="file" name="pimpinan_' . esc_attr( $pos ) . '_photo_file" accept="image/*"></label></p>';
        }
        echo '</fieldset>';
    }

    /**
     * @param array{role?:string,name?:string} $item
     */
    private static function render_harian_row( array $item ): void {
        echo '<div class="ptprm-org-repeater-row">';
        echo '<input type="text" name="harian_role[]" placeholder="' . esc_attr__( 'Jabatan', 'ptsbi-premium' ) . '" value="' . esc_attr( (string) ( $item['role'] ?? '' ) ) . '"> ';
        echo '<input type="text" name="harian_name[]" placeholder="' . esc_attr__( 'Nama', 'ptsbi-premium' ) . '" value="' . esc_attr( (string) ( $item['name'] ?? '' ) ) . '" class="regular-text"> ';
        echo '<button type="button" class="button-link-delete ptprm-org-remove-row" aria-label="' . esc_attr__( 'Hapus', 'ptsbi-premium' ) . '">&times;</button>';
        echo '</div>';
    }

    /**
     * @param array{title?:string,members?:array} $sec
     */
    private static function render_bidang_section( int $index, array $sec ): void {
        echo '<div class="ptprm-org-bidang-section" data-bidang-index="' . esc_attr( (string) $index ) . '">';
        echo '<p><input type="text" name="bidang_title[]" class="large-text" placeholder="' . esc_attr__( 'Nama bidang', 'ptsbi-premium' ) . '" value="' . esc_attr( (string) ( $sec['title'] ?? '' ) ) . '"></p>';
        echo '<div class="ptprm-org-bidang-members">';
        $members = $sec['members'] ?? [ [ 'role' => 'Ketua', 'name' => '' ] ];
        foreach ( $members as $m ) {
            echo '<div class="ptprm-org-repeater-row">';
            echo '<input type="text" name="bidang_role[' . esc_attr( (string) $index ) . '][]" placeholder="' . esc_attr__( 'Jabatan', 'ptsbi-premium' ) . '" value="' . esc_attr( (string) ( $m['role'] ?? '' ) ) . '"> ';
            echo '<input type="text" name="bidang_name[' . esc_attr( (string) $index ) . '][]" placeholder="' . esc_attr__( 'Nama', 'ptsbi-premium' ) . '" value="' . esc_attr( (string) ( $m['name'] ?? '' ) ) . '" class="regular-text"> ';
            echo '<button type="button" class="button-link-delete ptprm-org-remove-row">&times;</button>';
            echo '</div>';
        }
        echo '</div>';
        echo '<p><button type="button" class="button ptprm-org-add-bidang-member" data-bidang-index="' . esc_attr( (string) $index ) . '">' . esc_html__( '+ Anggota bidang', 'ptsbi-premium' ) . '</button></p>';
        echo '</div>';
    }
}
