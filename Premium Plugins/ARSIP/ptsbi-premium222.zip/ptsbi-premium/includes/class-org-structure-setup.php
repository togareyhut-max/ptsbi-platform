<?php
/**
 * Halaman wilayah & seed data struktur organisasi.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PTPRM_Org_Structure_Setup {

    /** @var array<string, string> slug lama => slug halaman baru */
    private static function slug_migrations(): array {
        return [
            'struktur-organisasi'  => 'ptsbi-pusat',
            'pengurus-kab-samosir' => 'ptsbi-samosir',
            'pengurus-kota-medan'  => 'ptsbi-medan',
            'pengurus-pekanbaru'   => 'ptsbi-pekanbaru',
        ];
    }

    public static function init(): void {
        add_action( 'init', [ __CLASS__, 'maybe_install' ], 22 );
        add_filter( 'ptprm_subpage_hero_skip', [ __CLASS__, 'skip_hero_on_org_pages' ] );
    }

    public static function maybe_install(): void {
        $version = (int) get_option( 'ptprm_org_structure_setup_v', 0 );
        if ( $version >= 3 ) {
            return;
        }
        self::install();
        if ( $version < 3 ) {
            self::migrate_pekanbaru_ladder();
        }
        update_option( 'ptprm_org_structure_setup_v', 3, false );
        flush_rewrite_rules( false );
    }

    public static function migrate_pekanbaru_ladder(): void {
        $all = get_option( PTPRM_Org_Structure::OPTION, [] );
        if ( ! is_array( $all ) ) {
            return;
        }
        $all['pekanbaru'] = PTPRM_Org_Structure::sanitize_structure(
            PTPRM_Org_Structure::default_seed_data()['pekanbaru']
        );
        update_option( PTPRM_Org_Structure::OPTION, $all, false );
        ptprm_flush_option_cache( PTPRM_Org_Structure::OPTION );
    }

    public static function install(): void {
        self::migrate_page_slugs();
        self::seed_data();
        self::ensure_pages();
        self::ensure_hub_page();
    }

    public static function migrate_page_slugs(): void {
        foreach ( self::slug_migrations() as $old => $new ) {
            $page = get_page_by_path( $old, OBJECT, 'page' );
            if ( ! $page instanceof WP_Post ) {
                continue;
            }
            if ( get_page_by_path( $new, OBJECT, 'page' ) ) {
                continue;
            }
            wp_update_post(
                [
                    'ID'        => (int) $page->ID,
                    'post_name' => $new,
                ]
            );
        }
    }

    public static function ensure_hub_page(): void {
        $page = get_page_by_path( 'struktur-organisasi', OBJECT, 'page' );
        if ( $page instanceof WP_Post ) {
            delete_post_meta( (int) $page->ID, '_ptprm_org_slug' );
            return;
        }
        wp_insert_post(
            [
                'post_title'   => __( 'Struktur Organisasi', 'ptsbi-premium' ),
                'post_name'    => 'struktur-organisasi',
                'post_status'  => 'publish',
                'post_type'    => 'page',
                'post_excerpt' => __( 'Indeks kepengurusan pusat dan wilayah.', 'ptsbi-premium' ),
                'post_content' => '<!-- Indeks struktur organisasi -->',
            ]
        );
    }

    public static function seed_data(): void {
        $existing = get_option( PTPRM_Org_Structure::OPTION, [] );
        if ( ! is_array( $existing ) ) {
            $existing = [];
        }
        foreach ( PTPRM_Org_Structure::default_seed_data() as $slug => $row ) {
            if ( empty( $existing[ $slug ] ) ) {
                $existing[ $slug ] = PTPRM_Org_Structure::sanitize_structure( $row );
            }
        }
        update_option( PTPRM_Org_Structure::OPTION, $existing, false );
        ptprm_flush_option_cache( PTPRM_Org_Structure::OPTION );
    }

    public static function ensure_pages(): void {
        foreach ( PTPRM_Org_Structure::region_registry() as $slug => $def ) {
            $pslug = (string) $def['page_slug'];
            $page  = get_page_by_path( $pslug, OBJECT, 'page' );
            if ( $page instanceof WP_Post ) {
                update_post_meta( (int) $page->ID, '_ptprm_org_slug', $slug );
                continue;
            }
            $id = wp_insert_post(
                [
                    'post_title'   => (string) $def['title'],
                    'post_name'    => $pslug,
                    'post_status'  => 'publish',
                    'post_type'    => 'page',
                    'post_excerpt' => __( 'Struktur kepengurusan organisasi.', 'ptsbi-premium' ),
                    'post_content' => '<!-- Struktur organisasi: konten dihasilkan plugin -->',
                ]
            );
            if ( ! is_wp_error( $id ) && $id ) {
                update_post_meta( (int) $id, '_ptprm_org_slug', $slug );
            }
        }
    }

    public static function skip_hero_on_org_pages( bool $skip ): bool {
        if ( ! is_page() ) {
            return $skip;
        }
        $path = (string) get_post_field( 'post_name', get_queried_object_id() );
        if ( $path === 'struktur-organisasi' ) {
            return true;
        }
        return PTPRM_Org_Structure::page_org_slug( get_queried_object_id() ) !== '' ? true : $skip;
    }
}
