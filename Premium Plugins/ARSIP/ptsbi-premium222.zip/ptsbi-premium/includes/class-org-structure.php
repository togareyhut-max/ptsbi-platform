<?php
/**
 * Struktur kepengurusan (pusat & wilayah) — data, render publik, shortcode.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PTPRM_Org_Structure {

    public const OPTION = 'ptprm_org_structures';

    /**
     * @return array<string, array{title:string,page_slug:string}>
     */
    public static function region_registry(): array {
        $stored = get_option( self::OPTION, [] );
        $custom = is_array( $stored['_regions'] ?? null ) ? $stored['_regions'] : [];

        $base = [
            'pusat'       => [
                'title'     => __( 'Pengurus Pusat PTSBI', 'ptsbi-premium' ),
                'page_slug' => 'ptsbi-pusat',
            ],
            'kab-samosir' => [
                'title'     => __( 'Pengurus PTSBI Kab. Samosir', 'ptsbi-premium' ),
                'page_slug' => 'ptsbi-samosir',
            ],
            'kota-medan'  => [
                'title'     => __( 'Pengurus PTSBI Kota Medan', 'ptsbi-premium' ),
                'page_slug' => 'ptsbi-medan',
            ],
            'pekanbaru'   => [
                'title'     => __( 'Pengurus PTSBI Pekan Baru', 'ptsbi-premium' ),
                'page_slug' => 'ptsbi-pekanbaru',
            ],
        ];

        foreach ( $custom as $slug => $meta ) {
            if ( ! is_array( $meta ) ) {
                continue;
            }
            $slug = sanitize_key( (string) $slug );
            if ( $slug === '' ) {
                continue;
            }
            $base[ $slug ] = [
                'title'     => sanitize_text_field( (string) ( $meta['title'] ?? $slug ) ),
                'page_slug' => sanitize_title( (string) ( $meta['page_slug'] ?? $slug ) ),
            ];
        }

        return $base;
    }

    public static function init(): void {
        add_shortcode( 'ptprm_org_structure', [ __CLASS__, 'shortcode' ] );
        add_filter( 'the_content', [ __CLASS__, 'inject_on_org_pages' ], 7 );
        add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue_assets' ] );
    }

    public static function enqueue_assets(): void {
        if ( ! is_page() ) {
            return;
        }
        $page_id = get_queried_object_id();
        $slug    = self::page_org_slug( $page_id );
        $path    = (string) get_post_field( 'post_name', $page_id );
        if ( $slug === '' && $path !== 'struktur-organisasi' && ! self::content_has_shortcode() ) {
            return;
        }
        wp_enqueue_style(
            'ptprm-org-structure',
            PTPRM_URL . 'assets/css/org-structure.css',
            [ 'ptprm-frontend' ],
            PTPRM_VERSION
        );
    }

    private static function content_has_shortcode(): bool {
        $post = get_post();
        return $post instanceof WP_Post && has_shortcode( (string) $post->post_content, 'ptprm_org_structure' );
    }

    public static function page_org_slug( int $page_id ): string {
        $meta = sanitize_key( (string) get_post_meta( $page_id, '_ptprm_org_slug', true ) );
        if ( $meta !== '' ) {
            return $meta;
        }
        $path = (string) get_post_field( 'post_name', $page_id );
        foreach ( self::region_registry() as $slug => $def ) {
            if ( (string) $def['page_slug'] === $path ) {
                return $slug;
            }
        }
        return '';
    }

    /**
     * @return array<string, mixed>
     */
    public static function get( string $slug ): array {
        $slug  = sanitize_key( $slug );
        $all   = get_option( self::OPTION, [] );
        $row   = is_array( $all[ $slug ] ?? null ) ? $all[ $slug ] : [];
        $title = (string) ( self::region_registry()[ $slug ]['title'] ?? '' );
        if ( ! empty( $row['title'] ) ) {
            $title = (string) $row['title'];
        }
        $row['title'] = $title;
        return self::prepare_data( self::sanitize_structure( $row ) );
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public static function prepare_data( array $data ): array {
        if ( empty( $data['pimpinan'] ) || ! is_array( $data['pimpinan'] ) ) {
            $data['pimpinan'] = self::pimpinan_from_legacy( $data );
        }
        return $data;
    }

    /**
     * @param array<string, mixed> $row
     * @return list<array{pos:string,role:string,name:string,photo:int}>
     */
    private static function pimpinan_from_legacy( array $row ): array {
        $map = [
            'center' => [ 'ketua_umum', '' ],
            'left'   => [ 'sekretaris_umum', '' ],
            'right'  => [ 'bendahara_umum', '' ],
        ];
        $out = [];
        foreach ( $map as $pos => $pair ) {
            $key = $pair[0];
            $p   = is_array( $row[ $key ] ?? null ) ? $row[ $key ] : [];
            $name = trim( (string) ( $p['name'] ?? '' ) );
            if ( $name === '' ) {
                continue;
            }
            $role = trim( (string) ( $p['role'] ?? '' ) );
            $out[] = [
                'pos'   => $pos,
                'role'  => $role,
                'name'  => $name,
                'photo' => max( 0, (int) ( $p['photo'] ?? 0 ) ),
            ];
        }
        return $out;
    }

    /**
     * @param array<string, mixed> $data
     * @return list<array{pos:string,role:string,name:string,photo:int}>
     */
    public static function pimpinan_list( array $data ): array {
        $list = [];
        if ( ! empty( $data['pimpinan'] ) && is_array( $data['pimpinan'] ) ) {
            foreach ( $data['pimpinan'] as $p ) {
                if ( ! is_array( $p ) ) {
                    continue;
                }
                $name = trim( (string) ( $p['name'] ?? '' ) );
                if ( $name === '' ) {
                    continue;
                }
                $pos = sanitize_key( (string) ( $p['pos'] ?? 'center' ) );
                if ( ! in_array( $pos, [ 'left', 'center', 'right' ], true ) ) {
                    $pos = 'center';
                }
                $list[] = [
                    'pos'   => $pos,
                    'role'  => sanitize_text_field( (string) ( $p['role'] ?? '' ) ),
                    'name'  => $name,
                    'photo' => max( 0, (int) ( $p['photo'] ?? 0 ) ),
                ];
            }
        }
        return $list;
    }

    /**
     * @param array<string, mixed> $data
     */
    private static function pimpinan_by_pos( array $data, string $pos ): ?array {
        foreach ( self::pimpinan_list( $data ) as $p ) {
            if ( (string) $p['pos'] === $pos ) {
                return $p;
            }
        }
        return null;
    }

    /**
     * @param array<string, mixed> $data
     */
    private static function resolve_layout( array $data ): string {
        $layout = sanitize_key( (string) ( $data['layout'] ?? 'auto' ) );
        if ( $layout === 'ladder' || $layout === 'triad' ) {
            return $layout;
        }
        $pimpinan = self::pimpinan_list( $data );
        $center   = self::pimpinan_by_pos( $data, 'center' );
        $left     = self::pimpinan_by_pos( $data, 'left' );
        $right    = self::pimpinan_by_pos( $data, 'right' );

        if ( ! $pimpinan && ! empty( $data['harian'] ) ) {
            return 'ladder';
        }
        if ( $center && ( $left || $right ) ) {
            return 'triad';
        }
        if ( $center && ! $left && ! $right ) {
            return 'triad';
        }
        if ( ! $center && $pimpinan ) {
            return 'ladder';
        }
        return 'ladder';
    }

    /**
     * @param array<string, mixed> $row
     */
    public static function save( string $slug, array $row ): bool {
        $slug = sanitize_key( $slug );
        if ( $slug === '' ) {
            return false;
        }
        $all         = get_option( self::OPTION, [] );
        if ( ! is_array( $all ) ) {
            $all = [];
        }
        $all[ $slug ] = self::sanitize_structure( $row );
        update_option( self::OPTION, $all, false );
        ptprm_flush_option_cache( self::OPTION );
        return true;
    }

    /**
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    public static function sanitize_structure( array $row ): array {
        $harian = [];
        if ( ! empty( $row['harian'] ) && is_array( $row['harian'] ) ) {
            foreach ( $row['harian'] as $item ) {
                if ( ! is_array( $item ) ) {
                    continue;
                }
                $role = sanitize_text_field( (string) ( $item['role'] ?? '' ) );
                $name = sanitize_text_field( (string) ( $item['name'] ?? '' ) );
                if ( $role === '' && $name === '' ) {
                    continue;
                }
                $harian[] = [ 'role' => $role, 'name' => $name ];
                if ( count( $harian ) >= 24 ) {
                    break;
                }
            }
        }

        $bidang = [];
        if ( ! empty( $row['bidang'] ) && is_array( $row['bidang'] ) ) {
            foreach ( $row['bidang'] as $sec ) {
                if ( ! is_array( $sec ) ) {
                    continue;
                }
                $title = sanitize_text_field( (string) ( $sec['title'] ?? '' ) );
                $mems  = [];
                if ( ! empty( $sec['members'] ) && is_array( $sec['members'] ) ) {
                    foreach ( $sec['members'] as $m ) {
                        if ( ! is_array( $m ) ) {
                            continue;
                        }
                        $r = sanitize_text_field( (string) ( $m['role'] ?? '' ) );
                        $n = sanitize_text_field( (string) ( $m['name'] ?? '' ) );
                        if ( $r === '' && $n === '' ) {
                            continue;
                        }
                        $mems[] = [ 'role' => $r, 'name' => $n ];
                    }
                }
                if ( $title === '' && ! $mems ) {
                    continue;
                }
                $bidang[] = [ 'title' => $title, 'members' => $mems ];
                if ( count( $bidang ) >= 12 ) {
                    break;
                }
            }
        }

        $lines = static function ( string $key ) use ( $row ): array {
            $raw = $row[ $key ] ?? [];
            if ( is_string( $raw ) ) {
                $raw = preg_split( '/\r\n|\r|\n/', $raw ) ?: [];
            }
            if ( ! is_array( $raw ) ) {
                return [];
            }
            $out = [];
            foreach ( $raw as $line ) {
                $line = sanitize_text_field( (string) $line );
                if ( $line !== '' ) {
                    $out[] = $line;
                }
                if ( count( $out ) >= 20 ) {
                    break;
                }
            }
            return $out;
        };

        $pimpinan = [];
        if ( ! empty( $row['pimpinan'] ) && is_array( $row['pimpinan'] ) ) {
            foreach ( $row['pimpinan'] as $p ) {
                if ( ! is_array( $p ) ) {
                    continue;
                }
                $pos = sanitize_key( (string) ( $p['pos'] ?? 'center' ) );
                if ( ! in_array( $pos, [ 'left', 'center', 'right' ], true ) ) {
                    $pos = 'center';
                }
                $name = sanitize_text_field( (string) ( $p['name'] ?? '' ) );
                if ( $name === '' ) {
                    continue;
                }
                $pimpinan[] = [
                    'pos'   => $pos,
                    'role'  => sanitize_text_field( (string) ( $p['role'] ?? '' ) ),
                    'name'  => $name,
                    'photo' => max( 0, (int) ( $p['photo'] ?? 0 ) ),
                ];
            }
        }

        $layout = sanitize_key( (string) ( $row['layout'] ?? 'auto' ) );
        if ( ! in_array( $layout, [ 'auto', 'triad', 'ladder' ], true ) ) {
            $layout = 'auto';
        }

        return [
            'title'     => sanitize_text_field( (string) ( $row['title'] ?? '' ) ),
            'layout'    => $layout,
            'pimpinan'  => $pimpinan ?: self::pimpinan_from_legacy( $row ),
            'harian'    => $harian,
            'bidang'    => $bidang,
            'penasehat' => $lines( 'penasehat' ),
            'pakar'     => $lines( 'pakar' ),
        ];
    }

    /**
     * @param array<string, string> $atts
     */
    public static function shortcode( $atts = [] ): string {
        $atts = shortcode_atts(
            [ 'slug' => '' ],
            is_array( $atts ) ? $atts : [],
            'ptprm_org_structure'
        );
        $slug = sanitize_key( (string) $atts['slug'] );
        if ( $slug === '' && is_page() ) {
            $slug = self::page_org_slug( get_queried_object_id() );
        }
        if ( $slug === '' ) {
            $slug = 'pusat';
        }
        return self::render( $slug, true );
    }

    /**
     * @param string $content
     */
    public static function inject_on_org_pages( $content ): string {
        if ( ! is_page() || ! in_the_loop() || ! is_main_query() ) {
            return $content;
        }
        $page_id  = get_queried_object_id();
        $org_slug = self::page_org_slug( $page_id );
        $path     = (string) get_post_field( 'post_name', $page_id );

        if ( $path === 'struktur-organisasi' ) {
            return self::render_structure_index();
        }

        if ( $org_slug === '' ) {
            return $content;
        }

        return self::render( $org_slug, false );
    }

    public static function render_structure_index(): string {
        $regions = self::region_registry();
        ob_start();
        echo '<div class="ptprm-org ptprm-org-index">';
        echo '<p class="ptprm-org-index-lead">' . esc_html__( 'Pilih tingkat kepengurusan untuk melihat susunan lengkap:', 'ptsbi-premium' ) . '</p>';
        echo '<div class="ptprm-org-wilayah-nav-grid">';
        foreach ( $regions as $slug => $def ) {
            $url = home_url( '/' . $def['page_slug'] . '/' );
            echo '<a class="ptprm-org-wilayah-card" href="' . esc_url( $url ) . '">';
            echo '<span class="ptprm-org-wilayah-card-label">' . esc_html( (string) $def['title'] ) . '</span>';
            echo '<span class="ptprm-org-wilayah-card-arrow" aria-hidden="true">&rarr;</span>';
            echo '</a>';
        }
        echo '</div></div>';
        return (string) ob_get_clean();
    }

    public static function render_wilayah_nav(): string {
        $regions = self::region_registry();
        ob_start();
        echo '<nav class="ptprm-org-wilayah-nav" aria-label="' . esc_attr__( 'Kepengurusan wilayah', 'ptsbi-premium' ) . '">';
        echo '<p class="ptprm-org-wilayah-nav-lead">' . esc_html__( 'Pilih kepengurusan wilayah:', 'ptsbi-premium' ) . '</p>';
        echo '<div class="ptprm-org-wilayah-nav-grid">';
        foreach ( $regions as $slug => $def ) {
            if ( $slug === 'pusat' ) {
                continue;
            }
            $url = home_url( '/' . $def['page_slug'] . '/' );
            echo '<a class="ptprm-org-wilayah-card" href="' . esc_url( $url ) . '">';
            echo '<span class="ptprm-org-wilayah-card-label">' . esc_html( (string) $def['title'] ) . '</span>';
            echo '<span class="ptprm-org-wilayah-card-arrow" aria-hidden="true">&rarr;</span>';
            echo '</a>';
        }
        echo '</nav>';
        return (string) ob_get_clean();
    }

    public static function render( string $slug, bool $wrap_shortcode ): string {
        $data  = self::get( $slug );
        $reg   = self::region_registry();
        $title = $data['title'] !== '' ? $data['title'] : (string) ( $reg[ $slug ]['title'] ?? __( 'Struktur Organisasi', 'ptsbi-premium' ) );
        $layout = self::resolve_layout( $data );

        ob_start();
        echo '<div class="ptprm-org' . ( $wrap_shortcode ? ' ptprm-org--shortcode' : '' ) . '">';

        echo '<header class="ptprm-org-header">';
        echo '<h2 class="ptprm-org-title">' . esc_html( $title ) . '</h2>';
        echo '</header>';

        if ( $layout === 'ladder' ) {
            self::render_ladder( $data );
        } else {
            self::render_executive( $data );
            self::render_harian( $data, false );
        }
        self::render_bidang( $data );
        self::render_board( __( 'Dewan Penasehat', 'ptsbi-premium' ), $data['penasehat'] );
        self::render_board( __( 'Dewan Pakar', 'ptsbi-premium' ), $data['pakar'] );

        echo '</div>';
        return (string) ob_get_clean();
    }

    /**
     * @param array<string, mixed> $data
     */
    private static function render_executive( array $data ): void {
        $center = self::pimpinan_by_pos( $data, 'center' );
        $left   = self::pimpinan_by_pos( $data, 'left' );
        $right  = self::pimpinan_by_pos( $data, 'right' );

        if ( ! $center ) {
            return;
        }

        $has_sides = $left || $right;
        $chart_cls = 'ptprm-org-chart';
        if ( $left ) {
            $chart_cls .= ' ptprm-org-chart--has-left';
        }
        if ( $right ) {
            $chart_cls .= ' ptprm-org-chart--has-right';
        }
        if ( ! $has_sides ) {
            $chart_cls .= ' ptprm-org-chart--solo';
        }

        echo '<section class="ptprm-org-executive" aria-label="' . esc_attr__( 'Pengurus inti', 'ptsbi-premium' ) . '">';
        echo '<div class="' . esc_attr( $chart_cls ) . '">';

        echo '<div class="ptprm-org-chart__ketua">';
        self::render_person_card( $center, true, true );
        echo '</div>';

        if ( $has_sides ) {
            echo '<div class="ptprm-org-chart__lines" aria-hidden="true">';
            echo '<span class="ptprm-org-line ptprm-org-line--stem"></span>';
            if ( $left && $right ) {
                echo '<span class="ptprm-org-line ptprm-org-line--bar"></span>';
            }
            if ( $left ) {
                echo '<span class="ptprm-org-line ptprm-org-line--left"></span>';
            }
            if ( $right ) {
                echo '<span class="ptprm-org-line ptprm-org-line--right"></span>';
            }
            echo '</div>';

            echo '<div class="ptprm-org-chart__row">';
            if ( $left ) {
                echo '<div class="ptprm-org-chart__side ptprm-org-chart__side--left">';
                self::render_person_card( $left, true, false );
                echo '</div>';
            } else {
                echo '<div class="ptprm-org-chart__side ptprm-org-chart__side--spacer" aria-hidden="true"></div>';
            }
            if ( $right ) {
                echo '<div class="ptprm-org-chart__side ptprm-org-chart__side--right">';
                self::render_person_card( $right, true, false );
                echo '</div>';
            } else {
                echo '<div class="ptprm-org-chart__side ptprm-org-chart__side--spacer" aria-hidden="true"></div>';
            }
            echo '</div>';
        }

        echo '</div></section>';
    }

    /**
     * @param array{role?:string,name?:string,photo?:int} $person
     */
    private static function render_person_card( array $person, bool $with_photo, bool $featured = false ): void {
        $role  = trim( (string) ( $person['role'] ?? '' ) );
        $name  = trim( (string) ( $person['name'] ?? '' ) );
        $photo = (int) ( $person['photo'] ?? 0 );
        $cls   = 'ptprm-org-person' . ( $featured ? ' ptprm-org-person--featured' : '' );
        echo '<div class="' . esc_attr( $cls ) . '">';
        if ( $with_photo ) {
            echo '<div class="ptprm-org-person-photo">';
            if ( $photo > 0 ) {
                echo wp_get_attachment_image( $photo, 'medium', false, [ 'class' => 'ptprm-org-person-img', 'loading' => 'lazy' ] );
            } else {
                echo '<span class="ptprm-org-person-placeholder" aria-hidden="true"></span>';
            }
            echo '</div>';
        }
        if ( $role !== '' ) {
            echo '<p class="ptprm-org-person-role">' . esc_html( $role ) . '</p>';
        }
        echo '<p class="ptprm-org-person-name">' . esc_html( $name !== '' ? $name : '—' ) . '</p>';
        echo '</div>';
    }

    /**
     * Daftar berjenjang (tanpa diagram tiga jabatan).
     *
     * @param array<string, mixed> $data
     */
    private static function render_ladder( array $data ): void {
        $rows = $data['harian'] ?? [];
        if ( ! is_array( $rows ) || ! $rows ) {
            return;
        }
        echo '<section class="ptprm-org-section ptprm-org-ladder-section">';
        echo '<ol class="ptprm-org-ladder">';
        foreach ( $rows as $item ) {
            $role = trim( (string) ( $item['role'] ?? '' ) );
            $name = trim( (string) ( $item['name'] ?? '' ) );
            if ( $role === '' && $name === '' ) {
                continue;
            }
            echo '<li class="ptprm-org-ladder-item">';
            if ( $role !== '' ) {
                echo '<span class="ptprm-org-ladder-role">' . esc_html( $role ) . '</span>';
            }
            echo '<span class="ptprm-org-ladder-name">' . esc_html( $name ) . '</span>';
            echo '</li>';
        }
        echo '</ol></section>';
    }

    /**
     * @param array<string, mixed> $data
     */
    private static function render_harian( array $data, bool $as_ladder = false ): void {
        if ( $as_ladder ) {
            self::render_ladder( $data );
            return;
        }
        $harian = $data['harian'] ?? [];
        if ( ! is_array( $harian ) || ! $harian ) {
            return;
        }
        echo '<section class="ptprm-org-section ptprm-org-harian">';
        echo '<h3 class="ptprm-org-section-title">' . esc_html__( 'Pengurus Lainnya', 'ptsbi-premium' ) . '</h3>';
        echo '<div class="ptprm-org-card-grid">';
        foreach ( $harian as $item ) {
            echo '<div class="ptprm-org-mini-card">';
            echo '<span class="ptprm-org-mini-role">' . esc_html( (string) ( $item['role'] ?? '' ) ) . '</span>';
            echo '<span class="ptprm-org-mini-name">' . esc_html( (string) ( $item['name'] ?? '' ) ) . '</span>';
            echo '</div>';
        }
        echo '</div></section>';
    }

    /**
     * @param array<string, mixed> $data
     */
    private static function render_bidang( array $data ): void {
        $bidang = $data['bidang'] ?? [];
        if ( ! is_array( $bidang ) || ! $bidang ) {
            return;
        }
        echo '<section class="ptprm-org-section ptprm-org-bidang">';
        echo '<h3 class="ptprm-org-section-title">' . esc_html__( 'Bidang Kerja', 'ptsbi-premium' ) . '</h3>';
        foreach ( $bidang as $sec ) {
            $title = (string) ( $sec['title'] ?? '' );
            echo '<div class="ptprm-org-bidang-block">';
            if ( $title !== '' ) {
                echo '<h4 class="ptprm-org-bidang-title">' . esc_html( $title ) . '</h4>';
            }
            $members = $sec['members'] ?? [];
            if ( is_array( $members ) && $members ) {
                echo '<div class="ptprm-org-bidang-members">';
                foreach ( $members as $m ) {
                    echo '<div class="ptprm-org-bidang-row">';
                    echo '<span class="ptprm-org-bidang-role">' . esc_html( (string) ( $m['role'] ?? '' ) ) . '</span>';
                    echo '<span class="ptprm-org-bidang-name">' . esc_html( (string) ( $m['name'] ?? '' ) ) . '</span>';
                    echo '</div>';
                }
                echo '</div>';
            }
            echo '</div>';
        }
        echo '</section>';
    }

    /**
     * @param list<string> $names
     */
    private static function render_board( string $heading, array $names ): void {
        if ( ! $names ) {
            return;
        }
        echo '<section class="ptprm-org-section ptprm-org-board">';
        echo '<h3 class="ptprm-org-section-title">' . esc_html( $heading ) . '</h3>';
        echo '<ol class="ptprm-org-board-list">';
        foreach ( $names as $name ) {
            echo '<li>' . esc_html( $name ) . '</li>';
        }
        echo '</ol></section>';
    }

    /**
     * Data awal dari dokumen organisasi (dapat diedit admin).
     *
     * @return array<string, array<string, mixed>>
     */
    public static function default_seed_data(): array {
        return [
            'pusat' => [
                'title'    => 'Pengurus Pusat PTSBI',
                'layout'   => 'triad',
                'pimpinan' => [
                    [ 'pos' => 'center', 'role' => 'Ketua Umum', 'name' => 'Ir. Raya Pontus Samosir', 'photo' => 0 ],
                    [ 'pos' => 'left', 'role' => 'Sekretaris Umum', 'name' => 'Toman Samosir', 'photo' => 0 ],
                    [ 'pos' => 'right', 'role' => 'Bendahara Umum', 'name' => 'Parluhutan Sinambela', 'photo' => 0 ],
                ],
                'harian' => [
                    [ 'role' => 'Ketua Harian', 'name' => 'Rolaw Samosir' ],
                    [ 'role' => 'Sekretaris I', 'name' => 'Jeny Samosir' ],
                    [ 'role' => 'Sekretaris II', 'name' => 'Atur Hamonangan Samosir' ],
                    [ 'role' => 'Bendahara I', 'name' => 'Henri Erikson Samosir' ],
                    [ 'role' => 'Bendahara II', 'name' => 'Jepri Sinaturi' ],
                ],
                'bidang' => [
                    [
                        'title'   => 'Bidang Adat dan Budaya',
                        'members' => [ [ 'role' => 'Ketua', 'name' => 'Alexander Samosir' ] ],
                    ],
                    [
                        'title'   => 'Bidang Usaha dan Dana',
                        'members' => [ [ 'role' => 'Ketua', 'name' => 'Adi Samosir' ] ],
                    ],
                    [
                        'title'   => 'Bidang Sosial, Pendidikan dan Kepemudaan',
                        'members' => [ [ 'role' => 'Ketua', 'name' => 'Henrico Samosir' ] ],
                    ],
                    [
                        'title'   => 'Bidang Hukum',
                        'members' => [ [ 'role' => 'Ketua', 'name' => 'Kardin Samosir' ] ],
                    ],
                ],
                'penasehat' => [
                    'Johny Samosir',
                    'Laurentius Samosir',
                    'Amansyah Samosir',
                    'Jisman Samosir',
                    'Omri Samosir',
                    'Op. Kenso Samosir',
                ],
                'pakar' => [
                    'Agunan Samosir',
                    'Dr. Osbin Samosir',
                    'Risto Samosir',
                    'Dr. Hollan Samosir',
                ],
            ],
            'kab-samosir' => [
                'title'    => 'Pengurus PTSBI Kab. Samosir',
                'layout'   => 'triad',
                'pimpinan' => [
                    [ 'pos' => 'center', 'role' => 'Ketua', 'name' => 'Daslon Samosir', 'photo' => 0 ],
                    [ 'pos' => 'left', 'role' => 'Sekretaris', 'name' => 'Freddy Samosir', 'photo' => 0 ],
                    [ 'pos' => 'right', 'role' => 'Bendahara', 'name' => 'Juni F Harianja', 'photo' => 0 ],
                ],
                'harian' => [
                    [ 'role' => 'Ketua I', 'name' => 'Jamron Samosir' ],
                    [ 'role' => 'Sekretaris I', 'name' => 'Andri Sembi Samosir' ],
                    [ 'role' => 'Sekretaris II', 'name' => 'Riwanto Samosir' ],
                    [ 'role' => 'Bendahara I', 'name' => 'Manatar Samosir' ],
                    [ 'role' => 'Bendahara II', 'name' => 'Jhon Wenry Samosir' ],
                ],
                'bidang' => [
                    [ 'title' => 'Bidang Adat dan Budaya', 'members' => [ [ 'role' => 'Ketua', 'name' => 'Patido Samosir' ] ] ],
                    [ 'title' => 'Bidang Sosial', 'members' => [ [ 'role' => 'Ketua', 'name' => 'Tondor Samosir' ] ] ],
                    [ 'title' => 'Bidang Organisasi', 'members' => [ [ 'role' => 'Ketua', 'name' => 'Alfonsus Samosir' ] ] ],
                    [ 'title' => 'Bidang Kepemudaan', 'members' => [ [ 'role' => 'Ketua', 'name' => 'Humisar Samosir' ] ] ],
                    [ 'title' => 'Koordinator Harian', 'members' => [ [ 'role' => 'Ketua', 'name' => 'Robert Samosir' ] ] ],
                ],
                'penasehat' => [],
                'pakar'     => [],
            ],
            'kota-medan' => [
                'title'    => 'Pengurus PTSBI Kota Medan 2025–2030',
                'layout'   => 'triad',
                'pimpinan' => [
                    [ 'pos' => 'center', 'role' => 'Ketua Umum', 'name' => 'Ir. Saidi Samosir', 'photo' => 0 ],
                    [ 'pos' => 'left', 'role' => 'Sekretaris Umum', 'name' => 'Tommy Samosir', 'photo' => 0 ],
                    [ 'pos' => 'right', 'role' => 'Bendahara Umum', 'name' => 'Parkin Sihaloho', 'photo' => 0 ],
                ],
                'harian' => [
                    [ 'role' => 'Ketua Harian', 'name' => 'Aron Samosir' ],
                    [ 'role' => 'Ketua I', 'name' => 'A.H. Samosir' ],
                    [ 'role' => 'Ketua II', 'name' => 'Lintong Samosir' ],
                    [ 'role' => 'Ketua III', 'name' => 'J. Samosir' ],
                    [ 'role' => 'Ketua IV', 'name' => 'AKBP. Dr. Parulian Samosir, S.H., M.H.' ],
                    [ 'role' => 'Sekretaris II', 'name' => 'Tunggul Samosir' ],
                ],
                'bidang' => [
                    [ 'title' => 'Bidang Adat dan Budaya', 'members' => [ [ 'role' => 'Koordinator', 'name' => 'Jennefer Samosir' ] ] ],
                    [ 'title' => 'Bidang Usaha Dana', 'members' => [ [ 'role' => 'Ketua', 'name' => 'St. Drs. D Samosir' ] ] ],
                    [ 'title' => 'Bidang Organisasi', 'members' => [ [ 'role' => 'Ketua', 'name' => 'Alfonsus Samosir' ] ] ],
                    [ 'title' => 'Bidang Kepemudaan, Sosial dan Pendidikan', 'members' => [ [ 'role' => 'Koordinator', 'name' => 'Ardin Dolok Saribu' ] ] ],
                    [ 'title' => 'Bidang Hukum', 'members' => [ [ 'role' => 'Koordinator', 'name' => 'Timbul Samosir' ] ] ],
                ],
                'penasehat' => [],
                'pakar'     => [],
            ],
            'pekanbaru' => [
                'title'    => 'Pengurus PTSBI Pekanbaru',
                'layout'   => 'ladder',
                'pimpinan' => [],
                'harian'   => [
                    [ 'role' => 'Ketua Umum', 'name' => 'Mangaratua Samosir' ],
                    [ 'role' => 'Ketua', 'name' => 'Jhonson Binsar Samosir' ],
                    [ 'role' => 'Wakil Ketua', 'name' => 'Parluhutan Samosir' ],
                    [ 'role' => 'Wakil Ketua', 'name' => 'Rexson Mangatur Samosir' ],
                    [ 'role' => 'Wakil Ketua', 'name' => 'Roncon Samosir' ],
                    [ 'role' => 'Wakil Ketua', 'name' => 'Parlindungan Samosir' ],
                    [ 'role' => 'Sekretaris', 'name' => 'Manuntun Samosir' ],
                    [ 'role' => 'Bendahara', 'name' => 'Nurdin Manullang' ],
                ],
                'bidang'    => [],
                'penasehat' => [],
                'pakar'     => [],
            ],
        ];
    }
}
