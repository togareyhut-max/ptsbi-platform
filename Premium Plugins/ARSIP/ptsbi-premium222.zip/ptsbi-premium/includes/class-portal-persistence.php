<?php
/**
 * Penyimpanan panel frontend: hindari cache halaman, flush opsi, jalur admin-ajax.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PTPRM_Portal_Persistence {

    public static function init(): void {
        add_action( 'template_redirect', [ __CLASS__, 'disable_page_cache_on_portals' ], 0 );
        add_action( 'wp_ajax_ptprm_save_member_profile', [ __CLASS__, 'route_member_profile' ] );
        add_action( 'wp_ajax_ptprm_save_org_structure', [ __CLASS__, 'route_org_structure' ] );
        add_action( 'wp_ajax_ptprm_save_admin_settings', [ __CLASS__, 'route_admin_settings' ] );
        add_action( 'wp_ajax_ptprm_save_admin_post', [ __CLASS__, 'route_admin_post' ] );
        add_action( 'wp_ajax_ptprm_approve_member', [ __CLASS__, 'route_approve_member' ] );
        add_action( 'wp_ajax_ptprm_reject_member', [ __CLASS__, 'route_reject_member' ] );
        add_action( 'wp_ajax_ptprm_import_members_csv', [ __CLASS__, 'route_import_csv' ] );
        add_action( 'wp_ajax_ptprm_bidang_save', [ __CLASS__, 'route_bidang_save' ] );
        add_action( 'wp_ajax_ptprm_member_register', [ __CLASS__, 'route_member_register' ] );
        add_action( 'wp_ajax_nopriv_ptprm_member_register', [ __CLASS__, 'route_member_register' ] );
    }

    public static function prepare_ajax_save(): void {
        if ( ! defined( 'DONOTCACHEPAGE' ) ) {
            define( 'DONOTCACHEPAGE', true );
        }
        nocache_headers();
    }

    public static function ajax_action_url( string $action ): string {
        return add_query_arg( 'action', $action, admin_url( 'admin-ajax.php' ) );
    }

    public static function disable_page_cache_on_portals(): void {
        if ( ! self::is_portal_front_page() ) {
            return;
        }
        if ( ! defined( 'DONOTCACHEPAGE' ) ) {
            define( 'DONOTCACHEPAGE', true );
        }
        if ( ! defined( 'DONOTCACHEOBJECT' ) ) {
            define( 'DONOTCACHEOBJECT', true );
        }
        if ( ! defined( 'DONOTCACHEDB' ) ) {
            define( 'DONOTCACHEDB', true );
        }
        nocache_headers();
    }

    public static function is_portal_front_page(): bool {
        if ( ! is_page() ) {
            return false;
        }
        $slug = (string) get_post_field( 'post_name', get_queried_object_id() );
        if ( class_exists( 'PTPRM_Member_Portal' ) && $slug === PTPRM_Member_Portal::portal_slug() ) {
            return true;
        }
        if ( class_exists( 'PTPRM_Admin_Portal' ) && $slug === PTPRM_Admin_Portal::portal_slug() ) {
            return true;
        }
        if ( class_exists( 'PTPRM_Login_Portal' ) && $slug === PTPRM_Login_Portal::login_slug() ) {
            return true;
        }
        if ( class_exists( 'PTPRM_Bidang_Registry' ) ) {
            foreach ( PTPRM_Bidang_Registry::definitions() as $def ) {
                if ( $slug === (string) ( $def['panel_slug'] ?? '' ) ) {
                    return true;
                }
            }
        }
        return false;
    }

    public static function route_member_profile(): void {
        self::prepare_ajax_save();
        if ( ! class_exists( 'PTPRM_Member_Portal' ) ) {
            wp_die( esc_html__( 'Modul tidak tersedia.', 'ptsbi-premium' ), 500 );
        }
        $portal = new PTPRM_Member_Portal();
        $portal->handle_profile_save();
    }

    public static function route_org_structure(): void {
        self::prepare_ajax_save();
        if ( class_exists( 'PTPRM_Org_Structure_Admin' ) ) {
            PTPRM_Org_Structure_Admin::handle_save();
        }
    }

    public static function route_admin_settings(): void {
        self::prepare_ajax_save();
        if ( class_exists( 'PTPRM_Admin_Portal' ) ) {
            $portal = new PTPRM_Admin_Portal();
            $portal->handle_save_settings();
        }
    }

    public static function route_admin_post(): void {
        self::prepare_ajax_save();
        if ( class_exists( 'PTPRM_Admin_Portal' ) ) {
            $portal = new PTPRM_Admin_Portal();
            $portal->handle_save_post();
        }
    }

    public static function route_approve_member(): void {
        self::prepare_ajax_save();
        if ( class_exists( 'PTPRM_Admin_Portal' ) ) {
            $portal = new PTPRM_Admin_Portal();
            $portal->handle_approve_pending_registrations();
        }
    }

    public static function route_reject_member(): void {
        self::prepare_ajax_save();
        if ( class_exists( 'PTPRM_Admin_Portal' ) ) {
            $portal = new PTPRM_Admin_Portal();
            $portal->handle_reject_pending_registrations();
        }
    }

    public static function route_import_csv(): void {
        self::prepare_ajax_save();
        if ( class_exists( 'PTPRM_Members' ) ) {
            $members = new PTPRM_Members();
            $members->handle_front_import_csv();
        }
    }

    public static function route_bidang_save(): void {
        self::prepare_ajax_save();
        if ( class_exists( 'PTPRM_Bidang_Portal' ) ) {
            PTPRM_Bidang_Portal::handle_forms();
        }
    }

    public static function route_member_register(): void {
        self::prepare_ajax_save();
        if ( class_exists( 'PTPRM_Members' ) ) {
            $members = new PTPRM_Members();
            $members->handle_front_registration();
        }
    }
}
