/* Premium Plugin — Frontend (minimal) */
(function () {
    'use strict';

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    function init() {
        animateStats();
        initGallerySliders();
        initLightbox();
        initPopup();
    }

    /* ===================================================================== */
    /* Gallery slider                                                        */
    /* ===================================================================== */

    function initGallerySliders() {
        var sliders = document.querySelectorAll('[data-ptprm-slider]');
        if (!sliders.length) return;
        Array.prototype.forEach.call(sliders, function (slider) {
            initOneSlider(slider);
        });
    }

    function initOneSlider(slider) {
        var track = slider.querySelector('.ptprm-slider-track');
        if (!track) return;
        var slides = track.querySelectorAll('.ptprm-slider-slide');
        if (slides.length < 2) return;

        var perView   = parseInt(slider.dataset.perView, 10) || 4;
        var autoplay  = parseInt(slider.dataset.autoplay, 10) || 0;
        var pauseHov  = slider.dataset.pause === '1';
        var idx       = 0;
        var timer     = null;

        function effectivePerView() {
            var w = window.innerWidth;
            if (w <= 480) return 1;
            if (w <= 768) return 2;
            if (w <= 1024) return 3;
            return perView;
        }

        slider.style.setProperty('--ptprm-pv', perView);
        Array.prototype.forEach.call(slides, function (s) { s.style.setProperty('--ptprm-pv', perView); });

        function maxIdx() { return Math.max(0, slides.length - effectivePerView()); }

        function go(to) {
            idx = Math.max(0, Math.min(to, maxIdx()));
            var slideW = slides[0].getBoundingClientRect().width;
            var gap = parseFloat(getComputedStyle(track).gap) || 14;
            track.style.transform = 'translateX(' + (-1 * idx * (slideW + gap)) + 'px)';
            updateDots();
        }

        function next() { idx >= maxIdx() ? go(0) : go(idx + 1); }
        function prev() { idx <= 0 ? go(maxIdx()) : go(idx - 1); }

        var prevBtn = slider.querySelector('.ptprm-slider-nav.prev');
        var nextBtn = slider.querySelector('.ptprm-slider-nav.next');
        if (prevBtn) prevBtn.addEventListener('click', function () { prev(); resetTimer(); });
        if (nextBtn) nextBtn.addEventListener('click', function () { next(); resetTimer(); });

        // Dots
        var dotsWrap = slider.querySelector('.ptprm-slider-dots');
        var dotEls = [];
        function buildDots() {
            if (!dotsWrap) return;
            dotsWrap.innerHTML = '';
            dotEls = [];
            for (var i = 0; i <= maxIdx(); i++) {
                (function (n) {
                    var b = document.createElement('button');
                    b.className = 'ptprm-slider-dot';
                    b.type = 'button';
                    b.setAttribute('aria-label', 'Slide ' + (n + 1));
                    b.addEventListener('click', function () { go(n); resetTimer(); });
                    dotsWrap.appendChild(b);
                    dotEls.push(b);
                })(i);
            }
            updateDots();
        }
        function updateDots() {
            for (var i = 0; i < dotEls.length; i++) {
                dotEls[i].classList.toggle('is-active', i === idx);
            }
        }

        function start() {
            if (!autoplay) return;
            stop();
            timer = setInterval(next, autoplay);
        }
        function stop() { if (timer) { clearInterval(timer); timer = null; } }
        function resetTimer() { stop(); start(); }

        if (pauseHov) {
            slider.addEventListener('mouseenter', stop);
            slider.addEventListener('mouseleave', start);
            slider.addEventListener('focusin', stop);
            slider.addEventListener('focusout', start);
        }

        var resizeTimer = null;
        window.addEventListener('resize', function () {
            if (resizeTimer) clearTimeout(resizeTimer);
            resizeTimer = setTimeout(function () {
                buildDots();
                go(idx);
            }, 120);
        });

        // Touch swipe
        var x0 = null;
        track.addEventListener('touchstart', function (e) { x0 = e.touches[0].clientX; }, { passive: true });
        track.addEventListener('touchend',   function (e) {
            if (x0 === null) return;
            var dx = e.changedTouches[0].clientX - x0;
            if (Math.abs(dx) > 40) (dx < 0 ? next : prev)();
            x0 = null;
            resetTimer();
        });

        buildDots();
        go(0);
        start();
    }

    /* ===================================================================== */
    /* Pop-up iklan                                                          */
    /* ===================================================================== */

    function initPopup() {
        var popup = document.querySelector('[data-ptprm-popup]');
        if (!popup) return;

        var delay     = parseInt(popup.dataset.delay, 10) || 3000;
        var frequency = popup.dataset.frequency || 'session';

        if (frequency === 'session') {
            try {
                if (sessionStorage.getItem('ptprm_popup_seen') === '1') return;
            } catch (e) {}
        } else if (frequency === 'day') {
            try {
                var ts = parseInt(localStorage.getItem('ptprm_popup_seen_ts'), 10) || 0;
                if (Date.now() - ts < 86400000) return;
            } catch (e) {}
        }

        function open() {
            popup.removeAttribute('hidden');
            popup.classList.add('is-visible');
            document.body.style.overflow = 'hidden';
        }
        function close() {
            popup.classList.remove('is-visible');
            popup.setAttribute('hidden', '');
            document.body.style.overflow = '';
            try {
                if (frequency === 'session')   sessionStorage.setItem('ptprm_popup_seen', '1');
                else if (frequency === 'day')  localStorage.setItem('ptprm_popup_seen_ts', String(Date.now()));
            } catch (e) {}
        }

        setTimeout(open, delay);

        var closers = popup.querySelectorAll('[data-ptprm-popup-close]');
        Array.prototype.forEach.call(closers, function (el) {
            el.addEventListener('click', close);
        });
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && popup.classList.contains('is-visible')) close();
        });
    }

    function initLightbox() {
        var items = document.querySelectorAll('[data-ptprm-lightbox]');
        if (!items.length) return;

        var images = Array.prototype.map.call(items, function (a) { return a.getAttribute('href'); });
        var idx = 0;

        var box = document.createElement('div');
        box.className = 'ptprm-lightbox';
        box.innerHTML =
            '<button class="ptprm-lightbox-close" aria-label="Tutup">&times;</button>' +
            '<button class="ptprm-lightbox-nav prev" aria-label="Sebelumnya">&#8592;</button>' +
            '<img alt="">' +
            '<button class="ptprm-lightbox-nav next" aria-label="Berikutnya">&#8594;</button>';
        document.body.appendChild(box);

        var img    = box.querySelector('img');
        var close  = box.querySelector('.ptprm-lightbox-close');
        var prev   = box.querySelector('.prev');
        var next   = box.querySelector('.next');

        function show(i) {
            idx = (i + images.length) % images.length;
            img.src = images[idx];
            box.classList.add('is-open');
            document.body.style.overflow = 'hidden';
        }
        function hide() {
            box.classList.remove('is-open');
            img.src = '';
            document.body.style.overflow = '';
        }

        Array.prototype.forEach.call(items, function (a, i) {
            a.addEventListener('click', function (e) {
                e.preventDefault();
                show(i);
            });
        });

        close.addEventListener('click', hide);
        prev.addEventListener('click', function () { show(idx - 1); });
        next.addEventListener('click', function () { show(idx + 1); });
        box.addEventListener('click', function (e) { if (e.target === box) hide(); });
        document.addEventListener('keydown', function (e) {
            if (!box.classList.contains('is-open')) return;
            if (e.key === 'Escape') hide();
            else if (e.key === 'ArrowLeft') show(idx - 1);
            else if (e.key === 'ArrowRight') show(idx + 1);
        });
    }

    function animateStats() {
        if (!window.PTPRM || !PTPRM.animateStats) return;
        if (!('IntersectionObserver' in window)) return;
        var nodes = document.querySelectorAll('[data-ptprm-counter]');
        if (!nodes.length) return;

        var io = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (!entry.isIntersecting) return;
                var el = entry.target;
                var raw = (el.textContent || '').trim();
                var m = raw.match(/(\d+)(.*)$/);
                if (!m) return;
                var target = parseInt(m[1], 10);
                var suffix = m[2] || '';
                if (!target) return;

                var start = 0;
                var dur = 1200;
                var t0 = null;
                function step(ts) {
                    if (!t0) t0 = ts;
                    var p = Math.min(1, (ts - t0) / dur);
                    var eased = 1 - Math.pow(1 - p, 3);
                    el.textContent = Math.floor(start + (target - start) * eased) + suffix;
                    if (p < 1) requestAnimationFrame(step);
                }
                requestAnimationFrame(step);
                io.unobserve(el);
            });
        }, { threshold: 0.4 });

        nodes.forEach(function (n) { io.observe(n); });
    }
})();
