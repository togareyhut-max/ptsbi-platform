/* Filter direktori: wilayah → provinsi → kota → kecamatan */
(function () {
    'use strict';

    function boot() {
        if (!window.PTPRM_AddressRegions) return;
        document.querySelectorAll('[data-ptprm-directory-filter]').forEach(function (form) {
            PTPRM_AddressRegions.initCascade(form, {
                defaultWilayah: 'jabodetabek',
                provinceSelector: 'select[name="provinsi"]',
                citySelector: 'select[name="kota"]',
                districtSelector: 'select[name="kecamatan"]',
                provincePlaceholder: 'Semua provinsi',
                cityPlaceholder: 'Semua kota',
                districtPlaceholder: 'Semua kecamatan'
            });
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
