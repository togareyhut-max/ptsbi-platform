<?php
/**
 * Admin settings page: tabs + sanitize + render.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PTPRM_Settings {

    const PAGE  = 'ptprm-settings';
    const GROUP = 'ptprm_group';

    public function __construct() {
        add_action( 'admin_menu', [ $this, 'menu' ] );
        add_action( 'admin_init', [ $this, 'register' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'assets' ] );
        add_filter( 'plugin_action_links_' . plugin_basename( PTPRM_FILE ), [ $this, 'action_links' ] );
    }

    public function menu() {
        add_menu_page(
            __( 'Premium Plugin', 'ptsbi-premium' ),
            __( 'Premium Plugin', 'ptsbi-premium' ),
            'manage_options',
            self::PAGE,
            [ $this, 'render' ],
            'data:image/svg+xml;base64,' . base64_encode(
                '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.4"><rect x="2.5" y="2.5" width="15" height="15" rx="2"/><path d="M10 5l1.3 3 3.2.2-2.5 2 .8 3.2L10 11.7 7.2 13.4l.8-3.2-2.5-2 3.2-.2z"/></svg>'
            ),
            58
        );
    }

    public function action_links( $links ) {
        $url = admin_url( 'admin.php?page=' . self::PAGE );
        array_unshift( $links, '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Pengaturan', 'ptsbi-premium' ) . '</a>' );
        return $links;
    }

    public function assets( $hook ) {
        if ( 'toplevel_page_' . self::PAGE !== $hook ) return;
        wp_enqueue_media();
        wp_enqueue_style( 'wp-color-picker' );
        wp_enqueue_script( 'wp-color-picker' );
        wp_enqueue_style( 'ptprm-admin', PTPRM_URL . 'assets/css/admin.css', [], PTPRM_VERSION );
        wp_enqueue_script( 'ptprm-admin', PTPRM_URL . 'assets/js/admin.js', [ 'jquery', 'wp-color-picker' ], PTPRM_VERSION, true );
        wp_localize_script( 'ptprm-admin', 'PTPRM_ADMIN', [
            'pluginUrl' => PTPRM_URL,
        ] );
    }

    public function register() {
        register_setting( self::GROUP, PTPRM_OPTION, [
            'type'              => 'array',
            'sanitize_callback' => [ $this, 'sanitize' ],
            'default'           => ptprm_defaults(),
        ] );
    }

    public function sanitize( $input ) {
        if ( ! is_array( $input ) ) $input = [];
        $d = ptprm_defaults();
        $c = [];

        $bools = [
            'enabled',
            'hero_show', 'hero_eyebrow_show', 'hero_title_show', 'hero_sub_show',
            'hero_overlay_gradient',
            'hero_eyebrow_shadow', 'hero_title_shadow', 'hero_sub_shadow',
            'cta1_show', 'cta2_show',
            'about_show', 'values_show', 'activities_show', 'stats_show', 'visit_show',
            'visit_show_address', 'visit_show_hours', 'visit_show_wa',
            'stats_animate',
            'footer_show', 'footer_show_social',
            'subpage_hero_show', 'subpage_breadcrumb', 'subpage_ornament', 'subpage_gorga', 'subpage_eyebrow_auto',
        ];
        foreach ( $bools as $k ) {
            $c[ $k ] = ! empty( $input[ $k ] ) ? 1 : 0;
        }

        $text_fields = [
            'org_name', 'whatsapp', 'hours',
            'hero_eyebrow_text', 'hero_title_text',
            'hero_height_mode', 'hero_text_align_h', 'hero_text_align_v', 'hero_animation', 'hero_img_position',
            'hero_eyebrow_weight', 'hero_eyebrow_style',
            'hero_title_weight', 'hero_title_style',
            'hero_sub_weight', 'hero_sub_style',
            'font_heading', 'font_body',
            'hero_eyebrow_font', 'hero_title_font', 'hero_sub_font',
            'cta1_label', 'cta1_target', 'cta1_icon', 'cta1_style', 'cta1_size',
            'cta2_label', 'cta2_target', 'cta2_icon', 'cta2_style', 'cta2_size',
            'about_eyebrow', 'about_title', 'about_layout', 'about_cta_label',
            'values_eyebrow', 'values_title',
            'values_1_icon', 'values_1_title', 'values_2_icon', 'values_2_title',
            'values_3_icon', 'values_3_title', 'values_4_icon', 'values_4_title',
            'activities_eyebrow', 'activities_title', 'activities_more_label',
            'stats_eyebrow', 'stats_title',
            'stats_a_num', 'stats_a_label', 'stats_b_num', 'stats_b_label',
            'stats_c_num', 'stats_c_label', 'stats_d_num', 'stats_d_label',
            'visit_eyebrow', 'visit_title',
            'footer_col1_label', 'footer_col2_label', 'footer_copyright',
        ];
        foreach ( $text_fields as $k ) {
            $c[ $k ] = isset( $input[ $k ] ) ? sanitize_text_field( (string) $input[ $k ] ) : ( $d[ $k ] ?? '' );
        }

        $textarea_fields = [
            'address', 'hero_sub_text', 'about_body', 'values_subtitle',
            'values_1_desc', 'values_2_desc', 'values_3_desc', 'values_4_desc',
            'activities_subtitle', 'visit_intro',
            'footer_tagline', 'footer_col1_links', 'footer_col2_links',
            'subpage_default_intro',
        ];
        foreach ( $textarea_fields as $k ) {
            $c[ $k ] = isset( $input[ $k ] ) ? sanitize_textarea_field( (string) $input[ $k ] ) : ( $d[ $k ] ?? '' );
        }

        $url_fields = [
            'fb_url', 'ig_url', 'yt_url', 'tt_url',
            'cta1_url', 'cta2_url', 'about_cta_url', 'activities_more_url',
            'visit_map_url', 'hero_img_desktop', 'hero_img_tablet', 'hero_img_mobile', 'about_image',
        ];
        foreach ( $url_fields as $k ) {
            $v = isset( $input[ $k ] ) ? trim( (string) $input[ $k ] ) : '';
            if ( $v === '' ) {
                $c[ $k ] = '';
            } elseif ( ctype_digit( $v ) ) {
                $c[ $k ] = (int) $v;
            } else {
                $c[ $k ] = esc_url_raw( $v );
            }
        }

        $color_fields = [
            'color_primary', 'color_accent', 'color_text', 'color_text_soft', 'color_cream',
            'hero_overlay_color',
            'hero_eyebrow_color', 'hero_title_color', 'hero_sub_color',
            'cta1_bg', 'cta1_color', 'cta1_bg_hover', 'cta1_color_hover',
            'cta2_bg', 'cta2_color', 'cta2_bg_hover', 'cta2_color_hover',
        ];
        foreach ( $color_fields as $k ) {
            $v = isset( $input[ $k ] ) ? trim( (string) $input[ $k ] ) : '';
            if ( $v === 'transparent' ) {
                $c[ $k ] = 'transparent';
            } else {
                $hex = sanitize_hex_color( $v );
                $c[ $k ] = $hex ? $hex : ( $d[ $k ] ?? '' );
            }
        }

        $int_fields = [
            'container_max'              => [ 600, 1600 ],
            'hero_overlay_opacity'       => [ 0, 100 ],
            'hero_height_desktop'        => [ 320, 1400 ],
            'hero_height_mobile'         => [ 320, 1200 ],
            'hero_text_max_width'        => [ 240, 1200 ],
            'hero_text_gap'              => [ 0, 80 ],
            'hero_eyebrow_size'          => [ 8, 60 ],
            'hero_eyebrow_size_mobile'   => [ 8, 60 ],
            'hero_eyebrow_letter_spacing'=> [ 0, 80 ],
            'hero_title_size'            => [ 20, 160 ],
            'hero_title_size_mobile'     => [ 16, 120 ],
            'hero_title_letter_spacing'  => [ -10, 30 ],
            'hero_title_line_height'     => [ 80, 200 ],
            'hero_sub_size'              => [ 10, 40 ],
            'hero_sub_size_mobile'       => [ 10, 36 ],
            'hero_sub_letter_spacing'    => [ -10, 30 ],
            'hero_sub_line_height'       => [ 100, 240 ],
            'cta1_radius'                => [ 0, 60 ],
            'cta2_radius'                => [ 0, 60 ],
            'activities_count'           => [ 1, 12 ],
            'activities_category'        => [ 0, 99999 ],
            'subpage_overlay'            => [ 0, 100 ],
        ];
        foreach ( $int_fields as $k => $range ) {
            $v = isset( $input[ $k ] ) ? (int) $input[ $k ] : (int) ( $d[ $k ] ?? 0 );
            $c[ $k ] = max( $range[0], min( $range[1], $v ) );
        }

        return $c;
    }

    /* ===================================================================== */
    /* RENDER                                                                */
    /* ===================================================================== */

    public function render() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        $o   = ptprm_options();
        $opt = PTPRM_OPTION;
        $tabs = [
            'umum'      => '⚙ Umum',
            'hero'      => '🎯 Hero',
            'beranda'   => '🏠 Beranda',
            'subpage'   => '📄 Sub-halaman',
            'footer'    => '🦶 Footer',
        ];
        ?>
        <div class="wrap ptprm-wrap">
            <div class="ptprm-topbar">
                <div class="ptprm-brand">
                    <strong>Premium Plugin</strong>
                    <span class="ptprm-ver">v<?php echo esc_html( PTPRM_VERSION ); ?></span>
                </div>
                <div class="ptprm-topbar-actions">
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank" class="button button-secondary">Buka Beranda</a>
                </div>
            </div>

            <form method="post" action="options.php" class="ptprm-form" id="ptprm-form">
                <?php settings_fields( self::GROUP ); ?>

                <div class="ptprm-layout">
                    <aside class="ptprm-sidebar">
                        <ul class="ptprm-tabs">
                            <?php foreach ( $tabs as $slug => $label ) : ?>
                                <li><a href="#tab-<?php echo esc_attr( $slug ); ?>" data-tab="<?php echo esc_attr( $slug ); ?>" class="<?php echo 'umum' === $slug ? 'is-active' : ''; ?>"><?php echo esc_html( $label ); ?></a></li>
                            <?php endforeach; ?>
                        </ul>
                        <div class="ptprm-save-box">
                            <?php submit_button( 'Simpan Perubahan', 'primary', 'submit', false ); ?>
                        </div>
                    </aside>

                    <main class="ptprm-main">
                        <?php $this->panel_umum( $o, $opt ); ?>
                        <?php $this->panel_hero( $o, $opt ); ?>
                        <?php $this->panel_beranda( $o, $opt ); ?>
                        <?php $this->panel_subpage( $o, $opt ); ?>
                        <?php $this->panel_footer( $o, $opt ); ?>
                    </main>
                </div>
            </form>
        </div>
        <?php
    }

    /* -- PANEL: UMUM -- */

    private function panel_umum( $o, $opt ) {
        ?>
        <section class="ptprm-panel" id="tab-umum" data-panel="umum">
            <h2>Pengaturan Umum</h2>
            <p class="ptprm-help">Identitas organisasi, warna, font, dan kontak global.</p>

            <div class="ptprm-card">
                <h3>Identitas</h3>
                <?php $this->t( 'Nama organisasi', 'org_name', $o, $opt ); ?>
            </div>

            <div class="ptprm-grid-2">
                <div class="ptprm-card">
                    <h3>Warna Brand</h3>
                    <?php
                    $this->color( 'Warna Primer (navy)',  'color_primary',   $o, $opt );
                    $this->color( 'Warna Aksen (emas)',   'color_accent',    $o, $opt );
                    $this->color( 'Warna Teks Utama',     'color_text',      $o, $opt );
                    $this->color( 'Warna Teks Halus',     'color_text_soft', $o, $opt );
                    $this->color( 'Warna Krem (BG soft)', 'color_cream',     $o, $opt );
                    ?>
                    <div class="ptprm-presets">
                        <span>Preset:</span>
                        <button type="button" class="button button-secondary ptprm-preset" data-primary="#0A1F3D" data-accent="#C9A44C">Navy + Emas</button>
                        <button type="button" class="button button-secondary ptprm-preset" data-primary="#0E3B2E" data-accent="#D4AF37">Hijau + Emas</button>
                        <button type="button" class="button button-secondary ptprm-preset" data-primary="#1A1A1A" data-accent="#C9A44C">Hitam + Emas</button>
                    </div>
                </div>
                <div class="ptprm-card">
                    <h3>Font Default</h3>
                    <?php
                    $this->select( 'Font Heading', 'font_heading', $o, $opt, ptprm_font_choices() );
                    $this->select( 'Font Body',    'font_body',    $o, $opt, ptprm_font_choices() );
                    $this->number( 'Lebar konten maks. (px)', 'container_max', $o, $opt, 600, 1600 );
                    ?>
                </div>
            </div>

            <div class="ptprm-grid-2">
                <div class="ptprm-card">
                    <h3>Kontak & Alamat</h3>
                    <?php
                    $this->t( 'Nomor WhatsApp (mis. +6281xxxx)', 'whatsapp', $o, $opt );
                    $this->ta( 'Alamat lengkap', 'address', $o, $opt, 3 );
                    $this->t( 'Jam operasional', 'hours', $o, $opt );
                    ?>
                </div>
                <div class="ptprm-card">
                    <h3>Sosial Media</h3>
                    <?php
                    $this->url( 'Facebook',  'fb_url', $o, $opt );
                    $this->url( 'Instagram', 'ig_url', $o, $opt );
                    $this->url( 'YouTube',   'yt_url', $o, $opt );
                    $this->url( 'TikTok',    'tt_url', $o, $opt );
                    ?>
                </div>
            </div>
        </section>
        <?php
    }

    /* -- PANEL: HERO -- */

    private function panel_hero( $o, $opt ) {
        ?>
        <section class="ptprm-panel" id="tab-hero" data-panel="hero" hidden>
            <h2>Hero & Tombol CTA</h2>
            <p class="ptprm-help">Atur gambar, teks, dan 2 tombol. Preview di bawah update otomatis saat Anda mengetik.</p>

            <?php $this->section_toggle( 'hero_show', 'Tampilkan section Hero', $o, $opt ); ?>

            <!-- LIVE PREVIEW -->
            <div class="ptprm-preview-card">
                <div class="ptprm-preview-bar">
                    <strong>Preview</strong>
                    <span class="ptprm-preview-help">Tidak persis 1:1 dengan situs; tujuan untuk gambaran cepat saat mengedit.</span>
                </div>
                <div class="ptprm-preview-frame" id="ptprm-hero-preview">
                    <div class="pv-media"><img src="" alt="" id="pv-img"><div class="pv-overlay" id="pv-overlay"></div></div>
                    <div class="pv-inner" id="pv-inner">
                        <span class="pv-eyebrow" id="pv-eyebrow"></span>
                        <h1 class="pv-title" id="pv-title"></h1>
                        <p class="pv-sub" id="pv-sub"></p>
                        <div class="pv-cta-row">
                            <a class="pv-cta pv-cta1" id="pv-cta1"><span class="pv-cta-icon" id="pv-cta1-icon"></span><span id="pv-cta1-label"></span></a>
                            <a class="pv-cta pv-cta2" id="pv-cta2"><span class="pv-cta-icon" id="pv-cta2-icon"></span><span id="pv-cta2-label"></span></a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="ptprm-grid-2">
                <div class="ptprm-card">
                    <h3>Gambar Latar (responsif)</h3>
                    <?php
                    $this->image( 'Gambar Desktop (≥1920×900)', 'hero_img_desktop', $o, $opt );
                    $this->image( 'Gambar Tablet (opsional)',    'hero_img_tablet',  $o, $opt );
                    $this->image( 'Gambar Mobile (opsional)',    'hero_img_mobile',  $o, $opt );
                    $this->select( 'Posisi fokus gambar', 'hero_img_position', $o, $opt, [
                        'center 35%' => 'Tengah-atas (rekomendasi wajah)',
                        'center center' => 'Tengah',
                        'center top'    => 'Atas',
                        'center bottom' => 'Bawah',
                        'left center'   => 'Kiri',
                        'right center'  => 'Kanan',
                    ] );
                    ?>
                </div>
                <div class="ptprm-card">
                    <h3>Overlay & Tinggi</h3>
                    <?php
                    $this->color( 'Warna overlay',          'hero_overlay_color',   $o, $opt );
                    $this->range( 'Opasitas overlay (0–100%)', 'hero_overlay_opacity', $o, $opt, 0, 100 );
                    $this->bool(  'Gradient overlay (kiri lebih gelap)', 'hero_overlay_gradient', $o, $opt );
                    $this->select( 'Tinggi hero', 'hero_height_mode', $o, $opt, [
                        'small'    => 'Kecil (≈60vh)',
                        'standard' => 'Standar (80vh) — rekomendasi',
                        'tall'     => 'Tinggi (90vh)',
                        'full'     => 'Penuh layar (100vh)',
                        'custom'   => 'Custom (px)',
                    ] );
                    $this->number( 'Tinggi custom desktop (px)', 'hero_height_desktop', $o, $opt, 320, 1400 );
                    $this->number( 'Tinggi custom mobile (px)',  'hero_height_mobile',  $o, $opt, 320, 1200 );
                    ?>
                </div>
            </div>

            <div class="ptprm-card">
                <h3>Layout Teks</h3>
                <div class="ptprm-grid-3">
                    <?php
                    $this->select( 'Posisi horizontal', 'hero_text_align_h', $o, $opt, [
                        'left' => 'Kiri', 'center' => 'Tengah', 'right' => 'Kanan',
                    ] );
                    $this->select( 'Posisi vertikal', 'hero_text_align_v', $o, $opt, [
                        'top' => 'Atas', 'middle' => 'Tengah', 'bottom' => 'Bawah',
                    ] );
                    $this->select( 'Animasi muncul', 'hero_animation', $o, $opt, [
                        'none' => 'Tidak ada', 'fade' => 'Fade', 'fade-up' => 'Fade-up', 'slide-in' => 'Slide-in',
                    ] );
                    $this->number( 'Lebar maks. teks (px)', 'hero_text_max_width', $o, $opt, 240, 1200 );
                    $this->number( 'Jarak antar elemen (px)', 'hero_text_gap', $o, $opt, 0, 80 );
                    ?>
                </div>
            </div>

            <?php $this->hero_text_card( 'Eyebrow (label kecil)', 'hero_eyebrow', $o, $opt, false ); ?>
            <?php $this->hero_text_card( 'Judul utama (H1)',      'hero_title',   $o, $opt, true  ); ?>
            <?php $this->hero_text_card( 'Subjudul (paragraf)',   'hero_sub',     $o, $opt, true  ); ?>

            <?php $this->cta_card( 'Tombol 1 (Primer)', 1, $o, $opt ); ?>
            <?php $this->cta_card( 'Tombol 2 (Sekunder)', 2, $o, $opt ); ?>
        </section>
        <?php
    }

    private function hero_text_card( $title, $prefix, $o, $opt, $with_line_height = false ) {
        ?>
        <div class="ptprm-card">
            <h3><?php echo esc_html( $title ); ?></h3>
            <?php $this->bool( 'Tampilkan', $prefix . '_show', $o, $opt ); ?>
            <?php
            if ( $prefix === 'hero_sub' ) {
                $this->ta( 'Teks', $prefix . '_text', $o, $opt, 3 );
            } else {
                $this->t( 'Teks', $prefix . '_text', $o, $opt );
            }
            ?>
            <div class="ptprm-grid-3">
                <?php
                $this->select( 'Font', $prefix . '_font', $o, $opt, ptprm_font_choices() );
                $this->select( 'Bobot', $prefix . '_weight', $o, $opt, [
                    '300' => '300 Light', '400' => '400 Regular', '500' => '500 Medium',
                    '600' => '600 Semi-bold', '700' => '700 Bold', '800' => '800 Extra-bold',
                ] );
                $this->select( 'Style', $prefix . '_style', $o, $opt, [
                    'normal' => 'Normal', 'italic' => 'Italic', 'uppercase' => 'UPPERCASE', 'capitalize' => 'Capitalize',
                ] );
                $this->color( 'Warna', $prefix . '_color', $o, $opt );
                $this->number( 'Ukuran desktop (px)', $prefix . '_size',        $o, $opt, 8, 200 );
                $this->number( 'Ukuran mobile (px)',  $prefix . '_size_mobile', $o, $opt, 8, 160 );
                $this->number( 'Letter spacing (×0.01em)', $prefix . '_letter_spacing', $o, $opt, -10, 80 );
                if ( $with_line_height ) {
                    $this->number( 'Line height (×0.01)', $prefix . '_line_height', $o, $opt, 80, 240 );
                }
                $this->bool( 'Bayangan teks', $prefix . '_shadow', $o, $opt );
                ?>
            </div>
        </div>
        <?php
    }

    private function cta_card( $title, $i, $o, $opt ) {
        ?>
        <div class="ptprm-card">
            <h3><?php echo esc_html( $title ); ?></h3>
            <?php $this->bool( 'Tampilkan', "cta{$i}_show", $o, $opt ); ?>
            <div class="ptprm-grid-3">
                <?php
                $this->t(   'Label tombol', "cta{$i}_label", $o, $opt );
                $this->url( 'URL tujuan',   "cta{$i}_url",   $o, $opt );
                $this->select( 'Target',    "cta{$i}_target", $o, $opt, [
                    '_self' => 'Tab sama', '_blank' => 'Tab baru',
                ] );
                $this->select( 'Ikon',      "cta{$i}_icon",  $o, $opt, ptprm_icon_choices() );
                $this->select( 'Style',     "cta{$i}_style", $o, $opt, [
                    'solid'   => 'Solid',
                    'outline' => 'Outline',
                    'ghost'   => 'Ghost',
                ] );
                $this->select( 'Ukuran',    "cta{$i}_size",  $o, $opt, [
                    'small' => 'Kecil', 'medium' => 'Sedang', 'large' => 'Besar',
                ] );
                $this->color( 'BG',           "cta{$i}_bg",          $o, $opt );
                $this->color( 'Teks',         "cta{$i}_color",       $o, $opt );
                $this->color( 'BG hover',     "cta{$i}_bg_hover",    $o, $opt );
                $this->color( 'Teks hover',   "cta{$i}_color_hover", $o, $opt );
                $this->number( 'Radius (px)', "cta{$i}_radius",      $o, $opt, 0, 60 );
                ?>
            </div>
        </div>
        <?php
    }

    /* -- PANEL: BERANDA (selain Hero) -- */

    private function panel_beranda( $o, $opt ) {
        ?>
        <section class="ptprm-panel" id="tab-beranda" data-panel="beranda" hidden>
            <h2>Section Beranda</h2>
            <p class="ptprm-help">Urutan: Hero → Tentang → Nilai-Nilai → Kegiatan → Statistik → Kunjungi. Setiap section punya toggle Tampilkan.</p>

            <!-- ABOUT -->
            <div class="ptprm-card">
                <h3>Tentang Kami</h3>
                <?php $this->bool( 'Tampilkan section', 'about_show', $o, $opt ); ?>
                <div class="ptprm-grid-2">
                    <div>
                        <?php
                        $this->t( 'Eyebrow', 'about_eyebrow', $o, $opt );
                        $this->t( 'Judul',  'about_title',   $o, $opt );
                        $this->ta( 'Isi paragraf', 'about_body', $o, $opt, 6 );
                        $this->t( 'Label tombol (opsional)', 'about_cta_label', $o, $opt );
                        $this->url( 'URL tombol (opsional)',  'about_cta_url',  $o, $opt );
                        ?>
                    </div>
                    <div>
                        <?php
                        $this->image( 'Gambar (opsional)', 'about_image', $o, $opt );
                        $this->select( 'Layout', 'about_layout', $o, $opt, [
                            'image-left'  => 'Gambar kiri, teks kanan',
                            'image-right' => 'Gambar kanan, teks kiri',
                            'text-only'   => 'Teks saja',
                        ] );
                        ?>
                    </div>
                </div>
            </div>

            <!-- VALUES -->
            <div class="ptprm-card">
                <h3>Nilai-Nilai Kami</h3>
                <?php
                $this->bool( 'Tampilkan section', 'values_show', $o, $opt );
                $this->t(  'Eyebrow',  'values_eyebrow',  $o, $opt );
                $this->t(  'Judul',    'values_title',    $o, $opt );
                $this->ta( 'Subjudul', 'values_subtitle', $o, $opt, 2 );
                ?>
                <div class="ptprm-grid-2">
                    <?php for ( $i = 1; $i <= 4; $i++ ) : ?>
                        <div class="ptprm-mini-card">
                            <strong>Nilai <?php echo $i; ?></strong>
                            <?php
                            $this->select( 'Ikon',     "values_{$i}_icon",  $o, $opt, ptprm_icon_choices() );
                            $this->t(      'Judul',    "values_{$i}_title", $o, $opt );
                            $this->ta(     'Deskripsi','values_{$i}_desc',  $o, $opt, 2 );
                            ?>
                        </div>
                    <?php endfor; ?>
                </div>
            </div>

            <!-- ACTIVITIES -->
            <div class="ptprm-card">
                <h3>Kegiatan Kami</h3>
                <?php $this->bool( 'Tampilkan section', 'activities_show', $o, $opt ); ?>
                <div class="ptprm-grid-2">
                    <div>
                        <?php
                        $this->t(  'Eyebrow',  'activities_eyebrow',  $o, $opt );
                        $this->t(  'Judul',    'activities_title',    $o, $opt );
                        $this->ta( 'Subjudul', 'activities_subtitle', $o, $opt, 2 );
                        ?>
                    </div>
                    <div>
                        <?php
                        $this->number( 'Jumlah kartu', 'activities_count', $o, $opt, 1, 12 );
                        $this->category_select( 'Kategori', 'activities_category', $o, $opt );
                        $this->t(   'Label tombol "lihat semua"', 'activities_more_label', $o, $opt );
                        $this->url( 'URL halaman semua kegiatan', 'activities_more_url',   $o, $opt );
                        ?>
                    </div>
                </div>
                <p class="ptprm-help">Data diambil otomatis dari post WordPress terbaru. Pastikan post punya gambar utama (featured image).</p>
            </div>

            <!-- STATS -->
            <div class="ptprm-card">
                <h3>Statistik</h3>
                <?php
                $this->bool( 'Tampilkan section', 'stats_show', $o, $opt );
                $this->t( 'Eyebrow', 'stats_eyebrow', $o, $opt );
                $this->t( 'Judul',   'stats_title',   $o, $opt );
                $this->bool( 'Animasi naik angka saat scroll', 'stats_animate', $o, $opt );
                ?>
                <div class="ptprm-grid-2">
                    <?php foreach ( [ 'a', 'b', 'c', 'd' ] as $k ) : ?>
                        <div class="ptprm-mini-card">
                            <strong>Statistik <?php echo strtoupper( $k ); ?></strong>
                            <?php
                            $this->t( 'Angka (mis. 10+)',  "stats_{$k}_num",   $o, $opt );
                            $this->t( 'Label',             "stats_{$k}_label", $o, $opt );
                            ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- VISIT -->
            <div class="ptprm-card">
                <h3>Kunjungi Kami</h3>
                <?php $this->bool( 'Tampilkan section', 'visit_show', $o, $opt ); ?>
                <div class="ptprm-grid-2">
                    <div>
                        <?php
                        $this->t(  'Eyebrow',  'visit_eyebrow', $o, $opt );
                        $this->t(  'Judul',    'visit_title',   $o, $opt );
                        $this->ta( 'Paragraf', 'visit_intro',   $o, $opt, 3 );
                        ?>
                    </div>
                    <div>
                        <?php
                        $this->bool( 'Tampilkan alamat',  'visit_show_address', $o, $opt );
                        $this->bool( 'Tampilkan jam',     'visit_show_hours',   $o, $opt );
                        $this->bool( 'Tampilkan WA',      'visit_show_wa',      $o, $opt );
                        $this->ta(   'URL embed Google Maps', 'visit_map_url',  $o, $opt, 3 );
                        ?>
                    </div>
                </div>
                <p class="ptprm-help">Untuk URL maps: di Google Maps → Bagikan → Sematkan peta → salin nilai <code>src</code> dari iframe.</p>
            </div>
        </section>
        <?php
    }

    /* -- PANEL: SUBPAGE -- */

    private function panel_subpage( $o, $opt ) {
        ?>
        <section class="ptprm-panel" id="tab-subpage" data-panel="subpage" hidden>
            <h2>Header Sub-halaman</h2>
            <p class="ptprm-help">Hero ini muncul di semua sub-halaman (Program Kerja, Tarombo, dll.) dengan gaya seragam. Gambar header memakai featured image halaman; kalau tidak ada, pakai pola Gorga di atas warna primer.</p>

            <div class="ptprm-card">
                <?php
                $this->bool( 'Tampilkan hero sub-halaman',    'subpage_hero_show',  $o, $opt );
                $this->bool( 'Tampilkan breadcrumb',          'subpage_breadcrumb', $o, $opt );
                $this->bool( 'Tampilkan ornamen emas',        'subpage_ornament',   $o, $opt );
                $this->bool( 'Tampilkan corak Gorga Batak',   'subpage_gorga',      $o, $opt );
                $this->bool( 'Eyebrow otomatis (= judul kapital)', 'subpage_eyebrow_auto', $o, $opt );
                $this->range( 'Opasitas overlay (0–100%)',    'subpage_overlay',    $o, $opt, 0, 100 );
                $this->ta(    'Intro default (jika halaman tidak punya)', 'subpage_default_intro', $o, $opt, 3 );
                ?>
            </div>
        </section>
        <?php
    }

    /* -- PANEL: FOOTER -- */

    private function panel_footer( $o, $opt ) {
        ?>
        <section class="ptprm-panel" id="tab-footer" data-panel="footer" hidden>
            <h2>Footer</h2>
            <p class="ptprm-help">Footer plugin akan menggantikan footer tema otomatis.</p>

            <div class="ptprm-card">
                <?php
                $this->bool( 'Tampilkan footer plugin', 'footer_show', $o, $opt );
                $this->ta(   'Tagline (paragraf brand)', 'footer_tagline', $o, $opt, 3 );
                ?>
            </div>

            <div class="ptprm-grid-2">
                <div class="ptprm-card">
                    <h3>Kolom Tautan 1</h3>
                    <?php
                    $this->t(  'Judul kolom', 'footer_col1_label', $o, $opt );
                    $this->ta( 'Tautan (satu per baris, format: Teks|URL)', 'footer_col1_links', $o, $opt, 6 );
                    ?>
                </div>
                <div class="ptprm-card">
                    <h3>Kolom Tautan 2</h3>
                    <?php
                    $this->t(  'Judul kolom', 'footer_col2_label', $o, $opt );
                    $this->ta( 'Tautan (satu per baris, format: Teks|URL)', 'footer_col2_links', $o, $opt, 6 );
                    ?>
                </div>
            </div>

            <div class="ptprm-card">
                <?php
                $this->bool( 'Tampilkan ikon sosial media', 'footer_show_social', $o, $opt );
                $this->t( 'Baris copyright (gunakan {year} dan {org})', 'footer_copyright', $o, $opt );
                ?>
            </div>
        </section>
        <?php
    }

    /* ===================================================================== */
    /* FIELDS                                                                */
    /* ===================================================================== */

    private function n( $key, $opt ) { return esc_attr( $opt . '[' . $key . ']' ); }
    private function v( $key, $o )   { return isset( $o[ $key ] ) ? $o[ $key ] : ''; }

    private function t( $label, $key, $o, $opt ) {
        ?>
        <label class="ptprm-field">
            <span class="ptprm-label"><?php echo esc_html( $label ); ?></span>
            <input type="text" class="regular-text" name="<?php echo $this->n( $key, $opt ); ?>" value="<?php echo esc_attr( $this->v( $key, $o ) ); ?>" data-ptprm="<?php echo esc_attr( $key ); ?>">
        </label>
        <?php
    }

    private function ta( $label, $key, $o, $opt, $rows = 4 ) {
        ?>
        <label class="ptprm-field">
            <span class="ptprm-label"><?php echo esc_html( $label ); ?></span>
            <textarea rows="<?php echo (int) $rows; ?>" class="large-text" name="<?php echo $this->n( $key, $opt ); ?>" data-ptprm="<?php echo esc_attr( $key ); ?>"><?php echo esc_textarea( $this->v( $key, $o ) ); ?></textarea>
        </label>
        <?php
    }

    private function url( $label, $key, $o, $opt ) {
        ?>
        <label class="ptprm-field">
            <span class="ptprm-label"><?php echo esc_html( $label ); ?></span>
            <input type="url" class="regular-text" name="<?php echo $this->n( $key, $opt ); ?>" value="<?php echo esc_attr( $this->v( $key, $o ) ); ?>" placeholder="https://" data-ptprm="<?php echo esc_attr( $key ); ?>">
        </label>
        <?php
    }

    private function number( $label, $key, $o, $opt, $min = 0, $max = 1000 ) {
        ?>
        <label class="ptprm-field">
            <span class="ptprm-label"><?php echo esc_html( $label ); ?></span>
            <input type="number" min="<?php echo (int) $min; ?>" max="<?php echo (int) $max; ?>" name="<?php echo $this->n( $key, $opt ); ?>" value="<?php echo esc_attr( $this->v( $key, $o ) ); ?>" data-ptprm="<?php echo esc_attr( $key ); ?>">
        </label>
        <?php
    }

    private function range( $label, $key, $o, $opt, $min = 0, $max = 100 ) {
        $val = (int) $this->v( $key, $o );
        ?>
        <label class="ptprm-field ptprm-range">
            <span class="ptprm-label"><?php echo esc_html( $label ); ?> <span class="ptprm-range-val"><?php echo $val; ?></span></span>
            <input type="range" min="<?php echo (int) $min; ?>" max="<?php echo (int) $max; ?>" name="<?php echo $this->n( $key, $opt ); ?>" value="<?php echo (int) $val; ?>" data-ptprm="<?php echo esc_attr( $key ); ?>">
        </label>
        <?php
    }

    private function color( $label, $key, $o, $opt ) {
        ?>
        <label class="ptprm-field">
            <span class="ptprm-label"><?php echo esc_html( $label ); ?></span>
            <input type="text" class="ptprm-color regular-text" name="<?php echo $this->n( $key, $opt ); ?>" value="<?php echo esc_attr( $this->v( $key, $o ) ); ?>" data-ptprm="<?php echo esc_attr( $key ); ?>" data-default-color="<?php echo esc_attr( $this->v( $key, $o ) ); ?>">
        </label>
        <?php
    }

    private function bool( $label, $key, $o, $opt ) {
        ?>
        <label class="ptprm-switch">
            <input type="checkbox" name="<?php echo $this->n( $key, $opt ); ?>" value="1" <?php checked( 1, (int) $this->v( $key, $o ) ); ?> data-ptprm="<?php echo esc_attr( $key ); ?>">
            <span><?php echo esc_html( $label ); ?></span>
        </label>
        <?php
    }

    private function section_toggle( $key, $label, $o, $opt ) {
        echo '<div class="ptprm-card ptprm-card-toggle">';
        $this->bool( $label, $key, $o, $opt );
        echo '</div>';
    }

    private function select( $label, $key, $o, $opt, $options ) {
        $val = (string) $this->v( $key, $o );
        ?>
        <label class="ptprm-field">
            <span class="ptprm-label"><?php echo esc_html( $label ); ?></span>
            <select name="<?php echo $this->n( $key, $opt ); ?>" data-ptprm="<?php echo esc_attr( $key ); ?>">
                <?php foreach ( $options as $k => $lab ) : ?>
                    <option value="<?php echo esc_attr( $k ); ?>" <?php selected( $val, (string) $k ); ?>><?php echo esc_html( $lab ); ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <?php
    }

    private function image( $label, $key, $o, $opt ) {
        $val = $this->v( $key, $o );
        $url = ptprm_image_url( $val );
        ?>
        <div class="ptprm-field ptprm-image-field">
            <span class="ptprm-label"><?php echo esc_html( $label ); ?></span>
            <div class="ptprm-image-control">
                <div class="ptprm-image-preview" style="<?php echo $url ? 'background-image:url(' . esc_url( $url ) . ');' : ''; ?>"></div>
                <input type="hidden" name="<?php echo $this->n( $key, $opt ); ?>" value="<?php echo esc_attr( $val ); ?>" class="ptprm-image-value" data-ptprm="<?php echo esc_attr( $key ); ?>">
                <button type="button" class="button ptprm-image-pick">Pilih gambar</button>
                <button type="button" class="button ptprm-image-clear">Hapus</button>
            </div>
        </div>
        <?php
    }

    private function category_select( $label, $key, $o, $opt ) {
        $val   = (int) $this->v( $key, $o );
        $terms = get_categories( [ 'hide_empty' => false ] );
        ?>
        <label class="ptprm-field">
            <span class="ptprm-label"><?php echo esc_html( $label ); ?></span>
            <select name="<?php echo $this->n( $key, $opt ); ?>" data-ptprm="<?php echo esc_attr( $key ); ?>">
                <option value="0" <?php selected( 0, $val ); ?>>— semua kategori —</option>
                <?php foreach ( $terms as $term ) : ?>
                    <option value="<?php echo (int) $term->term_id; ?>" <?php selected( $val, (int) $term->term_id ); ?>><?php echo esc_html( $term->name ); ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <?php
    }
}
