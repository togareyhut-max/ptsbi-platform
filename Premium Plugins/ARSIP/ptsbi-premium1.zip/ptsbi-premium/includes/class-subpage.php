<?php
/**
 * Sub-page hero wrapper. Injected before the entry-content of any single
 * Page (not front page, not posts) using the `the_content` filter.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PTPRM_Subpage {

    public function __construct() {
        add_filter( 'the_content', [ $this, 'inject_subhero' ], 8 );
    }

    public function inject_subhero( $content ) {
        if ( is_admin() || ! in_the_loop() || ! is_main_query() ) {
            return $content;
        }
        if ( is_front_page() || is_home() ) {
            return $content;
        }
        if ( ! is_page() ) {
            return $content;
        }
        if ( empty( ptprm_get( 'subpage_hero_show', 1 ) ) ) {
            return $content;
        }

        ob_start();
        PTPRM_Renderer::subpage_hero();
        echo '<div class="ptprm-subpage-content"><div class="ptprm-container">';
        echo $content; // already filtered upstream
        echo '</div></div>';
        return ob_get_clean();
    }
}
