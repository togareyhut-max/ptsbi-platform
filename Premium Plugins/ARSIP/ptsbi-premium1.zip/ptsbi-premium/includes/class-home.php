<?php
/**
 * Take over the homepage content with our premium sections.
 * Theme header/footer are kept (Astra menu still appears).
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PTPRM_Home {

    public function __construct() {
        add_filter( 'the_content', [ $this, 'replace_home_content' ], 9 );
        add_filter( 'body_class',  [ $this, 'body_class' ] );
        add_action( 'wp_body_open', [ $this, 'maybe_buffer_footer' ], 99 );
        add_action( 'wp_footer',    [ $this, 'render_premium_footer' ], 9 );
    }

    public function body_class( $classes ) {
        if ( is_front_page() || is_home() ) {
            $classes[] = 'ptprm-is-home';
        }
        if ( is_page() && ! is_front_page() ) {
            $classes[] = 'ptprm-is-subpage';
        }
        return $classes;
    }

    /**
     * Replace homepage entry content with our rendered sections.
     */
    public function replace_home_content( $content ) {
        if ( ! is_main_query() || ! in_the_loop() ) {
            return $content;
        }
        if ( ! ( is_front_page() || is_home() ) ) {
            return $content;
        }

        ob_start();
        PTPRM_Renderer::home();
        $html = ob_get_clean();

        return $html;
    }

    public function maybe_buffer_footer() {
        // Reserved for future page-template work; no-op for now.
    }

    /**
     * Render premium footer right before </body>; CSS hides theme footer.
     */
    public function render_premium_footer() {
        $o = ptprm_options();
        if ( empty( $o['footer_show'] ) ) {
            return;
        }
        PTPRM_Renderer::footer();
    }
}
