/* Premium Plugin — Admin (tabs, image picker, color picker, live preview) */
(function ($) {
    'use strict';

    $(function () {
        initTabs();
        initColorPickers();
        initImageFields();
        initRangeReadouts();
        initPresets();
        initLivePreview();
    });

    function initTabs() {
        var $tabs = $('.ptprm-tabs a');
        $tabs.on('click', function (e) {
            e.preventDefault();
            var slug = $(this).data('tab');
            $tabs.removeClass('is-active');
            $(this).addClass('is-active');
            $('.ptprm-panel').attr('hidden', true);
            $('#tab-' + slug).removeAttr('hidden');
            window.scrollTo({ top: 0, behavior: 'instant' });
        });
    }

    function initColorPickers() {
        if (!$.fn.wpColorPicker) return;
        $('.ptprm-color').each(function () {
            var $i = $(this);
            $i.wpColorPicker({
                change: function () {
                    setTimeout(function () { triggerPreview($i.get(0)); }, 20);
                },
                clear: function () {
                    setTimeout(function () { triggerPreview($i.get(0)); }, 20);
                }
            });
        });
    }

    function initImageFields() {
        $('.ptprm-image-pick').on('click', function (e) {
            e.preventDefault();
            var $wrap   = $(this).closest('.ptprm-image-field');
            var $input  = $wrap.find('.ptprm-image-value');
            var $prev   = $wrap.find('.ptprm-image-preview');

            var frame = wp.media({
                title: 'Pilih gambar',
                button: { text: 'Pakai gambar ini' },
                multiple: false,
                library: { type: 'image' },
            });

            frame.on('select', function () {
                var att = frame.state().get('selection').first().toJSON();
                $input.val(att.id).trigger('change');
                var url = att.sizes && att.sizes.large ? att.sizes.large.url : att.url;
                $prev.css('background-image', 'url(' + url + ')');
                triggerPreview($input.get(0));
            });

            frame.open();
        });

        $('.ptprm-image-clear').on('click', function (e) {
            e.preventDefault();
            var $wrap   = $(this).closest('.ptprm-image-field');
            $wrap.find('.ptprm-image-value').val('').trigger('change');
            $wrap.find('.ptprm-image-preview').css('background-image', '');
            triggerPreview($wrap.find('.ptprm-image-value').get(0));
        });
    }

    function initRangeReadouts() {
        $('.ptprm-range input[type=range]').on('input change', function () {
            $(this).closest('.ptprm-range').find('.ptprm-range-val').text($(this).val());
        });
    }

    function initPresets() {
        $('.ptprm-preset').on('click', function (e) {
            e.preventDefault();
            var p = $(this).data('primary');
            var a = $(this).data('accent');
            setColor('color_primary', p);
            setColor('color_accent', a);
        });
    }

    function setColor(key, value) {
        var $input = $('input[data-ptprm="' + key + '"]');
        if (!$input.length) return;
        if ($input.hasClass('ptprm-color') && $input.wpColorPicker) {
            $input.iris('color', value);
            $input.val(value).trigger('change');
        } else {
            $input.val(value).trigger('change');
        }
    }

    function triggerPreview(el) {
        if (!el) return;
        $(el).trigger('input');
    }

    /* ===================================================================== */
    /* LIVE PREVIEW                                                          */
    /* ===================================================================== */

    function initLivePreview() {
        var $preview = $('#ptprm-hero-preview');
        if (!$preview.length) return;

        function val(key) {
            var $f = $('[data-ptprm="' + key + '"]');
            if (!$f.length) return '';
            if ($f.attr('type') === 'checkbox') return $f.is(':checked') ? 1 : 0;
            return $f.val();
        }

        function update() {
            var pv = $preview.get(0);
            var img = document.getElementById('pv-img');
            var overlay = document.getElementById('pv-overlay');
            var inner = document.getElementById('pv-inner');
            var eyebrow = document.getElementById('pv-eyebrow');
            var title = document.getElementById('pv-title');
            var sub = document.getElementById('pv-sub');
            var cta1 = document.getElementById('pv-cta1');
            var cta1l = document.getElementById('pv-cta1-label');
            var cta2 = document.getElementById('pv-cta2');
            var cta2l = document.getElementById('pv-cta2-label');

            var bgImg = '';
            var d = val('hero_img_desktop');
            if (d) {
                if (/^\d+$/.test(d)) {
                    var prev = $('input[data-ptprm="hero_img_desktop"]').closest('.ptprm-image-field').find('.ptprm-image-preview').css('background-image');
                    if (prev && prev !== 'none') {
                        bgImg = prev.replace(/^url\(["']?/, '').replace(/["']?\)$/, '');
                    }
                } else {
                    bgImg = d;
                }
            }
            if (bgImg) {
                img.src = bgImg;
                $preview.attr('data-noimg', '0');
            } else {
                img.removeAttribute('src');
                $preview.attr('data-noimg', '1');
            }
            img.style.objectPosition = val('hero_img_position') || 'center 35%';

            // Overlay
            var oa = parseInt(val('hero_overlay_opacity'), 10);
            if (isNaN(oa)) oa = 55;
            var oc = val('hero_overlay_color') || '#0A1F3D';
            overlay.style.opacity = (oa / 100);
            overlay.style.background = 'linear-gradient(90deg, ' + oc + ' 0%, rgba(0,0,0,.15) 70%, transparent 100%)';

            // Alignments
            $preview.attr('class', 'ptprm-preview-frame'); // reset
            var ah = val('hero_text_align_h') || 'left';
            var av = val('hero_text_align_v') || 'middle';
            $preview.addClass('pv-align-h-' + ah).addClass('pv-align-v-' + av);

            // Texts
            eyebrow.textContent = val('hero_eyebrow_text') || '';
            eyebrow.style.display = val('hero_eyebrow_show') ? '' : 'none';
            title.textContent = val('hero_title_text') || '';
            title.style.display = val('hero_title_show') ? '' : 'none';
            sub.textContent = val('hero_sub_text') || '';
            sub.style.display = val('hero_sub_show') ? '' : 'none';

            // Eyebrow styles
            eyebrow.style.color = val('hero_eyebrow_color') || '#C9A44C';
            eyebrow.style.fontWeight = val('hero_eyebrow_weight') || '600';
            eyebrow.style.letterSpacing = ((parseInt(val('hero_eyebrow_letter_spacing'),10)||24) / 100) + 'em';
            applyStyleVariant(eyebrow, val('hero_eyebrow_style'));

            // Title styles
            title.style.color = val('hero_title_color') || '#fff';
            title.style.fontWeight = val('hero_title_weight') || '700';
            title.style.letterSpacing = ((parseInt(val('hero_title_letter_spacing'),10)||0) / 100) + 'em';
            title.style.lineHeight = ((parseInt(val('hero_title_line_height'),10)||112) / 100);
            applyStyleVariant(title, val('hero_title_style'));
            applyFont(title, val('hero_title_font'));

            // Sub
            sub.style.color = val('hero_sub_color') || 'rgba(255,255,255,.9)';
            sub.style.fontWeight = val('hero_sub_weight') || '400';
            sub.style.letterSpacing = ((parseInt(val('hero_sub_letter_spacing'),10)||0) / 100) + 'em';
            sub.style.lineHeight = ((parseInt(val('hero_sub_line_height'),10)||170) / 100);
            applyStyleVariant(sub, val('hero_sub_style'));
            applyFont(sub, val('hero_sub_font'));

            // CTA
            cta1l.textContent = val('cta1_label') || '';
            cta1.style.display = val('cta1_show') ? '' : 'none';
            cta1.style.background = val('cta1_bg') || '#C9A44C';
            cta1.style.color = val('cta1_color') || '#0A1F3D';
            cta1.style.borderRadius = (parseInt(val('cta1_radius'),10)||10) + 'px';

            cta2l.textContent = val('cta2_label') || '';
            cta2.style.display = val('cta2_show') ? '' : 'none';
            cta2.style.color = val('cta2_color') || '#fff';
            cta2.style.borderColor = val('cta2_color') || '#fff';
            cta2.style.background = (val('cta2_bg') && val('cta2_bg') !== 'transparent') ? val('cta2_bg') : 'transparent';
            cta2.style.borderRadius = (parseInt(val('cta2_radius'),10)||10) + 'px';
        }

        function applyStyleVariant(el, v) {
            el.style.fontStyle = (v === 'italic') ? 'italic' : 'normal';
            if (v === 'uppercase') el.style.textTransform = 'uppercase';
            else if (v === 'capitalize') el.style.textTransform = 'capitalize';
            else el.style.textTransform = 'none';
        }
        function applyFont(el, font) {
            if (!font || font === 'global') {
                el.style.fontFamily = '';
            } else {
                el.style.fontFamily = '"' + font + '"';
            }
        }

        $(document).on('input change', '[data-ptprm]', update);
        update();
    }
})(jQuery);
