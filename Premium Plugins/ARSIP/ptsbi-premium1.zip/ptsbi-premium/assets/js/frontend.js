/* Premium Plugin — Frontend (minimal) */
(function () {
    'use strict';

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    function init() {
        animateStats();
    }

    function animateStats() {
        if (!window.PTPRM || !PTPRM.animateStats) return;
        if (!('IntersectionObserver' in window)) return;
        var nodes = document.querySelectorAll('[data-ptprm-counter]');
        if (!nodes.length) return;

        var io = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (!entry.isIntersecting) return;
                var el = entry.target;
                var raw = (el.textContent || '').trim();
                var m = raw.match(/(\d+)(.*)$/);
                if (!m) return;
                var target = parseInt(m[1], 10);
                var suffix = m[2] || '';
                if (!target) return;

                var start = 0;
                var dur = 1200;
                var t0 = null;
                function step(ts) {
                    if (!t0) t0 = ts;
                    var p = Math.min(1, (ts - t0) / dur);
                    var eased = 1 - Math.pow(1 - p, 3);
                    el.textContent = Math.floor(start + (target - start) * eased) + suffix;
                    if (p < 1) requestAnimationFrame(step);
                }
                requestAnimationFrame(step);
                io.unobserve(el);
            });
        }, { threshold: 0.4 });

        nodes.forEach(function (n) { io.observe(n); });
    }
})();
