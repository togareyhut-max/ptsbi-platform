/* Cascading wilayah: provinsi → kota → kecamatan → kelurahan */
(function () {
    'use strict';

    function norm(s) {
        return String(s || '').trim().toLowerCase().replace(/\s+/g, ' ');
    }

    function findByName(list, name) {
        var n = norm(name);
        if (!n || !list) return null;
        for (var i = 0; i < list.length; i++) {
            if (norm(list[i].name) === n) return list[i];
        }
        return null;
    }

    function fillSelect(sel, items, placeholder, selected) {
        if (!sel) return;
        var html = '<option value="">' + (placeholder || '— Pilih —') + '</option>';
        (items || []).forEach(function (item) {
            var name = item.name || '';
            if (!name) return;
            var selAttr = norm(selected) === norm(name) ? ' selected' : '';
            html += '<option value="' + escapeAttr(name) + '"' + selAttr + '>' + escapeHtml(name) + '</option>';
        });
        sel.innerHTML = html;
        if (selected && !sel.value) {
            var opt = document.createElement('option');
            opt.value = selected;
            opt.textContent = selected;
            opt.selected = true;
            sel.appendChild(opt);
        }
    }

    function escapeHtml(s) {
        return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    function escapeAttr(s) {
        return escapeHtml(s).replace(/"/g, '&quot;');
    }

    function initAddressForm(wrap, tree) {
        var prov = wrap.querySelector('select[name="province"]');
        var city = wrap.querySelector('select[name="city"]');
        var dist = wrap.querySelector('select[name="district"]');
        var subd = wrap.querySelector('select[name="subdistrict"]');
        var postal = wrap.querySelector('input[name="postal_code"]');
        var overseas = wrap.querySelector('input[name="is_overseas"]');
        var idBlock = wrap.querySelector('[data-ptprm-address-id]');
        var intlBlock = wrap.querySelector('[data-ptprm-address-intl]');

        if (!prov || !city || !dist || !subd || !tree || !tree.provinces) return;

        var saved = {
            province: prov.getAttribute('data-current') || prov.value || '',
            city: city.getAttribute('data-current') || city.value || '',
            district: dist.getAttribute('data-current') || dist.value || '',
            subdistrict: subd.getAttribute('data-current') || subd.value || ''
        };

        function toggleOverseas() {
            var on = overseas && overseas.checked;
            if (idBlock) idBlock.style.display = on ? 'none' : '';
            if (intlBlock) intlBlock.style.display = on ? '' : 'none';
        }

        function onProvince() {
            var p = findByName(tree.provinces, prov.value);
            fillSelect(city, p ? p.cities : [], '— Pilih kota —', '');
            fillSelect(dist, [], '— Pilih kecamatan —', '');
            fillSelect(subd, [], '— Pilih kelurahan —', '');
            if (postal) postal.value = '';
        }

        function onCity() {
            var p = findByName(tree.provinces, prov.value);
            var c = p ? findByName(p.cities, city.value) : null;
            fillSelect(dist, c ? c.districts : [], '— Pilih kecamatan —', '');
            fillSelect(subd, [], '— Pilih kelurahan —', '');
            if (postal) postal.value = '';
        }

        function onDistrict() {
            var p = findByName(tree.provinces, prov.value);
            var c = p ? findByName(p.cities, city.value) : null;
            var d = c ? findByName(c.districts, dist.value) : null;
            fillSelect(subd, d ? d.subdistricts : [], '— Pilih kelurahan —', '');
            if (postal) postal.value = '';
        }

        function onSubdistrict() {
            if (!postal) return;
            var p = findByName(tree.provinces, prov.value);
            var c = p ? findByName(p.cities, city.value) : null;
            var d = c ? findByName(c.districts, dist.value) : null;
            var s = d ? findByName(d.subdistricts, subd.value) : null;
            if (s && s.postal_code) {
                postal.value = s.postal_code;
            }
        }

        fillSelect(prov, tree.provinces, '— Pilih provinsi —', saved.province);

        var p0 = findByName(tree.provinces, saved.province);
        fillSelect(city, p0 ? p0.cities : [], '— Pilih kota —', saved.city);

        var c0 = p0 ? findByName(p0.cities, saved.city) : null;
        fillSelect(dist, c0 ? c0.districts : [], '— Pilih kecamatan —', saved.district);

        var d0 = c0 ? findByName(c0.districts, saved.district) : null;
        fillSelect(subd, d0 ? d0.subdistricts : [], '— Pilih kelurahan —', saved.subdistrict);

        onSubdistrict();

        prov.addEventListener('change', onProvince);
        city.addEventListener('change', onCity);
        dist.addEventListener('change', onDistrict);
        subd.addEventListener('change', onSubdistrict);

        if (overseas) {
            overseas.addEventListener('change', toggleOverseas);
            toggleOverseas();
        }
    }

    function boot() {
        var tree = window.PTPRM_ADDRESS && window.PTPRM_ADDRESS.tree;
        var wraps = document.querySelectorAll('[data-ptprm-address-form]');
        if (!wraps.length) return;
        if (!tree || !tree.provinces) return;
        Array.prototype.forEach.call(wraps, function (wrap) {
            initAddressForm(wrap, tree);
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
