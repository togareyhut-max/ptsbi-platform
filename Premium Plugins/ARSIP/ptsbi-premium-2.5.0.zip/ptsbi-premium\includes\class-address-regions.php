<?php
/**
 * Master wilayah: provinsi → kota → kecamatan → kelurahan (+ kode pos).
 * Sumber utama: assets/data/indonesia-regions-dami.json (dari DATA DAMI 2024 DKI).
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PTPRM_Address_Regions {

    private const JSON_FILE = 'assets/data/indonesia-regions-dami.json';

    /** @var array{provinces:array<int,array<string,mixed>>}|null */
    private static $tree = null;

    public static function init(): void {
        add_action( 'wp_ajax_ptprm_address_regions', [ __CLASS__, 'ajax_tree' ] );
    }

    /**
     * @return array{provinces:array<int,array<string,mixed>>}
     */
    public static function get_tree(): array {
        if ( is_array( self::$tree ) ) {
            return self::$tree;
        }

        $tree = [ 'provinces' => [] ];
        $path = PTPRM_DIR . self::JSON_FILE;
        if ( is_readable( $path ) ) {
            $raw = file_get_contents( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
            if ( is_string( $raw ) && $raw !== '' ) {
                $json = json_decode( $raw, true );
                if ( is_array( $json ) && ! empty( $json['provinces'] ) ) {
                    $tree = $json;
                }
            }
        }

        self::merge_from_database( $tree );
        $tree = self::sort_tree( $tree );
        self::$tree = $tree;
        return $tree;
    }

    public static function ajax_tree(): void {
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => __( 'Login diperlukan.', 'ptsbi-premium' ) ], 403 );
        }
        wp_send_json_success( self::get_tree() );
    }

    /**
     * @param array{provinces:array<int,array<string,mixed>>} $tree
     */
    private static function merge_from_database( array &$tree ): void {
        global $wpdb;
        $table = $wpdb->prefix . 'ptprm_address_master';
        if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) !== $table ) { // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
            return;
        }

        $rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
            "SELECT province, city, district, subdistrict, postal_code FROM {$table} WHERE country_code IN ('ID','')",
            ARRAY_A
        );
        if ( ! is_array( $rows ) ) {
            return;
        }

        foreach ( $rows as $row ) {
            $prov = trim( (string) ( $row['province'] ?? '' ) );
            $city = trim( (string) ( $row['city'] ?? '' ) );
            $kec  = trim( (string) ( $row['district'] ?? '' ) );
            $kel  = trim( (string) ( $row['subdistrict'] ?? '' ) );
            $pos  = trim( (string) ( $row['postal_code'] ?? '' ) );
            if ( $city === '' || $kec === '' ) {
                continue;
            }
            if ( $prov === '' ) {
                $prov = self::guess_province( $city );
            }
            self::insert_path( $tree, $prov, $city, $kec, $kel, $pos );
        }
    }

    /**
     * @param array{provinces:array<int,array<string,mixed>>} $tree
     */
    private static function insert_path( array &$tree, string $prov, string $city, string $kec, string $kel, string $pos ): void {
        $pi = self::index_of( $tree['provinces'], $prov );
        if ( $pi < 0 ) {
            $tree['provinces'][] = [ 'name' => $prov, 'cities' => [] ];
            $pi                  = count( $tree['provinces'] ) - 1;
        }

        $ci = self::index_of( $tree['provinces'][ $pi ]['cities'], $city );
        if ( $ci < 0 ) {
            $tree['provinces'][ $pi ]['cities'][] = [ 'name' => $city, 'districts' => [] ];
            $ci                                    = count( $tree['provinces'][ $pi ]['cities'] ) - 1;
        }

        $di = self::index_of( $tree['provinces'][ $pi ]['cities'][ $ci ]['districts'], $kec );
        if ( $di < 0 ) {
            $tree['provinces'][ $pi ]['cities'][ $ci ]['districts'][] = [ 'name' => $kec, 'subdistricts' => [] ];
            $di                                                        = count( $tree['provinces'][ $pi ]['cities'][ $ci ]['districts'] ) - 1;
        }

        if ( $kel === '' ) {
            return;
        }

        $subs = &$tree['provinces'][ $pi ]['cities'][ $ci ]['districts'][ $di ]['subdistricts'];
        $si   = self::index_of( $subs, $kel );
        if ( $si < 0 ) {
            $leaf = [ 'name' => $kel ];
            if ( $pos !== '' ) {
                $leaf['postal_code'] = $pos;
            }
            $subs[] = $leaf;
            return;
        }
        if ( $pos !== '' ) {
            $subs[ $si ]['postal_code'] = $pos;
        }
    }

    /**
     * @param array<int,array{name:string}> $list
     */
    private static function index_of( array $list, string $name ): int {
        $n = self::norm( $name );
        foreach ( $list as $i => $item ) {
            if ( self::norm( (string) ( $item['name'] ?? '' ) ) === $n ) {
                return (int) $i;
            }
        }
        return -1;
    }

    /**
     * @param array{provinces:array<int,array<string,mixed>>} $tree
     * @return array{provinces:array<int,array<string,mixed>>}
     */
    private static function sort_tree( array $tree ): array {
        if ( empty( $tree['provinces'] ) ) {
            return $tree;
        }
        usort(
            $tree['provinces'],
            static fn( $a, $b ) => strcasecmp( (string) ( $a['name'] ?? '' ), (string) ( $b['name'] ?? '' ) )
        );
        foreach ( $tree['provinces'] as &$prov ) {
            if ( empty( $prov['cities'] ) ) {
                continue;
            }
            usort( $prov['cities'], static fn( $a, $b ) => strcasecmp( (string) ( $a['name'] ?? '' ), (string) ( $b['name'] ?? '' ) ) );
            foreach ( $prov['cities'] as &$city ) {
                if ( empty( $city['districts'] ) ) {
                    continue;
                }
                usort( $city['districts'], static fn( $a, $b ) => strcasecmp( (string) ( $a['name'] ?? '' ), (string) ( $b['name'] ?? '' ) ) );
                foreach ( $city['districts'] as &$dist ) {
                    if ( empty( $dist['subdistricts'] ) ) {
                        continue;
                    }
                    usort( $dist['subdistricts'], static fn( $a, $b ) => strcasecmp( (string) ( $a['name'] ?? '' ), (string) ( $b['name'] ?? '' ) ) );
                }
            }
        }
        return $tree;
    }

    public static function guess_province( string $city ): string {
        $k = strtolower( $city );
        if ( strpos( $k, 'jakarta' ) !== false ) {
            return 'DKI Jakarta';
        }
        $jabar = [ 'bekasi', 'depok', 'bogor', 'tangerang', 'cikarang', 'cibitung', 'babelan', 'ciracas', 'cimanggis', 'karawaci', 'serpong', 'pamulang', 'cileungsi', 'cikupa', 'cikampek', 'karawang', 'bks-', 'sekretariat-', 'perumnas' ];
        foreach ( $jabar as $needle ) {
            if ( strpos( $k, $needle ) !== false ) {
                return 'Jawa Barat';
            }
        }
        return 'Lainnya';
    }

    public static function norm( string $s ): string {
        $s = trim( strtolower( $s ) );
        $s = preg_replace( '/\s+/', ' ', $s );
        return is_string( $s ) ? $s : '';
    }

    /**
     * @param array<string,string> $attrs
     */
    public static function render_select( string $name, string $label, string $current, array $attrs = [] ): void {
        $attr_str = '';
        foreach ( $attrs as $k => $v ) {
            $attr_str .= ' ' . esc_attr( $k ) . '="' . esc_attr( (string) $v ) . '"';
        }
        echo '<label class="ptprm-address-field" data-ptprm-field="' . esc_attr( $name ) . '">';
        echo '<span>' . esc_html( $label ) . '</span>';
        echo '<select name="' . esc_attr( $name ) . '"' . $attr_str . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo '<option value="">' . esc_html__( '— Pilih —', 'ptsbi-premium' ) . '</option>';
        if ( $current !== '' ) {
            echo '<option value="' . esc_attr( $current ) . '" selected>' . esc_html( $current ) . '</option>';
        }
        echo '</select></label>';
    }
}
