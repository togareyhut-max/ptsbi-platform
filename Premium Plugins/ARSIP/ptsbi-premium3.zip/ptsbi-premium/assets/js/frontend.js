/* Premium Plugin — Frontend (minimal) */
(function () {
    'use strict';

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    function init() {
        animateStats();
        initLightbox();
    }

    function initLightbox() {
        var items = document.querySelectorAll('[data-ptprm-lightbox]');
        if (!items.length) return;

        var images = Array.prototype.map.call(items, function (a) { return a.getAttribute('href'); });
        var idx = 0;

        var box = document.createElement('div');
        box.className = 'ptprm-lightbox';
        box.innerHTML =
            '<button class="ptprm-lightbox-close" aria-label="Tutup">&times;</button>' +
            '<button class="ptprm-lightbox-nav prev" aria-label="Sebelumnya">&#8592;</button>' +
            '<img alt="">' +
            '<button class="ptprm-lightbox-nav next" aria-label="Berikutnya">&#8594;</button>';
        document.body.appendChild(box);

        var img    = box.querySelector('img');
        var close  = box.querySelector('.ptprm-lightbox-close');
        var prev   = box.querySelector('.prev');
        var next   = box.querySelector('.next');

        function show(i) {
            idx = (i + images.length) % images.length;
            img.src = images[idx];
            box.classList.add('is-open');
            document.body.style.overflow = 'hidden';
        }
        function hide() {
            box.classList.remove('is-open');
            img.src = '';
            document.body.style.overflow = '';
        }

        Array.prototype.forEach.call(items, function (a, i) {
            a.addEventListener('click', function (e) {
                e.preventDefault();
                show(i);
            });
        });

        close.addEventListener('click', hide);
        prev.addEventListener('click', function () { show(idx - 1); });
        next.addEventListener('click', function () { show(idx + 1); });
        box.addEventListener('click', function (e) { if (e.target === box) hide(); });
        document.addEventListener('keydown', function (e) {
            if (!box.classList.contains('is-open')) return;
            if (e.key === 'Escape') hide();
            else if (e.key === 'ArrowLeft') show(idx - 1);
            else if (e.key === 'ArrowRight') show(idx + 1);
        });
    }

    function animateStats() {
        if (!window.PTPRM || !PTPRM.animateStats) return;
        if (!('IntersectionObserver' in window)) return;
        var nodes = document.querySelectorAll('[data-ptprm-counter]');
        if (!nodes.length) return;

        var io = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (!entry.isIntersecting) return;
                var el = entry.target;
                var raw = (el.textContent || '').trim();
                var m = raw.match(/(\d+)(.*)$/);
                if (!m) return;
                var target = parseInt(m[1], 10);
                var suffix = m[2] || '';
                if (!target) return;

                var start = 0;
                var dur = 1200;
                var t0 = null;
                function step(ts) {
                    if (!t0) t0 = ts;
                    var p = Math.min(1, (ts - t0) / dur);
                    var eased = 1 - Math.pow(1 - p, 3);
                    el.textContent = Math.floor(start + (target - start) * eased) + suffix;
                    if (p < 1) requestAnimationFrame(step);
                }
                requestAnimationFrame(step);
                io.unobserve(el);
            });
        }, { threshold: 0.4 });

        nodes.forEach(function (n) { io.observe(n); });
    }
})();
