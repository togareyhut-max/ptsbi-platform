<?php
/**
 * Plugin Name:       Premium Organization — PTSBI
 * Plugin URI:        https://ptsbi.org/
 * Description:       Plugin premium untuk situs organisasi: Beranda lengkap (Hero responsif + 2 CTA, Tentang, Nilai, Kegiatan, Statistik, Kunjungi, Footer) dan sub-halaman seragam dengan ornamen Gorga Batak. Semua isi dapat diedit dari panel admin. Universal — bisa dipakai organisasi lain.
 * Version:           1.0.4
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Premium Plugins
 * License:           GPL-2.0-or-later
 * Text Domain:       ptsbi-premium
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'PTPRM_VERSION', '1.0.4' );
define( 'PTPRM_FILE',    __FILE__ );
define( 'PTPRM_DIR',     plugin_dir_path( __FILE__ ) );
define( 'PTPRM_URL',     plugin_dir_url( __FILE__ ) );
define( 'PTPRM_OPTION',  'ptprm_options' );

require_once PTPRM_DIR . 'includes/helpers.php';
require_once PTPRM_DIR . 'includes/class-assets.php';
require_once PTPRM_DIR . 'includes/class-renderer.php';
require_once PTPRM_DIR . 'includes/class-home.php';
require_once PTPRM_DIR . 'includes/class-subpage.php';
require_once PTPRM_DIR . 'includes/class-settings.php';

register_activation_hook( __FILE__, function () {
    if ( false === get_option( PTPRM_OPTION ) ) {
        add_option( PTPRM_OPTION, ptprm_defaults() );
    } else {
        $saved = (array) get_option( PTPRM_OPTION, [] );
        update_option( PTPRM_OPTION, array_merge( ptprm_defaults(), $saved ) );
    }
} );

add_action( 'plugins_loaded', function () {
    new PTPRM_Assets();
    new PTPRM_Home();
    new PTPRM_Subpage();
    if ( is_admin() ) {
        new PTPRM_Settings();
    }
} );
