=== Premium Organization Plugin ===
Contributors:      premiumplugins
Tags:              homepage, hero, premium, organization, sections, responsive
Requires at least: 5.8
Tested up to:      6.7
Requires PHP:      7.4
Stable tag:        1.0.2
License:           GPLv2 or later

Plugin premium untuk situs organisasi: Beranda lengkap (Hero responsif + 2 CTA, Tentang, Nilai, Kegiatan, Statistik, Kunjungi, Footer) dan sub-halaman seragam dengan ornamen Gorga Batak. Semua isi dapat diedit dari panel admin tanpa Elementor.

== Description ==

Plugin ini mengambil alih konten Beranda dan membungkus sub-halaman dengan template premium yang seragam. Tidak memerlukan Elementor.

**Beranda — urutan tetap:**
Hero → Tentang → Nilai-Nilai → Kegiatan → Statistik → Kunjungi → Footer.
Setiap section dapat dimatikan/dihidupkan dari panel.

**Hero — kontrol penuh:**
- Gambar terpisah untuk Desktop, Tablet, Mobile (responsif otomatis)
- Posisi fokus gambar, overlay, gradient
- Tinggi: kecil / standar / tinggi / penuh layar / custom px
- 3 elemen teks (eyebrow, judul, subjudul) — masing-masing: font, ukuran desktop & mobile, bobot, warna, letter-spacing, line-height, style (italic / uppercase / capitalize), bayangan
- 2 tombol CTA dengan style solid/outline/ghost, ikon, warna hover, radius, ukuran
- Posisi teks horizontal & vertikal
- Animasi muncul

**Live preview** di admin update otomatis saat Anda mengetik.

**Sub-halaman:**
Hero navy dengan corak Gorga Batak + ornamen emas + breadcrumb. Konten WP (entry-content) dibungkus container premium dengan tipografi serif untuk heading.

**Universal:**
Tidak hardcode untuk PTSBI — nama organisasi, warna, font, teks, ikon, tautan semua dapat diedit.

== Installation ==

1. Zip folder `ptsbi-premium`.
2. WP Admin → Plugins → Add New → Upload Plugin → pilih ZIP → Activate.
3. Buka menu **Premium Plugin** di sidebar admin.
4. Tab **Umum** — isi nama organisasi, warna, font, WA, alamat, sosial media.
5. Tab **Hero** — upload gambar (desktop/tablet/mobile), isi teks, atur warna tombol, lihat preview.
6. Tab **Beranda** — edit isi Tentang, Nilai, Kegiatan, Statistik, Kunjungi.
7. Tab **Sub-halaman** — atur header sub-halaman (Gorga, ornamen, breadcrumb).
8. Tab **Footer** — isi tagline & tautan.
9. Simpan.

== Changelog ==

= 1.0.2 =
* Fix: judul Statistik (teks navy di atas latar navy) sekarang putih.
* Fix: jarak antar section (Kegiatan / Statistik / Kunjungi) sekarang lega.
* Tentang Kami: gambar placeholder elegan saat belum upload + tombol default ke /tentang-kami/.
* Kunjungi Kami: layout baru — judul di tengah, kartu alamat di kiri, box Google Maps di kanan (dengan placeholder jika belum diisi).
* Tambah helper resolve URL relatif (/tentang-kami/) → URL absolut.

= 1.0.1 =
* Fix: Beranda kosong saat halaman home diatur dengan Elementor. Sekarang plugin pakai template_include sehingga selalu menang atas page builder lain.
* Fix: BUILD-ZIP.bat memakai .NET ZipFile.CreateFromDirectory supaya subfolder pasti ikut.

= 1.0.0 =
* Rilis pertama. Beranda diambil alih plugin (tanpa Elementor), Hero responsif penuh, sub-halaman seragam dengan ornamen Gorga.
