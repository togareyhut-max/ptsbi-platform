<?php
/**
 * Default option schema & helpers.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function ptprm_font_choices() {
    return [
        'global'             => __( '— pakai font global —', 'ptsbi-premium' ),
        'Playfair Display'   => 'Playfair Display, serif',
        'Cormorant Garamond' => 'Cormorant Garamond, serif',
        'Lora'               => 'Lora, serif',
        'Merriweather'       => 'Merriweather, serif',
        'Inter'              => 'Inter, sans-serif',
        'Plus Jakarta Sans'  => 'Plus Jakarta Sans, sans-serif',
        'Poppins'            => 'Poppins, sans-serif',
        'Montserrat'         => 'Montserrat, sans-serif',
        'Manrope'            => 'Manrope, sans-serif',
        'Open Sans'          => 'Open Sans, sans-serif',
    ];
}

function ptprm_icon_choices() {
    return [
        'none'     => __( '— tanpa ikon —', 'ptsbi-premium' ),
        'whatsapp' => 'WhatsApp',
        'arrow'    => 'Panah',
        'phone'    => 'Telepon',
        'mail'     => 'Email',
        'users'    => 'Anggota',
        'heart'    => 'Hati',
        'feather'  => 'Bulu',
        'hands'    => 'Tangan',
        'pin'      => 'Pin lokasi',
        'clock'    => 'Jam',
    ];
}

function ptprm_defaults() {
    return [
        'enabled'           => 1,

        // BRAND
        'org_name'          => 'Organisasi Premium',
        'color_primary'     => '#0A1F3D',
        'color_accent'      => '#C9A44C',
        'color_text'        => '#1C1C1C',
        'color_text_soft'   => '#4A4A4A',
        'color_cream'       => '#FAF6EE',
        'font_heading'      => 'Playfair Display',
        'font_body'         => 'Plus Jakarta Sans',
        'container_max'     => 1200,

        // CONTACT
        'whatsapp'          => '',
        'address'           => '',
        'hours'             => 'Senin–Jumat, 09.00–17.00 WIB',
        'fb_url'            => '',
        'ig_url'            => '',
        'yt_url'            => '',
        'tt_url'            => '',

        /* -------- HERO -------- */
        'hero_show'                  => 1,
        'hero_img_desktop'           => '',
        'hero_img_tablet'            => '',
        'hero_img_mobile'            => '',
        'hero_img_position'          => 'center 35%',
        'hero_overlay_opacity'       => 55,
        'hero_overlay_color'         => '#0A1F3D',
        'hero_overlay_gradient'      => 1,
        'hero_height_mode'           => 'standard', // small | standard | tall | full | custom
        'hero_height_desktop'        => 720,
        'hero_height_mobile'         => 560,
        'hero_text_align_h'          => 'left',
        'hero_text_align_v'          => 'middle',
        'hero_text_max_width'        => 620,
        'hero_text_gap'              => 18,
        'hero_pad_top'               => '',
        'hero_pad_bottom'            => '',
        'hero_animation'             => 'fade-up',

        'hero_eyebrow_show'          => 1,
        'hero_eyebrow_text'          => 'PUNGUAN TOGA SAMOSIR BORU BERE IBEBERE',
        'hero_eyebrow_font'          => 'global',
        'hero_eyebrow_size'          => 14,
        'hero_eyebrow_size_mobile'   => 12,
        'hero_eyebrow_weight'        => '600',
        'hero_eyebrow_color'         => '#C9A44C',
        'hero_eyebrow_letter_spacing'=> 24,
        'hero_eyebrow_style'         => 'uppercase',
        'hero_eyebrow_shadow'        => 0,

        'hero_title_show'            => 1,
        'hero_title_text'            => 'Wadah Kebersamaan Keluarga Besar yang Elegan',
        'hero_title_font'            => 'global',
        'hero_title_size'            => 64,
        'hero_title_size_mobile'     => 36,
        'hero_title_weight'          => '700',
        'hero_title_color'           => '#FFFFFF',
        'hero_title_letter_spacing'  => 0,
        'hero_title_style'           => 'normal',
        'hero_title_shadow'          => 1,
        'hero_title_line_height'     => 112, // x100, so 1.12

        'hero_sub_show'              => 1,
        'hero_sub_text'              => 'Mempererat persaudaraan, melestarikan adat istiadat, dan saling mendukung antar keluarga besar di seluruh wilayah Indonesia.',
        'hero_sub_font'              => 'global',
        'hero_sub_size'              => 18,
        'hero_sub_size_mobile'       => 15,
        'hero_sub_weight'            => '400',
        'hero_sub_color'             => '#E5E7EB',
        'hero_sub_letter_spacing'    => 0,
        'hero_sub_style'             => 'normal',
        'hero_sub_shadow'            => 1,
        'hero_sub_line_height'       => 170,

        // CTA 1
        'cta1_show'          => 1,
        'cta1_label'         => 'Bergabung Sekarang',
        'cta1_url'           => '',
        'cta1_target'        => '_self',
        'cta1_icon'          => 'arrow',
        'cta1_style'         => 'solid',
        'cta1_bg'            => '#C9A44C',
        'cta1_color'         => '#0A1F3D',
        'cta1_bg_hover'      => '#E0BC65',
        'cta1_color_hover'   => '#0A1F3D',
        'cta1_radius'        => 10,
        'cta1_size'          => 'medium',

        // CTA 2
        'cta2_show'          => 1,
        'cta2_label'         => 'Hubungi WA',
        'cta2_url'           => '',
        'cta2_target'        => '_blank',
        'cta2_icon'          => 'whatsapp',
        'cta2_style'         => 'ghost',
        'cta2_bg'            => 'transparent',
        'cta2_color'         => '#FFFFFF',
        'cta2_bg_hover'      => '#FFFFFF',
        'cta2_color_hover'   => '#0A1F3D',
        'cta2_radius'        => 10,
        'cta2_size'          => 'medium',

        /* -------- ABOUT -------- */
        'about_show'      => 1,
        'about_eyebrow'   => 'TENTANG KAMI',
        'about_title'     => 'Mengenal Organisasi Kami',
        'about_body'      => "Kami adalah wadah kebersamaan keluarga besar yang berkomitmen mempererat persaudaraan, melestarikan adat istiadat Batak, dan saling mendukung dalam setiap kegiatan keluarga.\n\nMelalui kepengurusan dan kegiatan rutin, kami menjaga warisan budaya dan menyatukan generasi.",
        'about_image'     => '',
        'about_layout'    => 'image-left',
        'about_cta_label' => 'Pelajari Selengkapnya',
        'about_cta_url'   => '/tentang-kami/',

        /* -------- VALUES -------- */
        'values_show'      => 1,
        'values_eyebrow'   => 'NILAI-NILAI KAMI',
        'values_title'     => 'Fondasi yang Kami Pegang Bersama',
        'values_subtitle'  => 'Empat nilai inti yang menuntun setiap langkah organisasi dalam menjaga kebersamaan keluarga besar.',
        'values_1_icon'    => 'users',
        'values_1_title'   => 'Kebersamaan',
        'values_1_desc'    => 'Kekuatan kami terletak pada ikatan yang erat antar anggota dan keluarga besar.',
        'values_2_icon'    => 'heart',
        'values_2_title'   => 'Kasih',
        'values_2_desc'    => 'Kasih menjadi dasar setiap tindakan, keputusan, dan hubungan dalam komunitas.',
        'values_3_icon'    => 'feather',
        'values_3_title'   => 'Pelestarian Budaya',
        'values_3_desc'    => 'Kami menjaga dan meneruskan nilai serta warisan budaya kepada generasi berikutnya.',
        'values_4_icon'    => 'hands',
        'values_4_title'   => 'Saling Mendukung',
        'values_4_desc'    => 'Dalam suka maupun duka, kami hadir untuk saling menopang dan menguatkan.',

        /* -------- ACTIVITIES -------- */
        'activities_show'        => 1,
        'activities_eyebrow'     => 'KEGIATAN KAMI',
        'activities_title'       => 'Kabar dan Kegiatan Terbaru',
        'activities_subtitle'    => 'Ikuti pembaruan kegiatan, agenda, dan informasi terkini dari keluarga besar.',
        'activities_count'       => 3,
        'activities_category'    => 0,
        'activities_more_label'  => 'Lihat Semua Kegiatan',
        'activities_more_url'    => '',

        /* -------- STATS -------- */
        'stats_show'        => 1,
        'stats_eyebrow'     => 'STATISTIK',
        'stats_title'       => 'Organisasi Kami dalam Angka',
        'stats_a_num'       => '10+',
        'stats_a_label'     => 'Cabang Wilayah',
        'stats_b_num'       => '500+',
        'stats_b_label'     => 'Kepala Keluarga',
        'stats_c_num'       => '1000+',
        'stats_c_label'     => 'Anggota Aktif',
        'stats_d_num'       => '20+',
        'stats_d_label'     => 'Tahun Kebersamaan',
        'stats_animate'     => 1,

        /* -------- VISIT -------- */
        'visit_show'         => 1,
        'visit_eyebrow'      => 'KUNJUNGI KAMI',
        'visit_title'        => 'Mari Terhubung & Bertemu Bersama Keluarga Besar',
        'visit_intro'        => 'Kami terbuka untuk silaturahmi, koordinasi kegiatan, dan masukan dari seluruh anggota.',
        'visit_show_address' => 1,
        'visit_show_hours'   => 1,
        'visit_show_wa'      => 1,
        'visit_map_url'      => '',

        /* -------- FOOTER -------- */
        'footer_show'        => 1,
        'footer_tagline'     => 'Wadah kebersamaan keluarga besar untuk mempererat persaudaraan, melestarikan budaya, dan saling mendukung.',
        'footer_col1_label'  => 'Tautan Cepat',
        'footer_col1_links'  => "Beranda|/\nTentang Kami|/tentang-kami/\nProgram Kerja|/program-kerja/\nInformasi Kegiatan|/informasi-kegiatan/",
        'footer_col2_label'  => 'Organisasi',
        'footer_col2_links'  => "Tarombo|/tarombo/\nStruktur Organisasi|/struktur-organisasi/",
        'footer_show_social' => 1,
        'footer_copyright'   => '© {year} {org}. Seluruh hak cipta dilindungi.',

        /* -------- TEAM (Pengurus) -------- */
        'team_show'      => 0,
        'team_eyebrow'   => 'PENGURUS',
        'team_title'     => 'Tim Kepengurusan',
        'team_subtitle'  => 'Wajah-wajah yang menggerakkan organisasi kami.',
        'team_columns'   => 4,
        // Up to 8 slots
        'team_1_image' => '', 'team_1_name' => '', 'team_1_role' => '', 'team_1_url' => '',
        'team_2_image' => '', 'team_2_name' => '', 'team_2_role' => '', 'team_2_url' => '',
        'team_3_image' => '', 'team_3_name' => '', 'team_3_role' => '', 'team_3_url' => '',
        'team_4_image' => '', 'team_4_name' => '', 'team_4_role' => '', 'team_4_url' => '',
        'team_5_image' => '', 'team_5_name' => '', 'team_5_role' => '', 'team_5_url' => '',
        'team_6_image' => '', 'team_6_name' => '', 'team_6_role' => '', 'team_6_url' => '',
        'team_7_image' => '', 'team_7_name' => '', 'team_7_role' => '', 'team_7_url' => '',
        'team_8_image' => '', 'team_8_name' => '', 'team_8_role' => '', 'team_8_url' => '',
        'team_more_label' => 'Lihat Struktur Lengkap',
        'team_more_url'   => '/struktur-organisasi/',

        /* -------- GALLERY -------- */
        'gallery_show'      => 0,
        'gallery_eyebrow'   => 'GALERI',
        'gallery_title'     => 'Momen Kebersamaan',
        'gallery_subtitle'  => 'Dokumentasi kegiatan dan pertemuan keluarga besar.',
        'gallery_ids'       => '', // comma-separated attachment IDs
        'gallery_columns'   => 4,
        'gallery_lightbox'  => 1,

        /* -------- BANNER CTA -------- */
        'banner_show'      => 0,
        'banner_image'     => '',
        'banner_overlay'   => 70,
        'banner_eyebrow'   => 'AYO BERGABUNG',
        'banner_title'     => 'Jadilah Bagian dari Keluarga Besar Kami',
        'banner_subtitle'  => 'Daftarkan diri Anda dan ikut serta dalam kegiatan, silaturahmi, dan pelestarian budaya.',
        'banner_cta_label' => 'Bergabung Sekarang',
        'banner_cta_url'   => '',
        'banner_cta2_show' => 0,
        'banner_cta2_label'=> 'Hubungi WA',
        'banner_cta2_url'  => '',

        /* -------- FAQ -------- */
        'faq_show'      => 0,
        'faq_eyebrow'   => 'PERTANYAAN UMUM',
        'faq_title'     => 'Hal yang Sering Ditanyakan',
        'faq_subtitle'  => 'Belum menemukan jawaban? Hubungi kami via WhatsApp.',
        'faq_1_q' => '', 'faq_1_a' => '',
        'faq_2_q' => '', 'faq_2_a' => '',
        'faq_3_q' => '', 'faq_3_a' => '',
        'faq_4_q' => '', 'faq_4_a' => '',
        'faq_5_q' => '', 'faq_5_a' => '',
        'faq_6_q' => '', 'faq_6_a' => '',
        'faq_7_q' => '', 'faq_7_a' => '',
        'faq_8_q' => '', 'faq_8_a' => '',
        'faq_9_q' => '', 'faq_9_a' => '',
        'faq_10_q' => '', 'faq_10_a' => '',

        /* -------- SUB-PAGE -------- */
        'subpage_hero_show'     => 1,
        'subpage_breadcrumb'    => 1,
        'subpage_ornament'      => 1,
        'subpage_gorga'         => 1,
        'subpage_overlay'       => 70,
        'subpage_eyebrow_auto'  => 1,
        'subpage_default_intro' => '',
    ];
}

function ptprm_options() {
    $saved = get_option( PTPRM_OPTION, [] );
    if ( ! is_array( $saved ) ) $saved = [];
    return array_merge( ptprm_defaults(), $saved );
}

function ptprm_get( $key, $default = '' ) {
    $o = ptprm_options();
    return $o[ $key ] ?? $default;
}

function ptprm_resolve_font( $key, $fallback = '' ) {
    if ( ! $key || $key === 'global' ) return $fallback;
    $list = ptprm_font_choices();
    if ( isset( $list[ $key ] ) && $key !== 'global' ) {
        return $list[ $key ];
    }
    return $fallback;
}

function ptprm_wa_link( $number ) {
    $d = preg_replace( '/\D/', '', (string) $number );
    if ( ! $d ) return '';
    if ( strpos( $d, '62' ) !== 0 && strpos( $d, '0' ) === 0 ) {
        $d = '62' . substr( $d, 1 );
    }
    return 'https://wa.me/' . $d;
}

function ptprm_resolve_url( $url ) {
    if ( ! $url ) return '';
    $url = trim( $url );
    if ( $url === '#' ) return $url;
    if ( strpos( $url, '//' ) === 0 ) return $url;
    if ( $url[0] === '/' ) return home_url( $url );
    if ( preg_match( '#^[a-z][a-z0-9+.-]*:#i', $url ) ) return $url;
    return home_url( '/' . ltrim( $url, '/' ) );
}

function ptprm_image_url( $value ) {
    if ( ! $value ) return '';
    if ( is_numeric( $value ) ) {
        $u = wp_get_attachment_image_url( (int) $value, 'full' );
        return $u ? $u : '';
    }
    return esc_url_raw( $value );
}

function ptprm_icon_svg( $name ) {
    $icons = [
        'whatsapp' => '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M.057 24l1.687-6.163a11.867 11.867 0 0 1-1.587-5.946C.16 5.335 5.495 0 12.05 0a11.82 11.82 0 0 1 8.413 3.488 11.82 11.82 0 0 1 3.48 8.414c-.003 6.554-5.338 11.892-11.893 11.892a11.9 11.9 0 0 1-5.688-1.45L.057 24zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.89 9.884a9.86 9.86 0 0 0 1.51 5.26l-.999 3.648 3.979-1.607zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.521.149-.174.198-.298.297-.497.099-.198.05-.372-.025-.521-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51l-.57-.01c-.198 0-.521.074-.793.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.227 1.36.195 1.872.118.571-.085 1.758-.719 2.006-1.413.247-.694.247-1.289.173-1.413z"/></svg>',
        'arrow'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>',
        'phone'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>',
        'mail'     => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>',
        'users'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
        'heart'    => '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>',
        'feather'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20.24 12.24a6 6 0 0 0-8.49-8.49L5 10.5V19h8.5z"/><line x1="16" y1="8" x2="2" y2="22"/><line x1="17.5" y1="15" x2="9" y2="15"/></svg>',
        'hands'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 11V6a2 2 0 1 1 4 0v5"/><path d="M13 11V4a2 2 0 1 1 4 0v8"/><path d="M17 12v-2a2 2 0 1 1 4 0v5a7 7 0 0 1-7 7H8a7 7 0 0 1-7-7v-2a2 2 0 1 1 4 0v2"/></svg>',
        'pin'      => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>',
        'clock'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',
        'facebook' => '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M22.675 0H1.325C.593 0 0 .593 0 1.325v21.351C0 23.407.593 24 1.325 24H12.82V14.706h-3.131v-3.622h3.131V8.413c0-3.1 1.894-4.788 4.659-4.788 1.325 0 2.464.099 2.795.143v3.24h-1.918c-1.504 0-1.796.715-1.796 1.762v2.31h3.587l-.467 3.622h-3.12V24h6.116c.731 0 1.324-.593 1.324-1.324V1.325C24 .593 23.407 0 22.675 0z"/></svg>',
        'instagram'=> '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 1.366.062 2.633.336 3.608 1.311.975.975 1.249 2.242 1.311 3.608.058 1.266.07 1.646.07 4.85s-.012 3.584-.07 4.85c-.062 1.366-.336 2.633-1.311 3.608-.975.975-2.242 1.249-3.608 1.311-1.266.058-1.646.07-4.85.07s-3.584-.012-4.85-.07c-1.366-.062-2.633-.336-3.608-1.311-.975-.975-1.249-2.242-1.311-3.608-.058-1.266-.07-1.646-.07-4.85s.012-3.584.07-4.85c.062-1.366.336-2.633 1.311-3.608.975-.975 2.242-1.249 3.608-1.311 1.266-.058 1.646-.07 4.85-.07zM12 0C8.741 0 8.332.014 7.052.072 5.775.13 4.602.405 3.635 1.372 2.668 2.339 2.393 3.512 2.335 4.789 2.277 6.069 2.263 6.478 2.263 9.737c0 3.259.014 3.668.072 4.948.058 1.277.333 2.45 1.3 3.417.967.967 2.14 1.242 3.417 1.3 1.28.058 1.689.072 4.948.072s3.668-.014 4.948-.072c1.277-.058 2.45-.333 3.417-1.3.967-.967 1.242-2.14 1.3-3.417.058-1.28.072-1.689.072-4.948s-.014-3.668-.072-4.948c-.058-1.277-.333-2.45-1.3-3.417C19.398.405 18.225.13 16.948.072 15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 1 0 0 12.324 6.162 6.162 0 0 0 0-12.324zM12 16a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm6.406-11.845a1.44 1.44 0 1 0 0 2.881 1.44 1.44 0 0 0 0-2.881z"/></svg>',
        'youtube'  => '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>',
        'tiktok'   => '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5.8 20.1a6.34 6.34 0 0 0 10.86-4.43V8.62a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.84 4.84 0 0 1-1.84-.05z"/></svg>',
    ];
    return $icons[ $name ] ?? '';
}

function ptprm_ornament_svg() {
    return '<svg viewBox="0 0 200 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid meet" aria-hidden="true">' .
        '<line x1="0" y1="12" x2="80" y2="12" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/>' .
        '<line x1="120" y1="12" x2="200" y2="12" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/>' .
        '<path d="M85 12 L100 4 L115 12 L100 20 Z" fill="none" stroke="currentColor" stroke-width="1.6"/>' .
        '<circle cx="100" cy="12" r="2.6" fill="currentColor"/>' .
        '<circle cx="74" cy="12" r="1.6" fill="currentColor"/>' .
        '<circle cx="126" cy="12" r="1.6" fill="currentColor"/>' .
        '</svg>';
}

function ptprm_parse_links( $text ) {
    $out   = [];
    $lines = preg_split( "/\r\n|\r|\n/", (string) $text );
    foreach ( $lines as $line ) {
        $line = trim( $line );
        if ( ! $line ) continue;
        $parts = array_map( 'trim', explode( '|', $line, 2 ) );
        if ( count( $parts ) >= 2 && $parts[0] !== '' ) {
            $out[] = [ 'label' => $parts[0], 'url' => $parts[1] ];
        }
    }
    return $out;
}
