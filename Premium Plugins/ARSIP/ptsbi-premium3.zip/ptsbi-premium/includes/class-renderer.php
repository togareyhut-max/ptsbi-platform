<?php
/**
 * Render all home sections + sub-page hero.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PTPRM_Renderer {

    /* ===================================================================== */
    /* HOMEPAGE                                                              */
    /* ===================================================================== */

    public static function home() {
        $o = ptprm_options();

        echo '<div class="ptprm ptprm-home">';
        if ( ! empty( $o['hero_show'] ) )       self::hero( $o );
        if ( ! empty( $o['about_show'] ) )      self::about( $o );
        if ( ! empty( $o['values_show'] ) )     self::values( $o );
        if ( ! empty( $o['team_show'] ) )       self::team( $o );
        if ( ! empty( $o['activities_show'] ) ) self::activities( $o );
        if ( ! empty( $o['gallery_show'] ) )    self::gallery( $o );
        if ( ! empty( $o['stats_show'] ) )      self::stats( $o );
        if ( ! empty( $o['banner_show'] ) )     self::banner( $o );
        if ( ! empty( $o['visit_show'] ) )      self::visit( $o );
        if ( ! empty( $o['faq_show'] ) )        self::faq( $o );
        echo '</div>';
    }

    /* -------- HERO -------- */

    public static function hero( $o ) {
        $img_d = ptprm_image_url( $o['hero_img_desktop'] );
        $img_t = ptprm_image_url( $o['hero_img_tablet'] );
        $img_m = ptprm_image_url( $o['hero_img_mobile'] );

        $align_h = in_array( $o['hero_text_align_h'], [ 'left', 'center', 'right' ], true ) ? $o['hero_text_align_h'] : 'left';
        $align_v = in_array( $o['hero_text_align_v'], [ 'top', 'middle', 'bottom' ], true ) ? $o['hero_text_align_v'] : 'middle';

        $classes = [
            'ptprm-hero',
            'ptprm-hero-align-h-' . $align_h,
            'ptprm-hero-align-v-' . $align_v,
            'ptprm-hero-height-' . $o['hero_height_mode'],
        ];
        if ( ! empty( $o['hero_animation'] ) && $o['hero_animation'] !== 'none' ) {
            $classes[] = 'ptprm-anim-' . $o['hero_animation'];
        }
        if ( ! $img_d && ! $img_t && ! $img_m ) {
            $classes[] = 'ptprm-hero-noimg';
        }

        echo '<section class="' . esc_attr( implode( ' ', $classes ) ) . '" data-ptprm-hero>';

        echo '<div class="ptprm-hero-media" aria-hidden="true">';
        if ( $img_d || $img_t || $img_m ) {
            echo '<picture>';
            if ( $img_m ) {
                echo '<source media="(max-width: 600px)" srcset="' . esc_url( $img_m ) . '">';
            }
            if ( $img_t ) {
                echo '<source media="(max-width: 1023px)" srcset="' . esc_url( $img_t ) . '">';
            }
            $main = $img_d ?: ( $img_t ?: $img_m );
            echo '<img src="' . esc_url( $main ) . '" alt="" loading="eager" fetchpriority="high" decoding="async">';
            echo '</picture>';
        }
        echo '<div class="ptprm-hero-overlay"></div>';
        echo '</div>';

        $cta1_url = $o['cta1_url'];
        $cta2_url = $o['cta2_url'];
        if ( ! $cta2_url && $o['whatsapp'] ) {
            $cta2_url = ptprm_wa_link( $o['whatsapp'] );
        }

        echo '<div class="ptprm-hero-inner"><div class="ptprm-hero-text">';

        if ( ! empty( $o['hero_eyebrow_show'] ) && $o['hero_eyebrow_text'] !== '' ) {
            echo '<span class="ptprm-hero-eyebrow">' . esc_html( $o['hero_eyebrow_text'] ) . '</span>';
        }
        if ( ! empty( $o['hero_title_show'] ) && $o['hero_title_text'] !== '' ) {
            echo '<h1 class="ptprm-hero-title">' . wp_kses_post( $o['hero_title_text'] ) . '</h1>';
        }
        if ( ! empty( $o['hero_sub_show'] ) && $o['hero_sub_text'] !== '' ) {
            echo '<p class="ptprm-hero-sub">' . wp_kses_post( nl2br( $o['hero_sub_text'] ) ) . '</p>';
        }

        if ( ! empty( $o['cta1_show'] ) || ! empty( $o['cta2_show'] ) ) {
            echo '<div class="ptprm-cta-row">';
            if ( ! empty( $o['cta1_show'] ) && $o['cta1_label'] !== '' ) {
                self::render_cta( 1, $o['cta1_label'], $cta1_url, $o['cta1_target'], $o['cta1_icon'], $o['cta1_style'], $o['cta1_size'] );
            }
            if ( ! empty( $o['cta2_show'] ) && $o['cta2_label'] !== '' ) {
                self::render_cta( 2, $o['cta2_label'], $cta2_url, $o['cta2_target'], $o['cta2_icon'], $o['cta2_style'], $o['cta2_size'] );
            }
            echo '</div>';
        }

        echo '</div></div></section>';
    }

    private static function render_cta( $i, $label, $url, $target, $icon, $style, $size ) {
        $url = $url ? ptprm_resolve_url( $url ) : '#';
        $rel = ( $target === '_blank' ) ? ' rel="noopener noreferrer"' : '';
        $cls = 'ptprm-cta ptprm-cta-' . $i . ' ptprm-cta-' . $style . ' ptprm-cta-size-' . $size;

        echo '<a class="' . esc_attr( $cls ) . '" href="' . esc_url( $url ) . '" target="' . esc_attr( $target ) . '"' . $rel . '>';
        $svg = ptprm_icon_svg( $icon );
        if ( $svg ) {
            echo '<span class="ptprm-cta-icon">' . $svg . '</span>'; // phpcs:ignore
        }
        echo '<span class="ptprm-cta-label">' . esc_html( $label ) . '</span>';
        echo '</a>';
    }

    /* -------- ABOUT -------- */

    public static function about( $o ) {
        $img = ptprm_image_url( $o['about_image'] );
        $layout = $o['about_layout'] === 'image-right' ? 'image-right' : ( $o['about_layout'] === 'text-only' ? 'text-only' : 'image-left' );

        echo '<section class="ptprm-section ptprm-about ptprm-about-' . esc_attr( $layout ) . '">';
        echo '<div class="ptprm-container ptprm-about-inner">';

        if ( $layout !== 'text-only' ) {
            echo '<div class="ptprm-about-media">';
            if ( $img ) {
                echo '<img src="' . esc_url( $img ) . '" alt="" loading="lazy" decoding="async">';
            } else {
                echo '<div class="ptprm-about-placeholder" aria-hidden="true">' . ptprm_icon_svg( 'users' ) . '</div>'; // phpcs:ignore
            }
            echo '</div>';
        }

        echo '<div class="ptprm-about-text">';
        if ( $o['about_eyebrow'] !== '' ) echo '<span class="ptprm-eyebrow">' . esc_html( $o['about_eyebrow'] ) . '</span>';
        if ( $o['about_title'] !== '' )   echo '<h2 class="ptprm-h2">' . esc_html( $o['about_title'] ) . '</h2>';
        if ( $o['about_body'] !== '' ) {
            echo '<div class="ptprm-prose">' . wpautop( wp_kses_post( $o['about_body'] ) ) . '</div>';
        }
        if ( $o['about_cta_label'] !== '' && $o['about_cta_url'] !== '' ) {
            echo '<a class="ptprm-link-arrow" href="' . esc_url( ptprm_resolve_url( $o['about_cta_url'] ) ) . '">';
            echo esc_html( $o['about_cta_label'] ) . ' ' . ptprm_icon_svg( 'arrow' ); // phpcs:ignore
            echo '</a>';
        }
        echo '</div>';

        echo '</div></section>';
    }

    /* -------- VALUES -------- */

    public static function values( $o ) {
        echo '<section class="ptprm-section ptprm-values">';
        echo '<div class="ptprm-container ptprm-text-center">';
        if ( $o['values_eyebrow'] !== '' )  echo '<span class="ptprm-eyebrow">' . esc_html( $o['values_eyebrow'] ) . '</span>';
        if ( $o['values_title'] !== '' )    echo '<h2 class="ptprm-h2">' . esc_html( $o['values_title'] ) . '</h2>';
        if ( $o['values_subtitle'] !== '' ) echo '<p class="ptprm-lead">' . esc_html( $o['values_subtitle'] ) . '</p>';

        echo '<div class="ptprm-values-grid">';
        for ( $i = 1; $i <= 4; $i++ ) {
            $title = $o[ "values_{$i}_title" ] ?? '';
            if ( $title === '' ) continue;
            $icon = $o[ "values_{$i}_icon" ] ?? 'users';
            $desc = $o[ "values_{$i}_desc" ] ?? '';
            echo '<article class="ptprm-value-card" tabindex="0">';
            echo '<div class="ptprm-value-icon">' . ptprm_icon_svg( $icon ) . '</div>'; // phpcs:ignore
            echo '<h3>' . esc_html( $title ) . '</h3>';
            echo '<p class="ptprm-value-teaser">Arahkan kursor untuk penjelasan</p>';
            echo '<div class="ptprm-value-tooltip"><p>' . esc_html( $desc ) . '</p></div>';
            echo '</article>';
        }
        echo '</div></div></section>';
    }

    /* -------- ACTIVITIES (posts) -------- */

    public static function activities( $o ) {
        $count    = max( 1, (int) $o['activities_count'] );
        $cat      = (int) $o['activities_category'];

        $args = [
            'post_type'      => 'post',
            'post_status'    => 'publish',
            'posts_per_page' => $count,
            'ignore_sticky_posts' => true,
        ];
        if ( $cat > 0 ) $args['cat'] = $cat;

        $q = new WP_Query( $args );

        echo '<section class="ptprm-section ptprm-activities">';
        echo '<div class="ptprm-container ptprm-text-center">';
        if ( $o['activities_eyebrow'] !== '' )  echo '<span class="ptprm-eyebrow">' . esc_html( $o['activities_eyebrow'] ) . '</span>';
        if ( $o['activities_title'] !== '' )    echo '<h2 class="ptprm-h2">' . esc_html( $o['activities_title'] ) . '</h2>';
        if ( $o['activities_subtitle'] !== '' ) echo '<p class="ptprm-lead">' . esc_html( $o['activities_subtitle'] ) . '</p>';

        if ( $q->have_posts() ) {
            echo '<div class="ptprm-activities-grid">';
            while ( $q->have_posts() ) {
                $q->the_post();
                $thumb = get_the_post_thumbnail_url( null, 'large' );
                echo '<article class="ptprm-activity-card">';
                echo '<a href="' . esc_url( get_permalink() ) . '" class="ptprm-activity-thumb">';
                if ( $thumb ) {
                    echo '<img src="' . esc_url( $thumb ) . '" alt="" loading="lazy" decoding="async">';
                } else {
                    echo '<div class="ptprm-activity-placeholder">' . ptprm_icon_svg( 'feather' ) . '</div>'; // phpcs:ignore
                }
                echo '</a>';
                echo '<div class="ptprm-activity-body">';
                echo '<time class="ptprm-activity-date">' . esc_html( get_the_date() ) . '</time>';
                echo '<h3 class="ptprm-activity-title"><a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a></h3>';
                echo '<p class="ptprm-activity-excerpt">' . esc_html( wp_trim_words( wp_strip_all_tags( get_the_excerpt() ), 22 ) ) . '</p>';
                echo '<a class="ptprm-link-arrow" href="' . esc_url( get_permalink() ) . '">Selengkapnya ' . ptprm_icon_svg( 'arrow' ) . '</a>'; // phpcs:ignore
                echo '</div></article>';
            }
            echo '</div>';
            wp_reset_postdata();
        } else {
            echo '<p class="ptprm-empty">Belum ada kegiatan yang dipublikasikan.</p>';
        }

        if ( $o['activities_more_label'] !== '' && $o['activities_more_url'] !== '' ) {
            echo '<div class="ptprm-section-cta">';
            echo '<a class="ptprm-cta ptprm-cta-outline ptprm-cta-size-medium" href="' . esc_url( ptprm_resolve_url( $o['activities_more_url'] ) ) . '">';
            echo '<span class="ptprm-cta-label">' . esc_html( $o['activities_more_label'] ) . '</span>';
            echo ptprm_icon_svg( 'arrow' ); // phpcs:ignore
            echo '</a></div>';
        }

        echo '</div></section>';
    }

    /* -------- STATS -------- */

    public static function stats( $o ) {
        echo '<section class="ptprm-section ptprm-stats">';
        echo '<div class="ptprm-container">';
        echo '<div class="ptprm-text-center">';
        if ( $o['stats_eyebrow'] !== '' ) echo '<span class="ptprm-eyebrow ptprm-eyebrow-on-dark">' . esc_html( $o['stats_eyebrow'] ) . '</span>';
        if ( $o['stats_title'] !== '' )   echo '<h2 class="ptprm-h2 ptprm-on-dark">' . esc_html( $o['stats_title'] ) . '</h2>';
        echo '</div>';
        echo '<div class="ptprm-stats-grid"' . ( ! empty( $o['stats_animate'] ) ? ' data-ptprm-animate' : '' ) . '>';
        foreach ( [ 'a', 'b', 'c', 'd' ] as $k ) {
            $num   = $o[ "stats_{$k}_num" ] ?? '';
            $label = $o[ "stats_{$k}_label" ] ?? '';
            if ( $num === '' && $label === '' ) continue;
            echo '<div class="ptprm-stat">';
            echo '<div class="ptprm-stat-num" data-ptprm-counter>' . esc_html( $num ) . '</div>';
            echo '<div class="ptprm-stat-label">' . esc_html( $label ) . '</div>';
            echo '</div>';
        }
        echo '</div></div></section>';
    }

    /* -------- VISIT -------- */

    public static function visit( $o ) {
        $wa = '';
        if ( ! empty( $o['visit_show_wa'] ) ) {
            $wa = ptprm_wa_link( $o['whatsapp'] );
        }

        echo '<section class="ptprm-section ptprm-visit">';
        echo '<div class="ptprm-container">';

        echo '<div class="ptprm-visit-head">';
        if ( $o['visit_eyebrow'] !== '' ) echo '<span class="ptprm-eyebrow">' . esc_html( $o['visit_eyebrow'] ) . '</span>';
        if ( $o['visit_title'] !== '' )   echo '<h2 class="ptprm-h2">' . esc_html( $o['visit_title'] ) . '</h2>';
        if ( $o['visit_intro'] !== '' )   echo '<p class="ptprm-lead">' . esc_html( $o['visit_intro'] ) . '</p>';
        echo '</div>';

        echo '<div class="ptprm-visit-grid">';

        // Address card (left)
        echo '<div class="ptprm-visit-card">';
        $has_line = false;
        if ( ! empty( $o['visit_show_address'] ) ) {
            if ( $o['address'] !== '' ) {
                echo '<div class="ptprm-visit-line">' . ptprm_icon_svg( 'pin' ); // phpcs:ignore
                echo '<span><strong>Alamat:</strong><br>' . esc_html( $o['address'] ) . '</span></div>';
                $has_line = true;
            } else {
                echo '<div class="ptprm-visit-line">' . ptprm_icon_svg( 'pin' ); // phpcs:ignore
                echo '<span><strong>Alamat:</strong><br><span class="ptprm-visit-empty-msg">Isi alamat di Premium Plugin → Umum → Kontak &amp; Alamat.</span></span></div>';
                $has_line = true;
            }
        }
        if ( ! empty( $o['visit_show_hours'] ) && $o['hours'] !== '' ) {
            echo '<div class="ptprm-visit-line">' . ptprm_icon_svg( 'clock' ); // phpcs:ignore
            echo '<span><strong>Jam Operasional:</strong><br>' . esc_html( $o['hours'] ) . '</span></div>';
            $has_line = true;
        }
        if ( $wa ) {
            echo '<div class="ptprm-visit-line">' . ptprm_icon_svg( 'whatsapp' ); // phpcs:ignore
            echo '<span><strong>WhatsApp:</strong><br><a href="' . esc_url( $wa ) . '" target="_blank" rel="noopener">Hubungi kami</a></span></div>';
            $has_line = true;
        }
        if ( ! $has_line ) {
            echo '<p class="ptprm-visit-empty-msg">Aktifkan informasi (alamat / jam / WA) di Premium Plugin → Beranda → Kunjungi Kami.</p>';
        }
        echo '</div>';

        // Map box (right)
        echo '<div class="ptprm-visit-map">';
        if ( $o['visit_map_url'] !== '' ) {
            echo '<iframe src="' . esc_url( $o['visit_map_url'] ) . '" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe>';
        } else {
            echo '<div class="ptprm-visit-map-empty">';
            echo ptprm_icon_svg( 'pin' ); // phpcs:ignore
            echo '<p>Tambahkan peta:<br><strong>Google Maps → Bagikan → Sematkan peta</strong>,<br>salin URL <code>src</code> ke Premium Plugin → Beranda → Kunjungi Kami → <em>URL embed Google Maps</em>.</p>';
            echo '</div>';
        }
        echo '</div>';

        echo '</div>'; // visit-grid
        echo '</div></section>';
    }

    /* -------- TEAM -------- */

    public static function team( $o ) {
        $cols = max( 2, min( 6, (int) ( $o['team_columns'] ?: 4 ) ) );
        echo '<section class="ptprm-section ptprm-team">';
        echo '<div class="ptprm-container ptprm-text-center">';
        if ( $o['team_eyebrow'] !== '' )  echo '<span class="ptprm-eyebrow">' . esc_html( $o['team_eyebrow'] ) . '</span>';
        if ( $o['team_title'] !== '' )    echo '<h2 class="ptprm-h2">' . esc_html( $o['team_title'] ) . '</h2>';
        if ( $o['team_subtitle'] !== '' ) echo '<p class="ptprm-lead">' . esc_html( $o['team_subtitle'] ) . '</p>';

        echo '<div class="ptprm-team-grid" style="--ptprm-team-cols:' . (int) $cols . ';">';
        $count = 0;
        for ( $i = 1; $i <= 8; $i++ ) {
            $name = $o[ "team_{$i}_name" ] ?? '';
            if ( $name === '' ) continue;
            $count++;
            $img  = ptprm_image_url( $o[ "team_{$i}_image" ] ?? '' );
            $role = $o[ "team_{$i}_role" ] ?? '';
            $url  = $o[ "team_{$i}_url" ] ?? '';

            echo '<article class="ptprm-team-card">';
            echo '<div class="ptprm-team-photo">';
            if ( $img ) {
                echo '<img src="' . esc_url( $img ) . '" alt="' . esc_attr( $name ) . '" loading="lazy" decoding="async">';
            } else {
                echo '<div class="ptprm-team-placeholder" aria-hidden="true">' . ptprm_icon_svg( 'users' ) . '</div>'; // phpcs:ignore
            }
            echo '</div>';
            echo '<div class="ptprm-team-body">';
            echo '<h3 class="ptprm-team-name">' . esc_html( $name ) . '</h3>';
            if ( $role !== '' ) echo '<p class="ptprm-team-role">' . esc_html( $role ) . '</p>';
            if ( $url !== '' ) {
                echo '<a class="ptprm-team-link" href="' . esc_url( ptprm_resolve_url( $url ) ) . '" target="_blank" rel="noopener">';
                echo 'Profil ' . ptprm_icon_svg( 'arrow' ); // phpcs:ignore
                echo '</a>';
            }
            echo '</div></article>';
        }
        echo '</div>';

        if ( $count === 0 ) {
            echo '<p class="ptprm-empty">Belum ada data pengurus. Isi di Premium Plugin → Beranda → Pengurus.</p>';
        }

        if ( $o['team_more_label'] !== '' && $o['team_more_url'] !== '' ) {
            echo '<div class="ptprm-section-cta">';
            echo '<a class="ptprm-cta ptprm-cta-outline ptprm-cta-size-medium" href="' . esc_url( ptprm_resolve_url( $o['team_more_url'] ) ) . '">';
            echo '<span class="ptprm-cta-label">' . esc_html( $o['team_more_label'] ) . '</span>';
            echo ptprm_icon_svg( 'arrow' ); // phpcs:ignore
            echo '</a></div>';
        }

        echo '</div></section>';
    }

    /* -------- GALLERY -------- */

    public static function gallery( $o ) {
        $ids = array_filter( array_map( 'intval', explode( ',', (string) $o['gallery_ids'] ) ) );
        $cols = max( 2, min( 6, (int) ( $o['gallery_columns'] ?: 4 ) ) );

        echo '<section class="ptprm-section ptprm-gallery">';
        echo '<div class="ptprm-container ptprm-text-center">';
        if ( $o['gallery_eyebrow'] !== '' )  echo '<span class="ptprm-eyebrow">' . esc_html( $o['gallery_eyebrow'] ) . '</span>';
        if ( $o['gallery_title'] !== '' )    echo '<h2 class="ptprm-h2">' . esc_html( $o['gallery_title'] ) . '</h2>';
        if ( $o['gallery_subtitle'] !== '' ) echo '<p class="ptprm-lead">' . esc_html( $o['gallery_subtitle'] ) . '</p>';

        if ( ! $ids ) {
            echo '<p class="ptprm-empty">Belum ada foto. Tambahkan di Premium Plugin → Beranda → Galeri Foto.</p>';
        } else {
            $lightbox = ! empty( $o['gallery_lightbox'] );
            echo '<div class="ptprm-gallery-grid" style="--ptprm-gallery-cols:' . (int) $cols . ';">';
            foreach ( $ids as $id ) {
                $thumb = wp_get_attachment_image_url( $id, 'large' );
                $full  = wp_get_attachment_image_url( $id, 'full' );
                if ( ! $thumb ) continue;
                $alt   = get_post_meta( $id, '_wp_attachment_image_alt', true );
                if ( $lightbox ) {
                    echo '<a class="ptprm-gallery-item" href="' . esc_url( $full ) . '" data-ptprm-lightbox>';
                } else {
                    echo '<div class="ptprm-gallery-item">';
                }
                echo '<img src="' . esc_url( $thumb ) . '" alt="' . esc_attr( $alt ) . '" loading="lazy" decoding="async">';
                echo $lightbox ? '</a>' : '</div>';
            }
            echo '</div>';
        }
        echo '</div></section>';
    }

    /* -------- BANNER CTA -------- */

    public static function banner( $o ) {
        $img = ptprm_image_url( $o['banner_image'] );
        $overlay = max( 0, min( 100, (int) $o['banner_overlay'] ) ) / 100;

        echo '<section class="ptprm-section ptprm-banner-cta"' . ( $img ? ' style="background-image:url(' . esc_url( $img ) . ');"' : '' ) . '>';
        echo '<div class="ptprm-banner-overlay" aria-hidden="true" style="opacity:' . esc_attr( $overlay ) . '"></div>';
        echo '<div class="ptprm-container ptprm-banner-inner">';
        if ( $o['banner_eyebrow'] !== '' )  echo '<span class="ptprm-eyebrow ptprm-eyebrow-on-dark">' . esc_html( $o['banner_eyebrow'] ) . '</span>';
        if ( $o['banner_title'] !== '' )    echo '<h2 class="ptprm-h2 ptprm-on-dark">' . esc_html( $o['banner_title'] ) . '</h2>';
        if ( $o['banner_subtitle'] !== '' ) echo '<p class="ptprm-lead ptprm-on-dark">' . esc_html( $o['banner_subtitle'] ) . '</p>';

        echo '<div class="ptprm-cta-row" style="justify-content:center;">';
        if ( $o['banner_cta_label'] !== '' ) {
            $url = $o['banner_cta_url'] ? ptprm_resolve_url( $o['banner_cta_url'] ) : '#';
            echo '<a class="ptprm-cta ptprm-cta-1 ptprm-cta-solid ptprm-cta-size-large" href="' . esc_url( $url ) . '">';
            echo '<span class="ptprm-cta-label">' . esc_html( $o['banner_cta_label'] ) . '</span>';
            echo ptprm_icon_svg( 'arrow' ); // phpcs:ignore
            echo '</a>';
        }
        if ( ! empty( $o['banner_cta2_show'] ) && $o['banner_cta2_label'] !== '' ) {
            $url2 = $o['banner_cta2_url'] ? ptprm_resolve_url( $o['banner_cta2_url'] ) : ( $o['whatsapp'] ? ptprm_wa_link( $o['whatsapp'] ) : '#' );
            echo '<a class="ptprm-cta ptprm-cta-2 ptprm-cta-ghost ptprm-cta-size-large" href="' . esc_url( $url2 ) . '" target="_blank" rel="noopener">';
            echo ptprm_icon_svg( 'whatsapp' ); // phpcs:ignore
            echo '<span class="ptprm-cta-label">' . esc_html( $o['banner_cta2_label'] ) . '</span>';
            echo '</a>';
        }
        echo '</div>';
        echo '</div></section>';
    }

    /* -------- FAQ -------- */

    public static function faq( $o ) {
        echo '<section class="ptprm-section ptprm-faq">';
        echo '<div class="ptprm-container">';
        echo '<div class="ptprm-text-center" style="max-width:760px;margin:0 auto 40px;">';
        if ( $o['faq_eyebrow'] !== '' )  echo '<span class="ptprm-eyebrow">' . esc_html( $o['faq_eyebrow'] ) . '</span>';
        if ( $o['faq_title'] !== '' )    echo '<h2 class="ptprm-h2">' . esc_html( $o['faq_title'] ) . '</h2>';
        if ( $o['faq_subtitle'] !== '' ) echo '<p class="ptprm-lead">' . esc_html( $o['faq_subtitle'] ) . '</p>';
        echo '</div>';

        echo '<div class="ptprm-faq-list">';
        $count = 0;
        for ( $i = 1; $i <= 10; $i++ ) {
            $q = $o[ "faq_{$i}_q" ] ?? '';
            $a = $o[ "faq_{$i}_a" ] ?? '';
            if ( $q === '' ) continue;
            $count++;
            echo '<details class="ptprm-faq-item"' . ( $count === 1 ? ' open' : '' ) . '>';
            echo '<summary class="ptprm-faq-q">';
            echo '<span>' . esc_html( $q ) . '</span>';
            echo '<span class="ptprm-faq-icon" aria-hidden="true">+</span>';
            echo '</summary>';
            echo '<div class="ptprm-faq-a">' . wpautop( wp_kses_post( $a ) ) . '</div>';
            echo '</details>';
        }
        if ( $count === 0 ) {
            echo '<p class="ptprm-empty">Belum ada pertanyaan. Isi di Premium Plugin → Beranda → FAQ.</p>';
        }
        echo '</div>';

        echo '</div></section>';
    }

    /* ===================================================================== */
    /* FOOTER                                                                */
    /* ===================================================================== */

    public static function footer() {
        $o = ptprm_options();
        if ( empty( $o['footer_show'] ) ) return;

        $year = (int) gmdate( 'Y' );
        $copy = str_replace(
            [ '{year}', '{org}' ],
            [ $year, $o['org_name'] ?: 'Organisasi' ],
            (string) $o['footer_copyright']
        );

        echo '<footer class="ptprm-footer" role="contentinfo">';
        echo '<div class="ptprm-container ptprm-footer-grid">';

        echo '<div class="ptprm-footer-brand">';
        echo '<h4>' . esc_html( $o['org_name'] ?: 'Organisasi' ) . '</h4>';
        if ( $o['footer_tagline'] !== '' ) {
            echo '<p>' . esc_html( $o['footer_tagline'] ) . '</p>';
        }
        if ( ! empty( $o['footer_show_social'] ) ) {
            echo '<div class="ptprm-footer-social">';
            $networks = [
                'facebook'  => $o['fb_url'],
                'instagram' => $o['ig_url'],
                'youtube'   => $o['yt_url'],
                'tiktok'    => $o['tt_url'],
            ];
            foreach ( $networks as $name => $url ) {
                if ( ! $url ) continue;
                echo '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener" aria-label="' . esc_attr( ucfirst( $name ) ) . '">';
                echo ptprm_icon_svg( $name ); // phpcs:ignore
                echo '</a>';
            }
            if ( $o['whatsapp'] ) {
                echo '<a href="' . esc_url( ptprm_wa_link( $o['whatsapp'] ) ) . '" target="_blank" rel="noopener" aria-label="WhatsApp">';
                echo ptprm_icon_svg( 'whatsapp' ); // phpcs:ignore
                echo '</a>';
            }
            echo '</div>';
        }
        echo '</div>';

        self::footer_column( $o['footer_col1_label'], $o['footer_col1_links'] );
        self::footer_column( $o['footer_col2_label'], $o['footer_col2_links'] );

        echo '<div class="ptprm-footer-contact"><h4>Kontak</h4>';
        if ( $o['address'] !== '' ) echo '<p>' . esc_html( $o['address'] ) . '</p>';
        if ( $o['hours'] !== '' )   echo '<p>' . esc_html( $o['hours'] ) . '</p>';
        echo '</div>';

        echo '</div>';
        echo '<div class="ptprm-footer-bottom">' . esc_html( $copy ) . '</div>';
        echo '</footer>';
    }

    private static function footer_column( $label, $links_text ) {
        $links = ptprm_parse_links( $links_text );
        if ( ! $links && $label === '' ) return;

        echo '<div class="ptprm-footer-col">';
        if ( $label !== '' ) echo '<h4>' . esc_html( $label ) . '</h4>';
        if ( $links ) {
            echo '<ul>';
            foreach ( $links as $l ) {
                $url = $l['url'];
                if ( $url && $url[0] === '/' ) {
                    $url = home_url( $url );
                }
                echo '<li><a href="' . esc_url( $url ) . '">' . esc_html( $l['label'] ) . '</a></li>';
            }
            echo '</ul>';
        }
        echo '</div>';
    }

    /* ===================================================================== */
    /* SUB-PAGE HERO                                                         */
    /* ===================================================================== */

    public static function subpage_hero( $args = [] ) {
        $o = ptprm_options();
        if ( empty( $o['subpage_hero_show'] ) ) return;

        $defaults = [
            'eyebrow' => '',
            'title'   => '',
            'intro'   => '',
            'image'   => '',
        ];
        $a = wp_parse_args( $args, $defaults );

        if ( $a['title'] === '' ) {
            $a['title'] = (string) get_the_title();
        }
        if ( $a['eyebrow'] === '' && ! empty( $o['subpage_eyebrow_auto'] ) ) {
            $a['eyebrow'] = mb_strtoupper( $a['title'] );
        }

        $img = ptprm_image_url( $a['image'] );
        if ( ! $img && has_post_thumbnail() ) {
            $img = get_the_post_thumbnail_url( null, 'full' );
        }

        $classes = [ 'ptprm-subhero' ];
        $classes[] = $img ? 'ptprm-subhero-photo' : 'ptprm-subhero-pattern';
        if ( ! empty( $o['subpage_gorga'] ) ) $classes[] = 'ptprm-subhero-gorga';

        echo '<section class="' . esc_attr( implode( ' ', $classes ) ) . '"' . ( $img ? ' style="background-image:url(' . esc_url( $img ) . ')"' : '' ) . '>';
        echo '<div class="ptprm-subhero-overlay" aria-hidden="true"></div>';
        echo '<div class="ptprm-container ptprm-subhero-inner">';

        if ( ! empty( $o['subpage_breadcrumb'] ) ) {
            echo '<nav class="ptprm-breadcrumb" aria-label="Breadcrumb">';
            echo '<a href="' . esc_url( home_url( '/' ) ) . '">Beranda</a><span class="sep">/</span>';
            echo '<span>' . esc_html( $a['title'] ) . '</span></nav>';
        }
        if ( $a['eyebrow'] !== '' ) {
            echo '<span class="ptprm-subhero-eyebrow">' . esc_html( $a['eyebrow'] ) . '</span>';
        }
        echo '<h1 class="ptprm-subhero-title">' . esc_html( $a['title'] ) . '</h1>';

        $intro = $a['intro'] !== '' ? $a['intro'] : (string) $o['subpage_default_intro'];
        if ( $intro !== '' ) {
            echo '<p class="ptprm-subhero-sub">' . esc_html( $intro ) . '</p>';
        }
        if ( ! empty( $o['subpage_ornament'] ) ) {
            echo '<div class="ptprm-subhero-ornament" aria-hidden="true">' . ptprm_ornament_svg() . '</div>'; // phpcs:ignore
        }

        echo '</div></section>';
    }
}
