<?php
/**
 * Take over the homepage rendering via template_include.
 * Astra header/menu masih dipanggil (get_header), tetapi seluruh konten Beranda
 * di-render oleh plugin. Elementor di Beranda diabaikan dengan aman.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PTPRM_Home {

    public function __construct() {
        add_filter( 'template_include', [ $this, 'use_home_template' ], 999 );
        add_filter( 'body_class',       [ $this, 'body_class' ] );
        add_action( 'wp_footer',        [ $this, 'render_premium_footer' ], 9 );
    }

    public function use_home_template( $template ) {
        if ( ! ( is_front_page() || is_home() ) ) {
            return $template;
        }
        $custom = PTPRM_DIR . 'templates/home.php';
        return file_exists( $custom ) ? $custom : $template;
    }

    public function body_class( $classes ) {
        if ( is_front_page() || is_home() ) {
            $classes[] = 'ptprm-is-home';
        } elseif ( is_page() ) {
            $classes[] = 'ptprm-is-subpage';
        }
        return $classes;
    }

    public function render_premium_footer() {
        $o = ptprm_options();
        if ( empty( $o['footer_show'] ) ) return;
        PTPRM_Renderer::footer();
    }
}
