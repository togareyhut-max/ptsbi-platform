# Membership API v1 Blueprint

Dokumen ini menjadi kontrak teknis untuk memulai layanan API terpisah:

- WordPress hanya frontend/panel.
- Membership API menangani auth + pendaftar + approval + import/export.
- Database membership dipisah dari database tarombo agar import CSV tidak merusak data tarombo.
- Transfer data anggota <-> tarombo hanya melalui approval superadmin.

Kondisi real dari `tarombo-app` (hasil analisa):
- `tarombo-app` adalah **Flask monolith** (session-cookie auth), bukan Laravel.
- Duplicate detection/treatment sudah ada di tarombo.
- Belum ada API integrasi resmi service-to-service untuk sinkron membership.

## 1) Arsitektur

### Komponen

1. **WordPress Frontend**
   - Halaman publik
   - Rumah Anggota (login/register)
   - Panel Anggota / Pengurus / Admin Organisasi
2. **Membership API (Laravel + Sanctum)**
   - Auth, role, registration, approval
   - Import CSV anggota
   - Export XLSX
   - Workflow transfer data ke/dari tarombo
3. **Membership DB (baru, terpisah)**
   - Menyimpan data user/pendaftar anggota organisasi
4. **Tarombo App + Tarombo DB (existing, Flask)**
   - Tetap source of truth data silsilah
   - Sudah punya deteksi/penanganan duplikat
   - Input silsilah tetap hanya via tarombo-app

### Prinsip integrasi

- Membership API **tidak menulis langsung** ke tabel inti tarombo.
- Untuk transfer, Membership API mengirim **transfer request** ke Tarombo Integration API layer (baru) di tarombo-app.
- Tarombo Integration API melakukan validasi + duplicate check + treatment internal.
- Semua write lintas sistem harus melewati queue + approval `superadmin`.

## 2) Role dan Hak Akses

- `member`
  - login
  - lihat/update profil sendiri
- `staff` (pengurus)
  - lihat pendaftar/panel operasional terbatas
  - tidak bisa approve transfer lintas sistem
- `org_admin` (admin organisasi)
  - approve pendaftar anggota
  - import CSV anggota
  - export XLSX anggota
  - kelola setting membership
- `superadmin`
  - approve transfer data anggota <-> tarombo
  - override/reprocess transfer gagal

## 3) Model Data (Membership DB)

## tabel: `users`
- `id` bigint PK
- `email` varchar(190) unique
- `password_hash` varchar(255)
- `role` enum(`member`,`staff`,`org_admin`,`superadmin`)
- `status` enum(`active`,`inactive`,`locked`)
- `last_login_at` datetime nullable
- `created_at`, `updated_at`

## tabel: `member_profiles`
- `id` bigint PK
- `user_id` FK -> users.id unique
- `full_name` varchar(190)
- `phone_wa` varchar(50)
- `family_name` varchar(190) nullable
- `city` varchar(190) nullable
- `district` varchar(190) nullable
- `address_detail` text nullable
- `meta_json` json nullable
- `created_at`, `updated_at`

## tabel: `registrations`
- `id` bigint PK
- `full_name` varchar(190)
- `email` varchar(190)
- `phone_wa` varchar(50)
- `password_hash` varchar(255)
- `status` enum(`pending`,`approved`,`rejected`,`cancelled`)
- `approved_by` bigint nullable
- `approved_at` datetime nullable
- `rejected_by` bigint nullable
- `rejected_at` datetime nullable
- `reject_reason` text nullable
- `source` enum(`form`,`csv_import`,`api`)
- `payload_json` json nullable
- `created_at`, `updated_at`
- index: `(status, created_at)`, `(email)`, `(phone_wa)`

## tabel: `imports`
- `id` bigint PK
- `file_name` varchar(255)
- `storage_path` varchar(255)
- `uploaded_by` bigint
- `status` enum(`uploaded`,`processing`,`completed`,`failed`)
- `total_rows` int default 0
- `success_rows` int default 0
- `failed_rows` int default 0
- `error_log_json` json nullable
- `created_at`, `updated_at`

## tabel: `transfer_requests`
- `id` bigint PK
- `direction` enum(`members_to_tarombo`,`tarombo_to_members`)
- `requested_by` bigint
- `approved_by_superadmin` bigint nullable
- `status` enum(`pending_superadmin`,`approved`,`running`,`done`,`failed`,`rejected`)
- `scope_json` json
- `result_json` json nullable
- `created_at`, `updated_at`

## tabel: `audit_logs`
- `id` bigint PK
- `actor_user_id` bigint nullable
- `action` varchar(120)
- `entity_type` varchar(120)
- `entity_id` varchar(120) nullable
- `ip_address` varchar(64) nullable
- `user_agent` text nullable
- `payload_json` json nullable
- `created_at`

## 4) Endpoint API v1

Base URL: `https://api.tarombo.ptsbi.org/v1`

### Auth

- `POST /auth/login`
  - body: `email`, `password`
  - result: access token + profile + role
- `POST /auth/logout`
- `GET /auth/me`

### Registrasi & Approval

- `POST /registrations`
  - body minimal: `full_name`, `email`, `phone_wa`, `password`
  - status default `pending` (atau `approved` jika auto approve aktif)
- `GET /registrations?status=pending`
  - role: `org_admin|superadmin`
- `POST /registrations/{id}/approve`
  - role: `org_admin|superadmin`
- `POST /registrations/{id}/reject`
  - role: `org_admin|superadmin`

### Member

- `GET /members`
  - filter: name, city, district, page, per_page
- `GET /members/{id}`
- `PATCH /members/{id}`
  - `member` hanya diri sendiri
  - `staff/org_admin` sesuai policy

### Import/Export

- `POST /imports/members/csv`
  - upload CSV
  - role: `org_admin|superadmin`
- `GET /imports/{id}`
  - status progres import
- `GET /exports/members.xlsx`
  - role: `org_admin|superadmin`
  - support filter query

### Transfer lintas sistem

- `POST /transfers`
  - body: `direction`, `scope_json`
  - status awal: `pending_superadmin`
- `GET /transfers`
- `POST /transfers/{id}/approve`
  - role: `superadmin` only
- `POST /transfers/{id}/run`
  - role: `superadmin` only

### Endpoint tambahan yang wajib dibuat di tarombo-app (Flask)

Base URL tarombo: `https://tarombo.ptsbi.org/api/integration`

- `POST /membership/submissions`
  - menerima payload transfer dari membership API
  - simpan ke staging queue tarombo, status `pending_superadmin`
- `GET /membership/submissions/{id}`
- `GET /membership/submissions?status=pending_superadmin`
- `POST /membership/submissions/{id}/approve`
  - jalankan flow internal tarombo untuk promote/merge + duplicate handling
- `POST /membership/submissions/{id}/reject`
- `GET /membership/events?since=<cursor>`
  - event outbound tarombo -> membership (approved/rejected/merged)

## 5) Workflow Penting

### A. Registrasi manual approve
1. User daftar dari WP frontend -> `POST /registrations`
2. Status `pending`
3. Admin organisasi approve
4. API membuat user aktif + member profile
5. Notifikasi email/WA link terkirim

### B. Import CSV
1. Admin upload CSV
2. API parsing + validasi skema
3. Data masuk ke membership DB (bukan tarombo DB)
4. Jika ada kebutuhan sinkron ke tarombo, buat `transfer_request`

### C. Transfer ke tarombo (harus superadmin)
1. Org admin/staff ajukan transfer
2. Superadmin approve
3. Runner transfer memanggil Tarombo Integration API
4. Tarombo Integration API menjalankan duplicate detection/treatment
5. Hasil tersimpan pada `transfer_requests.result_json`

### D. Sinkron balik dari tarombo
1. Membership API pull event dari `GET /api/integration/membership/events`
2. Update status transfer/member mapping lokal
3. Simpan jejak ke `audit_logs`

## 6) Security Baseline

- Hash password: Argon2id/bcrypt cost tinggi
- Token auth: Sanctum personal access token + expiry policy
- Rate limit login/register/import
- CORS whitelist origin WP frontend
- Audit log untuk approve/reject/import/transfer
- Encrypt secret env + backup rutin
- Semua endpoint write wajib auth + permission check
- Service-to-service auth antar API wajib API key/HMAC + idempotency key

## 7) Integrasi WordPress (Client API)

Plugin WP akan:
- simpan token/session API (cookie aman)
- panggil endpoint API untuk login/register/member CRUD
- menampilkan panel sesuai role dari claim API
- tidak lagi bergantung pada wp-admin untuk user organisasi

## 8) Tahap Implementasi

### Sprint 1
- Bootstrap Laravel + Sanctum
- endpoint auth + registration + pending/approve
- endpoint members basic

### Sprint 2
- import CSV + export XLSX
- notification email + wa link
- audit logs

### Sprint 3
- transfer request workflow + approval superadmin
- adapter Tarombo Integration API (Flask)
- duplicate-handling handshake

### Sprint 4
- migrasi plugin WP ke API client
- UAT + hardening

