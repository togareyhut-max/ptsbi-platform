# Tarombo Integration Contract v1

Kontrak ini mendefinisikan payload JSON antara:

- Membership API (`api.tarombo.ptsbi.org`)
- Tarombo App Integration API (`tarombo.ptsbi.org/api/integration`)

Tujuan:
- Transfer data aman tanpa direct write ke DB tarombo.
- Semua transfer harus lewat approval `superadmin`.
- Duplicate detection tetap dijalankan oleh tarombo-app internal flow.

## 1) Auth antar service

- Header wajib:
  - `X-Integration-Key: <shared-secret-or-key-id>`
  - `X-Idempotency-Key: <uuid-v4>`
  - `X-Signature: <hmac-sha256(payload, shared-secret)>` (opsional tahap 1, wajib tahap produksi)

## 2) State machine transfer

- `pending_superadmin` -> `approved` -> `running` -> `done`
- `pending_superadmin` -> `rejected`
- `running` -> `failed` (dengan detail error)

## 3) Endpoint Tarombo Integration API

Base: `https://tarombo.ptsbi.org/api/integration`

### 3.1 Create submission (membership -> tarombo)

`POST /membership/submissions`

Request:

```json
{
  "source_system": "membership-api",
  "direction": "members_to_tarombo",
  "requested_by": {
    "user_id": "mem_1001",
    "role": "org_admin",
    "email": "admin@ptsbi.org"
  },
  "scope": {
    "mode": "single",
    "member_ids": ["mbr_00123"]
  },
  "payload": {
    "member": {
      "external_id": "mbr_00123",
      "full_name": "Nama Anggota",
      "email": "anggota@example.com",
      "phone_wa": "6281234567890",
      "city": "Jakarta",
      "district": "Jagakarsa"
    },
    "tarombo_hints": {
      "father_name": null,
      "mother_name": null,
      "spouse_name": null
    }
  }
}
```

Response:

```json
{
  "transfer_id": "trf_9f7f8e",
  "status": "pending_superadmin",
  "created_at": "2026-05-28T08:00:00Z"
}
```

### 3.2 Get submission status

`GET /membership/submissions/{transfer_id}`

Response:

```json
{
  "transfer_id": "trf_9f7f8e",
  "status": "running",
  "direction": "members_to_tarombo",
  "superadmin": {
    "approved_by": "usr_1",
    "approved_at": "2026-05-28T08:10:00Z"
  },
  "result": null
}
```

### 3.3 Approve transfer (superadmin only)

`POST /membership/submissions/{transfer_id}/approve`

Request:

```json
{
  "approved_by": {
    "user_id": "usr_1",
    "email": "superadmin@ptsbi.org"
  },
  "note": "OK lanjutkan sinkron"
}
```

### 3.4 Reject transfer (superadmin only)

`POST /membership/submissions/{transfer_id}/reject`

Request:

```json
{
  "rejected_by": {
    "user_id": "usr_1",
    "email": "superadmin@ptsbi.org"
  },
  "reason": "Data belum lengkap"
}
```

### 3.5 Pull events (tarombo -> membership)

`GET /membership/events?since=2026-05-28T08:00:00Z&limit=100`

Response:

```json
{
  "events": [
    {
      "event_id": "evt_001",
      "event_type": "transfer.done",
      "occurred_at": "2026-05-28T08:20:00Z",
      "transfer_id": "trf_9f7f8e",
      "payload": {
        "status": "done",
        "duplicate_action": "merged",
        "tarombo_person_id": "prs_7788"
      }
    }
  ],
  "next_cursor": "2026-05-28T08:20:00Z"
}
```

## 4) Error format standar

```json
{
  "error": {
    "code": "TRANSFER_NOT_FOUND",
    "message": "Transfer request tidak ditemukan",
    "details": {}
  }
}
```

## 5) Mapping field minimum

- membership `full_name` -> tarombo candidate `full_name`
- membership `email` -> tarombo account email (jika account dibuat)
- membership `phone_wa` -> kontak (di staging/meta jika schema tarombo belum punya kolom)
- membership `city`, `district` -> metadata referensi (bukan penentu relasi silsilah)

Catatan:
- Relasi ayah/ibu/spouse tidak dipaksakan dari membership form awal.
- Tarombo-app tetap melakukan validasi + duplicate treatment internal sebelum commit.

