# VPS Setup Laravel Membership API

Panduan ini untuk memulai service API di VPS Anda sendiri (tanpa vendor berlangganan).

Catatan konteks:
- `tarombo-app` existing berjalan di Flask dan auth session.
- API ini adalah service baru untuk membership; integrasi ke tarombo dilakukan via endpoint integration yang ditambahkan di tarombo-app (bukan direct DB write).

## 1) Prasyarat di VPS

- Ubuntu 22.04+ (disarankan)
- Nginx
- PHP 8.2+
- Composer
- MySQL/MariaDB
- Redis (opsional, untuk queue/cache)
- Supervisor (opsional, untuk queue worker)

## 2) Struktur folder disarankan

- `/var/www/tarombo-api` -> source code Laravel
- domain API: `api.tarombo.ptsbi.org`

## 3) Bootstrap project

```bash
cd /var/www
composer create-project laravel/laravel tarombo-api
cd tarombo-api
composer require laravel/sanctum
php artisan vendor:publish --provider="Laravel\Sanctum\SanctumServiceProvider"
php artisan migrate
```

## 4) Buat database terpisah

```sql
CREATE DATABASE tarombo_membership_api
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
```

Set `.env`:

```env
APP_NAME=TaromboMembershipAPI
APP_ENV=production
APP_DEBUG=false
APP_URL=https://api.tarombo.ptsbi.org

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=tarombo_membership_api
DB_USERNAME=...
DB_PASSWORD=...
```

## 5) Sanctum config ringkas

- Pastikan middleware auth sanctum aktif untuk route protected.
- Untuk frontend WP beda subdomain, atur CORS whitelist + `SESSION_DOMAIN` jika mode cookie-based.
- Jika token-based, gunakan Bearer token pada client WP.

## 6) Nginx minimal

```nginx
server {
    listen 80;
    server_name api.tarombo.ptsbi.org;
    root /var/www/tarombo-api/public;
    index index.php;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/run/php/php8.2-fpm.sock;
    }
}
```

Lalu pasang SSL:

```bash
sudo certbot --nginx -d api.tarombo.ptsbi.org
```

## 7) Endpoint awal yang langsung dibuat

1. `POST /v1/auth/login`
2. `POST /v1/auth/logout`
3. `POST /v1/registrations`
4. `GET /v1/registrations?status=pending`
5. `POST /v1/registrations/{id}/approve`
6. `POST /v1/imports/members/csv`
7. `GET /v1/exports/members.xlsx`
8. `POST /v1/transfers`

## 8) Integrasi ke plugin WordPress

Setelah endpoint awal hidup:

- plugin WP pindah dari auth `wp_signon` ke API login endpoint.
- panel role diambil dari payload API.
- approval, import, export pakai API.

## 9) Catatan penting keamanan

- Jangan expose kredensial DB tarombo di plugin WP.
- Untuk transfer data lintas sistem, pakai service token antar API, bukan direct SQL lintas DB.
- Semua endpoint write harus ada audit log.
- Untuk koneksi Membership API -> Tarombo Integration API:
  - gunakan API key/HMAC khusus integration
  - tambahkan idempotency key pada request transfer
  - semua approve/reject transfer wajib oleh `superadmin`

