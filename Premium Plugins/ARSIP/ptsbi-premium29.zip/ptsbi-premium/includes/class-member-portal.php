<?php
/**
 * Portal anggota di frontend — tanpa wp-admin.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PTPRM_Member_Portal {

    public const SLUG_LOGIN  = 'masuk';
    public const SLUG_PORTAL = 'area-anggota';

    private const NONCE_PROFILE  = 'ptprm_member_profile';
    private const NONCE_LOGOUT   = 'ptprm_member_logout';

    public function __construct() {
        add_action( 'init', [ __CLASS__, 'maybe_ensure_pages' ], 15 );
        add_action( 'init', [ $this, 'handle_profile_save' ], 20 );
        add_action( 'init', [ $this, 'handle_logout' ], 20 );
        add_shortcode( 'ptprm_member_portal', [ $this, 'shortcode_portal' ] );
        add_filter( 'ptprm_subpage_hero_skip', [ $this, 'skip_subpage_hero' ] );
    }

    public static function login_slug(): string {
        $o = ptprm_options();
        $s = sanitize_title( (string) ( $o['members_login_slug'] ?? self::SLUG_LOGIN ) );
        return $s !== '' ? $s : self::SLUG_LOGIN;
    }

    public static function portal_slug(): string {
        $o = ptprm_options();
        $s = sanitize_title( (string) ( $o['members_portal_slug'] ?? self::SLUG_PORTAL ) );
        return $s !== '' ? $s : self::SLUG_PORTAL;
    }

    public static function login_url( string $redirect = '' ): string {
        if ( class_exists( 'PTPRM_Login_Portal' ) ) {
            return PTPRM_Login_Portal::login_url( $redirect );
        }
        $url = home_url( '/' . self::login_slug() . '/' );
        if ( $redirect !== '' ) {
            $url = add_query_arg( 'redirect_to', rawurlencode( $redirect ), $url );
        }
        return $url;
    }

    public static function portal_url(): string {
        return home_url( '/' . self::portal_slug() . '/' );
    }

    public static function is_anggota( $user = null ): bool {
        $user = $user ?: wp_get_current_user();
        if ( ! $user instanceof WP_User || ! $user->exists() ) {
            return false;
        }
        return in_array( 'anggota', (array) $user->roles, true );
    }

    public static function maybe_ensure_pages(): void {
        if ( get_option( 'ptprm_member_pages_v1' ) ) {
            return;
        }
        self::ensure_pages();
        update_option( 'ptprm_member_pages_v1', 1, false );
        flush_rewrite_rules( false );
    }

    public static function is_member_page(): bool {
        if ( ! is_page() ) {
            return false;
        }
        $slug = (string) get_post_field( 'post_name', get_queried_object_id() );
        return $slug === self::portal_slug();
    }

    public function skip_subpage_hero( bool $skip ): bool {
        return $skip || self::is_member_page();
    }

    public function handle_profile_save(): void {
        if ( empty( $_POST['ptprm_member_profile'] ) || ! is_user_logged_in() ) {
            return;
        }
        if ( ! isset( $_POST[ self::NONCE_PROFILE ] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( (string) $_POST[ self::NONCE_PROFILE ] ) ), 'ptprm_member_profile' ) ) {
            return;
        }

        $user_id = get_current_user_id();
        if ( ! self::is_anggota() && ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $data = [
            'kepala_keluarga' => sanitize_text_field( wp_unslash( (string) ( $_POST['kepala_keluarga'] ?? '' ) ) ),
            'nama_istri'      => sanitize_text_field( wp_unslash( (string) ( $_POST['nama_istri'] ?? '' ) ) ),
            'oppu'            => sanitize_text_field( wp_unslash( (string) ( $_POST['oppu'] ?? '' ) ) ),
            'nomor_sundut'    => sanitize_text_field( wp_unslash( (string) ( $_POST['nomor_sundut'] ?? '' ) ) ),
            'phone'           => sanitize_text_field( wp_unslash( (string) ( $_POST['phone'] ?? '' ) ) ),
            'country_name'    => sanitize_text_field( wp_unslash( (string) ( $_POST['country_name'] ?? 'Indonesia' ) ) ),
            'province'        => sanitize_text_field( wp_unslash( (string) ( $_POST['province'] ?? '' ) ) ),
            'city'            => sanitize_text_field( wp_unslash( (string) ( $_POST['city'] ?? '' ) ) ),
            'district'        => sanitize_text_field( wp_unslash( (string) ( $_POST['district'] ?? '' ) ) ),
            'subdistrict'     => sanitize_text_field( wp_unslash( (string) ( $_POST['subdistrict'] ?? '' ) ) ),
            'postal_code'     => sanitize_text_field( wp_unslash( (string) ( $_POST['postal_code'] ?? '' ) ) ),
            'state_city'      => sanitize_text_field( wp_unslash( (string) ( $_POST['state_city'] ?? '' ) ) ),
            'address_detail'  => sanitize_textarea_field( wp_unslash( (string) ( $_POST['address_detail'] ?? '' ) ) ),
            'rt'              => sanitize_text_field( wp_unslash( (string) ( $_POST['rt'] ?? '' ) ) ),
            'rw'              => sanitize_text_field( wp_unslash( (string) ( $_POST['rw'] ?? '' ) ) ),
            'hula_boru'       => sanitize_text_field( wp_unslash( (string) ( $_POST['hula_boru'] ?? '' ) ) ),
            'is_overseas'     => ! empty( $_POST['is_overseas'] ) ? 1 : 0,
            'country_code'    => ! empty( $_POST['is_overseas'] ) ? 'INTL' : 'ID',
        ];

        if ( empty( $_POST['ptprm_password_only'] ) ) {
            PTPRM_Members::save_profile_for_user( $user_id, $data );
        }

        $pass1 = (string) ( $_POST['pass1'] ?? '' );
        $pass2 = (string) ( $_POST['pass2'] ?? '' );
        if ( $pass1 !== '' ) {
            if ( $pass1 !== $pass2 ) {
                wp_safe_redirect( add_query_arg( 'ptprm_profile_error', rawurlencode( __( 'Konfirmasi password tidak sama.', 'ptsbi-premium' ) ), self::portal_url() ) );
                exit;
            }
            if ( strlen( $pass1 ) < 6 ) {
                wp_safe_redirect( add_query_arg( 'ptprm_profile_error', rawurlencode( __( 'Password minimal 6 karakter.', 'ptsbi-premium' ) ), self::portal_url() ) );
                exit;
            }
            wp_set_password( $pass1, $user_id );
            wp_set_auth_cookie( $user_id, true );
        }

        wp_safe_redirect( add_query_arg( 'ptprm_profile_ok', '1', self::portal_url() ) );
        exit;
    }

    public function handle_logout(): void {
        if ( empty( $_POST['ptprm_member_logout'] ) ) {
            return;
        }
        if ( ! isset( $_POST[ self::NONCE_LOGOUT ] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( (string) $_POST[ self::NONCE_LOGOUT ] ) ), 'ptprm_member_logout' ) ) {
            return;
        }
        wp_logout();
        if ( class_exists( 'PTPRM_Login_Portal' ) ) {
            wp_safe_redirect( add_query_arg( 'ptprm_logged_out', '1', PTPRM_Login_Portal::login_url() ) );
        } else {
            wp_safe_redirect( add_query_arg( 'ptprm_logged_out', '1', self::login_url() ) );
        }
        exit;
    }

    public function shortcode_portal(): string {
        ob_start();

        if ( ! is_user_logged_in() ) {
            echo '<div class="ptprm-member-card ptprm-portal-card">';
            echo '<p>' . esc_html__( 'Silakan masuk untuk mengakses area anggota.', 'ptsbi-premium' ) . '</p>';
            echo '<a class="ptprm-cta ptprm-cta-1 ptprm-cta-size-medium" href="' . esc_url( self::login_url( self::portal_url() ) ) . '">';
            echo '<span class="ptprm-cta-label">' . esc_html__( 'Rumah Anggota', 'ptsbi-premium' ) . '</span></a>';
            echo '</div>';
            return (string) ob_get_clean();
        }

        if ( ! self::is_anggota() && ! PTPRM_Members::can_view_sensitive_fields() ) {
            echo '<div class="ptprm-member-card ptprm-portal-card">';
            if ( PTPRM_Members::is_pending_registration_user( get_current_user_id() ) ) {
                echo '<p>' . esc_html__( 'Pendaftaran Anda masih menunggu persetujuan admin. Setelah disetujui, Anda bisa melengkapi detail profil di sini.', 'ptsbi-premium' ) . '</p>';
            } else {
                echo '<p>' . esc_html__( 'Area ini untuk akun dengan role Anggota.', 'ptsbi-premium' ) . '</p>';
            }
            echo '</div>';
            return (string) ob_get_clean();
        }

        $user    = wp_get_current_user();
        $record  = PTPRM_Members::get_record_by_user_id( (int) $user->ID );
        $tab     = sanitize_key( (string) ( $_GET['tab'] ?? 'profil' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $allowed = [ 'profil', 'cari', 'akun' ];
        if ( ! in_array( $tab, $allowed, true ) ) {
            $tab = 'profil';
        }

        echo '<div class="ptprm-portal-wrap">';
        echo '<header class="ptprm-portal-head">';
        echo '<h2 class="ptprm-portal-title">' . esc_html__( 'Area Anggota', 'ptsbi-premium' ) . '</h2>';
        echo '<p class="ptprm-portal-greet">' . esc_html( sprintf(
            /* translators: %s: display name */
            __( 'Halo, %s', 'ptsbi-premium' ),
            $user->display_name ?: $user->user_login
        ) ) . '</p>';
        echo '</header>';

        echo '<nav class="ptprm-portal-tabs" aria-label="' . esc_attr__( 'Menu area anggota', 'ptsbi-premium' ) . '">';
        foreach (
            [
                'profil' => __( 'Profil Keluarga', 'ptsbi-premium' ),
                'cari'   => __( 'Cari Anggota', 'ptsbi-premium' ),
                'akun'   => __( 'Akun', 'ptsbi-premium' ),
            ] as $key => $label
        ) {
            $active = $tab === $key ? ' is-active' : '';
            $url    = add_query_arg( 'tab', $key, self::portal_url() );
            echo '<a class="ptprm-portal-tab' . esc_attr( $active ) . '" href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a>';
        }
        echo '</nav>';

        echo '<div class="ptprm-portal-panel">';
        if ( $tab === 'cari' ) {
            echo do_shortcode( '[ptprm_member_directory]' );
        } elseif ( $tab === 'akun' ) {
            $this->render_account_tab( $user );
        } else {
            $this->render_profile_tab( $record );
        }
        echo '</div>';

        echo '<footer class="ptprm-portal-footbar">';
        echo '<form method="post">';
        wp_nonce_field( 'ptprm_member_logout', self::NONCE_LOGOUT );
        echo '<input type="hidden" name="ptprm_member_logout" value="1">';
        echo '<button type="submit" class="ptprm-cta ptprm-cta-2 ptprm-cta-size-medium"><span class="ptprm-cta-label">' . esc_html__( 'Keluar', 'ptsbi-premium' ) . '</span></button>';
        echo '</form>';
        echo '</footer>';

        echo '</div>';

        return (string) ob_get_clean();
    }

    /**
     * @param array<string,mixed>|null $record
     */
    private function render_profile_tab( ?array $record ): void {
        $r = is_array( $record ) ? $record : [];

        echo '<div class="ptprm-member-card ptprm-portal-card">';
        if ( isset( $_GET['ptprm_profile_ok'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            echo '<p class="ptprm-member-alert ptprm-member-alert-ok">' . esc_html__( 'Profil berhasil disimpan.', 'ptsbi-premium' ) . '</p>';
        }
        if ( isset( $_GET['ptprm_profile_error'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $err = sanitize_text_field( wp_unslash( (string) $_GET['ptprm_profile_error'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            if ( $err !== '' ) {
                echo '<p class="ptprm-member-alert ptprm-member-alert-error">' . esc_html( $err ) . '</p>';
            }
        }

        echo '<p class="ptprm-portal-help">' . esc_html__( 'Kelola data keluarga Anda di sini. Perubahan tampil di direktori sesuai aturan privasi (anggota lain hanya melihat sampai kecamatan).', 'ptsbi-premium' ) . '</p>';

        echo '<form method="post" class="ptprm-member-form">';
        wp_nonce_field( 'ptprm_member_profile', self::NONCE_PROFILE );
        echo '<input type="hidden" name="ptprm_member_profile" value="1">';
        echo '<div class="ptprm-member-grid">';

        $fields = [
            'kepala_keluarga' => __( 'Nama Kepala Keluarga', 'ptsbi-premium' ),
            'nama_istri'      => __( 'Nama Istri', 'ptsbi-premium' ),
            'oppu'            => __( 'Oppu (Paroppuon)', 'ptsbi-premium' ),
            'nomor_sundut'    => __( 'Nomor Sundut', 'ptsbi-premium' ),
            'phone'           => __( 'No HP', 'ptsbi-premium' ),
            'country_name'    => __( 'Negara', 'ptsbi-premium' ),
            'province'        => __( 'Provinsi', 'ptsbi-premium' ),
            'city'            => __( 'Kota', 'ptsbi-premium' ),
            'district'        => __( 'Kecamatan', 'ptsbi-premium' ),
            'subdistrict'     => __( 'Kelurahan', 'ptsbi-premium' ),
            'postal_code'     => __( 'Kode Pos', 'ptsbi-premium' ),
            'state_city'      => __( 'State/Kota (luar negeri)', 'ptsbi-premium' ),
            'rt'              => 'RT',
            'rw'              => 'RW',
            'hula_boru'       => __( 'Hula / Boru', 'ptsbi-premium' ),
        ];

        foreach ( $fields as $key => $label ) {
            $val = (string) ( $r[ $key ] ?? '' );
            echo '<label><span>' . esc_html( $label ) . '</span>';
            echo '<input type="text" name="' . esc_attr( $key ) . '" value="' . esc_attr( $val ) . '"></label>';
        }

        $addr = (string) ( $r['address_detail'] ?? '' );
        echo '<label class="ptprm-member-full"><span>' . esc_html__( 'Alamat lengkap', 'ptsbi-premium' ) . '</span>';
        echo '<textarea name="address_detail" rows="3">' . esc_textarea( $addr ) . '</textarea></label>';

        $overseas = ! empty( $r['is_overseas'] );
        echo '<label class="ptprm-member-full"><input type="checkbox" name="is_overseas" value="1"' . checked( $overseas, true, false ) . '> ';
        echo esc_html__( 'Alamat luar negeri', 'ptsbi-premium' ) . '</label>';

        echo '</div>';
        echo '<button type="submit" class="ptprm-cta ptprm-cta-1 ptprm-cta-size-medium"><span class="ptprm-cta-label">' . esc_html__( 'Simpan Profil', 'ptsbi-premium' ) . '</span></button>';
        echo '</form></div>';
    }

    private function render_account_tab( WP_User $user ): void {
        echo '<div class="ptprm-member-card ptprm-portal-card">';
        echo '<p><strong>' . esc_html__( 'Username', 'ptsbi-premium' ) . ':</strong> ' . esc_html( $user->user_login ) . '</p>';
        echo '<p class="ptprm-portal-help">' . esc_html__( 'Ganti password di bawah jika perlu. Kosongkan jika tidak ingin mengubah.', 'ptsbi-premium' ) . '</p>';
        echo '<form method="post" class="ptprm-member-form">';
        wp_nonce_field( 'ptprm_member_profile', self::NONCE_PROFILE );
        echo '<input type="hidden" name="ptprm_member_profile" value="1">';
        echo '<input type="hidden" name="ptprm_password_only" value="1">';
        echo '<label><span>' . esc_html__( 'Password baru', 'ptsbi-premium' ) . '</span>';
        echo '<input type="password" name="pass1" autocomplete="new-password"></label>';
        echo '<label><span>' . esc_html__( 'Ulangi password baru', 'ptsbi-premium' ) . '</span>';
        echo '<input type="password" name="pass2" autocomplete="new-password"></label>';
        echo '<button type="submit" class="ptprm-cta ptprm-cta-1 ptprm-cta-size-medium"><span class="ptprm-cta-label">' . esc_html__( 'Simpan Password', 'ptsbi-premium' ) . '</span></button>';
        echo '</form></div>';
    }

    /**
     * Buat halaman masuk & area anggota jika belum ada.
     *
     * @return array{login:int,portal:int}
     */
    public static function ensure_pages(): array {
        $ids = [ 'portal' => 0 ];

        $pages = [
            'portal' => [
                'slug'    => self::portal_slug(),
                'title'   => __( 'Area Anggota', 'ptsbi-premium' ),
                'content' => '[ptprm_member_portal]',
            ],
        ];

        foreach ( $pages as $key => $bp ) {
            $existing = get_page_by_path( $bp['slug'], OBJECT, 'page' );
            if ( $existing instanceof WP_Post ) {
                $ids[ $key ] = (int) $existing->ID;
                continue;
            }
            $id = wp_insert_post(
                [
                    'post_title'   => $bp['title'],
                    'post_name'    => $bp['slug'],
                    'post_content' => $bp['content'],
                    'post_status'  => 'publish',
                    'post_type'    => 'page',
                ],
                true
            );
            if ( ! is_wp_error( $id ) ) {
                $ids[ $key ] = (int) $id;
            }
        }

        return $ids;
    }
}
