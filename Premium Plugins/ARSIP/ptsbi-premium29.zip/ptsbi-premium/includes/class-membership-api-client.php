<?php
/**
 * Skeleton client untuk Membership API terpisah.
 * Belum mengganti flow existing; dipakai sebagai fondasi migrasi bertahap.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PTPRM_Membership_Api_Client {

    public static function enabled(): bool {
        $o = ptprm_options();
        return ! empty( $o['membership_api_enabled'] );
    }

    public static function base_url(): string {
        $o   = ptprm_options();
        $url = trim( (string) ( $o['membership_api_base_url'] ?? '' ) );
        return untrailingslashit( $url );
    }

    private static function integration_key(): string {
        $o = ptprm_options();
        return trim( (string) ( $o['membership_api_integration_key'] ?? '' ) );
    }

    private static function timeout(): int {
        $o = ptprm_options();
        $n = (int) ( $o['membership_api_timeout_sec'] ?? 15 );
        return max( 5, min( 60, $n ) );
    }

    /**
     * @param array<string,mixed> $payload
     * @return array<string,mixed>|\WP_Error
     */
    public static function post( string $path, array $payload = [] ) {
        return self::request( 'POST', $path, $payload );
    }

    /**
     * @return array<string,mixed>|\WP_Error
     */
    public static function get( string $path ) {
        return self::request( 'GET', $path, null );
    }

    /**
     * @param array<string,mixed>|null $payload
     * @return array<string,mixed>|\WP_Error
     */
    private static function request( string $method, string $path, ?array $payload ) {
        if ( ! self::enabled() ) {
            return new WP_Error( 'ptprm_api_disabled', __( 'Membership API belum diaktifkan.', 'ptsbi-premium' ) );
        }

        $base = self::base_url();
        if ( $base === '' ) {
            return new WP_Error( 'ptprm_api_base_missing', __( 'Base URL Membership API belum diisi.', 'ptsbi-premium' ) );
        }

        $url = $base . '/' . ltrim( $path, '/' );
        $args = [
            'method'  => strtoupper( $method ),
            'timeout' => self::timeout(),
            'headers' => [
                'Accept'             => 'application/json',
                'Content-Type'       => 'application/json',
                'X-Integration-Key'  => self::integration_key(),
                'X-Idempotency-Key'  => wp_generate_uuid4(),
            ],
        ];
        if ( is_array( $payload ) ) {
            $args['body'] = wp_json_encode( $payload );
        }

        $res = wp_remote_request( $url, $args );
        if ( is_wp_error( $res ) ) {
            return $res;
        }

        $code = (int) wp_remote_retrieve_response_code( $res );
        $body = (string) wp_remote_retrieve_body( $res );
        $json = json_decode( $body, true );
        if ( ! is_array( $json ) ) {
            $json = [ 'raw' => $body ];
        }

        if ( $code < 200 || $code >= 300 ) {
            return new WP_Error(
                'ptprm_api_http_' . $code,
                sprintf( __( 'Membership API mengembalikan status %d.', 'ptsbi-premium' ), $code ),
                $json
            );
        }
        return $json;
    }
}

