<?php
/**
 * Akses situs: anggota & pengurus ke portal depan; pemilik situs (manage_options) tetap wp-admin.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PTPRM_Access {

    public const CAP_MANAGE          = 'ptprm_manage';
    public const CAP_APPROVE_MEMBERS = 'ptprm_approve_members';
    public const CAP_ORG_SETTINGS    = 'ptprm_manage_org_settings';
    public const ROLE_ORG_ADMIN      = 'admin_organisasi';

    public static function init(): void {
        add_action( 'init', [ __CLASS__, 'ensure_capabilities' ], 4 );
        add_action( 'init', [ __CLASS__, 'block_wp_admin_early' ], 1 );
        add_action( 'admin_init', [ __CLASS__, 'block_wp_admin' ], 1 );
        add_action( 'login_init', [ __CLASS__, 'redirect_logged_in_from_wp_login' ] );
        add_filter( 'show_admin_bar', [ __CLASS__, 'hide_admin_bar_on_front' ] );
    }

    /**
     * Hard block paling awal untuk URL /wp-admin.
     * Semua akun organisasi tetap user WordPress, tetapi tidak boleh masuk area wp-admin.
     */
    public static function block_wp_admin_early(): void {
        if ( wp_doing_ajax() || wp_doing_cron() ) {
            return;
        }
        if ( defined( 'WP_CLI' ) && WP_CLI ) {
            return;
        }

        $req = (string) ( $_SERVER['REQUEST_URI'] ?? '' );
        if ( $req === '' || strpos( $req, '/wp-admin' ) === false ) {
            return;
        }
        if ( strpos( $req, 'admin-ajax.php' ) !== false ) {
            return;
        }

        // Administrator situs saja yang boleh wp-admin.
        if ( is_user_logged_in() && self::is_site_admin() ) {
            return;
        }

        if ( is_user_logged_in() ) {
            wp_safe_redirect( self::portal_url_for_user() );
            exit;
        }

        if ( class_exists( 'PTPRM_Login_Portal' ) ) {
            wp_safe_redirect( PTPRM_Login_Portal::login_url() );
            exit;
        }
        wp_safe_redirect( home_url( '/' ) );
        exit;
    }

    public static function ensure_capabilities(): void {
        $base_caps = [
            'read'                   => true,
            'edit_posts'             => true,
            'publish_posts'          => true,
            'upload_files'           => true,
            'edit_published_posts'   => true,
            'delete_posts'           => true,
            'delete_published_posts' => true,
            self::CAP_MANAGE         => true,
        ];
        $admin_only_caps = [
            self::CAP_APPROVE_MEMBERS => true,
            self::CAP_ORG_SETTINGS    => true,
        ];

        $pengurus = get_role( 'pengurus' );
        if ( $pengurus ) {
            foreach ( $base_caps as $cap => $grant ) {
                if ( $grant ) {
                    $pengurus->add_cap( $cap );
                }
            }
        }

        add_role(
            self::ROLE_ORG_ADMIN,
            __( 'Admin Organisasi', 'ptsbi-premium' ),
            [ 'read' => true ]
        );
        $org_admin = get_role( self::ROLE_ORG_ADMIN );
        if ( $org_admin ) {
            foreach ( array_merge( $base_caps, $admin_only_caps ) as $cap => $grant ) {
                if ( $grant ) {
                    $org_admin->add_cap( $cap );
                }
            }
        }

        $admin = get_role( 'administrator' );
        if ( $admin ) {
            $admin->add_cap( self::CAP_MANAGE );
            $admin->add_cap( self::CAP_APPROVE_MEMBERS );
            $admin->add_cap( self::CAP_ORG_SETTINGS );
        }
    }

    public static function can_manage(): bool {
        return current_user_can( self::CAP_MANAGE );
    }

    public static function can_approve_members(): bool {
        return current_user_can( self::CAP_APPROVE_MEMBERS );
    }

    public static function can_manage_org_settings(): bool {
        return current_user_can( self::CAP_ORG_SETTINGS );
    }

    public static function is_manager( $user = null ): bool {
        $user = $user ?: wp_get_current_user();
        if ( ! $user instanceof WP_User || ! $user->exists() ) {
            return false;
        }
        return user_can( $user, self::CAP_MANAGE );
    }

    public static function is_org_admin( $user = null ): bool {
        $user = $user ?: wp_get_current_user();
        if ( ! $user instanceof WP_User || ! $user->exists() ) {
            return false;
        }
        return user_can( $user, self::CAP_ORG_SETTINGS );
    }

    /** Pemilik situs / pengelola plugin Premium (akses wp-admin penuh). */
    public static function is_site_admin( $user = null ): bool {
        $user = $user ?: wp_get_current_user();
        if ( ! $user instanceof WP_User || ! $user->exists() ) {
            return false;
        }
        return user_can( $user, 'manage_options' );
    }

    /** Role pengurus organisasi (panel depan), bukan administrator WordPress. */
    public static function is_pengurus_only( $user = null ): bool {
        return self::is_manager( $user ) && ! self::is_site_admin( $user ) && ! self::is_org_admin( $user );
    }

    public static function portal_url_for_user( $user = null ): string {
        $user = $user ?: wp_get_current_user();
        if ( class_exists( 'PTPRM_Member_Portal' ) && PTPRM_Member_Portal::is_anggota( $user ) ) {
            return PTPRM_Member_Portal::portal_url();
        }
        if ( class_exists( 'PTPRM_Members' ) && PTPRM_Members::is_pending_registration_user( $user ) ) {
            return class_exists( 'PTPRM_Login_Portal' ) ? PTPRM_Login_Portal::login_url() : home_url( '/rumah-anggota/' );
        }
        if ( self::is_site_admin( $user ) ) {
            return admin_url();
        }
        if ( class_exists( 'PTPRM_Admin_Portal' ) && self::is_manager( $user ) ) {
            return PTPRM_Admin_Portal::portal_url();
        }
        return home_url( '/' );
    }

    public static function login_url_for_user( $user = null ): string {
        unset( $user );
        if ( class_exists( 'PTPRM_Login_Portal' ) ) {
            return PTPRM_Login_Portal::login_url();
        }
        return home_url( '/' );
    }

    public static function block_wp_admin(): void {
        if ( wp_doing_ajax() || wp_doing_cron() ) {
            return;
        }
        if ( defined( 'WP_CLI' ) && WP_CLI ) {
            return;
        }

        // Administrator WordPress: kelola Premium Plugin & wp-admin seperti biasa.
        if ( is_user_logged_in() && self::is_site_admin() ) {
            return;
        }

        if ( ! is_user_logged_in() ) {
            if ( class_exists( 'PTPRM_Login_Portal' ) ) {
                wp_safe_redirect( PTPRM_Login_Portal::login_url() );
                exit;
            }
            wp_safe_redirect( home_url( '/' ) );
            exit;
        }

        wp_safe_redirect( self::portal_url_for_user() );
        exit;
    }

    public static function redirect_logged_in_from_wp_login(): void {
        if ( is_user_logged_in() ) {
            wp_safe_redirect( self::portal_url_for_user() );
            exit;
        }
    }

    public static function hide_admin_bar_on_front( $show ) {
        if ( is_admin() ) {
            return $show;
        }
        if ( self::is_site_admin() ) {
            return $show;
        }
        if ( is_user_logged_in() ) {
            return false;
        }
        return $show;
    }
}
