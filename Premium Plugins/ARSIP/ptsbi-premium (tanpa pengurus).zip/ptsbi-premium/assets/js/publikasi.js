(function () {
  var modal = document.getElementById('ptprm-pub-modal');
  if (!modal) return;

  var body = modal.querySelector('.ptprm-pub-modal-body');

  function closeModal() {
    modal.classList.remove('is-open');
    modal.setAttribute('hidden', 'hidden');
    modal.setAttribute('aria-hidden', 'true');
    if (body) body.innerHTML = '';
  }

  function openModal(item) {
    if (!body) return;
    var html = '<h2 class="ptprm-h2">' + escapeHtml(item.title || '') + '</h2>';
    if (item.type === 'pdf' && item.full) {
      html +=
        '<p><a class="ptprm-cta ptprm-cta-1 ptprm-cta-size-medium" href="' +
        escapeAttr(item.full) +
        '" target="_blank" rel="noopener"><span class="ptprm-cta-label">Buka PDF</span></a></p>';
    } else if (item.full) {
      html +=
        '<p><img src="' +
        escapeAttr(item.full) +
        '" alt="' +
        escapeAttr(item.title || '') +
        '"></p>';
    }
    if (item.desc) {
      html += '<div class="ptprm-bidang-text">' + escapeHtml(item.desc).replace(/\n/g, '<br>') + '</div>';
    }
    body.innerHTML = html;
    modal.removeAttribute('hidden');
    modal.setAttribute('aria-hidden', 'false');
    modal.classList.add('is-open');
  }

  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function escapeAttr(s) {
    return escapeHtml(s).replace(/'/g, '&#39;');
  }

  document.addEventListener('click', function (e) {
    var btn = e.target.closest('[data-ptprm-pub]');
    if (btn) {
      try {
        var data = JSON.parse(btn.getAttribute('data-ptprm-pub') || '{}');
        openModal(data);
      } catch (err) {
        /* ignore */
      }
      return;
    }
    if (e.target.closest('[data-ptprm-pub-close]')) {
      closeModal();
    }
  });

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeModal();
  });
})();
