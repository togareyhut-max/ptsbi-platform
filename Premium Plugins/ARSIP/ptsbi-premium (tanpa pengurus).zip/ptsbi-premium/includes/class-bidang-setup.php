<?php
/**
 * Halaman bidang, kategori berita, menu Program Kerja, panel per bidang.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PTPRM_Bidang_Setup {

    public static function init(): void {
        add_action( 'init', [ __CLASS__, 'register_publikasi_cpt' ], 5 );
        add_action( 'init', [ __CLASS__, 'maybe_install' ], 20 );
        add_filter( 'ptprm_subpage_hero_skip', [ __CLASS__, 'skip_hero_on_bidang_pages' ] );
        add_filter( 'the_content', [ __CLASS__, 'inject_bidang_public_content' ], 8 );
    }

    public static function register_publikasi_cpt(): void {
        register_post_type(
            PTPRM_Bidang_Registry::CPT_PUBLIKASI,
            [
                'labels'              => [
                    'name'          => __( 'Publikasi', 'ptsbi-premium' ),
                    'singular_name' => __( 'Publikasi', 'ptsbi-premium' ),
                ],
                'public'              => false,
                'show_ui'             => false,
                'supports'            => [ 'title' ],
                'capability_type'     => 'post',
                'map_meta_cap'        => true,
            ]
        );
    }

    public static function maybe_install(): void {
        if ( get_option( 'ptprm_bidang_setup_v1' ) ) {
            return;
        }
        self::install();
        update_option( 'ptprm_bidang_setup_v1', 1, false );
        flush_rewrite_rules( false );
    }

    public static function install(): void {
        self::ensure_categories();
        self::ensure_pages();
        self::sync_header_menu_defaults();
    }

    public static function ensure_categories(): void {
        foreach ( PTPRM_Bidang_Registry::definitions() as $def ) {
            $slug = (string) $def['category_slug'];
            if ( ! term_exists( $slug, 'category' ) ) {
                wp_insert_term(
                    (string) $def['title'],
                    'category',
                    [ 'slug' => $slug ]
                );
            }
        }
    }

    public static function ensure_pages(): void {
        foreach ( PTPRM_Bidang_Registry::definitions() as $def ) {
            $slug = (string) $def['slug'];
            $page = get_page_by_path( $slug, OBJECT, 'page' );
            if ( $page instanceof WP_Post ) {
                continue;
            }
            wp_insert_post(
                [
                    'post_title'   => (string) $def['title'],
                    'post_name'    => $slug,
                    'post_status'  => 'publish',
                    'post_type'    => 'page',
                    'post_excerpt' => sprintf(
                        /* translators: %s: bidang name */
                        __( 'Program kerja %s.', 'ptsbi-premium' ),
                        (string) $def['title']
                    ),
                    'post_content' => '<!-- Bidang: konten dihasilkan plugin -->',
                ]
            );
        }

        if ( ! get_page_by_path( 'publikasi', OBJECT, 'page' ) ) {
            wp_insert_post(
                [
                    'post_title'   => __( 'Publikasi', 'ptsbi-premium' ),
                    'post_name'    => 'publikasi',
                    'post_status'  => 'publish',
                    'post_type'    => 'page',
                    'post_content' => '[ptprm_publikasi_wall]',
                ]
            );
        }

        foreach ( PTPRM_Bidang_Registry::definitions() as $def ) {
            $pslug = (string) $def['panel_slug'];
            if ( get_page_by_path( $pslug, OBJECT, 'page' ) ) {
                continue;
            }
            wp_insert_post(
                [
                    'post_title'   => sprintf(
                        /* translators: %s: bidang */
                        __( 'Panel %s', 'ptsbi-premium' ),
                        (string) $def['title']
                    ),
                    'post_name'    => $pslug,
                    'post_status'  => 'publish',
                    'post_type'    => 'page',
                    'post_content' => '[ptprm_bidang_portal]',
                ]
            );
        }
    }

    public static function sync_header_menu_defaults(): void {
        if ( ! class_exists( 'PTPRM_Pages' ) ) {
            return;
        }
        // Hanya dipakai saat menu kustom kosong — lihat default_menu_items_for_options.
    }

    /**
     * @param array<int, array<string,mixed>> $items
     * @return array<int, array<string,mixed>>
     */
    public static function program_kerja_menu_children(): array {
        $children = [];
        foreach ( PTPRM_Bidang_Registry::definitions() as $def ) {
            $children[] = [
                'label'     => (string) $def['title'],
                'url'       => '/' . $def['slug'] . '/',
                'target'    => '_self',
                'highlight' => 0,
                'children'  => [],
            ];
        }
        return $children;
    }

    public static function skip_hero_on_bidang_pages( bool $skip ): bool {
        if ( ! is_page() ) {
            return $skip;
        }
        $slug = (string) get_post_field( 'post_name', get_queried_object_id() );
        if ( PTPRM_Bidang_Registry::get_by_page_slug( $slug ) || $slug === 'publikasi' ) {
            return true;
        }
        foreach ( PTPRM_Bidang_Registry::definitions() as $def ) {
            if ( $slug === (string) $def['panel_slug'] ) {
                return true;
            }
        }
        return $skip;
    }

    /**
     * @param string $content
     */
    public static function inject_bidang_public_content( $content ): string {
        if ( ! is_page() || ! in_the_loop() || ! is_main_query() ) {
            return $content;
        }
        $slug = (string) get_post_field( 'post_name', get_queried_object_id() );
        $def  = PTPRM_Bidang_Registry::get_by_page_slug( $slug );
        if ( ! $def ) {
            return $content;
        }
        return class_exists( 'PTPRM_Bidang_Public' )
            ? PTPRM_Bidang_Public::render( (string) $def['slug'] )
            : (string) $content;
    }
}
