<?php
/**
 * Arsip kegiatan/berita dengan filter kategori per bidang.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PTPRM_Kegiatan_Archive {

    public static function init(): void {
        add_shortcode( 'ptprm_kegiatan_archive', [ __CLASS__, 'shortcode' ] );
        add_filter( 'the_content', [ __CLASS__, 'inject_kegiatan_archive' ], 7 );
        add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue' ] );
    }

    public static function enqueue(): void {
        if ( ! is_page( 'kegiatan' ) ) {
            return;
        }
        wp_enqueue_style( 'ptprm-bidang', PTPRM_URL . 'assets/css/bidang.css', [ 'ptprm-frontend' ], PTPRM_VERSION );
    }

    /**
     * @param string $content
     */
    public static function inject_kegiatan_archive( $content ): string {
        if ( ! is_page( 'kegiatan' ) || ! in_the_loop() || ! is_main_query() ) {
            return $content;
        }
        return self::shortcode();
    }

    public static function shortcode(): string {
        $bidang = sanitize_key( (string) ( $_GET['bidang'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $cat_id = 0;
        if ( $bidang !== '' ) {
            $cat_id = PTPRM_Bidang_Registry::category_id_for_bidang( $bidang );
        }

        ob_start();
        echo '<div class="ptprm-kegiatan-archive">';
        echo '<nav class="ptprm-kegiatan-filters" aria-label="' . esc_attr__( 'Filter bidang', 'ptsbi-premium' ) . '">';
        $all_active = $bidang === '' ? ' is-active' : '';
        echo '<a class="ptprm-kegiatan-filter' . esc_attr( $all_active ) . '" href="' . esc_url( home_url( '/kegiatan/' ) ) . '">' . esc_html__( 'Semua bidang', 'ptsbi-premium' ) . '</a>';
        foreach ( PTPRM_Bidang_Registry::definitions() as $slug => $def ) {
            if ( ! empty( $def['is_sekretariat'] ) ) {
                continue;
            }
            $active = $bidang === $slug ? ' is-active' : '';
            echo '<a class="ptprm-kegiatan-filter' . esc_attr( $active ) . '" href="' . esc_url( add_query_arg( 'bidang', $slug, home_url( '/kegiatan/' ) ) ) . '">';
            echo esc_html( (string) $def['title'] );
            echo '</a>';
        }
        echo '</nav>';

        $args = [
            'post_type'      => 'post',
            'post_status'    => 'publish',
            'posts_per_page' => 12,
            'paged'          => max( 1, (int) get_query_var( 'paged', 1 ) ),
        ];
        if ( $cat_id > 0 ) {
            $args['cat'] = $cat_id;
        } else {
            $slugs = [];
            foreach ( PTPRM_Bidang_Registry::definitions() as $def ) {
                $cid = PTPRM_Bidang_Registry::category_id_for_bidang( (string) $def['slug'] );
                if ( $cid > 0 ) {
                    $slugs[] = $cid;
                }
            }
            if ( $slugs ) {
                $args['category__in'] = $slugs;
            }
        }

        $q = new WP_Query( $args );
        if ( $q->have_posts() ) {
            echo '<div class="ptprm-bidang-news-grid">';
            while ( $q->have_posts() ) {
                $q->the_post();
                echo '<article class="ptprm-bidang-news-card">';
                if ( has_post_thumbnail() ) {
                    echo '<a class="ptprm-bidang-news-thumb" href="' . esc_url( get_permalink() ) . '">';
                    the_post_thumbnail( 'medium' );
                    echo '</a>';
                }
                echo '<h3 class="ptprm-h3"><a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a></h3>';
                echo '<p class="ptprm-bidang-news-meta">' . esc_html( get_the_date() ) . '</p>';
                echo '<p>' . esc_html( wp_trim_words( get_the_excerpt(), 24 ) ) . '</p>';
                echo '</article>';
            }
            wp_reset_postdata();
            echo '</div>';
        } else {
            echo '<p class="ptprm-empty">' . esc_html__( 'Belum ada berita kegiatan.', 'ptsbi-premium' ) . '</p>';
        }
        echo '</div>';
        return (string) ob_get_clean();
    }
}
