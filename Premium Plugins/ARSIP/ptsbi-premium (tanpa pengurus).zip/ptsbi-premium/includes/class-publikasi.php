<?php
/**
 * Publikasi gabungan (majalah dinding) — gambar atau PDF per bidang.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PTPRM_Publikasi {

    public const META_BIDANG   = 'ptprm_publikasi_bidang';
    public const META_DESC     = 'ptprm_publikasi_desc';
    public const META_MEDIA    = 'ptprm_publikasi_media_id';
    public const META_TYPE       = 'ptprm_publikasi_media_type';

    public static function init(): void {
        add_shortcode( 'ptprm_publikasi_wall', [ __CLASS__, 'shortcode_wall' ] );
        add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue' ] );
    }

    public static function enqueue(): void {
        if ( ! is_page( 'publikasi' ) ) {
            return;
        }
        wp_enqueue_style( 'ptprm-bidang', PTPRM_URL . 'assets/css/bidang.css', [ 'ptprm-frontend' ], PTPRM_VERSION );
        wp_enqueue_script(
            'ptprm-publikasi',
            PTPRM_URL . 'assets/js/publikasi.js',
            [],
            PTPRM_VERSION,
            true
        );
    }

    /**
     * @return array<int, array{id:int,title:string,bidang:string,desc:string,thumb:string,full:string,type:string}>
     */
    public static function list_for_bidang( string $slug, int $limit = 12 ): array {
        $slug = sanitize_key( $slug );
        $q    = new WP_Query(
            [
                'post_type'      => PTPRM_Bidang_Registry::CPT_PUBLIKASI,
                'post_status'    => 'publish',
                'posts_per_page' => max( 1, min( 50, $limit ) ),
                'meta_key'       => self::META_BIDANG,
                'meta_value'     => $slug,
                'orderby'        => 'date',
                'order'          => 'DESC',
                'no_found_rows'  => true,
            ]
        );
        $out = [];
        while ( $q->have_posts() ) {
            $q->the_post();
            $row = self::map_post( get_post() );
            if ( $row ) {
                $out[] = $row;
            }
        }
        wp_reset_postdata();
        return $out;
    }

    /**
     * @return array<int, array{id:int,title:string,bidang:string,desc:string,thumb:string,full:string,type:string}>
     */
    public static function list_all_grouped(): array {
        $q = new WP_Query(
            [
                'post_type'      => PTPRM_Bidang_Registry::CPT_PUBLIKASI,
                'post_status'    => 'publish',
                'posts_per_page' => 200,
                'orderby'        => 'date',
                'order'          => 'DESC',
                'no_found_rows'  => true,
            ]
        );
        $out = [];
        while ( $q->have_posts() ) {
            $q->the_post();
            $row = self::map_post( get_post() );
            if ( $row ) {
                $out[] = $row;
            }
        }
        wp_reset_postdata();
        return $out;
    }

    /**
     * @param WP_Post|null $post
     * @return array{id:int,title:string,bidang:string,desc:string,thumb:string,full:string,type:string}|null
     */
    public static function map_post( $post ): ?array {
        if ( ! $post instanceof WP_Post ) {
            return null;
        }
        $media_id = (int) get_post_meta( $post->ID, self::META_MEDIA, true );
        $type     = sanitize_key( (string) get_post_meta( $post->ID, self::META_TYPE, true ) );
        if ( $type === '' ) {
            $type = 'image';
        }
        $thumb = '';
        $full  = '';
        if ( $type === 'pdf' && $media_id ) {
            $full  = wp_get_attachment_url( $media_id ) ?: '';
            $thumb = $full ? PTPRM_URL . 'assets/img/pdf-thumb.svg' : '';
        } elseif ( $media_id ) {
            $thumb = (string) wp_get_attachment_image_url( $media_id, 'medium' );
            $full  = (string) wp_get_attachment_image_url( $media_id, 'large' );
        }
        if ( $thumb === '' ) {
            return null;
        }
        return [
            'id'     => (int) $post->ID,
            'title'  => get_the_title( $post ),
            'bidang' => sanitize_key( (string) get_post_meta( $post->ID, self::META_BIDANG, true ) ),
            'desc'   => (string) get_post_meta( $post->ID, self::META_DESC, true ),
            'thumb'  => $thumb,
            'full'   => $full ?: $thumb,
            'type'   => $type,
        ];
    }

    /**
     * @param array{id:int,title:string,bidang:string,desc:string,thumb:string,full:string,type:string} $item
     */
    public static function render_thumb( array $item ): void {
        $json = wp_json_encode( $item );
        echo '<button type="button" class="ptprm-pub-thumb" data-ptprm-pub="' . esc_attr( (string) $json ) . '">';
        echo '<img src="' . esc_url( $item['thumb'] ) . '" alt="' . esc_attr( $item['title'] ) . '" loading="lazy">';
        echo '<span class="ptprm-pub-thumb-label">' . esc_html( $item['title'] ) . '</span>';
        echo '</button>';
    }

    public static function shortcode_wall(): string {
        $items = self::list_all_grouped();
        ob_start();
        echo '<div class="ptprm-publikasi-page">';
        if ( ! $items ) {
            echo '<p class="ptprm-empty">' . esc_html__( 'Belum ada publikasi.', 'ptsbi-premium' ) . '</p>';
            echo '</div>';
            return (string) ob_get_clean();
        }

        $grouped = [];
        foreach ( $items as $item ) {
            $b = $item['bidang'] !== '' ? $item['bidang'] : 'lainnya';
            $grouped[ $b ][] = $item;
        }

        foreach ( PTPRM_Bidang_Registry::definitions() as $slug => $def ) {
            if ( empty( $grouped[ $slug ] ) ) {
                continue;
            }
            echo '<h2 class="ptprm-h2 ptprm-pub-bidang-heading" id="bidang-' . esc_attr( $slug ) . '">' . esc_html( (string) $def['title'] ) . '</h2>';
            echo '<div class="ptprm-pub-wall">';
            foreach ( $grouped[ $slug ] as $item ) {
                self::render_thumb( $item );
            }
            echo '</div>';
        }

        echo '<div class="ptprm-pub-modal" id="ptprm-pub-modal" hidden aria-hidden="true">';
        echo '<div class="ptprm-pub-modal-backdrop" data-ptprm-pub-close></div>';
        echo '<div class="ptprm-pub-modal-panel" role="dialog" aria-modal="true">';
        echo '<button type="button" class="ptprm-pub-modal-close" data-ptprm-pub-close aria-label="' . esc_attr__( 'Tutup', 'ptsbi-premium' ) . '">&times;</button>';
        echo '<div class="ptprm-pub-modal-body"></div>';
        echo '</div></div>';
        echo '</div>';
        return (string) ob_get_clean();
    }

    public static function save_from_panel( string $bidang_slug, array $post_data, array $files ): bool {
        $title = sanitize_text_field( (string) ( $post_data['pub_title'] ?? '' ) );
        $desc  = sanitize_textarea_field( (string) ( $post_data['pub_desc'] ?? '' ) );
        $id    = (int) ( $post_data['pub_id'] ?? 0 );
        if ( $title === '' ) {
            return false;
        }

        $postarr = [
            'post_title'  => $title,
            'post_type'   => PTPRM_Bidang_Registry::CPT_PUBLIKASI,
            'post_status' => 'publish',
        ];
        if ( $id > 0 ) {
            $postarr['ID'] = $id;
            $result        = wp_update_post( $postarr, true );
        } else {
            $result = wp_insert_post( $postarr, true );
        }
        if ( is_wp_error( $result ) ) {
            return false;
        }
        $post_id = (int) $result;
        update_post_meta( $post_id, self::META_BIDANG, sanitize_key( $bidang_slug ) );
        update_post_meta( $post_id, self::META_DESC, $desc );

        $media_id = (int) ( $post_data['pub_media_id'] ?? 0 );
        $type     = 'image';
        if ( ! empty( $files['pub_file']['name'] ) ) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
            $att_id = media_handle_upload( 'pub_file', $post_id );
            if ( ! is_wp_error( $att_id ) ) {
                $media_id = (int) $att_id;
                $mime     = get_post_mime_type( $media_id );
                $type     = $mime && strpos( $mime, 'pdf' ) !== false ? 'pdf' : 'image';
            }
        }
        if ( $media_id > 0 ) {
            update_post_meta( $post_id, self::META_MEDIA, $media_id );
            update_post_meta( $post_id, self::META_TYPE, $type );
        }
        return true;
    }

    public static function delete_item( int $post_id, string $bidang_slug ): bool {
        $post = get_post( $post_id );
        if ( ! $post || $post->post_type !== PTPRM_Bidang_Registry::CPT_PUBLIKASI ) {
            return false;
        }
        if ( sanitize_key( (string) get_post_meta( $post_id, self::META_BIDANG, true ) ) !== sanitize_key( $bidang_slug ) ) {
            return false;
        }
        return (bool) wp_trash_post( $post_id );
    }
}
