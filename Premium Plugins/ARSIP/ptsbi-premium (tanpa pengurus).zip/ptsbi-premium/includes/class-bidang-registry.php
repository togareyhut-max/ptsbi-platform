<?php
/**
 * Registry bidang Program Kerja (slug, kategori, panel).
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PTPRM_Bidang_Registry {

    public const META_BIDANG_SLUG = 'ptprm_bidang_slug';
    public const OPTION_DATA      = 'ptprm_bidang_content';
    public const CPT_PUBLIKASI    = 'ptprm_publikasi';

    /**
     * @return array<string, array{title:string,slug:string,category_slug:string,panel_slug:string,is_sekretariat:bool}>
     */
    public static function definitions(): array {
        return [
            'sekretariat'  => [
                'title'         => 'Sekretariat',
                'slug'          => 'sekretariat',
                'category_slug' => 'bidang-sekretariat',
                'panel_slug'    => 'panel-sekretariat',
                'is_sekretariat' => true,
            ],
            'adat-budaya'  => [
                'title'         => 'Bidang Adat dan Budaya',
                'slug'          => 'adat-budaya',
                'category_slug' => 'bidang-adat-budaya',
                'panel_slug'    => 'panel-adat-budaya',
                'is_sekretariat' => false,
            ],
            'usaha-dana'   => [
                'title'         => 'Bidang Usaha dan Dana',
                'slug'          => 'usaha-dana',
                'category_slug' => 'bidang-usaha-dana',
                'panel_slug'    => 'panel-usaha-dana',
                'is_sekretariat' => false,
            ],
            'sos-dik-mud'  => [
                'title'         => 'Bidang Sosial, Pendidikan dan Pemuda',
                'slug'          => 'sos-dik-mud',
                'category_slug' => 'bidang-sos-dik-mud',
                'panel_slug'    => 'panel-sos-dik-mud',
                'is_sekretariat' => false,
            ],
            'hukum'        => [
                'title'         => 'Bidang Hukum',
                'slug'          => 'hukum',
                'category_slug' => 'bidang-hukum',
                'panel_slug'    => 'panel-hukum',
                'is_sekretariat' => false,
            ],
        ];
    }

    public static function get( string $slug ): ?array {
        $slug = sanitize_key( $slug );
        $all  = self::definitions();
        return $all[ $slug ] ?? null;
    }

    public static function get_by_page_slug( string $page_slug ): ?array {
        $page_slug = sanitize_title( $page_slug );
        foreach ( self::definitions() as $def ) {
            if ( (string) $def['slug'] === $page_slug ) {
                return $def;
            }
        }
        return null;
    }

    public static function get_by_panel_slug( string $panel_slug ): ?array {
        $panel_slug = sanitize_title( $panel_slug );
        foreach ( self::definitions() as $def ) {
            if ( (string) $def['panel_slug'] === $panel_slug ) {
                return $def;
            }
        }
        return null;
    }

    public static function category_id_for_bidang( string $slug ): int {
        $def = self::get( $slug );
        if ( ! $def ) {
            return 0;
        }
        $term = get_category_by_slug( (string) $def['category_slug'] );
        return $term ? (int) $term->term_id : 0;
    }

    public static function user_bidang_slug( $user = null ): string {
        $user = $user ?: wp_get_current_user();
        if ( ! $user instanceof WP_User || ! $user->exists() ) {
            return '';
        }
        return sanitize_key( (string) get_user_meta( $user->ID, self::META_BIDANG_SLUG, true ) );
    }

    public static function set_user_bidang_slug( int $user_id, string $slug ): void {
        update_user_meta( $user_id, self::META_BIDANG_SLUG, sanitize_key( $slug ) );
    }

    public static function is_sekretariat_user( $user = null ): bool {
        $slug = self::user_bidang_slug( $user );
        if ( $slug === 'sekretariat' ) {
            return true;
        }
        $def = self::get( $slug );
        return $def && ! empty( $def['is_sekretariat'] );
    }

    public static function panel_url( string $slug, string $tab = '', array $args = [] ): string {
        $def = self::get( $slug );
        if ( ! $def ) {
            return home_url( '/' );
        }
        $url = home_url( '/' . $def['panel_slug'] . '/' );
        if ( $tab !== '' ) {
            $args['tab'] = $tab;
        }
        return $args ? add_query_arg( $args, $url ) : $url;
    }

    public static function public_url( string $slug ): string {
        $def = self::get( $slug );
        return $def ? home_url( '/' . $def['slug'] . '/' ) : home_url( '/' );
    }

    public static function publikasi_url(): string {
        return home_url( '/publikasi/' );
    }
}
