<?php
/**
 * Tampilan publik halaman bidang.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PTPRM_Bidang_Public {

    public static function init(): void {
        add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue' ] );
    }

    public static function enqueue(): void {
        if ( ! is_page() ) {
            return;
        }
        $slug = (string) get_post_field( 'post_name', get_queried_object_id() );
        if ( ! PTPRM_Bidang_Registry::get_by_page_slug( $slug ) ) {
            return;
        }
        wp_enqueue_style(
            'ptprm-bidang',
            PTPRM_URL . 'assets/css/bidang.css',
            [ 'ptprm-frontend' ],
            PTPRM_VERSION
        );
    }

    public static function render( string $slug ): string {
        $def = PTPRM_Bidang_Registry::get( $slug );
        if ( ! $def ) {
            return '';
        }
        $data = PTPRM_Bidang_Data::get( $slug );
        ob_start();
        echo '<div class="ptprm-bidang-public">';

        echo '<section class="ptprm-bidang-block">';
        echo '<h2 class="ptprm-h2">' . esc_html( sprintf( __( 'Visi dan Misi %s', 'ptsbi-premium' ), (string) $def['title'] ) ) . '</h2>';
        if ( $data['visi'] !== '' ) {
            echo '<h3 class="ptprm-h3">' . esc_html__( 'Visi', 'ptsbi-premium' ) . '</h3>';
            echo '<div class="ptprm-bidang-text">' . nl2br( esc_html( $data['visi'] ) ) . '</div>';
        }
        if ( $data['misi'] !== '' ) {
            echo '<h3 class="ptprm-h3">' . esc_html__( 'Misi', 'ptsbi-premium' ) . '</h3>';
            echo '<div class="ptprm-bidang-text">' . nl2br( esc_html( $data['misi'] ) ) . '</div>';
        }
        if ( $data['visi'] === '' && $data['misi'] === '' ) {
            echo '<p class="ptprm-empty">' . esc_html__( 'Visi dan misi akan segera diumumkan.', 'ptsbi-premium' ) . '</p>';
        }
        echo '</section>';

        echo '<section class="ptprm-bidang-block">';
        echo '<h2 class="ptprm-h2">' . esc_html( sprintf( __( 'Program Unggulan %s', 'ptsbi-premium' ), (string) $def['title'] ) ) . '</h2>';
        if ( ! empty( $data['programs'] ) ) {
            echo '<div class="ptprm-bidang-table-wrap"><table class="ptprm-bidang-table"><thead><tr>';
            echo '<th>' . esc_html__( 'Judul', 'ptsbi-premium' ) . '</th>';
            echo '<th>' . esc_html__( 'Tujuan', 'ptsbi-premium' ) . '</th>';
            echo '<th>' . esc_html__( 'Sasaran', 'ptsbi-premium' ) . '</th>';
            echo '<th>' . esc_html__( 'Waktu pengerjaan', 'ptsbi-premium' ) . '</th>';
            echo '</tr></thead><tbody>';
            foreach ( $data['programs'] as $p ) {
                echo '<tr>';
                echo '<td>' . esc_html( (string) $p['judul'] ) . '</td>';
                echo '<td>' . nl2br( esc_html( (string) $p['tujuan'] ) ) . '</td>';
                echo '<td>' . nl2br( esc_html( (string) $p['sasaran'] ) ) . '</td>';
                echo '<td>' . esc_html( (string) $p['waktu'] ) . '</td>';
                echo '</tr>';
            }
            echo '</tbody></table></div>';
        } else {
            echo '<p class="ptprm-empty">' . esc_html__( 'Belum ada program unggulan.', 'ptsbi-premium' ) . '</p>';
        }
        echo '</section>';

        self::render_news( $slug, $def );
        self::render_publikasi_teaser( $slug );

        echo '</div>';
        return (string) ob_get_clean();
    }

    /**
     * @param array<string,mixed> $def
     */
    private static function render_news( string $slug, array $def ): void {
        $cat_id = PTPRM_Bidang_Registry::category_id_for_bidang( $slug );
        $q      = new WP_Query(
            [
                'post_type'      => 'post',
                'post_status'    => 'publish',
                'posts_per_page' => 6,
                'cat'            => $cat_id > 0 ? $cat_id : 0,
                'no_found_rows'  => true,
            ]
        );

        echo '<section class="ptprm-bidang-block">';
        echo '<h2 class="ptprm-h2">' . esc_html__( 'Berita Program Terlaksana', 'ptsbi-premium' ) . '</h2>';
        if ( $q->have_posts() ) {
            echo '<div class="ptprm-bidang-news-grid">';
            while ( $q->have_posts() ) {
                $q->the_post();
                echo '<article class="ptprm-bidang-news-card">';
                if ( has_post_thumbnail() ) {
                    echo '<a class="ptprm-bidang-news-thumb" href="' . esc_url( get_permalink() ) . '">';
                    the_post_thumbnail( 'medium' );
                    echo '</a>';
                }
                echo '<h3 class="ptprm-h3"><a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a></h3>';
                echo '<p class="ptprm-bidang-news-meta">' . esc_html( get_the_date() ) . '</p>';
                echo '<p>' . esc_html( wp_trim_words( get_the_excerpt(), 22 ) ) . '</p>';
                echo '</article>';
            }
            wp_reset_postdata();
            echo '</div>';
            echo '<p><a class="ptprm-cta ptprm-cta-outline ptprm-cta-size-medium" href="' . esc_url( add_query_arg( 'bidang', $slug, home_url( '/kegiatan/' ) ) ) . '">';
            echo '<span class="ptprm-cta-label">' . esc_html__( 'Lihat semua berita bidang ini', 'ptsbi-premium' ) . '</span></a></p>';
        } else {
            echo '<p class="ptprm-empty">' . esc_html__( 'Belum ada berita program.', 'ptsbi-premium' ) . '</p>';
        }
        echo '</section>';
    }

    private static function render_publikasi_teaser( string $slug ): void {
        if ( ! class_exists( 'PTPRM_Publikasi' ) ) {
            return;
        }
        $items = PTPRM_Publikasi::list_for_bidang( $slug, 4 );
        if ( ! $items ) {
            return;
        }
        echo '<section class="ptprm-bidang-block">';
        echo '<h2 class="ptprm-h2">' . esc_html__( 'Publikasi & Promosi', 'ptsbi-premium' ) . '</h2>';
        echo '<div class="ptprm-pub-wall ptprm-pub-wall--compact">';
        foreach ( $items as $item ) {
            PTPRM_Publikasi::render_thumb( $item );
        }
        echo '</div>';
        echo '<p><a class="ptprm-cta ptprm-cta-outline ptprm-cta-size-small" href="' . esc_url( PTPRM_Bidang_Registry::publikasi_url() ) . '#bidang-' . esc_attr( $slug ) . '">';
        echo '<span class="ptprm-cta-label">' . esc_html__( 'Lihat semua publikasi', 'ptsbi-premium' ) . '</span></a></p>';
        echo '</section>';
    }
}
