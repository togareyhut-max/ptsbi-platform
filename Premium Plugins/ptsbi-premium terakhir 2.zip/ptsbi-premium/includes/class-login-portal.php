<?php
/**
 * Portal masuk tunggal (Rumah Anggota) — semua peran login di sini, diarahkan ke panel masing-masing.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PTPRM_Login_Portal {

    public const SLUG_LOGIN = 'rumah-anggota';

    private const NONCE_LOGIN = 'ptprm_portal_login';
    private const NONCE_LOGOUT = 'ptprm_portal_logout';

    public function __construct() {
        add_action( 'init', [ __CLASS__, 'maybe_ensure_pages' ], 13 );
        add_action( 'template_redirect', [ __CLASS__, 'redirect_legacy_login_pages' ], 5 );
        add_action( 'init', [ $this, 'handle_login' ], 20 );
        add_action( 'init', [ $this, 'handle_logout' ], 20 );
        add_filter( 'login_redirect', [ $this, 'login_redirect' ], 10, 3 );
        add_shortcode( 'ptprm_login_portal', [ $this, 'shortcode_login' ] );
        add_shortcode( 'ptprm_member_login', [ $this, 'shortcode_login' ] );
        add_shortcode( 'ptprm_admin_login', [ $this, 'shortcode_login' ] );
        add_filter( 'ptprm_subpage_hero_skip', [ $this, 'skip_subpage_hero' ] );
    }

    public static function login_slug(): string {
        $o = ptprm_options();
        $s = sanitize_title( (string) ( $o['portal_login_slug'] ?? '' ) );
        if ( $s === '' ) {
            $s = sanitize_title( (string) ( $o['members_login_slug'] ?? self::SLUG_LOGIN ) );
        }
        return $s !== '' ? $s : self::SLUG_LOGIN;
    }

    public static function login_url( string $redirect = '' ): string {
        $url = home_url( '/' . self::login_slug() . '/' );
        if ( $redirect !== '' ) {
            $url = add_query_arg( 'redirect_to', rawurlencode( $redirect ), $url );
        }
        return $url;
    }

    /** URL masuk jika belum login; panel jika sudah login. */
    public static function entry_url( string $redirect = '' ): string {
        if ( is_user_logged_in() ) {
            return PTPRM_Access::portal_url_for_user();
        }
        return self::login_url( $redirect );
    }

    public static function legacy_login_slugs(): array {
        $o      = ptprm_options();
        $legacy = [
            'masuk',
            'masuk-pengurus',
            self::SLUG_LOGIN,
            sanitize_title( (string) ( $o['members_login_slug'] ?? 'masuk' ) ),
            sanitize_title( (string) ( $o['admin_login_slug'] ?? 'masuk-pengurus' ) ),
        ];
        $unified = self::login_slug();
        $out     = [];
        foreach ( $legacy as $slug ) {
            if ( $slug !== '' && $slug !== $unified ) {
                $out[] = $slug;
            }
        }
        return array_values( array_unique( $out ) );
    }

    public static function maybe_ensure_pages(): void {
        if ( get_option( 'ptprm_unified_login_v1' ) ) {
            return;
        }
        self::ensure_pages();
        update_option( 'ptprm_unified_login_v1', 1, false );
        flush_rewrite_rules( false );
    }

    public static function is_login_page(): bool {
        if ( ! is_page() ) {
            return false;
        }
        $slug = (string) get_post_field( 'post_name', get_queried_object_id() );
        return $slug === self::login_slug();
    }

    public function skip_subpage_hero( bool $skip ): bool {
        return $skip || self::is_login_page();
    }

    public static function redirect_legacy_login_pages(): void {
        if ( ! is_page() || self::is_login_page() ) {
            return;
        }
        $slug = (string) get_post_field( 'post_name', get_queried_object_id() );
        if ( in_array( $slug, self::legacy_login_slugs(), true ) ) {
            $target = self::login_url();
            if ( ! empty( $_GET['redirect_to'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                $maybe = wp_validate_redirect( wp_unslash( (string) $_GET['redirect_to'] ), '' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                if ( $maybe ) {
                    $target = self::login_url( $maybe );
                }
            }
            wp_safe_redirect( $target, 301 );
            exit;
        }
    }

    /**
     * @param WP_User|WP_Error $user
     */
    public function login_redirect( $redirect_to, $requested_redirect_to, $user ) {
        if ( ! $user instanceof WP_User ) {
            return $redirect_to;
        }
        return self::redirect_after_login( $user, (string) $requested_redirect_to );
    }

    public static function redirect_after_login( WP_User $user, string $requested = '' ): string {
        if ( $requested !== '' ) {
            $valid = wp_validate_redirect( $requested, false );
            if ( $valid ) {
                return $valid;
            }
        }
        return PTPRM_Access::portal_url_for_user( $user );
    }

    public static function panel_label_for_user( ?WP_User $user = null ): string {
        $user = $user ?: wp_get_current_user();
        if ( class_exists( 'PTPRM_Member_Portal' ) && PTPRM_Member_Portal::is_anggota( $user ) ) {
            return __( 'Buka Area Anggota', 'ptsbi-premium' );
        }
        if ( PTPRM_Access::is_site_admin( $user ) ) {
            return __( 'Buka Dashboard WordPress', 'ptsbi-premium' );
        }
        if ( PTPRM_Access::is_manager( $user ) ) {
            return __( 'Buka Panel Pengurus', 'ptsbi-premium' );
        }
        return __( 'Buka Beranda', 'ptsbi-premium' );
    }

    public function handle_login(): void {
        if ( empty( $_POST['ptprm_portal_login'] ) ) {
            return;
        }
        if ( ! isset( $_POST[ self::NONCE_LOGIN ] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( (string) $_POST[ self::NONCE_LOGIN ] ) ), 'ptprm_portal_login' ) ) {
            return;
        }

        $requested = '';
        if ( ! empty( $_GET['redirect_to'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $maybe = wp_validate_redirect( wp_unslash( (string) $_GET['redirect_to'] ), '' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            if ( $maybe ) {
                $requested = $maybe;
            }
        }

        $user = wp_signon(
            [
                'user_login'    => sanitize_user( wp_unslash( (string) ( $_POST['log'] ?? '' ) ) ),
                'user_password' => (string) ( $_POST['pwd'] ?? '' ),
                'remember'      => ! empty( $_POST['rememberme'] ),
            ],
            is_ssl()
        );

        if ( is_wp_error( $user ) ) {
            wp_safe_redirect(
                add_query_arg( 'ptprm_login_error', rawurlencode( $user->get_error_message() ), self::login_url() )
            );
            exit;
        }

        if ( class_exists( 'PTPRM_Default_Accounts' )
            && PTPRM_Default_Accounts::is_demo_anggota_locked()
            && PTPRM_Default_Accounts::is_demo_anggota_user( $user )
        ) {
            wp_logout();
            wp_safe_redirect(
                add_query_arg(
                    'ptprm_login_error',
                    rawurlencode( __( 'Akun demo anggota sudah tidak aktif. Silakan daftar akun sendiri di beranda.', 'ptsbi-premium' ) ),
                    self::login_url()
                )
            );
            exit;
        }

        wp_safe_redirect( self::redirect_after_login( $user, $requested ) );
        exit;
    }

    public function handle_logout(): void {
        if ( empty( $_POST['ptprm_portal_logout'] ) ) {
            return;
        }
        if ( ! isset( $_POST[ self::NONCE_LOGOUT ] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( (string) $_POST[ self::NONCE_LOGOUT ] ) ), 'ptprm_portal_logout' ) ) {
            return;
        }
        wp_logout();
        wp_safe_redirect( add_query_arg( 'ptprm_logged_out', '1', self::login_url() ) );
        exit;
    }

    public function shortcode_login(): string {
        ob_start();
        echo '<div class="ptprm-portal-login-wrap">';

        if ( is_user_logged_in() ) {
            $user = wp_get_current_user();
            echo '<div class="ptprm-member-card ptprm-portal-card">';
            echo '<h2 class="ptprm-portal-login-title">' . esc_html__( 'Rumah Anggota', 'ptsbi-premium' ) . '</h2>';
            echo '<p>' . esc_html__( 'Anda sudah masuk.', 'ptsbi-premium' ) . '</p>';
            echo '<a class="ptprm-cta ptprm-cta-1 ptprm-cta-size-medium" href="' . esc_url( PTPRM_Access::portal_url_for_user( $user ) ) . '">';
            echo '<span class="ptprm-cta-label">' . esc_html( self::panel_label_for_user( $user ) ) . '</span></a>';
            echo '<form method="post" class="ptprm-portal-logout-form" style="margin-top:1rem;">';
            wp_nonce_field( 'ptprm_portal_logout', self::NONCE_LOGOUT );
            echo '<input type="hidden" name="ptprm_portal_logout" value="1">';
            echo '<button type="submit" class="ptprm-cta ptprm-cta-2 ptprm-cta-size-medium ptprm-cta--ghost">';
            echo '<span class="ptprm-cta-label">' . esc_html__( 'Keluar', 'ptsbi-premium' ) . '</span></button>';
            echo '</form>';
            echo '</div></div>';
            return (string) ob_get_clean();
        }

        echo '<div class="ptprm-member-card ptprm-portal-card">';
        echo '<h2 class="ptprm-portal-login-title">' . esc_html__( 'Rumah Anggota', 'ptsbi-premium' ) . '</h2>';
        echo '<p class="ptprm-portal-help">' . esc_html__( 'Masuk dengan akun Anda. Setelah login, Anda diarahkan ke panel sesuai peran (anggota, pengurus, atau administrator situs).', 'ptsbi-premium' ) . '</p>';

        if ( isset( $_GET['ptprm_login_error'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $err = sanitize_text_field( wp_unslash( (string) $_GET['ptprm_login_error'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            if ( $err !== '' ) {
                echo '<p class="ptprm-member-alert ptprm-member-alert-error">' . esc_html( $err ) . '</p>';
            }
        }
        if ( isset( $_GET['ptprm_logged_out'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            echo '<p class="ptprm-member-alert ptprm-member-alert-ok">' . esc_html__( 'Anda telah keluar.', 'ptsbi-premium' ) . '</p>';
        }

        echo '<form method="post" class="ptprm-member-form ptprm-login-form">';
        wp_nonce_field( 'ptprm_portal_login', self::NONCE_LOGIN );
        echo '<input type="hidden" name="ptprm_portal_login" value="1">';
        echo '<label><span>' . esc_html__( 'Username', 'ptsbi-premium' ) . '</span>';
        echo '<input type="text" name="log" autocomplete="username" required></label>';
        echo '<label><span>' . esc_html__( 'Password', 'ptsbi-premium' ) . '</span>';
        echo '<input type="password" name="pwd" autocomplete="current-password" required></label>';
        echo '<label class="ptprm-member-remember"><input type="checkbox" name="rememberme" value="1"> ' . esc_html__( 'Ingat saya', 'ptsbi-premium' ) . '</label>';
        echo '<button type="submit" class="ptprm-cta ptprm-cta-1 ptprm-cta-size-medium"><span class="ptprm-cta-label">' . esc_html__( 'Masuk', 'ptsbi-premium' ) . '</span></button>';
        echo '</form>';

        $register = home_url( '/#daftar-anggota' );
        echo '<p class="ptprm-portal-foot">';
        echo esc_html__( 'Belum punya akun anggota?', 'ptsbi-premium' ) . ' ';
        echo '<a href="' . esc_url( $register ) . '">' . esc_html__( 'Daftar di beranda', 'ptsbi-premium' ) . '</a>';
        echo '</p>';
        echo '</div></div>';

        return (string) ob_get_clean();
    }

    /**
     * @return array{login:int}
     */
    public static function ensure_pages(): array {
        $ids = [ 'login' => 0 ];
        $bp  = [
            'slug'    => self::login_slug(),
            'title'   => __( 'Rumah Anggota', 'ptsbi-premium' ),
            'content' => '[ptprm_login_portal]',
        ];

        $existing = get_page_by_path( $bp['slug'], OBJECT, 'page' );
        if ( $existing instanceof WP_Post ) {
            $ids['login'] = (int) $existing->ID;
            if ( strpos( (string) $existing->post_content, 'ptprm_login_portal' ) === false ) {
                wp_update_post(
                    [
                        'ID'           => $existing->ID,
                        'post_content' => $bp['content'],
                    ]
                );
            }
            return $ids;
        }

        $id = wp_insert_post(
            [
                'post_title'   => $bp['title'],
                'post_name'    => $bp['slug'],
                'post_content' => $bp['content'],
                'post_status'  => 'publish',
                'post_type'    => 'page',
            ],
            true
        );
        if ( ! is_wp_error( $id ) ) {
            $ids['login'] = (int) $id;
        }

        return $ids;
    }
}
