<?php
/**
 * Halaman kepengurusan per wilayah: /ptsbi-pusat/, /ptsbi-samosir/, dll.
 * Data disimpan di opsi plugin (regional_boards), disinkron ke halaman publik.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PTPRM_Regional_Pages {

    public const DATA_VERSION = 6;

    public const OPTION_KEY = 'regional_boards';

    /**
     * @return array<string, array{title:string, excerpt:string, intro:string, lines:string}>
     */
    public static function regions(): array {
        return [
            'ptsbi-pusat' => [
                'title'   => __( 'PTSBI Pusat', 'ptsbi-premium' ),
                'excerpt' => __( 'Struktur pengurus pusat Perkumpulan PTSBI.', 'ptsbi-premium' ),
                'intro'   => __( 'Struktur Pengurus Pusat.', 'ptsbi-premium' ),
                'lines'   => self::lines_pusat(),
            ],
            'ptsbi-samosir' => [
                'title'   => __( 'PTSBI Samosir', 'ptsbi-premium' ),
                'excerpt' => __( 'Pengurus PTSBI Kabupaten Samosir.', 'ptsbi-premium' ),
                'intro'   => __( 'Pengurus PTSBI Kab. Samosir.', 'ptsbi-premium' ),
                'lines'   => self::lines_samosir(),
            ],
            'ptsbi-medan' => [
                'title'   => __( 'PTSBI Medan', 'ptsbi-premium' ),
                'excerpt' => __( 'Pengurus PTSBI Kota Medan.', 'ptsbi-premium' ),
                'intro'   => __( 'Pengurus PTSBI Kota Medan.', 'ptsbi-premium' ),
                'lines'   => self::lines_medan(),
            ],
            'ptsbi-pekanbaru' => [
                'title'   => __( 'PTSBI Pekanbaru', 'ptsbi-premium' ),
                'excerpt' => __( 'Pengurus PTSBI Pekanbaru.', 'ptsbi-premium' ),
                'intro'   => __( 'Pengurus PTSBI Pekanbaru.', 'ptsbi-premium' ),
                'lines'   => self::lines_pekanbaru(),
            ],
        ];
    }

    public static function field_key( string $slug ): string {
        return 'regional_board_' . str_replace( '-', '_', sanitize_key( $slug ) );
    }

    /**
     * @param array<string, mixed>|null $o Options.
     * @return array<string, string>
     */
    public static function get_boards( ?array $o = null ): array {
        $o     = $o ?? ptprm_options();
        $out   = [];
        $saved = [];
        $raw   = $o[ self::OPTION_KEY ] ?? '';

        if ( is_string( $raw ) && $raw !== '' && $raw !== '{}' ) {
            $decoded = json_decode( $raw, true );
            if ( is_array( $decoded ) ) {
                $saved = $decoded;
            }
        } elseif ( is_array( $raw ) ) {
            $saved = $raw;
        }

        foreach ( self::regions() as $slug => $def ) {
            $lines = isset( $saved[ $slug ] ) ? trim( (string) $saved[ $slug ] ) : '';
            if ( $lines === '' ) {
                $lines = (string) $def['lines'];
            }
            $out[ $slug ] = $lines;
        }

        return $out;
    }

    public static function boards_are_empty( ?array $o = null ): bool {
        $o   = $o ?? ptprm_options();
        $raw = $o[ self::OPTION_KEY ] ?? '';
        if ( is_string( $raw ) ) {
            $raw = trim( $raw );
            return $raw === '' || $raw === '{}' || $raw === '[]';
        }
        return empty( $raw );
    }

    /**
     * @param array<string, string> $boards
     * @return array<string, string>
     */
    public static function sanitize_boards( array $boards ): array {
        $clean = [];
        foreach ( self::regions() as $slug => $def ) {
            if ( ! isset( $boards[ $slug ] ) ) {
                continue;
            }
            $clean[ $slug ] = sanitize_textarea_field( (string) $boards[ $slug ] );
        }
        return $clean;
    }

    /**
     * @param array<string, string> $boards
     */
    public static function save_boards_to_option( array $boards ): void {
        $clean    = self::sanitize_boards( $boards );
        $existing = (array) get_option( PTPRM_OPTION, [] );
        $existing[ self::OPTION_KEY ] = wp_json_encode( $clean, JSON_UNESCAPED_UNICODE );
        update_option( PTPRM_OPTION, ptprm_normalize_option_for_storage( $existing ), true );
        ptprm_flush_option_cache( PTPRM_OPTION );
        self::sync_boards_to_pages( $clean );
    }

    /**
     * @param array<string, string> $boards
     */
    public static function sync_boards_to_pages( array $boards ): void {
        foreach ( self::regions() as $slug => $def ) {
            if ( ! isset( $boards[ $slug ] ) ) {
                continue;
            }
            $page = get_page_by_path( $slug, OBJECT, 'page' );
            if ( $page instanceof WP_Post ) {
                update_post_meta( (int) $page->ID, PTPRM_Wilayah_Board::META_CONTENT, $boards[ $slug ] );
            }
        }
    }

    public static function get_lines_for_slug( string $slug ): string {
        $boards = self::get_boards();
        return $boards[ $slug ] ?? (string) ( self::regions()[ $slug ]['lines'] ?? '' );
    }

    /**
     * Buat halaman yang belum ada (tidak menghapus yang sudah ada).
     *
     * @return array{created:int, page_ids:array<string,int>}
     */
    public static function ensure_pages_exist(): array {
        $result = [ 'created' => 0, 'page_ids' => [] ];

        foreach ( self::regions() as $slug => $def ) {
            $existing = get_page_by_path( $slug, OBJECT, 'page' );
            if ( $existing instanceof WP_Post ) {
                $result['page_ids'][ $slug ] = (int) $existing->ID;
                wp_update_post(
                    [
                        'ID'           => (int) $existing->ID,
                        'post_title'   => $def['title'],
                        'post_excerpt' => $def['excerpt'],
                        'post_content' => self::page_content(),
                    ]
                );
                continue;
            }

            $post_id = wp_insert_post(
                [
                    'post_title'   => $def['title'],
                    'post_name'    => $slug,
                    'post_status'  => 'publish',
                    'post_type'    => 'page',
                    'post_excerpt' => $def['excerpt'],
                    'post_content' => self::page_content(),
                ],
                true
            );

            if ( is_wp_error( $post_id ) ) {
                continue;
            }

            $result['page_ids'][ $slug ] = (int) $post_id;
            $result['created']++;
        }

        self::sync_boards_to_pages( self::get_boards() );
        return $result;
    }

    /**
     * Isi contoh resmi ke opsi (hanya saat diminta admin).
     */
    public static function apply_default_boards(): void {
        $boards = [];
        foreach ( self::regions() as $slug => $def ) {
            $boards[ $slug ] = (string) $def['lines'];
        }
        self::save_boards_to_option( $boards );
    }

    /**
     * Matikan pengurus di beranda (sekali).
     */
    public static function disable_home_team_section(): void {
        $o = (array) get_option( PTPRM_OPTION, [] );
        $o['team_show']    = 0;
        $o['wilayah_show'] = 0;
        $order             = ptprm_get_home_sections_order( $o );
        $order             = array_values( array_filter( $order, static fn( $s ) => $s !== 'team' ) );
        $o['home_sections_order'] = wp_json_encode( $order, JSON_UNESCAPED_UNICODE );
        update_option( PTPRM_OPTION, ptprm_normalize_option_for_storage( $o ), true );
        ptprm_flush_option_cache( PTPRM_OPTION );
    }

    /**
     * Setup aman: dipanggil saat aktivasi — tidak menghapus halaman atau data custom.
     */
    public static function ensure_setup(): void {
        if ( self::boards_are_empty() ) {
            self::apply_default_boards();
        }
        self::ensure_pages_exist();
        self::disable_home_team_section();
    }

    /**
     * @return list<array{label:string,url:string}>
     */
    public static function nav_links(): array {
        $links = [];
        foreach ( self::regions() as $slug => $def ) {
            $page = get_page_by_path( $slug, OBJECT, 'page' );
            $url  = $page instanceof WP_Post ? get_permalink( $page ) : home_url( '/' . $slug . '/' );
            $links[] = [
                'label' => (string) $def['title'],
                'url'   => (string) $url,
            ];
        }
        return $links;
    }

    private static function page_content(): string {
        return '<!-- wp:shortcode -->[ptprm_wilayah_board]<!-- /wp:shortcode -->';
    }

    private static function lines_pusat(): string {
        return <<<'TXT'
## Pengurus
Ketua Umum | Ir. Raya Pontus Samosir
Ketua Harian | Rolaw Samosir
Sekretaris Umum | Toman Samosir
Sekretaris I | Jeny Samosir
Sekretaris II | Atur Hamonangan Samosir
Bendahara Umum | Parluhutan Sinambela
Bendahara I | Henri Erikson Samosir
Bendahara II | Jepri Sinaturi

## Bidang Adat dan Budaya
Ketua | Alexander Samosir

## Bidang Usaha dan Dana
Ketua | Adi Samosir

## Bidang Sosial, Pendidikan dan Kepemudaan
Ketua | Henrico Samosir

## Bidang Hukum
Ketua | Kardin Samosir

## Dewan Penasehat
1. Johny Samosir
2. Laurentius Samosir
3. Amansyah Samosri
4. Jisman Samosir
5. Omri Samosir
6. Op. Kenso Samosir

## Dewan Pakar
1. Agunan Samosir
2. Dr. Osbin Samosir
3. Risto Samosir
4. Dr. Hollan Samosir
TXT;
    }

    private static function lines_samosir(): string {
        return <<<'TXT'
## Pengurus
Ketua | Daslon Samosir
Ketua 1 | Jamron Samosir
Sekretaris | Freddy Samosir
Sekretaris 1 | Andri Sembi Samosir
Sekretaris 2 | Riwanto Samosir
Bendahara | Juni F Harianja
Bendahara 1 | Manatar Samosir
Bendahara 2 | Jhon Wenry Samosir

## Bidang Adat dan Budaya
Ketua | Patido Samosir

## Bidang Sosial
Ketua | Tondor Samosir

## Bidang Organisasi
Ketua | Alfonsus Samosir

## Bidang Kepemudaan
Ketua | Humisar Samosir

## Koordinator Harian
Ketua | Robert Samosir
TXT;
    }

    private static function lines_medan(): string {
        return <<<'TXT'
## Pengurus
Ketua Umum | Ir. Saidi Samosir
Sekretaris Umum | Tommy Samosir
Sekretaris 2 | Tunggul Samosir
Bendahara Umum | Parkin Sihaloho
Ketua Harian | Aron Samosir
Ketua 1 | A.H. Samosir
Ketua 2 | Lintong Samosir
Ketua 3 | J. Samosir
Ketua 4 | AKBP. Dr. Parulian Samosir, S.H., M.H.

## Bidang Adat dan Budaya
Koordinator | Jennefer Samosir

## Bidang Usaha Dana
Ketua | St. Drs. D Samosir

## Bidang Organisasi
Ketua | Alfonsus Samosir

## Bidang Kepemudaan, Sosial dan Pendidikan
Koordinator | Ardin Dolok Saribu

## Bidang Hukum
Koordinator | Timbul Samosir
TXT;
    }

    private static function lines_pekanbaru(): string {
        return <<<'TXT'
## Pengurus
Ketua Umum | Mangaratua Samosir
Ketua | Jhonson Binsar Samosir
Wakil Ketua | Parluhutan Samosir
Wakil Ketua | Rexson Mangatur Samosir
Wakil Ketua | Roncon Samosir
Wakil Ketua | Parlindungan Samosir
Sekretaris | Manuntun Samosir
Bendahara | Nurdin Manullang
TXT;
    }

    /**
     * Migrasi sekali setelah update plugin (admin only, tidak di front-end).
     */
    public static function maybe_migrate(): void {
        if ( (int) get_option( 'ptprm_regional_pages_v', 0 ) >= self::DATA_VERSION ) {
            return;
        }

        self::ensure_setup();
        update_option( 'ptprm_regional_pages_v', self::DATA_VERSION, false );
        flush_rewrite_rules( false );
    }
}
