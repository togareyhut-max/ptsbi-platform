<?php
/**
 * Shortcode daftar pengurus wilayah per halaman.
 *
 * Format:
 *   Jabatan | Nama
 *   ## Judul bagian
 *   ## Dewan Penasehat / Dewan Pakar → daftar bernomor: 1. Nama atau satu nama per baris
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PTPRM_Wilayah_Board {

    public const META_CONTENT = 'ptprm_wilayah_board_lines';

    public function __construct() {
        add_shortcode( 'ptprm_wilayah_board', [ $this, 'shortcode' ] );
    }

    /**
     * @param array<string,string>|string $atts
     */
    public function shortcode( $atts = [] ): string {
        $atts = shortcode_atts(
            [
                'title' => '',
            ],
            is_array( $atts ) ? $atts : [],
            'ptprm_wilayah_board'
        );

        $post_id = get_the_ID();
        $lines   = '';
        if ( $post_id ) {
            $slug = (string) get_post_field( 'post_name', $post_id );
            if ( class_exists( 'PTPRM_Regional_Pages' ) && isset( PTPRM_Regional_Pages::regions()[ $slug ] ) ) {
                $lines = PTPRM_Regional_Pages::get_lines_for_slug( $slug );
            } else {
                $lines = (string) get_post_meta( (int) $post_id, self::META_CONTENT, true );
            }
        }
        if ( $lines === '' && is_singular() && $post_id ) {
            $lines = (string) get_post_field( 'post_content', $post_id );
        }

        $sections = self::parse_lines( $lines );
        if ( ! $sections ) {
            return '';
        }

        $title = trim( (string) $atts['title'] );
        $is_regional = $post_id && class_exists( 'PTPRM_Regional_Pages' )
            && isset( PTPRM_Regional_Pages::regions()[ (string) get_post_field( 'post_name', $post_id ) ] );

        ob_start();
        echo '<div class="ptprm-wilayah-board">';
        if ( $title !== '' && ! $is_regional ) {
            echo '<h2 class="ptprm-wilayah-board-title">' . esc_html( $title ) . '</h2>';
        }
        foreach ( $sections as $section ) {
            $heading   = (string) ( $section['heading'] ?? '' );
            $list_type = (string) ( $section['list_type'] ?? 'roles' );
            $rows      = $section['rows'] ?? [];

            if ( $heading !== '' ) {
                echo '<h3 class="ptprm-wilayah-board-section">' . esc_html( $heading ) . '</h3>';
            }
            if ( ! $rows ) {
                continue;
            }

            if ( 'numbered' === $list_type ) {
                echo '<ol class="ptprm-wilayah-board-numbered">';
                $n = 0;
                foreach ( $rows as $row ) {
                    $name = trim( (string) ( $row['name'] ?? '' ) );
                    if ( $name === '' ) {
                        $name = trim( (string) ( $row['role'] ?? '' ) );
                    }
                    if ( $name === '' ) {
                        continue;
                    }
                    $n = ! empty( $row['num'] ) ? (int) $row['num'] : $n + 1;
                    echo '<li class="ptprm-wilayah-board-numbered__item">';
                    echo '<span class="ptprm-wilayah-board-numbered__index">' . esc_html( (string) $n ) . '.</span>';
                    echo '<span class="ptprm-wilayah-board-numbered__name">' . esc_html( $name ) . '</span>';
                    echo '</li>';
                }
                echo '</ol>';
                continue;
            }

            echo '<dl class="ptprm-wilayah-board-list">';
            foreach ( $rows as $row ) {
                $role = trim( (string) ( $row['role'] ?? '' ) );
                $name = trim( (string) ( $row['name'] ?? '' ) );
                if ( $role === '' && $name === '' ) {
                    continue;
                }
                echo '<div class="ptprm-wilayah-board-row">';
                echo '<dt>' . esc_html( $role ) . '</dt>';
                echo '<dd>' . esc_html( $name ) . '</dd>';
                echo '</div>';
            }
            echo '</dl>';
        }
        echo '</div>';
        return (string) ob_get_clean();
    }

    /**
     * @return list<array{heading:string,list_type:string,rows:list<array{role:string,name:string,num?:int}>}>
     */
    public static function parse_lines( string $raw ): array {
        $sections = [
            [
                'heading'   => '',
                'list_type' => 'roles',
                'rows'      => [],
            ],
        ];
        $lines = preg_split( '/\r\n|\r|\n/', $raw ) ?: [];
        foreach ( $lines as $line ) {
            $line = trim( (string) $line );
            if ( $line === '' || strpos( $line, '[' ) === 0 ) {
                continue;
            }
            if ( strpos( $line, '##' ) === 0 ) {
                $heading = trim( substr( $line, 2 ) );
                $sections[] = [
                    'heading'   => $heading,
                    'list_type' => self::list_type_for_heading( $heading ),
                    'rows'      => [],
                ];
                continue;
            }
            if ( strpos( $line, '#' ) === 0 ) {
                $heading = trim( ltrim( $line, '#' ) );
                $sections[] = [
                    'heading'   => $heading,
                    'list_type' => self::list_type_for_heading( $heading ),
                    'rows'      => [],
                ];
                continue;
            }

            $idx       = count( $sections ) - 1;
            $list_type = $sections[ $idx ]['list_type'] ?? 'roles';

            if ( 'numbered' === $list_type ) {
                $row = self::parse_numbered_line( $line );
                if ( $row ) {
                    $sections[ $idx ]['rows'][] = $row;
                }
                continue;
            }

            $role = $line;
            $name = '';
            if ( strpos( $line, '|' ) !== false ) {
                $parts = array_map( 'trim', explode( '|', $line, 2 ) );
                $role  = $parts[0] ?? '';
                $name  = $parts[1] ?? '';
            } elseif ( preg_match( '/^([^:]+):\s*(.+)$/', $line, $m ) ) {
                $role = trim( $m[1] );
                $name = trim( $m[2] );
            }
            if ( $role === '' ) {
                continue;
            }
            $sections[ $idx ]['rows'][] = [
                'role' => $role,
                'name' => $name,
            ];
        }

        return array_values(
            array_filter(
                $sections,
                static function ( array $section ): bool {
                    return ( $section['heading'] ?? '' ) !== '' || ! empty( $section['rows'] );
                }
            )
        );
    }

    private static function list_type_for_heading( string $heading ): string {
        $h = strtolower( $heading );
        if ( preg_match( '/dewan\s+(penasehat|pembina|pakar)/u', $h ) ) {
            return 'numbered';
        }
        return 'roles';
    }

    /**
     * @return array{role:string,name:string,num?:int}|null
     */
    private static function parse_numbered_line( string $line ): ?array {
        if ( preg_match( '/^(\d+)\.\s*(.+)$/u', $line, $m ) ) {
            return [
                'role' => '',
                'name' => trim( $m[2] ),
                'num'  => (int) $m[1],
            ];
        }
        if ( strpos( $line, '|' ) !== false ) {
            $parts = array_map( 'trim', explode( '|', $line, 2 ) );
            $name  = $parts[1] ?? $parts[0] ?? '';
            if ( $name !== '' ) {
                return [ 'role' => '', 'name' => $name ];
            }
            return null;
        }
        if ( preg_match( '/^([^:]+):\s*(.+)$/', $line, $m ) ) {
            $left  = strtolower( trim( $m[1] ) );
            $name  = trim( $m[2] );
            if ( $name !== '' && preg_match( '/^(penasehat|pembina|pakar|anggota)$/u', $left ) ) {
                return [ 'role' => '', 'name' => $name ];
            }
        }
        return [
            'role' => '',
            'name' => $line,
        ];
    }
}
