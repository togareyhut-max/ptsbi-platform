<?php
/**
 * Plugin Name:       PTSBI Members
 * Plugin URI:        https://ptsbi.org/
 * Description:       Modul anggota reusable: pendaftaran, profil keluarga, import CSV DAMI, panel admin. Pasangkan dengan Premium Organization 3.0.3+ (bukan 2.7.x yang masih embed modul anggota).
 * Version:           1.0.3
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Premium Plugins
 * License:           GPL-2.0-or-later
 * Text Domain:       ptsbi-members
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! defined( 'PTSMB_VERSION' ) ) {
    define( 'PTSMB_VERSION', '1.0.3' );
}
if ( ! defined( 'PTSMB_FILE' ) ) {
    define( 'PTSMB_FILE', __FILE__ );
}
if ( ! defined( 'PTSMB_DIR' ) ) {
    define( 'PTSMB_DIR', plugin_dir_path( __FILE__ ) );
}
if ( ! defined( 'PTSMB_URL' ) ) {
    define( 'PTSMB_URL', plugin_dir_url( __FILE__ ) );
}
if ( ! defined( 'PTPRM_OPTION' ) ) {
    define( 'PTPRM_OPTION', 'ptprm_options' );
}

require_once PTSMB_DIR . 'includes/ptsmb-loader.php';

register_activation_hook( __FILE__, 'ptsmb_activate_plugin' );

add_action(
    'plugins_loaded',
    static function (): void {
        ptsmb_init_plugin();
        if ( is_admin() && ptsmb_members_already_loaded() && ! ptsmb_load_includes() ) {
            add_action( 'admin_notices', 'ptsmb_compat_admin_notice' );
        }
    },
    10
);
