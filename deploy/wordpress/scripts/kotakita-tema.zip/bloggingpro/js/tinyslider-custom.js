/**
 * Copyright (c) 2016 Gian MR
 * Gian MR Theme Custom Javascript
 *
 * @package Idtheme
 */

(function( slider ) {
"use strict";
	document.addEventListener( 'DOMContentLoaded', function () {
		if ( document.getElementsByClassName( 'gmr-owl-carousel' ).length ){
			var slider = tns({
				container: '.gmr-owl-carousel',
				loop: true,
				gutter: 15,
				controlsText: ['&laquo;', '&raquo;'],
				items: 3,
				swipeAngle: false,
				mouseDrag: true,
				nav: false,
				autoplay: true,
				autoplayButtonOutput: false,
				responsive : {
					0 : {
						items : 2,
					},
					250 : {
						items : 2,
					},
					400 : {
						items : 2,
					},
					600 : {
						items : 3,
					},
					1000 : {
						items : 3,
					}
				}
			});
		}
		if ( document.getElementsByClassName( 'gmr-owl-carousel-bigheadline' ).length ){
			// forEach function from Todd Motto's  blog, as mentioned above
			var forEach = function (array, callback, scope) {
				for (var i = 0; i < array.length; i++) {
					callback.call(scope, i, array[i]); // passes back stuff we need
				}
			};
			var gmrsliders = document.querySelectorAll( '.gmr-owl-carousel-bigheadline' );
			forEach( gmrsliders, function ( index, value ) {
				var slider = tns({
					container: value,
					loop: true,
					gutter: 15,
					controlsText: ['&laquo;', '&raquo;'],
					items: 3,
					swipeAngle: false,
					mouseDrag: true,
					nav: false,
					autoplay: true,
					autoplayButtonOutput: false,
					responsive : {
						0 : {
							items : 2,
						},
						250 : {
							items : 2,
						},
						400 : {
							items : 2,
						},
						600 : {
							items : 3,
						},
						1000 : {
							items : 3,
						}
					}
				});
			});
		}
	});
})( window.slider );

