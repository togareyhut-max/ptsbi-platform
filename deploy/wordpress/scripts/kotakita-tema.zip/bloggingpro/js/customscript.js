/**
 * Copyright (c) 2021 Gian MR
 * Gian MR Theme Custom Javascript
 *
 * @package idtheme
 */

(function(sidr) {
	"use strict"

	sidr.new('#gmr-responsive-menu', {
		name: 'menus',
		source: '.gmr-logo, .close-topnavmenu-wrap, .gmr-mainmenu',
		displace: false,
		onOpen   : function( name ) {
			// Re-name font Icons to correct classnames and support menu icon plugins.
			var elems = document.querySelectorAll( "#menus [class*='sidr-class-icon_'], #menus [class*='sidr-class-_mi']" ), i;
			for ( i = 0; i < elems.length; i++ ) {
				var elm = elems[i];
				if ( elm.className ) {
					elm.className = elm.className.replace(/sidr-class-/g,'');
				}
			}
		}
	});

	window.onresize = function() {
		sidr.close('menus');
	};

	var closemenu = document.querySelector( '#sidr-id-close-topnavmenu-button' );
	
	if ( closemenu !== null ) {
		closemenu.addEventListener(
			'click',
			function( e ) {
				e.preventDefault();
				sidr.close('menus');
			}
		);
	}
	
	/* $( '.sidr-inner li' ).each( */
	var elmTag = document.querySelectorAll( '.sidr-inner li' ), i;
	
	for ( i = 0; i < elmTag.length; i++ ) {
		if ( elmTag[i].querySelectorAll( 'ul' ).length > 0 ) {
			var elm = elmTag[i].querySelectorAll( 'a' );
			if ( elm !== null ) {
				elm[0].innerHTML += '<span class="sub-toggle"><span class="gmr-icon-down"></span></span>';
			}
		}
	}
	
	/* $( '.sidr-inner .sub-toggle' ).click( */
	var elmTag = document.querySelectorAll( '.sidr-inner .sub-toggle' ), i;
	
	for ( i = 0; i < elmTag.length; i++ ) {
		elmTag[i].addEventListener(
			'click',
			function( e ) {
				e.preventDefault();
				var t = this;
				t.classList.toggle( 'is-open' );
				if ( t.classList.contains( 'is-open' ) ) {
					var txt = '<span class="gmr-icon-up"></span>';
				} else {
					var txt = '<span class="gmr-icon-down"></span>';
				}
				t.innerHTML = txt;
				/* console.log (t.parentNode.parentNode.querySelectorAll( 'a' )[0].nextElementSibling); */
				var container = t.parentNode.parentNode.querySelectorAll( 'a' )[0].nextElementSibling;
				if ( !container.classList.contains( 'active' ) ) {
					container.classList.add('active');
				} else {
					container.classList.remove('active');
				}
			}
		);
	}

})( window.sidr );

// get the sticky element
(function() {
	"use strict";

	var header = document.querySelector( '.top-header' );
	var sticky = header.offsetTop;
	window.onscroll = function() {
		if ( window.pageYOffset > sticky ) {
			header.classList.add( 'issticky' );
		} else {
			header.classList.remove( 'issticky' );
		}
	};
})();

/* Click Dropdown Search */
(function(){
	"use strict";

	var btn = document.getElementById( 'search-menu-button' );

	// Close the dropdown menu if the user clicks outside of it
	if ( btn ) {
		btn.addEventListener(
			'click',
			function( e ) {
				e.stopPropagation();
				e.preventDefault();
				var dropdowns = document.querySelector( '.search-dropdown' );
				var closebtn  = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24"><g fill="none"><path d="M21 21l-4.486-4.494M19 10.5a8.5 8.5 0 1 1-17 0a8.5 8.5 0 0 1 17 0z" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></g></svg>';
				var searchbtn = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24"><g fill="none"><path d="M21 21l-4.486-4.494M19 10.5a8.5 8.5 0 1 1-17 0a8.5 8.5 0 0 1 17 0z" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></g></svg>';
				dropdowns.classList.toggle( 'open' );
				if ( dropdowns.classList.contains( 'open' ) ) {
					btn.innerHTML = closebtn;
				} else {
					btn.innerHTML = searchbtn;
				}
				var getid = document.getElementById( 'search-dropdown-container' );
				document.addEventListener(
					'click',
					function( e ) {
						if ( getid !== e.target && !getid.contains(e.target) ) {
							if ( dropdowns.classList.contains( 'open' ) ) {
								dropdowns.classList.remove( 'open' );
								btn.innerHTML = searchbtn;
							}
						}
					}
				);
			}
		);
	}

})();

(function(){
	"use strict";

	var btnsecond = document.getElementById( 'search-menu-button-top' );
	// Close the dropdown menu if the user clicks outside of it
	if ( btnsecond ) {
		btnsecond.addEventListener(
			'click',
			function( e ) {
				e.stopPropagation();
				e.preventDefault();
				var dropdownsecond = document.querySelector( '.topsearchform' );
				var closebtnscd  = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24"><g fill="none"><path d="M21 21l-4.486-4.494M19 10.5a8.5 8.5 0 1 1-17 0a8.5 8.5 0 0 1 17 0z" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></g></svg>';
				var searchbtnscd = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24"><g fill="none"><path d="M21 21l-4.486-4.494M19 10.5a8.5 8.5 0 1 1-17 0a8.5 8.5 0 0 1 17 0z" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></g></svg>';
				dropdownsecond.classList.toggle( 'open' );
				if ( dropdownsecond.classList.contains( 'open' ) ) {
					btnsecond.innerHTML = closebtnscd;
				} else {
					btnsecond.innerHTML = searchbtnscd;
				}
				var getidscd = document.getElementById( 'search-topsearchform-container' );
				document.addEventListener(
					'click',
					function( e ) {
						if ( getidscd !== e.target && !getidscd.contains(e.target) ) {
							if ( dropdownsecond.classList.contains( 'open' ) ) {
								dropdownsecond.classList.remove( 'open' );
								btnsecond.innerHTML = searchbtnscd;
							}
						}
					}
				);
			}
		);
	}

})();

/* Date, for non minify see in wpmedia theme non productions */
const idthemeloadDate=()=>{let e=document.querySelector(".gmr-top-date");if(null!==e){let t=Date.now();if(null!==e){let n=e.getAttribute("data-lang"),l=n||"en-US";if(null!==t){let a={weekday:"long",day:"numeric",month:"long",year:"numeric"},o=new Intl.DateTimeFormat(l,a).format(t);null!==o&&(e.innerHTML=o)}}}};window.addEventListener("DOMContentLoaded",function(){setTimeout(()=>{idthemeloadDate()},150)});

/* Back to top */
( function() {
	"use strict";
	
	window.addEventListener(
	'scroll',
	function() {
		var elm = document.querySelector( '.site' );
		if ( document.body.scrollTop > 5 || document.documentElement.scrollTop > 5 ) {
			if ( elm !== null ) {
				elm.classList.add( 'sticky-menu' );
			}
		} else {
			if ( elm !== null ) {
				elm.classList.remove( 'sticky-menu' );
			}
		}
		var elmontop = document.querySelector( '.gmr-ontop' );
		if ( document.body.scrollTop > 85 || document.documentElement.scrollTop > 85 ) {
			if ( elmontop !== null ) {
				elmontop.style.display = 'block';
				document.querySelector( '.gmr-ontop' ).addEventListener(
					'click',
					function( e ) {
						e.preventDefault();
						window.scroll({top: 0, left: 0, behavior: 'smooth'});
					}
				);
			}
		} else {
			if ( elmontop !== null ) {
				elmontop.style.display = 'none';
			}
		}

	});
})();

/**
 * File skip-link-focus-fix.js.
 *
 * Helps with accessibility for keyboard only users.
 *
 * Learn more: https://git.io/vWdr2
 */
(function() {
	var isIe = /(trident|msie)/i.test( navigator.userAgent );

	if ( isIe && document.getElementById && window.addEventListener ) {
		window.addEventListener(
			'hashchange',
			function() {
				var id = location.hash.substring( 1 ),
					element;

				if ( ! ( /^[A-z0-9_-]+$/.test( id ) ) ) {
					return;
				}

				element = document.getElementById( id );

				if ( element ) {
					if ( ! ( /^(?:a|select|input|button|textarea)$/i.test( element.tagName ) ) ) {
						element.tabIndex = -1;
					}

					element.focus();
				}
			},
			false
		);
	}
})();
