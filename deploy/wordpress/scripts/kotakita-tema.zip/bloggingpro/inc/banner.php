<?php
/**
 * Banner features
 *
 * Author: Gian MR - http://www.gianmr.com
 *
 * @since 1.0.0
 * @package Bloggingpro
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'bloggingpro_topbanner_verytop' ) ) {
	/**
	 * Adding banner at top after menu via hook
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function bloggingpro_topbanner_verytop() {
		$banner = get_theme_mod( 'gmr_adsverytop' );

		if ( isset( $banner ) && ! empty( $banner ) ) {
			echo '<div class="gmr-verytopbanner text-center">';
				echo '<div class="container">';
					echo do_shortcode( $banner );
				echo '</div>';
			echo '</div>';
		}
	}
}
add_action( 'bloggingpro_topbanner_verytop', 'bloggingpro_topbanner_verytop', 10 );

if ( ! function_exists( 'bloggingpro_topbanner_aftermenu' ) ) {
	/**
	 * Adding banner at top after menu via hook
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function bloggingpro_topbanner_aftermenu() {
		$ampbanner = get_theme_mod( 'gmr_adsaftermenu_amp' );
		$banner    = get_theme_mod( 'gmr_adsaftermenu' );

		if ( bloggingpro_is_amp() ) {
			if ( isset( $ampbanner ) && ! empty( $ampbanner ) ) {
				echo '<div class="gmr-topbanner text-center">';
					echo '<div class="container">';
						echo do_shortcode( $ampbanner );
					echo '</div>';
				echo '</div>';
			}
		} else {
			if ( isset( $banner ) && ! empty( $banner ) ) {
				echo '<div class="gmr-topbanner text-center">';
					echo '<div class="container">';
						echo do_shortcode( $banner );
					echo '</div>';
				echo '</div>';
			}
		}
	}
}
add_action( 'bloggingpro_topbanner_aftermenu', 'bloggingpro_topbanner_aftermenu', 10 );

if ( ! function_exists( 'bloggingpro_banner_after_modulehome' ) ) {
	/**
	 * Adding banner at top via hook
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function bloggingpro_banner_after_modulehome() {
		$banner = get_theme_mod( 'gmr_adsaftermodulehome' );

		if ( isset( $banner ) && ! empty( $banner ) ) {
			echo '<div class="gmr-banner-aftermodulehome text-center">';
				echo do_shortcode( $banner );
			echo '</div>';
		}
	}
}
add_action( 'bloggingpro_banner_after_modulehome', 'bloggingpro_banner_after_modulehome', 10 );

if ( ! function_exists( 'bloggingpro_banner_between_posts' ) ) {
	/**
	 * Adding banner between posts in archive and index post
	 *
	 * @since 1.0.5
	 * @param int $post Post ID.
	 * @return void
	 */
	function bloggingpro_banner_between_posts( $post ) {
		global $wp_query;

		$ampbanner = get_theme_mod( 'gmr_adsbetweenpost_amp' );
		$banner    = get_theme_mod( 'gmr_adsbetweenpost' );

		$ampposition = get_theme_mod( 'gmr_adsbetweenpostposition_amp', 'third' );
		$position    = get_theme_mod( 'gmr_adsbetweenpostposition', 'third' );

		if ( bloggingpro_is_amp() ) {
			/* Check if we're at the right position and option not empty */
			if ( isset( $ampbanner ) && ! empty( $ampbanner ) ) {
				if ( 'first' === $ampposition ) {
					$numb = 0;
				} elseif ( 'second' === $ampposition ) {
					$numb = 1;
				} elseif ( 'third' === $ampposition ) {
					$numb = 2;
				} elseif ( 'fourth' === $ampposition ) {
					$numb = 3;
				} else {
					$numb = 2;
				}

				if ( intval( $numb ) === $wp_query->current_post ) {
					/* Display the banner */
					echo '<div class="text-center item-content">';
						echo '<div class="gmr-box-content infeed-ads">';
							echo do_shortcode( $ampbanner );
						echo '</div>';
					echo '</div>';
				}
			}
		} else {
			/* Check if we're at the right position and option not empty */
			if ( isset( $banner ) && ! empty( $banner ) ) {
				if ( 'first' === $position ) {
					$numb = 0;
				} elseif ( 'second' === $position ) {
					$numb = 1;
				} elseif ( 'third' === $position ) {
					$numb = 2;
				} elseif ( 'fourth' === $position ) {
					$numb = 3;
				} else {
					$numb = 2;
				}

				if ( intval( $numb ) === $wp_query->current_post ) {
					/* Display the banner */
					echo '<div class="text-center item-content">';
						echo '<div class="gmr-box-content infeed-ads">';
							echo do_shortcode( $banner );
						echo '</div>';
					echo '</div>';
				}
			}
		}
	}
}
add_action( 'bloggingpro_banner_between_posts', 'bloggingpro_banner_between_posts' );

if ( ! function_exists( 'bloggingpro_banner_before_content' ) ) {
	/**
	 * Adding banner at before content via hook
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function bloggingpro_banner_before_content() {
		$ampbanner = get_theme_mod( 'gmr_adsbeforecontent_amp' );
		$banner    = get_theme_mod( 'gmr_adsbeforecontent' );

		$position = get_theme_mod( 'gmr_adsbeforecontentposition' );

		if ( bloggingpro_is_amp() ) {
			if ( isset( $ampbanner ) && ! empty( $ampbanner ) ) {
				echo '<div class="gmr-banner-beforecontent text-center">';
				echo do_shortcode( $ampbanner );
				echo '</div>';
			}
		} else {
			if ( isset( $banner ) && ! empty( $banner ) ) {
				if ( 'floatleft' === $position ) {
					$class = ' pull-left';
				} elseif ( 'floatright' === $position ) {
					$class = ' pull-right';
				} elseif ( 'center' === $position ) {
					$class = ' text-center';
				} else {
					$class = '';
				}
				echo '<div class="gmr-banner-beforecontent' . esc_html( $class ) . '">';
				echo do_shortcode( $banner );
				echo '</div>';
			}
		}
	}
}

if ( ! function_exists( 'bloggingpro_add_banner_before_content' ) ) :
	/**
	 * Insert content after box content single
	 *
	 * @since 1.0.0
	 * @param string $content Content Posts.
	 * @return string
	 */
	function bloggingpro_add_banner_before_content( $content ) {
		if ( is_singular( array( 'post' ) ) && in_the_loop() ) {
			$content = bloggingpro_banner_before_content() . $content;
		}
		return $content;
	}
endif; /* endif bloggingpro_add_banner_before_content */
add_filter( 'the_content', 'bloggingpro_add_banner_before_content', 30, 1 );

if ( ! function_exists( 'bloggingpro_add_banner_inside_content' ) ) :
	/**
	 * Insert content inside content single
	 *
	 * @since 1.0.0
	 * @return string
	 */
	function bloggingpro_add_banner_inside_content() {
		$ampbanner = get_theme_mod( 'gmr_adsinsidecontent_amp' );
		$banner    = get_theme_mod( 'gmr_adsinsidecontent' );
		$position  = get_theme_mod( 'gmr_adsinsidecontentposition', 'left' );

		if ( bloggingpro_is_amp() ) {
			if ( isset( $ampbanner ) && ! empty( $ampbanner ) ) {
				return '<div class="gmr-banner-insidecontent text-center">' . do_shortcode( $ampbanner ) . '</div>';
			}
		} else {
			if ( isset( $banner ) && ! empty( $banner ) ) {
				if ( 'right' === $position ) {
					$class = ' text-right';
				} elseif ( 'center' === $position ) {
					$class = ' text-center';
				} else {
					$class = '';
				}
				return '<div class="gmr-banner-insidecontent' . esc_html( $class ) . '">' . do_shortcode( $banner ) . '</div>';
			}
		}
	}
endif;

if ( ! function_exists( 'bloggingpro_banner_after_content' ) ) {
	/**
	 * Adding banner at before content via hook
	 *
	 * @since 1.0.0
	 * @return string
	 */
	function bloggingpro_banner_after_content() {
		$ampbanner = get_theme_mod( 'gmr_adsaftercontent_amp' );
		$banner    = get_theme_mod( 'gmr_adsaftercontent' );

		$position = get_theme_mod( 'gmr_adsaftercontentposition' );

		$ads = '';
		if ( bloggingpro_is_amp() ) {
			if ( isset( $ampbanner ) && ! empty( $ampbanner ) ) {
				$ads .= '<div class="gmr-banner-aftercontent text-center">';
				$ads .= do_shortcode( $ampbanner );
				$ads .= '</div>';
			}
		} else {
			if ( isset( $banner ) && ! empty( $banner ) ) {
				if ( 'right' === $position ) {
					$class = ' text-right';
				} elseif ( 'center' === $position ) {
					$class = ' text-center';
				} else {
					$class = '';
				}
				$ads .= '<div class="gmr-banner-aftercontent' . esc_html( $class ) . '">';
				$ads .= do_shortcode( $banner );
				$ads .= '</div>';
			}
		}
		return $ads;
	}
}

if ( ! function_exists( 'bloggingpro_add_banner_after_content' ) ) :
	/**
	 * Insert content after box content single
	 *
	 * @since 1.0.0
	 * @param string $content Content Posts.
	 * @return string
	 */
	function bloggingpro_add_banner_after_content( $content ) {
		if ( is_singular( array( 'post' ) ) && in_the_loop() ) {
			$content = $content . bloggingpro_banner_after_content();
		}
		return $content;
	}
endif; /* endif bloggingpro_add_banner_after_content */
add_filter( 'the_content', 'bloggingpro_add_banner_after_content', 30 );

if ( ! function_exists( 'bloggingpro_banner_after_relpost' ) ) {
	/**
	 * Adding banner after related posts via hook
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function bloggingpro_banner_after_relpost() {
		$ampbanner = get_theme_mod( 'gmr_adsafterrelpost_amp' );
		$banner    = get_theme_mod( 'gmr_adsafterrelpost' );

		$position = get_theme_mod( 'gmr_adsafterrelpostposition' );

		if ( bloggingpro_is_amp() ) {
			if ( isset( $ampbanner ) && ! empty( $ampbanner ) ) {
				echo '<div class="gmr-banner-afterrelpost clearfix">';
					echo do_shortcode( $ampbanner );
				echo '</div>';
			}
		} else {
			if ( isset( $banner ) && ! empty( $banner ) ) {
				if ( 'right' === $position ) {
					$class = ' text-right';
				} elseif ( 'center' === $position ) {
					$class = ' text-center';
				} else {
					$class = '';
				}
				echo '<div class="gmr-banner-afterrelpost clearfix' . esc_html( $class ) . '">';
					echo do_shortcode( $banner );
				echo '</div>';
			}
		}
	}
}
add_action( 'bloggingpro_banner_after_relpost', 'bloggingpro_banner_after_relpost', 10 );

if ( ! function_exists( 'bloggingpro_floating_banner_left' ) ) {
	/**
	 * Adding banner at top via hook
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function bloggingpro_floating_banner_left() {
		$banner = get_theme_mod( 'gmr_adsfloatleft' );

		if ( isset( $banner ) && ! empty( $banner ) ) {
			echo '<div class="gmr-floatbanner gmr-floatbanner-left">';
				echo '<div class="inner-floatleft">';
				echo '<button onclick="parentNode.remove()" title="' . esc_html__( 'close', 'bloggingpro' ) . '">' . esc_html__( 'close', 'bloggingpro' ) . '</button>';
				echo do_shortcode( $banner );
				echo '</div>';
			echo '</div>';
		}
	}
}
add_action( 'bloggingpro_floating_banner_left', 'bloggingpro_floating_banner_left', 10 );

if ( ! function_exists( 'bloggingpro_floating_banner_right' ) ) {
	/**
	 * Adding banner at top via hook
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function bloggingpro_floating_banner_right() {
		$banner = get_theme_mod( 'gmr_adsfloatright' );

		if ( isset( $banner ) && ! empty( $banner ) ) {
			echo '<div class="gmr-floatbanner gmr-floatbanner-right">';
				echo '<div class="inner-floatright">';
				echo '<button onclick="parentNode.remove()" title="' . esc_html__( 'close', 'bloggingpro' ) . '">' . esc_html__( 'close', 'bloggingpro' ) . '</button>';
				echo do_shortcode( $banner );
				echo '</div>';
			echo '</div>';
		}
	}
}
add_action( 'bloggingpro_floating_banner_right', 'bloggingpro_floating_banner_right', 10 );

if ( ! function_exists( 'bloggingpro_floating_banner_footer' ) ) {
	/**
	 * Adding floating banner
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function bloggingpro_floating_banner_footer() {
		$banner = get_theme_mod( 'gmr_adsfloatbottom' );

		if ( isset( $banner ) && ! empty( $banner ) ) {
			echo '<div class="gmr-floatbanner gmr-floatbanner-footer">';
				echo '<div class="container">';
					echo '<div class="inner-floatbottom">';
					echo '<button onclick="parentNode.remove()" title="' . esc_html__( 'close', 'bloggingpro' ) . '">' . esc_html__( 'close', 'bloggingpro' ) . '</button>';
					echo do_shortcode( $banner );
					echo '</div>';
				echo '</div>';
			echo '</div>';
		}
	}
}
add_action( 'bloggingpro_floating_banner_footer', 'bloggingpro_floating_banner_footer', 20 );

if ( ! function_exists( 'bloggingpro_footerbanner' ) ) {
	/**
	 * Adding banner at top via hook
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function bloggingpro_footerbanner() {
		$banner = get_theme_mod( 'gmr_adsfooter' );

		if ( isset( $banner ) && ! empty( $banner ) ) {
			echo '<div class="gmr-footerbanner text-center">';
				echo '<div class="container">';
					echo do_shortcode( $banner );
				echo '</div>';
			echo '</div>';
		}
	}
}
add_action( 'bloggingpro_footerbanner', 'bloggingpro_footerbanner', 10 );
