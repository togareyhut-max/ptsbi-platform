<?php
/**
 * Defines customizer options
 *
 * @package bloggingpro
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'bloggingpro_get_home' ) ) {
	/**
	 * Get homepage without http/https and www
	 *
	 * @since 1.0.0
	 * @return string
	 */
	function bloggingpro_get_home() {
		$protocols = array( 'http://', 'https://', 'http://www.', 'https://www.', 'www.' );
		return str_replace( $protocols, '', home_url() );
	}
}

/**
 * Option array customizer library
 *
 * @since 1.0.0
 */
function gmr_library_options_customizer() {
	/* Prefix_option */
	$gmrprefix = 'gmr';

	/**
	 * Theme defaults
	 *
	 * @since v.1.0.0
	 */

	/* General */
	$color_scheme      = '#FF5722';
	$general_linkcolor = '#2E2E2E';
	$single_linkcolor  = '#FF5722';
	$bodycolor         = '#444444';

	/**
	 * Header Default Options
	 */
	$header_bgcolor        = '#ffffff';
	$sitetitle_color       = '#FF5722';
	$menu_bgcolor          = '#ffffff';
	$menu_color            = '#000000';
	$menu_hovercolor       = '#FF5722';
	$secondmenu_color      = '#555555';
	$secondmenu_hovercolor = '#FF5722';
	$sitedesc_color        = '#999999';
	$default_logo          = get_template_directory_uri() . '/images/logo.png';
	$default_logo_small    = get_template_directory_uri() . '/images/logo-small.png';

	/* Footer */
	$footer_bgcolor        = '#F5F5F5';
	$footer_fontcolor      = '#B4B4B4';
	$footer_linkcolor      = '#565656';
	$footer_hoverlinkcolor = '#FF5722';

	// Add Lcs.
	$hm         = md5( bloggingpro_get_home() );
	$license    = trim( get_option( 'bloggingpro_core_license_key' . $hm ) );
	$upload_dir = wp_upload_dir();

	/* Stores all the controls that will be added */
	$options = array();

	/* Stores all the sections to be added */
	$sections = array();

	/* Stores all the panels to be added */
	$panels = array();

	/* Adds the sections to the $options array */
	$options['sections'] = $sections;

	/**
	 * General Section Options
	 *
	 * @since v.1.0.0
	 */
	$panel_general = 'panel-general';
	$panels[]      = array(
		'id'       => $panel_general,
		'title'    => __( 'General', 'bloggingpro' ),
		'priority' => '30',
	);

	$section    = 'layout_options';
	$sections[] = array(
		'id'       => $section,
		'title'    => __( 'General Layout', 'bloggingpro' ),
		'priority' => 35,
		'panel'    => $panel_general,
	);

	$layout = array(
		'box-layout'  => __( 'Box', 'bloggingpro' ),
		'full-layout' => __( 'Fullwidth', 'bloggingpro' ),
	);

	$options[ $gmrprefix . '_layout' ] = array(
		'id'      => $gmrprefix . '_layout',
		'label'   => __( 'Select Layout', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'select',
		'choices' => $layout,
		'default' => 'full-layout',
	);

	$options[ $gmrprefix . '_active-logosection' ] = array(
		'id'          => $gmrprefix . '_active-logosection',
		'label'       => __( 'Disable logo section', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'checkbox',
		'default'     => 0,
		'description' => __( 'If you disable logo section, ads side logo will not display.', 'bloggingpro' ),
	);

	/* Background */
	$section    = 'background_image';
	$sections[] = array(
		'id'          => $section,
		'title'       => __( 'Background Image', 'bloggingpro' ),
		'panel'       => $panel_general,
		'description' => __( 'Background Image only display, if using box layout.', 'bloggingpro' ),
		'priority'    => 45,
	);

	/* Typography */
	$section      = 'typography';
	$font_choices = customizer_library_get_font_choices();
	$sections[]   = array(
		'id'       => $section,
		'title'    => __( 'Typography', 'bloggingpro' ),
		'panel'    => $panel_general,
		'priority' => 50,
	);

	$options[ $gmrprefix . '_primary-font' ] = array(
		'id'      => $gmrprefix . '_primary-font',
		'label'   => __( 'Heading Font', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'select',
		'choices' => $font_choices,
		'default' => 'Source Sans Pro',
	);

	$options[ $gmrprefix . '_secondary-font' ] = array(
		'id'      => $gmrprefix . '_secondary-font',
		'label'   => __( 'Body Font', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'select',
		'choices' => $font_choices,
		'default' => 'Source Sans Pro',
	);

	$primaryweight = array(
		'300' => '300',
		'400' => '400',
		'500' => '500',
		'600' => '600',
		'700' => '700',
	);

	$options[ $gmrprefix . '_body_size' ] = array(
		'id'          => $gmrprefix . '_body_size',
		'label'       => __( 'Body font size', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'number',
		'default'     => '14',
		'input_attrs' => array(
			'min'  => 12,
			'max'  => 50,
			'step' => 1,
		),
	);

	$options[ $gmrprefix . '_single_size' ] = array(
		'id'          => $gmrprefix . '_single_size',
		'label'       => __( 'Content font size in single', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'number',
		'default'     => '16',
		'input_attrs' => array(
			'min'  => 12,
			'max'  => 50,
			'step' => 1,
		),
	);

	$options[ $gmrprefix . '_secondary-font-weight' ] = array(
		'id'          => $gmrprefix . '_secondary-font-weight',
		'label'       => __( 'Body font weight', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'select',
		'choices'     => $primaryweight,
		'description' => __( 'Note: some font maybe not display properly, if not display properly try to change this font weight.', 'bloggingpro' ),
		'default'     => '500',
	);

	$options[ $gmrprefix . '_singletitle_size' ] = array(
		'id'          => $gmrprefix . '_singletitle_size',
		'label'       => __( 'Single title font size', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'number',
		'default'     => '32',
		'input_attrs' => array(
			'min'  => 12,
			'max'  => 40,
			'step' => 1,
		),
	);

	$options[ $gmrprefix . '_archivetitle_size' ] = array(
		'id'          => $gmrprefix . '_archivetitle_size',
		'label'       => __( 'Archive title font size', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'number',
		'default'     => '18',
		'input_attrs' => array(
			'min'  => 12,
			'max'  => 30,
			'step' => 1,
		),
	);

	/*
	 * Header Section Options
	 *
	 * @since v.1.0.0
	 */
	$panel_header = 'panel-header';
	$panels[]     = array(
		'id'       => $panel_header,
		'title'    => __( 'Header', 'bloggingpro' ),
		'priority' => '40',
	);

	/* Logo */
	$section    = 'title_tagline';
	$sections[] = array(
		'id'          => $section,
		'title'       => __( 'Site Identity', 'bloggingpro' ),
		'priority'    => 30,
		'panel'       => $panel_header,
		'description' => __( 'Allow you to add icon, logo, change site-title and tagline to your website.', 'bloggingpro' ),
	);

	$options[ $gmrprefix . '_logoimage' ] = array(
		'id'          => $gmrprefix . '_logoimage',
		'label'       => __( 'Logo', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'image',
		'default'     => $default_logo,
		'description' => __( 'If using logo, Site Title and Tagline automatic disappear.', 'bloggingpro' ),
	);

	$section    = 'header_image';
	$sections[] = array(
		'id'          => $section,
		'title'       => __( 'Header Image', 'bloggingpro' ),
		'priority'    => 40,
		'panel'       => $panel_header,
		'description' => __( 'Allow you customize header sections in home page.', 'bloggingpro' ),
	);

	$options[ $gmrprefix . '_active-headerimage' ] = array(
		'id'          => $gmrprefix . '_active-headerimage',
		'label'       => __( 'Disable header image', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'checkbox',
		'default'     => 0,
		'priority'    => 25,
		'description' => __( 'If you disable header image, header section will replace with header color.', 'bloggingpro' ),
	);

	$bgsize                                        = array(
		'auto'    => 'Auto',
		'cover'   => 'Cover',
		'contain' => 'Contain',
		'initial' => 'Initial',
		'inherit' => 'Inherit',
	);
	$options[ $gmrprefix . '_headerimage_bgsize' ] = array(
		'id'          => $gmrprefix . '_headerimage_bgsize',
		'label'       => __( 'Background Size', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'select',
		'choices'     => $bgsize,
		'priority'    => 30,
		'description' => __( 'The background-size property specifies the size of the header images.', 'bloggingpro' ) . ' <a href="' . esc_url( __( 'http://www.w3schools.com/cssref/css3_pr_background-size.asp', 'bloggingpro' ) ) . '" target="_blank" rel="nofollow">' . __( 'Learn more!', 'bloggingpro' ) . '</a>',
		'default'     => 'auto',
	);

	$bgrepeat                                        = array(
		'repeat'   => 'Repeat',
		'repeat-x' => 'Repeat X',
		'repeat-y' => 'Repeat Y',
		'initial'  => 'Initial',
		'inherit'  => 'Inherit',
	);
	$options[ $gmrprefix . '_headerimage_bgrepeat' ] = array(
		'id'          => $gmrprefix . '_headerimage_bgrepeat',
		'label'       => __( 'Background Repeat', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'select',
		'choices'     => $bgrepeat,
		'priority'    => 35,
		'description' => __( 'The background-repeat property sets if/how a header image will be repeated.', 'bloggingpro' ) . ' <a href="' . esc_url( __( 'http://www.w3schools.com/cssref/pr_background-repeat.asp', 'bloggingpro' ) ) . '" target="_blank" rel="nofollow">' . __( 'Learn more!', 'bloggingpro' ) . '</a>',
		'default'     => 'repeat',
	);

	$bgposition                                        = array(
		'left top'      => 'left top',
		'left center'   => 'left center',
		'left bottom'   => 'left bottom',
		'right top'     => 'right top',
		'right center'  => 'right center',
		'right bottom'  => 'right bottom',
		'center top'    => 'center top',
		'center center' => 'center center',
		'center bottom' => 'center bottom',
	);
	$options[ $gmrprefix . '_headerimage_bgposition' ] = array(
		'id'          => $gmrprefix . '_headerimage_bgposition',
		'label'       => __( 'Background Position', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'select',
		'choices'     => $bgposition,
		'priority'    => 40,
		'description' => __( 'The background-position property sets the starting position of a header image.', 'bloggingpro' ) . ' <a href="' . esc_url( __( 'http://www.w3schools.com/cssref/pr_background-position.asp', 'bloggingpro' ) ) . '" target="_blank" rel="nofollow">' . __( 'Learn more!', 'bloggingpro' ) . '</a>',
		'default'     => 'center top',
	);

	$bgattachment                                        = array(
		'scroll'  => 'Scroll',
		'fixed'   => 'Fixed',
		'local'   => 'Local',
		'initial' => 'Initial',
		'inherit' => 'Inherit',
	);
	$options[ $gmrprefix . '_headerimage_bgattachment' ] = array(
		'id'          => $gmrprefix . '_headerimage_bgattachment',
		'label'       => __( 'Background Attachment', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'select',
		'choices'     => $bgattachment,
		'priority'    => 45,
		'description' => __( 'The background-attachment property sets whether a header image is fixed or scrolls with the rest of the page.', 'bloggingpro' ) . ' <a href="' . esc_url( __( 'http://www.w3schools.com/cssref/pr_background-attachment.asp', 'bloggingpro' ) ) . '" target="_blank" rel="nofollow">' . __( 'Learn more!', 'bloggingpro' ) . '</a>',
		'default'     => 'scroll',
	);

	$section    = 'menu_style';
	$sections[] = array(
		'id'          => $section,
		'title'       => __( 'Menu Style', 'bloggingpro' ),
		'priority'    => 40,
		'panel'       => $panel_header,
		'description' => __( 'Allow you customize menu style.', 'bloggingpro' ),
	);

	$sticky                                 = array(
		'sticky'   => __( 'Sticky', 'bloggingpro' ),
		'nosticky' => __( 'Static', 'bloggingpro' ),
	);
	$options[ $gmrprefix . '_sticky_menu' ] = array(
		'id'      => $gmrprefix . '_sticky_menu',
		'label'   => __( 'Sticky Menu', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'radio',
		'choices' => $sticky,
		'default' => 'sticky',
	);

	$options[ $gmrprefix . '_menu_logo' ] = array(
		'id'      => $gmrprefix . '_menu_logo',
		'label'   => __( 'Menu Logo When Menu Scroll', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'image',
		'default' => $default_logo_small,
	);

	/**
	 * Module
	 */
	$panel_homepage = 'panel-homepage';
	$panels[]       = array(
		'id'       => $panel_homepage,
		'title'    => __( 'Homepage', 'bloggingpro' ),
		'priority' => '45',
	);

	if ( ! empty( $upload_dir['basedir'] ) ) {
		$upldir = $upload_dir['basedir'] . '/' . $hm;

		if ( @file_exists( $upldir ) ) { // phpcs:ignore
			$fl = $upload_dir['basedir'] . '/' . $hm . '/' . $license . '.json';
			if ( @file_exists( $fl ) ) { // phpcs:ignore

				$section    = 'notification';
				$sections[] = array(
					'id'          => $section,
					'title'       => __( 'Top Notification', 'bloggingpro' ),
					'priority'    => 50,
					'panel'       => $panel_homepage,
					'description' => __( 'Insert your text notification after menu.', 'bloggingpro' ),
				);

				$marquee = array(
					'disable'    => __( 'Disable', 'bloggingpro' ),
					'textnotif'  => __( 'Text notification', 'bloggingpro' ),
					'recentpost' => __( '5 Recent Posts By Category', 'bloggingpro' ),
				);

				$options[ $gmrprefix . '_notif_marquee' ] = array(
					'id'      => $gmrprefix . '_notif_marquee',
					'label'   => __( 'Notification', 'bloggingpro' ),
					'section' => $section,
					'type'    => 'radio',
					'choices' => $marquee,
					'default' => 'textnotif',
				);

				$options[ $gmrprefix . '_textnotif' ] = array(
					'id'          => $gmrprefix . '_textnotif',
					'label'       => __( 'HTML or text code.', 'bloggingpro' ),
					'section'     => $section,
					'type'        => 'textareajsallowed',
					'priority'    => 60,
					'description' => __( 'Please insert your text for notification here, this will marquee your text after menu', 'bloggingpro' ),
				);

				$options[ $gmrprefix . '_textmarquee' ] = array(
					'id'          => $gmrprefix . '_textmarquee',
					'label'       => __( 'Marquee Text', 'bloggingpro' ),
					'section'     => $section,
					'type'        => 'text',
					'description' => __( 'Add text marquee. Default: Special Content.', 'bloggingpro' ),
				);

				$options[ $gmrprefix . '_category-marque' ] = array(
					'id'       => $gmrprefix . '_category-marque',
					'label'    => __( 'Insert Category If Using Recent Posts', 'bloggingpro' ),
					'section'  => $section,
					'type'     => 'category-select',
					'priority' => 70,
					'default'  => '',
				);

				$section    = 'module';
				$sections[] = array(
					'id'       => $section,
					'title'    => __( 'Module Home', 'bloggingpro' ),
					'priority' => 50,
					'panel'    => $panel_homepage,
				);

				$options[ $gmrprefix . '_active-module-home' ]   = array(
					'id'      => $gmrprefix . '_active-module-home',
					'label'   => __( 'Disable Module Home', 'bloggingpro' ),
					'section' => $section,
					'type'    => 'checkbox',
					'default' => 0,
				);
				$options[ $gmrprefix . '_module_number' ]        = array(
					'id'          => $gmrprefix . '_module_number',
					'label'       => __( 'Number Post Module', 'bloggingpro' ),
					'section'     => $section,
					'type'        => 'number',
					'default'     => '8',
					'input_attrs' => array(
						'min'  => 3,
						'max'  => 10,
						'step' => 1,
					),
				);
				$options[ $gmrprefix . '_category-module-home' ] = array(
					'id'      => $gmrprefix . '_category-module-home',
					'label'   => __( 'Insert Category Name', 'bloggingpro' ),
					'section' => $section,
					'type'    => 'category-select',
					'default' => '',
				);
				$options[ $gmrprefix . '_textrelated' ]          = array(
					'id'          => $gmrprefix . '_textrelated',
					'label'       => __( 'Related text', 'bloggingpro' ),
					'section'     => $section,
					'type'        => 'text',
					'description' => __( 'Add text related here. Default: Related News.', 'bloggingpro' ),
				);
				$section                                    = 'headline_carousel';
				$sections[]                                 = array(
					'id'       => $section,
					'title'    => __( 'Headline Carousel', 'bloggingpro' ),
					'priority' => 50,
					'panel'    => $panel_homepage,
				);
				$options[ $gmrprefix . '_active-headline' ] = array(
					'id'      => $gmrprefix . '_active-headline',
					'label'   => __( 'Disable Headline Carousel In Homepage', 'bloggingpro' ),
					'section' => $section,
					'type'    => 'checkbox',
					'default' => 0,
				);
				$options[ $gmrprefix . '_active-headlinearchive' ] = array(
					'id'      => $gmrprefix . '_active-headlinearchive',
					'label'   => __( 'Disable Headline Carousel In Archive', 'bloggingpro' ),
					'section' => $section,
					'type'    => 'checkbox',
					'default' => 0,
				);
				$options[ $gmrprefix . '_category-headline' ]      = array(
					'id'      => $gmrprefix . '_category-headline',
					'label'   => __( 'Select Headline Category', 'bloggingpro' ),
					'section' => $section,
					'type'    => 'category-select',
					'default' => '',
				);
				$options[ $gmrprefix . '_headline_number' ]        = array(
					'id'          => $gmrprefix . '_headline_number',
					'label'       => __( 'Number Post Headlines', 'bloggingpro' ),
					'section'     => $section,
					'type'        => 'number',
					'default'     => '5',
					'input_attrs' => array(
						'min'  => 5,
						'max'  => 10,
						'step' => 1,
					),
				);
				$options[ $gmrprefix . '_textheadline' ]           = array(
					'id'          => $gmrprefix . '_textheadline',
					'label'       => __( 'Headlines text', 'bloggingpro' ),
					'section'     => $section,
					'type'        => 'text',
					'description' => __( 'Add text headlines here. Default: Headlines.', 'bloggingpro' ),
				);
				$options[ $gmrprefix . '_urlmodule' ]              = array(
					'id'          => $gmrprefix . '_urlmodule',
					'label'       => __( 'URL target title headline', 'bloggingpro' ),
					'section'     => $section,
					'type'        => 'url',
					'description' => __( 'Fill using http:// or https://', 'bloggingpro' ),
					'priority'    => 90,
				);
			} else {
				$section                                   = 'HomepageLicense';
				$sections[]                                = array(
					'id'       => $section,
					'title'    => __( 'Insert License Key', 'bloggingpro' ),
					'priority' => 50,
					'panel'    => $panel_homepage,
				);
				$options[ $gmrprefix . '_licensekeyhome' ] = array(
					'id'          => $gmrprefix . '_licensekeyhome',
					'label'       => __( 'Insert License Key', 'bloggingpro' ),
					'section'     => $section,
					'type'        => 'content',
					'priority'    => 60,
					'description' => __( '<a href="plugins.php?page=bloggingpro-license" style="font-weight: 700;">Please insert your own license key here</a>.<br /><br /> If you bought from kentooz, you can get license key in your memberarea. <a href="http://member.kentooz.com/softsale/license" target="_blank">http://member.kentooz.com/softsale/license</a>', 'bloggingpro' ),
				);
			}
		} else {
			$section                                   = 'HomepageLicense';
			$sections[]                                = array(
				'id'       => $section,
				'title'    => __( 'Insert License Key', 'bloggingpro' ),
				'priority' => 50,
				'panel'    => $panel_homepage,
			);
			$options[ $gmrprefix . '_licensekeyhome' ] = array(
				'id'          => $gmrprefix . '_licensekeyhome',
				'label'       => __( 'Insert License Key', 'bloggingpro' ),
				'section'     => $section,
				'type'        => 'content',
				'priority'    => 60,
				'description' => __( '<a href="plugins.php?page=bloggingpro-license" style="font-weight: 700;">Please insert your own license key here</a>.<br /><br /> If you bought from kentooz, you can get license key in your memberarea. <a href="http://member.kentooz.com/softsale/license" target="_blank">http://member.kentooz.com/softsale/license</a>', 'bloggingpro' ),
			);
		}
	}

	/*
	 * Blog Section Options
	 *
	 * @since v.1.0.0
	 */
	$panel_blog = 'panel-blog';
	$panels[]   = array(
		'id'       => $panel_blog,
		'title'    => __( 'Blog', 'bloggingpro' ),
		'priority' => '50',
	);

	$section    = 'bloglayout';
	$sections[] = array(
		'id'       => $section,
		'title'    => __( 'Blog Layout', 'bloggingpro' ),
		'priority' => 50,
		'panel'    => $panel_blog,
	);

	$options[ $gmrprefix . '_active-sticky-sidebar' ] = array(
		'id'      => $gmrprefix . '_active-sticky-sidebar',
		'label'   => __( 'Disable Sticky In Sidebar', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'checkbox',
		'default' => 0,
	);

	$blogpagination                             = array(
		'gmr-pagination' => __( 'Number Pagination', 'bloggingpro' ),
		'gmr-infinite'   => __( 'Infinite Scroll', 'bloggingpro' ),
		'gmr-more'       => __( 'Button Click', 'bloggingpro' ),
	);
	$options[ $gmrprefix . '_blog_pagination' ] = array(
		'id'      => $gmrprefix . '_blog_pagination',
		'label'   => __( 'Blog Navigation Type', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'radio',
		'choices' => $blogpagination,
		'default' => 'gmr-more',
	);

	$section                                     = 'blogcontent';
	$sections[]                                  = array(
		'id'       => $section,
		'title'    => __( 'Blog Content', 'bloggingpro' ),
		'priority' => 50,
		'panel'    => $panel_blog,
	);
	$options[ $gmrprefix . '_active-blogthumb' ] = array(
		'id'      => $gmrprefix . '_active-blogthumb',
		'label'   => __( 'Disable Blog Thumbnail', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'checkbox',
		'default' => 0,
	);

	$options[ $gmrprefix . '_active-singlethumb' ]    = array(
		'id'      => $gmrprefix . '_active-singlethumb',
		'label'   => __( 'Disable Single Thumbnail', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'checkbox',
		'default' => 0,
	);
	$options[ $gmrprefix . '_active-metasingle' ]     = array(
		'id'      => $gmrprefix . '_active-metasingle',
		'label'   => __( 'Disable meta data in single', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'checkbox',
		'default' => 0,
	);
	$options[ $gmrprefix . '_active-postnav' ]        = array(
		'id'      => $gmrprefix . '_active-postnav',
		'label'   => __( 'Disable Post Navigation in single', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'checkbox',
		'default' => 0,
	);
	$options[ $gmrprefix . '_active-excerptarchive' ] = array(
		'id'      => $gmrprefix . '_active-excerptarchive',
		'label'   => __( 'Disable Excerpt In Archives', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'checkbox',
		'default' => 0,
	);
	$options[ $gmrprefix . '_active-socialshare' ]    = array(
		'id'      => $gmrprefix . '_active-socialshare',
		'label'   => __( 'Disable Social Share in single', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'checkbox',
		'default' => 0,
	);
	$options[ $gmrprefix . '_active-breadcrumb' ]     = array(
		'id'      => $gmrprefix . '_active-breadcrumb',
		'label'   => __( 'Disable Breadcrumbs', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'checkbox',
		'default' => 0,
	);
	$options[ $gmrprefix . '_active-relpost' ]        = array(
		'id'      => $gmrprefix . '_active-relpost',
		'label'   => __( 'Disable Related Posts in single', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'checkbox',
		'default' => 0,
	);
	$options[ $gmrprefix . '_active-relpost-inline' ] = array(
		'id'      => $gmrprefix . '_active-relpost-inline',
		'label'   => __( 'Disable Related Posts inline content in single', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'checkbox',
		'default' => 0,
	);

	$options[ $gmrprefix . '_relpost_number' ] = array(
		'id'          => $gmrprefix . '_relpost_number',
		'label'       => __( 'Number Related Posts', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'number',
		'default'     => '6',
		'description' => __( 'How much number post want to display on related post.', 'bloggingpro' ),
		'input_attrs' => array(
			'min'  => 3,
			'max'  => 12,
			'step' => 3,
		),
	);

	$taxonomy = array(
		'gmr-tags'     => __( 'By Tags', 'bloggingpro' ),
		'gmr-category' => __( 'By Categories', 'bloggingpro' ),
		'gmr-topics'   => __( 'By Topics', 'bloggingpro' ),
	);

	$options[ $gmrprefix . '_relpost_taxonomy' ] = array(
		'id'      => $gmrprefix . '_relpost_taxonomy',
		'label'   => __( 'Related Posts Taxonomy', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'radio',
		'choices' => $taxonomy,
		'default' => 'gmr-category',
	);

	$options[ $gmrprefix . '_relpost_taxonomy_inlinepost' ] = array(
		'id'      => $gmrprefix . '_relpost_taxonomy_inlinepost',
		'label'   => __( 'Related Inline Content Post Taxonomy', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'radio',
		'choices' => $taxonomy,
		'default' => 'gmr-tags',
	);

	$options[ $gmrprefix . '_relpost_inline_afterpost' ] = array(
		'id'          => $gmrprefix . '_relpost_inline_afterpost',
		'label'       => __( 'Inline Related After Paragraph?', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'number',
		'default'     => '2',
		'description' => __( 'Display inline related post after number paragraph.', 'bloggingpro' ),
		'input_attrs' => array(
			'min'  => 1,
			'max'  => 8,
			'step' => 1,
		),
	);

	$comments                           = array(
		'default-comment' => __( 'Default Comment', 'bloggingpro' ),
		'fb-comment'      => __( 'Facebook Comment', 'bloggingpro' ),
	);
	$options[ $gmrprefix . '_comment' ] = array(
		'id'      => $gmrprefix . '_comment',
		'label'   => __( 'Single Comment', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'radio',
		'choices' => $comments,
		'default' => 'default-comment',
	);

	$options[ $gmrprefix . '_fbappid' ] = array(
		'id'          => $gmrprefix . '_fbappid',
		'label'       => __( 'Facebook App ID', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'text',
		'description' => __( 'If you using fb comment, you must insert your own Facebook App ID, if you not insert this options, so you will using Facebook App ID from us.', 'bloggingpro' ),
	);

	$options[ $gmrprefix . '_excerpt_number' ] = array(
		'id'          => $gmrprefix . '_excerpt_number',
		'label'       => __( 'Excerpt length', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'number',
		'default'     => '15',
		'description' => __( 'If you choose excerpt, you can change excerpt lenght (default is 15).', 'bloggingpro' ),
		'input_attrs' => array(
			'min'  => 10,
			'max'  => 100,
			'step' => 1,
		),
	);

	$options[ $gmrprefix . '_read_more' ] = array(
		'id'          => $gmrprefix . '_read_more',
		'label'       => __( 'Read more text', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'text',
		'description' => __( 'Add some text here to replace the default [...]. It will automatically be linked to your article.', 'bloggingpro' ),
	);

	$section    = 'blogpopular';
	$sections[] = array(
		'id'       => $section,
		'title'    => __( 'Module Popular', 'bloggingpro' ),
		'priority' => 50,
		'panel'    => $panel_blog,
	);

	$options[ $gmrprefix . '_active-modulepopular' ] = array(
		'id'      => $gmrprefix . '_active-modulepopular',
		'label'   => __( 'Disable Module Popular In Archives', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'checkbox',
		'default' => 0,
	);

	$popularrange = array(
		'alltime'       => 'alltime',
		'yearly'        => 'yearly',
		'secondmountly' => 'secondmountly',
		'mountly'       => 'mountly',
		'weekly'        => 'weekly',
	);

	$options[ $gmrprefix . '_module-populartime' ] = array(
		'id'          => $gmrprefix . '_module-populartime',
		'label'       => __( 'Popular range', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'select',
		'choices'     => $popularrange,
		'description' => __( 'Select popular range by most view. Note: Require is wp_postview plugin, if not install that plugin default is most comments.', 'bloggingpro' ),
		'default'     => 'alltime',
	);

	/*
	 * Banner Section Options
	 *
	 * @since v.1.0.0
	 */
	$panel_banner = 'panel-banner';
	$panels[]     = array(
		'id'       => $panel_banner,
		'title'    => __( 'Banner', 'bloggingpro' ),
		'priority' => '50',
	);

	if ( ! empty( $upload_dir['basedir'] ) ) {
		$upldir = $upload_dir['basedir'] . '/' . $hm;

		if ( @file_exists( $upldir ) ) { // phpcs:ignore
			$fl = $upload_dir['basedir'] . '/' . $hm . '/' . $license . '.json';
			if ( @file_exists( $fl ) ) { // phpcs:ignore

				$section    = 'verytopads';
				$sections[] = array(
					'id'          => $section,
					'title'       => __( 'Very Top Banner', 'bloggingpro' ),
					'priority'    => 50,
					'panel'       => $panel_banner,
					'description' => __( 'Insert your banner before logo or very top location.', 'bloggingpro' ),
				);

				$options[ $gmrprefix . '_adsverytop' ] = array(
					'id'          => $gmrprefix . '_adsverytop',
					'label'       => __( 'HTML code.', 'bloggingpro' ),
					'section'     => $section,
					'type'        => 'textareajsallowed',
					'priority'    => 60,
					'description' => __( 'Please insert your html code, adsense code or other ads code here. This option support shortcode too.', 'bloggingpro' ),
				);

				$section    = 'topads';
				$sections[] = array(
					'id'          => $section,
					'title'       => __( 'Top Banner After Menu', 'bloggingpro' ),
					'priority'    => 50,
					'panel'       => $panel_banner,
					'description' => __( 'Insert your banner after menu.', 'bloggingpro' ),
				);

				$options[ $gmrprefix . '_adsaftermenu' ] = array(
					'id'          => $gmrprefix . '_adsaftermenu',
					'label'       => __( 'HTML code.', 'bloggingpro' ),
					'section'     => $section,
					'type'        => 'textareajsallowed',
					'priority'    => 60,
					'description' => __( 'Please insert your html code, adsense code or other ads code here. This option support shortcode too.', 'bloggingpro' ),
				);

				$section    = 'topadsmodule';
				$sections[] = array(
					'id'          => $section,
					'title'       => __( 'Top Banner After Module Home', 'bloggingpro' ),
					'priority'    => 50,
					'panel'       => $panel_banner,
					'description' => __( 'Insert your banner after module home.', 'bloggingpro' ),
				);

				$options[ $gmrprefix . '_adsaftermodulehome' ] = array(
					'id'          => $gmrprefix . '_adsaftermodulehome',
					'label'       => __( 'HTML code.', 'bloggingpro' ),
					'section'     => $section,
					'type'        => 'textareajsallowed',
					'priority'    => 60,
					'description' => __( 'Please insert your html code, adsense code or other ads code here. This option support shortcode too.', 'bloggingpro' ),
				);

				$section    = 'betweenpostads';
				$sections[] = array(
					'id'          => $section,
					'title'       => __( 'Banner Between Posts', 'bloggingpro' ),
					'priority'    => 50,
					'panel'       => $panel_banner,
					'description' => __( 'Insert your banner between post in archive page.', 'bloggingpro' ),
				);

				$options[ $gmrprefix . '_adsbetweenpost' ] = array(
					'id'          => $gmrprefix . '_adsbetweenpost',
					'label'       => __( 'HTML code.', 'bloggingpro' ),
					'section'     => $section,
					'type'        => 'textareajsallowed',
					'priority'    => 60,
					'description' => __( 'Please insert your html code, adsense code or other ads code here. This option support shortcode too.', 'bloggingpro' ),
				);

				$afterpostlocation                                 = array(
					'first'  => __( 'After First Post', 'bloggingpro' ),
					'second' => __( 'After Second Post', 'bloggingpro' ),
					'third'  => __( 'After Third Post', 'bloggingpro' ),
					'fourth' => __( 'After Fourth Post', 'bloggingpro' ),
				);
				$options[ $gmrprefix . '_adsbetweenpostposition' ] = array(
					'id'      => $gmrprefix . '_adsbetweenpostposition',
					'label'   => __( 'Banner Position', 'bloggingpro' ),
					'section' => $section,
					'type'    => 'radio',
					'choices' => $afterpostlocation,
					'default' => 'third',
				);

				$section    = 'beforecontentads';
				$sections[] = array(
					'id'          => $section,
					'title'       => __( 'Banner Before Content', 'bloggingpro' ),
					'priority'    => 50,
					'panel'       => $panel_banner,
					'description' => __( 'Insert your banner before single content.', 'bloggingpro' ),
				);

				$options[ $gmrprefix . '_adsbeforecontent' ] = array(
					'id'          => $gmrprefix . '_adsbeforecontent',
					'label'       => __( 'HTML code.', 'bloggingpro' ),
					'section'     => $section,
					'type'        => 'textareajsallowed',
					'priority'    => 60,
					'description' => __( 'Please insert your html code, adsense code or other ads code here. This option support shortcode too.', 'bloggingpro' ),
				);

				$locationbanner                                      = array(
					'default'    => __( 'Default', 'bloggingpro' ),
					'floatleft'  => __( 'Float Left', 'bloggingpro' ),
					'floatright' => __( 'Float Right', 'bloggingpro' ),
					'center'     => __( 'Center', 'bloggingpro' ),
				);
				$options[ $gmrprefix . '_adsbeforecontentposition' ] = array(
					'id'      => $gmrprefix . '_adsbeforecontentposition',
					'label'   => __( 'Banner Position', 'bloggingpro' ),
					'section' => $section,
					'type'    => 'radio',
					'choices' => $locationbanner,
					'default' => 'default',
				);

				$section    = 'insidecontentads';
				$sections[] = array(
					'id'          => $section,
					'title'       => __( 'Banner Inside Content After Inline Related', 'bloggingpro' ),
					'priority'    => 50,
					'panel'       => $panel_banner,
					'description' => __( 'Insert your banner inside content in single post. This options active if you activated inline related post.', 'bloggingpro' ),
				);

				$options[ $gmrprefix . '_adsinsidecontent' ] = array(
					'id'          => $gmrprefix . '_adsinsidecontent',
					'label'       => __( 'HTML code.', 'bloggingpro' ),
					'section'     => $section,
					'type'        => 'textareajsallowed',
					'priority'    => 60,
					'description' => __( 'Please insert your html code, adsense code or other ads code here. This option support shortcode too.', 'bloggingpro' ),
				);

				$locationbanner                                      = array(
					'left'   => __( 'Left', 'bloggingpro' ),
					'right'  => __( 'Right', 'bloggingpro' ),
					'center' => __( 'Center', 'bloggingpro' ),
				);
				$options[ $gmrprefix . '_adsinsidecontentposition' ] = array(
					'id'      => $gmrprefix . '_adsinsidecontentposition',
					'label'   => __( 'Banner Position', 'bloggingpro' ),
					'section' => $section,
					'type'    => 'radio',
					'choices' => $locationbanner,
					'default' => 'left',
				);

				$section    = 'aftercontentads';
				$sections[] = array(
					'id'          => $section,
					'title'       => __( 'Banner After Content', 'bloggingpro' ),
					'priority'    => 50,
					'panel'       => $panel_banner,
					'description' => __( 'Insert your banner after content in single post.', 'bloggingpro' ),
				);

				$options[ $gmrprefix . '_adsaftercontent' ] = array(
					'id'          => $gmrprefix . '_adsaftercontent',
					'label'       => __( 'HTML code.', 'bloggingpro' ),
					'section'     => $section,
					'type'        => 'textareajsallowed',
					'priority'    => 60,
					'description' => __( 'Please insert your html code, adsense code or other ads code here. This option support shortcode too.', 'bloggingpro' ),
				);

				$options[ $gmrprefix . '_adsaftercontentposition' ] = array(
					'id'      => $gmrprefix . '_adsaftercontentposition',
					'label'   => __( 'Banner Position', 'bloggingpro' ),
					'section' => $section,
					'type'    => 'radio',
					'choices' => $locationbanner,
					'default' => 'left',
				);

				$section    = 'afterrelpostads';
				$sections[] = array(
					'id'          => $section,
					'title'       => __( 'Banner After Related Posts', 'bloggingpro' ),
					'priority'    => 50,
					'panel'       => $panel_banner,
					'description' => __( 'Insert your banner after related posts in single post.', 'bloggingpro' ),
				);

				$options[ $gmrprefix . '_adsafterrelpost' ] = array(
					'id'          => $gmrprefix . '_adsafterrelpost',
					'label'       => __( 'HTML code.', 'bloggingpro' ),
					'section'     => $section,
					'type'        => 'textareajsallowed',
					'priority'    => 60,
					'description' => __( 'Please insert your html code, adsense code or other ads code here. This option support shortcode too.', 'bloggingpro' ),
				);

				$options[ $gmrprefix . '_adsafterrelpostposition' ] = array(
					'id'      => $gmrprefix . '_adsafterrelpostposition',
					'label'   => __( 'Banner Position', 'bloggingpro' ),
					'section' => $section,
					'type'    => 'radio',
					'choices' => $locationbanner,
					'default' => 'left',
				);

				$section    = 'floatleftads';
				$sections[] = array(
					'id'          => $section,
					'title'       => __( 'Floating Left Ads', 'bloggingpro' ),
					'priority'    => 50,
					'panel'       => $panel_banner,
					'description' => __( 'Insert your banner floating left in all page.', 'bloggingpro' ),
				);

				$options[ $gmrprefix . '_adsfloatleft' ] = array(
					'id'          => $gmrprefix . '_adsfloatleft',
					'label'       => __( 'HTML code.', 'bloggingpro' ),
					'section'     => $section,
					'type'        => 'textareajsallowed',
					'priority'    => 60,
					'description' => __( 'Please insert your html code, adsense code or other ads code here. This option support shortcode too.', 'bloggingpro' ),
				);

				$section    = 'floatrightads';
				$sections[] = array(
					'id'          => $section,
					'title'       => __( 'Floating Right Ads', 'bloggingpro' ),
					'priority'    => 50,
					'panel'       => $panel_banner,
					'description' => __( 'Insert your banner floating right in all page.', 'bloggingpro' ),
				);

				$options[ $gmrprefix . '_adsfloatright' ] = array(
					'id'          => $gmrprefix . '_adsfloatright',
					'label'       => __( 'HTML code.', 'bloggingpro' ),
					'section'     => $section,
					'type'        => 'textareajsallowed',
					'priority'    => 60,
					'description' => __( 'Please insert your html code, adsense code or other ads code here. This option support shortcode too.', 'bloggingpro' ),
				);

				$section                                   = 'floatbottomads';
				$sections[]                                = array(
					'id'          => $section,
					'title'       => __( 'Floating Bottom Ads', 'bloggingpro' ),
					'priority'    => 50,
					'panel'       => $panel_banner,
					'description' => __( 'Insert your banner floating bottom in all page.', 'bloggingpro' ),
				);
				$options[ $gmrprefix . '_adsfloatbottom' ] = array(
					'id'          => $gmrprefix . '_adsfloatbottom',
					'label'       => __( 'HTML code.', 'bloggingpro' ),
					'section'     => $section,
					'type'        => 'textareajsallowed',
					'priority'    => 60,
					'description' => __( 'Please insert your html code, adsense code or other ads code here. This option support shortcode too.', 'bloggingpro' ),
				);

				$section    = 'footerads';
				$sections[] = array(
					'id'          => $section,
					'title'       => __( 'Footer Banner Before Widget', 'bloggingpro' ),
					'priority'    => 50,
					'panel'       => $panel_banner,
					'description' => __( 'Insert your banner in footer before widget footer or copyright.', 'bloggingpro' ),
				);

				$options[ $gmrprefix . '_adsfooter' ] = array(
					'id'          => $gmrprefix . '_adsfooter',
					'label'       => __( 'HTML code.', 'bloggingpro' ),
					'section'     => $section,
					'type'        => 'textareajsallowed',
					'priority'    => 60,
					'description' => __( 'Please insert your html code, adsense code or other ads code here. This option support shortcode too.', 'bloggingpro' ),
				);

			} else {
				$section                                     = 'BannerLicense';
				$sections[]                                  = array(
					'id'       => $section,
					'title'    => __( 'Insert License Key', 'bloggingpro' ),
					'priority' => 50,
					'panel'    => $panel_banner,
				);
				$options[ $gmrprefix . '_licensekeybanner' ] = array(
					'id'          => $gmrprefix . '_licensekeybanner',
					'label'       => __( 'Insert License Key', 'bloggingpro' ),
					'section'     => $section,
					'type'        => 'content',
					'priority'    => 60,
					'description' => __( '<a href="plugins.php?page=bloggingpro-license" style="font-weight: 700;">Please insert your own license key here</a>.<br /><br /> If you bought from kentooz, you can get license key in your memberarea. <a href="http://member.kentooz.com/softsale/license" target="_blank">http://member.kentooz.com/softsale/license</a>', 'bloggingpro' ),
				);
			}
		} else {
			$section                                     = 'BannerLicense';
			$sections[]                                  = array(
				'id'       => $section,
				'title'    => __( 'Insert License Key', 'bloggingpro' ),
				'priority' => 50,
				'panel'    => $panel_banner,
			);
			$options[ $gmrprefix . '_licensekeybanner' ] = array(
				'id'          => $gmrprefix . '_licensekeybanner',
				'label'       => __( 'Insert License Key', 'bloggingpro' ),
				'section'     => $section,
				'type'        => 'content',
				'priority'    => 60,
				'description' => __( '<a href="plugins.php?page=bloggingpro-license" style="font-weight: 700;">Please insert your own license key here</a>.<br /><br /> If you bought from kentooz, you can get license key in your memberarea. <a href="http://member.kentooz.com/softsale/license" target="_blank">http://member.kentooz.com/softsale/license</a>', 'bloggingpro' ),
			);
		}
	}

	/*
	 * Color Section Options
	 *
	 * @since v.1.0.0
	 */
	$panel_color = 'panel-color';
	$panels[]    = array(
		'id'       => $panel_color,
		'title'    => __( 'Color', 'bloggingpro' ),
		'priority' => '50',
	);

	/* Colors */
	$section    = 'colors';
	$sections[] = array(
		'id'       => $section,
		'title'    => __( 'General Colors', 'bloggingpro' ),
		'panel'    => $panel_color,
		'priority' => 40,
	);

	$options[ $gmrprefix . '_scheme-color' ] = array(
		'id'      => $gmrprefix . '_scheme-color',
		'label'   => __( 'Base Color Scheme', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'color',
		'default' => $color_scheme,
	);

	$options[ $gmrprefix . '_general-linkcolor' ] = array(
		'id'      => $gmrprefix . '_general-linkcolor',
		'label'   => __( 'General Link Color', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'color',
		'default' => $general_linkcolor,
	);

	$options[ $gmrprefix . '_single-linkcolor' ] = array(
		'id'      => $gmrprefix . '_single-linkcolor',
		'label'   => __( 'Content Link Color In Single', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'color',
		'default' => $single_linkcolor,
	);

	$options[ $gmrprefix . '_body-color' ] = array(
		'id'      => $gmrprefix . '_body-color',
		'label'   => __( 'Content Color', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'color',
		'default' => $bodycolor,
	);

	$options[ $gmrprefix . '_chrome_mobile_color' ] = array(
		'id'      => $gmrprefix . '_chrome_mobile_color',
		'label'   => __( 'Color In Chrome Mobile', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'color',
		'default' => '',
	);

	$section    = 'header_color';
	$sections[] = array(
		'id'          => $section,
		'title'       => __( 'Header Color', 'bloggingpro' ),
		'priority'    => 40,
		'panel'       => $panel_color,
		'description' => __( 'Allow you customize header color style.', 'bloggingpro' ),
	);

	$options[ $gmrprefix . '_header-bgcolor' ] = array(
		'id'      => $gmrprefix . '_header-bgcolor',
		'label'   => __( 'Background Color - Header', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'color',
		'default' => $header_bgcolor,
	);

	$options[ $gmrprefix . '_sitetitle-color' ] = array(
		'id'      => $gmrprefix . '_sitetitle-color',
		'label'   => __( 'Site title color', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'color',
		'default' => $sitetitle_color,
	);

	$options[ $gmrprefix . '_sitedesc-color' ] = array(
		'id'      => $gmrprefix . '_sitedesc-color',
		'label'   => __( 'Site description color', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'color',
		'default' => $sitedesc_color,
	);

	$section    = 'menu_color';
	$sections[] = array(
		'id'          => $section,
		'title'       => __( 'Menu Color', 'bloggingpro' ),
		'priority'    => 40,
		'panel'       => $panel_color,
		'description' => __( 'Allow you customize menu color style.', 'bloggingpro' ),
	);

	$options[ $gmrprefix . '_mainmenu-bgcolor' ] = array(
		'id'      => $gmrprefix . '_mainmenu-bgcolor',
		'label'   => __( 'Background Menu', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'color',
		'default' => $menu_bgcolor,
	);

	$options[ $gmrprefix . '_mainmenu-color' ] = array(
		'id'      => $gmrprefix . '_mainmenu-color',
		'label'   => __( 'Text color - Menu', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'color',
		'default' => $menu_color,
	);

	$options[ $gmrprefix . '_hovermenu-color' ] = array(
		'id'      => $gmrprefix . '_hovermenu-color',
		'label'   => __( 'Text hover color - Menu', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'color',
		'default' => $menu_hovercolor,
	);

	$options[ $gmrprefix . '_secondmenu-color' ] = array(
		'id'      => $gmrprefix . '_secondmenu-color',
		'label'   => __( 'Text color - Secondary Menu', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'color',
		'default' => $secondmenu_color,
	);

	$options[ $gmrprefix . '_hoversecondmenu-color' ] = array(
		'id'      => $gmrprefix . '_hoversecondmenu-color',
		'label'   => __( 'Text hover color - Secondary Menu', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'color',
		'default' => $secondmenu_hovercolor,
	);

	$section    = 'footer_color';
	$sections[] = array(
		'id'          => $section,
		'title'       => __( 'Footer Color', 'bloggingpro' ),
		'priority'    => 60,
		'panel'       => $panel_color,
		'description' => __( 'Allow you customize footer color style.', 'bloggingpro' ),
	);

	$options[ $gmrprefix . '_footer-bgcolor' ] = array(
		'id'      => $gmrprefix . '_footer-bgcolor',
		'label'   => __( 'Background Color - Footer', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'color',
		'default' => $footer_bgcolor,
	);

	$options[ $gmrprefix . '_footer-fontcolor' ] = array(
		'id'      => $gmrprefix . '_footer-fontcolor',
		'label'   => __( 'Font Color - Footer', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'color',
		'default' => $footer_fontcolor,
	);

	$options[ $gmrprefix . '_footer-linkcolor' ] = array(
		'id'      => $gmrprefix . '_footer-linkcolor',
		'label'   => __( 'Link Color - Footer', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'color',
		'default' => $footer_linkcolor,
	);

	$options[ $gmrprefix . '_footer-hoverlinkcolor' ] = array(
		'id'      => $gmrprefix . '_footer-hoverlinkcolor',
		'label'   => __( 'Hover Link Color - Footer', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'color',
		'default' => $footer_hoverlinkcolor,
	);

	/*
	 * Footer Section Options
	 *
	 * @since v.1.0.0
	 */
	$panel_footer = 'panel-footer';
	$panels[]     = array(
		'id'       => $panel_footer,
		'title'    => __( 'Footer', 'bloggingpro' ),
		'priority' => '50',
	);

	$section    = 'widget_section';
	$sections[] = array(
		'id'          => $section,
		'title'       => __( 'Widgets Footer', 'bloggingpro' ),
		'priority'    => 50,
		'panel'       => $panel_footer,
		'description' => __( 'Footer widget columns.', 'bloggingpro' ),
	);

	$columns = array(
		'1' => __( '1 Column', 'bloggingpro' ),
		'2' => __( '2 Columns', 'bloggingpro' ),
		'3' => __( '3 Columns', 'bloggingpro' ),
		'4' => __( '4 Columns', 'bloggingpro' ),
	);

	$options[ $gmrprefix . '_footer_column' ] = array(
		'id'      => $gmrprefix . '_footer_column',
		'label'   => __( 'Widgets Footer', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'radio',
		'choices' => $columns,
		'default' => '3',
	);

	$section    = 'social_section';
	$sections[] = array(
		'id'          => $section,
		'title'       => __( 'Social Footer', 'bloggingpro' ),
		'priority'    => 50,
		'panel'       => $panel_footer,
		'description' => __( 'Social Footer.', 'bloggingpro' ),
	);

	$options[ $gmrprefix . '_active-socialnetwork' ] = array(
		'id'      => $gmrprefix . '_active-socialnetwork',
		'label'   => __( 'Disable social in footer', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'checkbox',
		'default' => 0,
	);

	$options[ $gmrprefix . '_active-rssicon' ] = array(
		'id'      => $gmrprefix . '_active-rssicon',
		'label'   => __( 'Disable RSS icon in social', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'checkbox',
		'default' => 0,
	);

	$options[ $gmrprefix . '_fb_url_icon' ] = array(
		'id'          => $gmrprefix . '_fb_url_icon',
		'label'       => __( 'FB Url', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'bloggingpro' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_twitter_url_icon' ] = array(
		'id'          => $gmrprefix . '_twitter_url_icon',
		'label'       => __( 'Twitter Url', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'bloggingpro' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_pinterest_url_icon' ] = array(
		'id'          => $gmrprefix . '_pinterest_url_icon',
		'label'       => __( 'Pinterest Url', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'bloggingpro' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_tumblr_url_icon' ] = array(
		'id'          => $gmrprefix . '_tumblr_url_icon',
		'label'       => __( 'Tumblr Url', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'bloggingpro' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_stumbleupon_url_icon' ] = array(
		'id'          => $gmrprefix . '_stumbleupon_url_icon',
		'label'       => __( 'Stumbleupon Url', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'bloggingpro' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_wordpress_url_icon' ] = array(
		'id'          => $gmrprefix . '_wordpress_url_icon',
		'label'       => __( 'Wordpress Url', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'bloggingpro' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_instagram_url_icon' ] = array(
		'id'          => $gmrprefix . '_instagram_url_icon',
		'label'       => __( 'Instagram Url', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'bloggingpro' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_dribbble_url_icon' ] = array(
		'id'          => $gmrprefix . '_dribbble_url_icon',
		'label'       => __( 'Dribbble Url', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'bloggingpro' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_vimeo_url_icon' ] = array(
		'id'          => $gmrprefix . '_vimeo_url_icon',
		'label'       => __( 'Vimeo Url', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'bloggingpro' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_linkedin_url_icon' ] = array(
		'id'          => $gmrprefix . '_linkedin_url_icon',
		'label'       => __( 'Linkedin Url', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'bloggingpro' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_deviantart_url_icon' ] = array(
		'id'          => $gmrprefix . '_deviantart_url_icon',
		'label'       => __( 'Deviantart Url', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'bloggingpro' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_myspace_url_icon' ] = array(
		'id'          => $gmrprefix . '_myspace_url_icon',
		'label'       => __( 'Myspace Url', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'bloggingpro' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_skype_url_icon' ] = array(
		'id'          => $gmrprefix . '_skype_url_icon',
		'label'       => __( 'Skype Url', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'bloggingpro' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_youtube_url_icon' ] = array(
		'id'          => $gmrprefix . '_youtube_url_icon',
		'label'       => __( 'Youtube Url', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'bloggingpro' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_picassa_url_icon' ] = array(
		'id'          => $gmrprefix . '_picassa_url_icon',
		'label'       => __( 'Picassa Url', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'bloggingpro' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_flickr_url_icon' ] = array(
		'id'          => $gmrprefix . '_flickr_url_icon',
		'label'       => __( 'Flickr Url', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'bloggingpro' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_blogger_url_icon' ] = array(
		'id'          => $gmrprefix . '_blogger_url_icon',
		'label'       => __( 'Blogger Url', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'bloggingpro' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_spotify_url_icon' ] = array(
		'id'          => $gmrprefix . '_spotify_url_icon',
		'label'       => __( 'Spotify Url', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'bloggingpro' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_delicious_url_icon' ] = array(
		'id'          => $gmrprefix . '_delicious_url_icon',
		'label'       => __( 'Delicious Url', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'bloggingpro' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_tiktok_url_icon' ] = array(
		'id'          => $gmrprefix . '_tiktok_url_icon',
		'label'       => __( 'Tiktok Url', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'bloggingpro' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_telegram_url_icon' ] = array(
		'id'          => $gmrprefix . '_telegram_url_icon',
		'label'       => __( 'Telegram Url', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'bloggingpro' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_soundcloud_url_icon' ] = array(
		'id'          => $gmrprefix . '_soundcloud_url_icon',
		'label'       => __( 'Soundcloud Url', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'bloggingpro' ),
		'priority'    => 90,
	);

	$section    = 'copyright_section';
	$sections[] = array(
		'id'       => $section,
		'title'    => __( 'Copyright & Other Footer', 'bloggingpro' ),
		'priority' => 60,
		'panel'    => $panel_footer,
	);
	if ( ! empty( $upload_dir['basedir'] ) ) {
		$upldir = $upload_dir['basedir'] . '/' . $hm;

		if ( @file_exists( $upldir ) ) { // phpcs:ignore
			$fl = $upload_dir['basedir'] . '/' . $hm . '/' . $license . '.json';
			if ( @file_exists( $fl ) ) { // phpcs:ignore
				$options[ $gmrprefix . '_copyright' ] = array(
					'id'          => $gmrprefix . '_copyright',
					'label'       => __( 'Footer Copyright.', 'bloggingpro' ),
					'section'     => $section,
					'type'        => 'textarea',
					'description' => __( 'Display your own copyright text in footer.', 'bloggingpro' ),
				);
			} else {
				$section                                        = 'CopyrightLicense';
				$sections[]                                     = array(
					'id'       => $section,
					'title'    => __( 'Insert License Key', 'bloggingpro' ),
					'priority' => 50,
					'panel'    => $panel_footer,
				);
				$options[ $gmrprefix . '_licensekeycopyright' ] = array(
					'id'          => $gmrprefix . '_licensekeycopyright',
					'label'       => __( 'Insert License Key', 'bloggingpro' ),
					'section'     => $section,
					'type'        => 'content',
					'priority'    => 60,
					'description' => __( '<a href="plugins.php?page=bloggingpro-license" style="font-weight: 700;">Please insert your own license key here</a>.<br /><br /> If you bought from kentooz, you can get license key in your memberarea. <a href="http://member.kentooz.com/softsale/license" target="_blank">http://member.kentooz.com/softsale/license</a>', 'bloggingpro' ),
				);
			}
		} else {
			$section                                        = 'CopyrightLicense';
			$sections[]                                     = array(
				'id'       => $section,
				'title'    => __( 'Insert License Key', 'bloggingpro' ),
				'priority' => 50,
				'panel'    => $panel_footer,
			);
			$options[ $gmrprefix . '_licensekeycopyright' ] = array(
				'id'          => $gmrprefix . '_licensekeycopyright',
				'label'       => __( 'Insert License Key', 'bloggingpro' ),
				'section'     => $section,
				'type'        => 'content',
				'priority'    => 60,
				'description' => __( '<a href="plugins.php?page=bloggingpro-license" style="font-weight: 700;">Please insert your own license key here</a>.<br /><br /> If you bought from kentooz, you can get license key in your memberarea. <a href="http://member.kentooz.com/softsale/license" target="_blank">http://member.kentooz.com/softsale/license</a>', 'bloggingpro' ),
			);
		}
	}
	$options[ $gmrprefix . '_footer_logo' ] = array(
		'id'      => $gmrprefix . '_footer_logo',
		'label'   => __( 'Footer Logo', 'bloggingpro' ),
		'section' => $section,
		'type'    => 'image',
		'default' => $default_logo,
	);

	/*
	 * Other Section Options
	 *
	 * @since v.1.0.0
	 */
	$panel_other = 'panel-other';
	$panels[]    = array(
		'id'       => $panel_other,
		'title'    => __( 'Other', 'bloggingpro' ),
		'priority' => '50',
	);

	$section    = 'head_script';
	$sections[] = array(
		'id'          => $section,
		'title'       => __( 'Head Script', 'bloggingpro' ),
		'priority'    => 60,
		'panel'       => $panel_other,
		'description' => __( 'Allow you add script inside &lt;head&gt;&lt;/head&gt;.', 'bloggingpro' ),
	);

	$options[ $gmrprefix . '_head_script' ] = array(
		'id'          => $gmrprefix . '_head_script',
		'label'       => __( 'HTML code.', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'textareajsallowed',
		'priority'    => 60,
		'description' => __( 'Please insert your code here.', 'bloggingpro' ),
	);

	$section    = 'footer_script';
	$sections[] = array(
		'id'          => $section,
		'title'       => __( 'Footer Script', 'bloggingpro' ),
		'priority'    => 60,
		'panel'       => $panel_other,
		'description' => __( 'Allow you add script before &lt;/body&gt;.', 'bloggingpro' ),
	);

	$options[ $gmrprefix . '_footer_script' ] = array(
		'id'          => $gmrprefix . '_footer_script',
		'label'       => __( 'HTML code.', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'textareajsallowed',
		'priority'    => 60,
		'description' => __( 'Please insert your code here.', 'bloggingpro' ),
	);

	$section    = 'analytic_script';
	$sections[] = array(
		'id'          => $section,
		'title'       => __( 'Analytic & Pixel', 'bloggingpro' ),
		'priority'    => 60,
		'panel'       => $panel_other,
		'description' => __( 'Allow you add google analytic and facebook pixel.', 'bloggingpro' ),
	);

	$options[ $gmrprefix . '_analytic' ] = array(
		'id'          => $gmrprefix . '_analytic',
		'label'       => __( 'Google Analytics ID', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'text',
		'description' => __( 'Enter your Google Analytics ID (Ex: UA-XXXXX-X).', 'bloggingpro' ),
	);

	$options[ $gmrprefix . '_pixel' ] = array(
		'id'          => $gmrprefix . '_pixel',
		'label'       => __( 'Facebook Pixel ID', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'text',
		'description' => __( 'Enter your Facebook Pixel ID.', 'bloggingpro' ),
	);

	$section    = 'other_other';
	$sections[] = array(
		'id'          => $section,
		'title'       => __( 'Other Settings', 'bloggingpro' ),
		'priority'    => 60,
		'panel'       => $panel_other,
		'description' => __( 'Other Settings.', 'bloggingpro' ),
	);

	$enable_disable = array(
		'enable'  => __( 'Enable', 'bloggingpro' ),
		'disable' => __( 'Disable', 'bloggingpro' ),
	);

	$options[ $gmrprefix . '_remove_emoji_script' ] = array(
		'id'          => $gmrprefix . '_remove_emoji_script',
		'label'       => __( 'Remove Emoji Script', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'radio',
		'choices'     => $enable_disable,
		'default'     => 'disable',
		'description' => __( 'Enable this if you want remove emoji script from &lt;head&gt; section. This can improve your web performance.', 'bloggingpro' ),
	);

	$options[ $gmrprefix . '_wp_head_tag' ] = array(
		'id'          => $gmrprefix . '_wp_head_tag',
		'label'       => __( 'Remove WP Head Meta Tag', 'bloggingpro' ),
		'section'     => $section,
		'type'        => 'radio',
		'choices'     => $enable_disable,
		'default'     => 'disable',
		'description' => __( 'Enable this if you want remove wp head meta tag, if this conflict with some plugin please do not activated. This option can remove wp meta tag generator, rds, wlwmanifest, feed links, shortlink, comments feed so your head tag look simple and hope can fast your index.', 'bloggingpro' ),
	);

	/*
	 * Call if only woocommerce actived
	 *
	 * @since v.1.0.0
	 */
	if ( class_exists( 'WooCommerce' ) ) {

		$panel_woo = 'woocommerce';
		$panels[]  = array(
			'id'       => $panel_woo,
			'title'    => __( 'WooCommerce', 'bloggingpro' ),
			'priority' => '200',
		);

		/* Woocommerce options */
		$section    = 'woocommerce_layout';
		$sections[] = array(
			'id'       => $section,
			'title'    => __( 'Layout Settings', 'bloggingpro' ),
			'panel'    => $panel_woo,
			'priority' => 100,
		);

		$sidebar = array(
			'sidebar'   => __( 'Sidebar', 'bloggingpro' ),
			'fullwidth' => __( 'Fullwidth', 'bloggingpro' ),
		);

		$options[ $gmrprefix . '_wc_sidebar' ] = array(
			'id'      => $gmrprefix . '_wc_sidebar',
			'label'   => __( 'Woocommerce Sidebar', 'bloggingpro' ),
			'section' => $section,
			'type'    => 'radio',
			'choices' => $sidebar,
			'default' => 'sidebar',
		);

		$options[ $gmrprefix . '_active-cartbutton' ] = array(
			'id'      => $gmrprefix . '_active-cartbutton',
			'label'   => __( 'Remove Cart button from menu', 'bloggingpro' ),
			'section' => $section,
			'type'    => 'checkbox',
			'default' => 0,
		);

	}

	/*
	 * Call AMP exist
	 *
	 * @since v.1.0.0
	 */
	if ( function_exists( 'is_amp_endpoint' ) ) {
		$panel_amp = 'amppanel';
		$panels[]  = array(
			'id'       => $panel_amp,
			'title'    => __( 'AMP (New)', 'bloggingpro' ),
			'priority' => '200',
		);

		$section    = 'head_script_amp';
		$sections[] = array(
			'id'          => $section,
			'title'       => __( 'Head Script (AMP)', 'bloggingpro' ),
			'priority'    => 50,
			'panel'       => $panel_amp,
			'description' => __( 'You can insert amp page level adsense here or other amp script. Learn more here: https://amp.dev/documentation/components/amp-ad/. These scripts will be printed in the &lt;head&gt;&lt;/head&gt; section.', 'bloggingpro' ),
		);

		$options[ $gmrprefix . '_head_script_amp' ] = array(
			'id'       => $gmrprefix . '_head_script_amp',
			'label'    => __( 'Ads code.', 'bloggingpro' ),
			'section'  => $section,
			'type'     => 'textareajsallowed',
			'priority' => 60,
		);

		$section    = 'footer_script_amp';
		$sections[] = array(
			'id'          => $section,
			'title'       => __( 'Footer Script (AMP)', 'bloggingpro' ),
			'priority'    => 50,
			'panel'       => $panel_amp,
			'description' => __( 'You can insert amp script here. These scripts will be printed before &lt;/body&gt; in amp page.', 'bloggingpro' ),
		);

		$options[ $gmrprefix . '_footer_script_amp' ] = array(
			'id'       => $gmrprefix . '_footer_script_amp',
			'label'    => __( 'AMP code.', 'bloggingpro' ),
			'section'  => $section,
			'type'     => 'textareajsallowed',
			'priority' => 60,
		);

		$section    = 'topadsamp';
		$sections[] = array(
			'id'          => $section,
			'title'       => __( 'Top Banner After Menu (AMP)', 'bloggingpro' ),
			'priority'    => 50,
			'panel'       => $panel_amp,
			'description' => __( 'Display amp ads after menu. Learn more here: https://amp.dev/documentation/components/amp-ad/', 'bloggingpro' ),
		);

		$options[ $gmrprefix . '_adsaftermenu_amp' ] = array(
			'id'       => $gmrprefix . '_adsaftermenu_amp',
			'label'    => __( 'Ads code.', 'bloggingpro' ),
			'section'  => $section,
			'type'     => 'textareajsallowed',
			'priority' => 60,
		);

		$section    = 'betweenpostadsamp';
		$sections[] = array(
			'id'          => $section,
			'title'       => __( 'Banner Between Posts (AMP)', 'bloggingpro' ),
			'priority'    => 50,
			'panel'       => $panel_amp,
			'description' => __( 'Display amp ads between post in index and archive page. Learn more here: https://amp.dev/documentation/components/amp-ad/.', 'bloggingpro' ),
		);

		$options[ $gmrprefix . '_adsbetweenpost_amp' ] = array(
			'id'       => $gmrprefix . '_adsbetweenpost_amp',
			'label'    => __( 'Ads code.', 'bloggingpro' ),
			'section'  => $section,
			'type'     => 'textareajsallowed',
			'priority' => 60,
		);

		$afterpostlocationamp                                  = array(
			'first'  => __( 'After First Post', 'bloggingpro' ),
			'second' => __( 'After Second Post', 'bloggingpro' ),
			'third'  => __( 'After Third Post', 'bloggingpro' ),
			'fourth' => __( 'After Fourth Post', 'bloggingpro' ),
		);
		$options[ $gmrprefix . '_adsbetweenpostposition_amp' ] = array(
			'id'      => $gmrprefix . '_adsbetweenpostposition_amp',
			'label'   => __( 'Banner Position', 'bloggingpro' ),
			'section' => $section,
			'type'    => 'radio',
			'choices' => $afterpostlocationamp,
			'default' => 'third',
		);

		$section    = 'beforecontentadsamp';
		$sections[] = array(
			'id'          => $section,
			'title'       => __( 'Banner Before Content (AMP)', 'bloggingpro' ),
			'priority'    => 50,
			'panel'       => $panel_amp,
			'description' => __( 'Display amp ads before single content. Learn more here: https://amp.dev/documentation/components/amp-ad/.', 'bloggingpro' ),
		);

		$options[ $gmrprefix . '_adsbeforecontent_amp' ] = array(
			'id'       => $gmrprefix . '_adsbeforecontent_amp',
			'label'    => __( 'Ads code.', 'bloggingpro' ),
			'section'  => $section,
			'type'     => 'textareajsallowed',
			'priority' => 60,
		);

		$section    = 'insidecontentadsamp';
		$sections[] = array(
			'id'          => $section,
			'title'       => __( 'Banner Inside Content After Inline Related (AMP)', 'bloggingpro' ),
			'priority'    => 50,
			'panel'       => $panel_amp,
			'description' => __( 'Display amp ads inside paragraph single content. Learn more here: https://amp.dev/documentation/components/amp-ad/. This options active if you activated inline related post.', 'bloggingpro' ),
		);

		$options[ $gmrprefix . '_adsinsidecontent_amp' ] = array(
			'id'       => $gmrprefix . '_adsinsidecontent_amp',
			'label'    => __( 'Ads code.', 'bloggingpro' ),
			'section'  => $section,
			'type'     => 'textareajsallowed',
			'priority' => 60,
		);

		$section    = 'aftercontentadsamp';
		$sections[] = array(
			'id'          => $section,
			'title'       => __( 'Banner After Content (AMP)', 'bloggingpro' ),
			'priority'    => 50,
			'panel'       => $panel_amp,
			'description' => __( 'Display amp ads after single content. Learn more here: https://amp.dev/documentation/components/amp-ad/.', 'bloggingpro' ),
		);

		$options[ $gmrprefix . '_adsaftercontent_amp' ] = array(
			'id'       => $gmrprefix . '_adsaftercontent_amp',
			'label'    => __( 'Ads code.', 'bloggingpro' ),
			'section'  => $section,
			'type'     => 'textareajsallowed',
			'priority' => 60,
		);

		$section    = 'afterrelpostadsamp';
		$sections[] = array(
			'id'          => $section,
			'title'       => __( 'Banner After Related Posts (AMP)', 'bloggingpro' ),
			'priority'    => 50,
			'panel'       => $panel_amp,
			'description' => __( 'Display amp ads after related post in single. Learn more here: https://amp.dev/documentation/components/amp-ad/.', 'bloggingpro' ),
		);

		$options[ $gmrprefix . '_adsafterrelpost_amp' ] = array(
			'id'       => $gmrprefix . '_adsafterrelpost_amp',
			'label'    => __( 'Ads code.', 'bloggingpro' ),
			'section'  => $section,
			'type'     => 'textareajsallowed',
			'priority' => 60,
		);

	}

	/* Adds the sections to the $options array */
	$options['sections'] = $sections;

	/* Adds the panels to the $options array */
	$options['panels']  = $panels;
	$customizer_library = Customizer_Library::Instance();
	$customizer_library->add_options( $options );
	/* To delete custom mods use: customizer_library_remove_theme_mods(); */
}
add_action( 'init', 'gmr_library_options_customizer' );

if ( ! function_exists( 'gmr_library_customizer_build_styles' ) && class_exists( 'Customizer_Library_Styles' ) ) :
	/**
	 * Process user options to generate CSS needed to implement the choices.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function gmr_library_customizer_build_styles() {

		/* Color scheme */
		$setting = 'gmr_scheme-color';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		if ( $mod ) {
			$color = sanitize_hex_color( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'kbd',
						'a.button',
						'button',
						'.button',
						'button.button',
						'input[type="button"]',
						'input[type="reset"]',
						'input[type="submit"]',
						'.tagcloud a',
						'ul.page-numbers li a.prev.page-numbers',
						'ul.page-numbers li a.next.page-numbers',
						'ul.page-numbers li span.page-numbers',
						'.page-links > .page-link-number',
						'.cat-links ul li a',
						'.entry-footer .tag-text',
						'.gmr-recentposts-widget li.listpost-gallery .gmr-rp-content .gmr-metacontent .cat-links-content a',
						'.page-links > .post-page-numbers.current span',
						'ol.comment-list li div.reply a',
						'#cancel-comment-reply-link',
						'.entry-footer .tags-links a:hover',
						'.gmr-topnotification',
					),
					'declarations' => array(
						'background-color' => $color,
					),
				)
			);

			if ( class_exists( 'WooCommerce' ) ) {

				$color = sanitize_hex_color( $mod );
				Customizer_Library_Styles()->add(
					array(
						'selectors'    => array(
							'.woocommerce #respond input#submit',
							'.woocommerce a.button',
							'.woocommerce button.button',
							'.woocommerce input.button',
							'.woocommerce #respond input#submit.alt',
							'.woocommerce a.button.alt',
							'.woocommerce button.button.alt',
							'.woocommerce input.button.alt',
						),
						'declarations' => array(
							'background-color' => $color . ' !important',
						),
					)
				);
			}

			$color = sanitize_hex_color( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'#primary-menu > li ul .current-menu-item > a',
						'#primary-menu .sub-menu > li:hover > a',
						'.cat-links-content a',
						'.tagcloud li:before',
						'a:hover',
						'a:focus',
						'a:active',
						'.gmr-ontop:hover path',
						'#navigationamp button.close-topnavmenu-wrap',
						'.sidr a#sidr-id-close-topnavmenu-button',
						'.sidr-class-menu-item i._mi',
						'.sidr-class-menu-item img._mi',
						'.text-marquee',
					),
					'declarations' => array(
						'color' => $color,
					),
				)
			);

			$color = sanitize_hex_color( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'.widget-title:after',
						'a.button',
						'button',
						'.button',
						'button.button',
						'input[type="button"]',
						'input[type="reset"]',
						'input[type="submit"]',
						'.tagcloud a',
						'.sticky .gmr-box-content',
						'.bypostauthor > .comment-body',
						'.gmr-ajax-loader div:nth-child(1)',
						'.gmr-ajax-loader div:nth-child(2)',
						'.entry-footer .tags-links a:hover',
					),
					'declarations' => array(
						'border-color' => $color,
					),
				)
			);
		}

		/* General Link scheme */
		$setting = 'gmr_general-linkcolor';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		if ( $mod ) {
			$color = sanitize_hex_color( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'a',
						'.gmr-ontop path',
					),
					'declarations' => array(
						'color' => $color,
					),
				)
			);
		}

		/* Single Link scheme */
		$setting = 'gmr_single-linkcolor';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		if ( $mod ) {
			$color = sanitize_hex_color( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'.entry-content-single p a',
					),
					'declarations' => array(
						'color' => $color,
					),
				)
			);
		}

		/* Content Color */
		$setting = 'gmr_body-color';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		if ( $mod ) {
			$color = sanitize_hex_color( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'body',
					),
					'declarations' => array(
						'color' => $color,
					),
				)
			);
		}

		/* Header Background image */
		$url     = has_header_image() ? get_header_image() : get_theme_support( 'custom-header', 'default-image' );
		$setting = 'gmr_active-headerimage';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );
		if ( 0 === $mod ) {
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'.site-header',
					),
					'declarations' => array(
						'background-image' => 'url(' . $url . ')',
					),
				)
			);
		}

		/* Header Background Size */
		$setting = 'gmr_headerimage_bgsize';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );
		if ( $mod ) {
			$bgsize = wp_filter_nohtml_kses( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'.site-header',
					),
					'declarations' => array(
						'-webkit-background-size' => $bgsize,
						'-moz-background-size'    => $bgsize,
						'-o-background-size'      => $bgsize,
						'background-size'         => $bgsize,
					),
				)
			);
		}

		/* Header Background Repeat */
		$setting = 'gmr_headerimage_bgrepeat';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );
		if ( $mod ) {
			$bgrepeat = wp_filter_nohtml_kses( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'.site-header',
					),
					'declarations' => array(
						'background-repeat' => $bgrepeat,
					),
				)
			);
		}

		/* Header Background Position */
		$setting = 'gmr_headerimage_bgposition';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );
		if ( $mod ) {
			$bgposition = wp_filter_nohtml_kses( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'.site-header',
					),
					'declarations' => array(
						'background-position' => $bgposition,
					),
				)
			);
		}

		/* Header Background Position */
		$setting = 'gmr_headerimage_bgattachment';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );
		if ( $mod ) {
			$bgattachment = wp_filter_nohtml_kses( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'.site-header',
					),
					'declarations' => array(
						'background-attachment' => $bgattachment,
					),
				)
			);
		}

		/* Header Background Color */
		$setting = 'gmr_header-bgcolor';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		if ( $mod ) {
			$color = sanitize_hex_color( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'.site-header',
						'.gmr-verytopbanner',
					),
					'declarations' => array(
						'background-color' => $color,
					),
				)
			);
		}

		/* site title */
		$setting = 'gmr_sitetitle-color';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );
		if ( $mod ) {
			$color = sanitize_hex_color( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'.site-title a',
					),
					'declarations' => array(
						'color' => $color,
					),
				)
			);
		}

		/* site description */
		$setting = 'gmr_sitedesc-color';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );
		if ( $mod ) {
			$color = sanitize_hex_color( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'.site-description',
					),
					'declarations' => array(
						'color' => $color,
					),
				)
			);
		}

		$setting = 'gmr_mainmenu-bgcolor';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );
		if ( $mod ) {
			$color = sanitize_hex_color( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'.top-header',
					),
					'declarations' => array(
						'background-color' => $color,
					),
				)
			);
		}

		/* Menu text color */
		$setting = 'gmr_mainmenu-color';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );
		if ( $mod ) {
			$color = sanitize_hex_color( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'#gmr-responsive-menu',
						'.gmr-mainmenu #primary-menu > li > a',
						'.search-trigger .gmr-icon',
					),
					'declarations' => array(
						'color' => $color,
					),
				)
			);

			$color = sanitize_hex_color( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'.gmr-mainmenu #primary-menu > li.menu-border > a span',
						'.gmr-mainmenu #primary-menu > li.page_item_has_children > a:after',
						'.gmr-mainmenu #primary-menu > li.menu-item-has-children > a:after',
						'.gmr-mainmenu #primary-menu .sub-menu > li.page_item_has_children > a:after',
						'.gmr-mainmenu #primary-menu .sub-menu > li.menu-item-has-children > a:after',
					),
					'declarations' => array(
						'border-color' => $color,
					),
				)
			);
		}

		/* Hover text color */
		$setting = 'gmr_hovermenu-color';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );
		if ( $mod ) {
			$color = sanitize_hex_color( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'#gmr-responsive-menu:hover',
						'.gmr-mainmenu #primary-menu > li:hover > a',
						'.gmr-mainmenu #primary-menu > .current-menu-item > a',
						'.gmr-mainmenu #primary-menu .current-menu-ancestor > a',
						'.gmr-mainmenu #primary-menu .current_page_item > a',
						'.gmr-mainmenu #primary-menu .current_page_ancestor > a',
						'.search-trigger .gmr-icon:hover',
					),
					'declarations' => array(
						'color' => $color,
					),
				)
			);

			$color = sanitize_hex_color( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'.gmr-mainmenu #primary-menu > li.menu-border:hover > a span',
						'.gmr-mainmenu #primary-menu > li.menu-border.current-menu-item > a span',
						'.gmr-mainmenu #primary-menu > li.menu-border.current-menu-ancestor > a span',
						'.gmr-mainmenu #primary-menu > li.menu-border.current_page_item > a span',
						'.gmr-mainmenu #primary-menu > li.menu-border.current_page_ancestor > a span',
						'.gmr-mainmenu #primary-menu > li.page_item_has_children:hover > a:after',
						'.gmr-mainmenu #primary-menu > li.menu-item-has-children:hover > a:after',
						'.gmr-mainmenu #primary-menu .sub-menu > li.page_item_has_children:hover > a:after',
						'.gmr-mainmenu #primary-menu .sub-menu > li.menu-item-has-children:hover > a:after',
					),
					'declarations' => array(
						'border-color' => $color,
					),
				)
			);
		}

		/* Second Menu text color */
		$setting = 'gmr_secondmenu-color';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );
		if ( $mod ) {
			$color = sanitize_hex_color( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'.secondwrap-menu .gmr-mainmenu #primary-menu > li > a',
						'.secondwrap-menu .search-trigger .gmr-icon',
					),
					'declarations' => array(
						'color' => $color,
					),
				)
			);

			$color = sanitize_hex_color( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'#primary-menu > li.menu-border > a span',
					),
					'declarations' => array(
						'border-color' => $color,
					),
				)
			);
		}

		/* Hover text color */
		$setting = 'gmr_hoversecondmenu-color';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );
		if ( $mod ) {
			$color = sanitize_hex_color( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'.secondwrap-menu .gmr-mainmenu #primary-menu > li:hover > a',
						'.secondwrap-menu .gmr-mainmenu #primary-menu > .current-menu-item > a',
						'.secondwrap-menu .gmr-mainmenu #primary-menu .current-menu-ancestor > a',
						'.secondwrap-menu .gmr-mainmenu #primary-menu .current_page_item > a',
						'.secondwrap-menu .gmr-mainmenu #primary-menu .current_page_ancestor > a',
						'.secondwrap-menu .gmr-mainmenu #primary-menu > li.page_item_has_children:hover > a:after',
						'.secondwrap-menu .gmr-mainmenu #primary-menu > li.menu-item-has-children:hover > a:after',
						'.secondwrap-menu .gmr-mainmenu #primary-menu .sub-menu > li.page_item_has_children:hover > a:after',
						'.secondwrap-menu .gmr-mainmenu #primary-menu .sub-menu > li.menu-item-has-children:hover > a:after',
						'.secondwrap-menu .search-trigger .gmr-icon:hover',
					),
					'declarations' => array(
						'color' => $color,
					),
				)
			);

			$color = sanitize_hex_color( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'.secondwrap-menu .gmr-mainmenu #primary-menu > li.menu-border:hover > a span',
						'.secondwrap-menu .gmr-mainmenu #primary-menu > li.menu-border.current-menu-item > a span',
						'.secondwrap-menu .gmr-mainmenu #primary-menu > li.menu-border.current-menu-ancestor > a span',
						'.secondwrap-menu .gmr-mainmenu #primary-menu > li.menu-border.current_page_item > a span',
						'.secondwrap-menu .gmr-mainmenu #primary-menu > li.menu-border.current_page_ancestor > a span',
						'.secondwrap-menu .gmr-mainmenu #primary-menu > li.page_item_has_children:hover > a:after',
						'.secondwrap-menu .gmr-mainmenu #primary-menu > li.menu-item-has-children:hover > a:after',
						'.secondwrap-menu .gmr-mainmenu #primary-menu .sub-menu > li.page_item_has_children:hover > a:after',
						'.secondwrap-menu .gmr-mainmenu #primary-menu .sub-menu > li.menu-item-has-children:hover > a:after',
					),
					'declarations' => array(
						'border-color' => $color,
					),
				)
			);
		}

		/* Primary Font */
		$setting = 'gmr_primary-font';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );
		$stack   = customizer_library_get_font_stack( $mod );
		if ( $mod ) {
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'h1',
						'h2',
						'h3',
						'h4',
						'h5',
						'h6',
						'.h1',
						'.h2',
						'.h3',
						'.h4',
						'.h5',
						'.h6',
						'.site-title',
						'#primary-menu > li > a',
						'.gmr-rp-biglink a',
						'.gmr-rp-link a',
						'.gmr-gallery-related ul li p a',
					),
					'declarations' => array(
						'font-family' => $stack,
					),
				)
			);
		}

		/* Secondary Font */
		$setting = 'gmr_secondary-font';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );
		$stack   = customizer_library_get_font_stack( $mod );
		if ( $mod ) {
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'body',
					),
					'declarations' => array(
						'font-family' => $stack,
					),
				)
			);
		}

		$setting = 'gmr_secondary-font-weight';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );
		if ( $mod ) {
			$size = absint( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'body',
					),
					'declarations' => array(
						'font-weight' => $size,
					),
				)
			);
		}

		/* body size */
		$setting = 'gmr_body_size';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );
		if ( $mod ) {
			$size = absint( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'body',
					),
					'declarations' => array(
						'font-size' => $size . 'px',
					),
				)
			);
		}

		/* body size */
		$setting = 'gmr_single_size';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );
		if ( $mod ) {
			$size = absint( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'.entry-main-single',
						'.entry-main-single p',
					),
					'declarations' => array(
						'font-size' => $size . 'px',
					),
				)
			);
		}

		/* Single title size */
		$setting = 'gmr_singletitle_size';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );
		if ( $mod ) {
			$size = absint( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'h1.title',
						'h1.entry-title',
					),
					'declarations' => array(
						'font-size' => $size . 'px',
					),
				)
			);
		}

		/* h2 size */
		$setting = 'gmr_archivetitle_size';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );
		if ( $mod ) {
			$size = absint( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'h2.entry-title',
					),
					'declarations' => array(
						'font-size' => $size . 'px',
					),
				)
			);
		}

		/* h3 size */
		$setting = 'gmr_h3_size';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );
		if ( $mod ) {
			$size = absint( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'h3',
					),
					'declarations' => array(
						'font-size' => $size . 'px',
					),
				)
			);
		}

		/* h4 size */
		$setting = 'gmr_h4_size';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );
		if ( $mod ) {
			$size = absint( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'h4',
					),
					'declarations' => array(
						'font-size' => $size . 'px',
					),
				)
			);
		}

		/* h5 size */
		$setting = 'gmr_h5_size';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );
		if ( $mod ) {
			$size = absint( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'h5',
					),
					'declarations' => array(
						'font-size' => $size . 'px',
					),
				)
			);
		}

		/* h6 size */
		$setting = 'gmr_h6_size';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );
		if ( $mod ) {
			$size = absint( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'h6',
					),
					'declarations' => array(
						'font-size' => $size . 'px',
					),
				)
			);
		}

		/* Footer Background Color */
		$setting = 'gmr_footer-bgcolor';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );
		if ( $mod ) {
			$color = sanitize_hex_color( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'.footer-container',
					),
					'declarations' => array(
						'background-color' => $color,
					),
				)
			);
		}

		/* Footer Font Color */
		$setting = 'gmr_footer-fontcolor';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );
		if ( $mod ) {
			$color = sanitize_hex_color( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'.widget-footer',
						'.content-footer',
						'.site-footer',
						'.content-footer h3.widget-title',
					),
					'declarations' => array(
						'color' => $color,
					),
				)
			);
		}

		/* Footer Link Color */
		$setting = 'gmr_footer-linkcolor';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );
		if ( $mod ) {
			$color = sanitize_hex_color( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'.widget-footer a',
						'.content-footer a',
						'.site-footer a',
					),
					'declarations' => array(
						'color' => $color,
					),
				)
			);
		}

		/* Footer Hover Link Color */
		$setting = 'gmr_footer-hoverlinkcolor';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );
		if ( $mod ) {
			$color = sanitize_hex_color( $mod );
			Customizer_Library_Styles()->add(
				array(
					'selectors'    => array(
						'.widget-footer a:hover',
						'.content-footer a:hover',
						'.site-footer a:hover',
					),
					'declarations' => array(
						'color' => $color,
					),
				)
			);
		}
	}
endif; /* endif gmr_library_customizer_build_styles */
add_action( 'customizer_library_styles', 'gmr_library_customizer_build_styles' );

if ( ! function_exists( 'gmr_library_customizer_styles' ) ) :
	/**
	 * Generates the style tag and CSS needed for the theme options.
	 *
	 * By using the "Customizer_Library_Styles" filter, different components can print CSS in the header.
	 * It is organized this way to ensure there is only one "style" tag.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function gmr_library_customizer_styles() {
		do_action( 'customizer_library_styles' );
		/* Echo the rules */
		$css = Customizer_Library_Styles()->build();
		if ( ! empty( $css ) ) {
			wp_add_inline_style( 'bloggingpro-style', $css );
		}
	}
endif; /* endif gmr_library_customizer_styles */
add_action( 'wp_enqueue_scripts', 'gmr_library_customizer_styles' );

if ( ! function_exists( 'gmr_remove_customizer_register' ) ) :
	/**
	 * Add postMessage support for site title and description for the Theme Customizer.
	 *
	 * @since 1.0.0
	 *
	 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
	 */
	function gmr_remove_customizer_register( $wp_customize ) {
		$wp_customize->remove_control( 'display_header_text' );
	}
endif; /* endif gmr_remove_customizer_register */
add_action( 'customize_register', 'gmr_remove_customizer_register' );
