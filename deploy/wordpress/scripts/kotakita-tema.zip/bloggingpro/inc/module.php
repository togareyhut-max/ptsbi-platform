<?php
/**
 * Custom homepage category content.
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package Bloggingpro
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'bloggingpro_display_carousel' ) ) :
	/**
	 * This function for display slider in homepage
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function bloggingpro_display_carousel() {
		global $post;
		$post_num = get_theme_mod( 'gmr_headline_number', '5' );
		$cat      = get_theme_mod( 'gmr_category-headline', 0 );

		$args = array(
			'post_type'              => 'post',
			'cat'                    => $cat,
			'orderby'                => 'date',
			'order'                  => 'desc',
			'showposts'              => $post_num,
			'post_status'            => 'publish',
			'ignore_sticky_posts'    => 1,
			/**
			 * Make it fast withour update term cache and cache results
			 * https://thomasgriffin.io/optimize-wordpress-queries/
			 */
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
			'no_found_rows'          => true,
		);

		$recent = get_posts( $args );
		echo '<div class="clearfix gmr-element-carousel">';
		echo '<div class="gmr-title-carousel">';
		echo '<h3 class="widget-title">';
		$textheadline = get_theme_mod( 'gmr_textheadline' );
		$urltarget    = get_theme_mod( 'gmr_urlmodule' );
		if ( $textheadline ) :
			$text = esc_html( $textheadline );
		else :
			$text = __( 'Headlines', 'bloggingpro' );
		endif;

		if ( $urltarget ) :
			echo '<a href="' . esc_url( $urltarget ) . '" title=" ' . esc_html( $text ) . '">';
		endif;
			echo esc_html( $text );
		if ( $urltarget ) :
			echo '</a>';
		endif;
		echo '</h3>';
		echo '</div>';
		echo '<div class="gmr-owl-carousel">';
		foreach ( $recent as $post ) :
			setup_postdata( $post );
			?>
				<div class="gmr-slider-content">
				<?php
				if ( has_post_thumbnail() ) {
					?>
					<div class="other-content-thumbnail thumb-radius">
					<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
					<?php
					the_post_thumbnail( 'medium' );
					?>
					</a>
					<?php
					if ( has_post_format( 'gallery' ) ) {
						echo '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 1024 1024"><path d="M864 248H728l-32.4-90.8a32.07 32.07 0 0 0-30.2-21.2H358.6c-13.5 0-25.6 8.5-30.1 21.2L296 248H160c-44.2 0-80 35.8-80 80v456c0 44.2 35.8 80 80 80h704c44.2 0 80-35.8 80-80V328c0-44.2-35.8-80-80-80zm8 536c0 4.4-3.6 8-8 8H160c-4.4 0-8-3.6-8-8V328c0-4.4 3.6-8 8-8h186.7l17.1-47.8l22.9-64.2h250.5l22.9 64.2l17.1 47.8H864c4.4 0 8 3.6 8 8v456zM512 384c-88.4 0-160 71.6-160 160s71.6 160 160 160s160-71.6 160-160s-71.6-160-160-160zm0 256c-53 0-96-43-96-96s43-96 96-96s96 43 96 96s-43 96-96 96z" fill="currentColor"/></svg>';
					} elseif ( has_post_format( 'video' ) ) {
						echo '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 1024 1024"><path fill="currentColor" d="M512 64a448 448 0 1 1 0 896a448 448 0 0 1 0-896zm0 832a384 384 0 0 0 0-768a384 384 0 0 0 0 768zm-48-247.616L668.608 512L464 375.616v272.768zm10.624-342.656l249.472 166.336a48 48 0 0 1 0 79.872L474.624 718.272A48 48 0 0 1 400 678.336V345.6a48 48 0 0 1 74.624-39.936z"/></svg>';
						$h = get_post_meta( $post->ID, '_durh', true );
						$m = get_post_meta( $post->ID, '_durm', true );
						$s = get_post_meta( $post->ID, '_durs', true );
						if ( ! empty( $h ) || ! empty( $m ) || ! empty( $s ) ) {
							echo '<div class="duration">';
							if ( ! empty( $h ) && 0 !== $h ) {
								echo esc_html( str_pad( absint( $h ), 2, '0', STR_PAD_LEFT ) . ':' );
							}
							if ( ! empty( $m ) ) {
								echo esc_html( str_pad( absint( $m ), 2, '0', STR_PAD_LEFT ) . ':' );
							} else {
								echo '00';
							}
							if ( ! empty( $s ) ) {
								echo esc_html( str_pad( absint( $s ), 2, '0', STR_PAD_LEFT ) );
							} else {
								echo '00';
							}
							echo '</div>';
						}
					}
					?>
					</div>
					<?php
				}
				?>
					<div class="gmr-rp-link">
						<a href="<?php the_permalink(); ?>" class="gmr-slide-titlelink" title="<?php the_title(); ?>"><?php the_title(); ?></a>
					</div>
				</div>
			<?php
		endforeach;
		wp_reset_postdata();
		echo '</div>';
		echo '</div>';
	}
endif; /* endif bloggingpro_display_carousel */
add_action( 'bloggingpro_display_carousel', 'bloggingpro_display_carousel', 50 );

if ( ! function_exists( 'bloggingpro_display_modulehome' ) ) :
	/**
	 * This function for display module in homepage
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function bloggingpro_display_modulehome() {
		global $post;
		$post_num = get_theme_mod( 'gmr_module_number', '8' );
		$cat      = get_theme_mod( 'gmr_category-module-home', 0 );

		$args = array(
			'post_type'              => 'post',
			'cat'                    => $cat,
			'orderby'                => 'date',
			'order'                  => 'desc',
			'showposts'              => $post_num,
			'post_status'            => 'publish',
			'ignore_sticky_posts'    => 1,
			/**
			 * Make it fast withour update term cache and cache results
			 * https://thomasgriffin.io/optimize-wordpress-queries/
			 */
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
			'no_found_rows'          => true,
		);

		$recent = get_posts( $args );
		if ( $recent ) {
			echo '<div class="gmr-bigheadline clearfix">';
			$count = 0;
			foreach ( $recent as $post ) :
				setup_postdata( $post );
				$count++;
				if ( $count <= 1 ) {
					?>
					<div class="gmr-big-headline">
						<div class="other-content-thumbnail">
							<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
								<?php
								if ( has_post_thumbnail() ) :
									the_post_thumbnail( 'verylarge' );
								endif;
								?>
							</a>
							<?php
							if ( has_post_format( 'gallery' ) ) {
								echo '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 1024 1024"><path d="M864 248H728l-32.4-90.8a32.07 32.07 0 0 0-30.2-21.2H358.6c-13.5 0-25.6 8.5-30.1 21.2L296 248H160c-44.2 0-80 35.8-80 80v456c0 44.2 35.8 80 80 80h704c44.2 0 80-35.8 80-80V328c0-44.2-35.8-80-80-80zm8 536c0 4.4-3.6 8-8 8H160c-4.4 0-8-3.6-8-8V328c0-4.4 3.6-8 8-8h186.7l17.1-47.8l22.9-64.2h250.5l22.9 64.2l17.1 47.8H864c4.4 0 8 3.6 8 8v456zM512 384c-88.4 0-160 71.6-160 160s71.6 160 160 160s160-71.6 160-160s-71.6-160-160-160zm0 256c-53 0-96-43-96-96s43-96 96-96s96 43 96 96s-43 96-96 96z" fill="currentColor"/></svg>';
							} elseif ( has_post_format( 'video' ) ) {
								echo '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 1024 1024"><path fill="currentColor" d="M512 64a448 448 0 1 1 0 896a448 448 0 0 1 0-896zm0 832a384 384 0 0 0 0-768a384 384 0 0 0 0 768zm-48-247.616L668.608 512L464 375.616v272.768zm10.624-342.656l249.472 166.336a48 48 0 0 1 0 79.872L474.624 718.272A48 48 0 0 1 400 678.336V345.6a48 48 0 0 1 74.624-39.936z"/></svg>';
								$h = get_post_meta( $post->ID, '_durh', true );
								$m = get_post_meta( $post->ID, '_durm', true );
								$s = get_post_meta( $post->ID, '_durs', true );
								if ( ! empty( $h ) || ! empty( $m ) || ! empty( $s ) ) {
									echo '<div class="duration">';
									if ( ! empty( $h ) && 0 !== $h ) {
										echo esc_html( str_pad( absint( $h ), 2, '0', STR_PAD_LEFT ) . ':' );
									}
									if ( ! empty( $m ) ) {
										echo esc_html( str_pad( absint( $m ), 2, '0', STR_PAD_LEFT ) . ':' );
									} else {
										echo '00';
									}
									if ( ! empty( $s ) ) {
										echo esc_html( str_pad( absint( $s ), 2, '0', STR_PAD_LEFT ) );
									} else {
										echo '00';
									}
									echo '</div>';
								}
							}
							?>
						</div>
						<div class="gmr-bigheadline-content">
							<?php
							/* Disable meta data options via customizer */
							$metadata = get_theme_mod( 'gmr_active-metaarchive', 0 );

							/* translators: used between list items, there is a space after the comma */
							$time_string = '<time class="entry-date published updated" ' . bloggingpro_itemprop_schema( 'dateModified' ) . ' datetime="%1$s">%2$s</time>';
							if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
								$time_string = '<time class="entry-date published" ' . bloggingpro_itemprop_schema( 'datePublished' ) . ' datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
							}

							$time_string = sprintf(
								$time_string,
								esc_attr( get_the_date( 'c' ) ),
								esc_html( get_the_date() ),
								esc_attr( get_the_modified_date( 'c' ) ),
								esc_html( get_the_modified_date() )
							);

							$posted_on = sprintf( '%s', $time_string );

							if ( 0 === $metadata ) :
								echo '<div class="gmr-metacontent"><span class="posted-on">' . $posted_on . '</span></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							endif;
							?>
							<div class="gmr-rp-biglink">
								<a href="<?php the_permalink(); ?>" class="gmr-slide-titlelink" title="<?php the_title(); ?>"><?php the_title(); ?></a>
							</div>
							<?php echo gmr_set_custom_excerpt_length( 120 ); /* phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped */ ?>
						</div>
					</div>
					<div class="gmr-owl-bigheadline">
						<?php
						echo '<h3 class="widget-title">';
						$textrelated = get_theme_mod( 'gmr_textrelated' );
						if ( $textrelated ) :
							/* sanitize html output */
							echo esc_html( $textrelated );
						else :
							echo esc_html__( 'Related News', 'bloggingpro' );
						endif;
						echo '</h3>';
						?>
					<div class="gmr-owl-carousel-bigheadline">
					<?php } else { ?>
						<div class="gmr-slider-content">
							<?php
							if ( has_post_thumbnail() ) {
								?>
								<div class="other-content-thumbnail thumb-radius">
									<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
										<?php the_post_thumbnail( 'medium' ); ?>
										<?php
										if ( has_post_format( 'gallery' ) ) {
											echo '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 1024 1024"><path d="M864 248H728l-32.4-90.8a32.07 32.07 0 0 0-30.2-21.2H358.6c-13.5 0-25.6 8.5-30.1 21.2L296 248H160c-44.2 0-80 35.8-80 80v456c0 44.2 35.8 80 80 80h704c44.2 0 80-35.8 80-80V328c0-44.2-35.8-80-80-80zm8 536c0 4.4-3.6 8-8 8H160c-4.4 0-8-3.6-8-8V328c0-4.4 3.6-8 8-8h186.7l17.1-47.8l22.9-64.2h250.5l22.9 64.2l17.1 47.8H864c4.4 0 8 3.6 8 8v456zM512 384c-88.4 0-160 71.6-160 160s71.6 160 160 160s160-71.6 160-160s-71.6-160-160-160zm0 256c-53 0-96-43-96-96s43-96 96-96s96 43 96 96s-43 96-96 96z" fill="currentColor"/></svg>';

										} elseif ( has_post_format( 'video' ) ) {
											echo '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 1024 1024"><path fill="currentColor" d="M512 64a448 448 0 1 1 0 896a448 448 0 0 1 0-896zm0 832a384 384 0 0 0 0-768a384 384 0 0 0 0 768zm-48-247.616L668.608 512L464 375.616v272.768zm10.624-342.656l249.472 166.336a48 48 0 0 1 0 79.872L474.624 718.272A48 48 0 0 1 400 678.336V345.6a48 48 0 0 1 74.624-39.936z"/></svg>';
											$h = get_post_meta( $post->ID, '_durh', true );
											$m = get_post_meta( $post->ID, '_durm', true );
											$s = get_post_meta( $post->ID, '_durs', true );
											if ( ! empty( $h ) || ! empty( $m ) || ! empty( $s ) ) {
												echo '<div class="duration">';
												if ( ! empty( $h ) && 0 !== $h ) {
													echo esc_html( str_pad( absint( $h ), 2, '0', STR_PAD_LEFT ) . ':' );
												}
												if ( ! empty( $m ) ) {
													echo esc_html( str_pad( absint( $m ), 2, '0', STR_PAD_LEFT ) . ':' );
												} else {
													echo '00';
												}
												if ( ! empty( $s ) ) {
													echo esc_html( str_pad( absint( $s ), 2, '0', STR_PAD_LEFT ) );
												} else {
													echo '00';
												}
												echo '</div>';
											}
										}
										?>
									</a>
								</div>
							<?php } ?>
							<div class="gmr-rp-link">
								<?php
								/* Disable meta data options via customizer */
								$metadata = get_theme_mod( 'gmr_active-metaarchive', 0 );

								/* translators: used between list items, there is a space after the comma */
								$time_string = '<time class="entry-date published updated" ' . bloggingpro_itemprop_schema( 'dateModified' ) . ' datetime="%1$s">%2$s</time>';
								if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
									$time_string = '<time class="entry-date published" ' . bloggingpro_itemprop_schema( 'datePublished' ) . ' datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
								}

								$time_string = sprintf(
									$time_string,
									esc_attr( get_the_date( 'c' ) ),
									esc_html( get_the_date() ),
									esc_attr( get_the_modified_date( 'c' ) ),
									esc_html( get_the_modified_date() )
								);

								$posted_on = sprintf( '%s', $time_string );

								if ( 0 === $metadata ) :
									echo '<div class="gmr-metacontent"><span class="posted-on">' . $posted_on . '</span></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								endif;
								?>
								<a href="<?php the_permalink(); ?>" class="gmr-slide-titlelink" title="<?php the_title(); ?>"><?php the_title(); ?></a>
							</div>
						</div>
					<?php } ?>
				<?php
			endforeach;
			wp_reset_postdata();
				echo '</div>';
				echo '</div>';
			echo '</div>';
		}
	}
endif; /* endif bloggingpro_display_modulehome */
add_action( 'bloggingpro_display_modulehome', 'bloggingpro_display_modulehome', 50 );

if ( ! function_exists( 'bloggingpro_display_modulepopuler' ) ) :
	/**
	 * This function for display module populer
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function bloggingpro_display_modulepopuler() {
		global $post;
		$post_num      = get_theme_mod( 'gmr_module_number', '8' );
		$popular_range = get_theme_mod( 'gmr_module-populartime', 'alltime' );

		$args = array(
			'post_type'              => 'post',
			'showposts'              => $post_num,
			'post_status'            => 'publish',
			'ignore_sticky_posts'    => 1,
			/**
			 * Make it fast withour update term cache and cache results
			 * https://thomasgriffin.io/optimize-wordpress-queries/
			 */
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
			'no_found_rows'          => true,
		);

		if ( class_exists( 'Post_Views_Counter' ) ) {
			$args['orderby'] = 'post_views';
		} else {
			$args['orderby']  = 'meta_value_num';
			$args['meta_key'] = 'views'; // phpcs:ignore
			$args['order']    = 'DESC';
		}

		/* Get Current Tax ID */
		$tax    = get_queried_object();
		$tax_id = $tax->term_id;

		if ( is_category() ) {
			$args['cat'] = $tax_id;
		} elseif ( is_tag() ) {
			$args['tag_id'] = $tax_id;
		} elseif ( is_tax( 'newstopic' ) ) {
			/* Get posts last week */
			$args['tax_query'] = array( // phpcs:ignore
				array(
					'taxonomy' => 'newstopic',
					'field'    => 'term_id',
					'terms'    => $tax_id,
				),
			);
		}

		if ( 'weekly' === $popular_range ) {
			/* Get posts last week */
			$args['date_query'] = array(
				array(
					'after' => '1 week ago',
				),
			);
		} elseif ( 'mountly' === $popular_range ) {
			/* Get posts last mount */
			$args['date_query'] = array(
				array(
					'after' => '1 month ago',
				),
			);
		} elseif ( 'secondmountly' === $popular_range ) {
			/* Get posts last second mount */
			$args['date_query'] = array(
				array(
					'after' => '2 months ago',
				),
			);
		} elseif ( 'yearly' === $popular_range ) {
			/* Get posts last year */
			$args['date_query'] = array(
				array(
					'after' => '1 year ago',
				),
			);
		}

		$recent = get_posts( $args );
		if ( $recent ) {
			echo '<div class="gmr-bigheadline clearfix">';
			$count = 0;
			foreach ( $recent as $post ) :
				setup_postdata( $post );
				$count++;
				if ( $count <= 1 ) {
					?>
					<div class="gmr-big-headline">
						<div class="other-content-thumbnail thumb-radius">
							<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
								<?php
								if ( has_post_thumbnail() ) :
									the_post_thumbnail( 'verylarge' );
								endif;
								?>
							</a>
							<?php
							if ( has_post_format( 'gallery' ) ) {
								echo '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 1024 1024"><path d="M864 248H728l-32.4-90.8a32.07 32.07 0 0 0-30.2-21.2H358.6c-13.5 0-25.6 8.5-30.1 21.2L296 248H160c-44.2 0-80 35.8-80 80v456c0 44.2 35.8 80 80 80h704c44.2 0 80-35.8 80-80V328c0-44.2-35.8-80-80-80zm8 536c0 4.4-3.6 8-8 8H160c-4.4 0-8-3.6-8-8V328c0-4.4 3.6-8 8-8h186.7l17.1-47.8l22.9-64.2h250.5l22.9 64.2l17.1 47.8H864c4.4 0 8 3.6 8 8v456zM512 384c-88.4 0-160 71.6-160 160s71.6 160 160 160s160-71.6 160-160s-71.6-160-160-160zm0 256c-53 0-96-43-96-96s43-96 96-96s96 43 96 96s-43 96-96 96z" fill="currentColor"/></svg>';

							} elseif ( has_post_format( 'video' ) ) {
								echo '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 1024 1024"><path fill="currentColor" d="M512 64a448 448 0 1 1 0 896a448 448 0 0 1 0-896zm0 832a384 384 0 0 0 0-768a384 384 0 0 0 0 768zm-48-247.616L668.608 512L464 375.616v272.768zm10.624-342.656l249.472 166.336a48 48 0 0 1 0 79.872L474.624 718.272A48 48 0 0 1 400 678.336V345.6a48 48 0 0 1 74.624-39.936z"/></svg>';
								$h = get_post_meta( $post->ID, '_durh', true );
								$m = get_post_meta( $post->ID, '_durm', true );
								$s = get_post_meta( $post->ID, '_durs', true );
								if ( ! empty( $h ) || ! empty( $m ) || ! empty( $s ) ) {
									echo '<div class="duration">';
									if ( ! empty( $h ) && 0 !== $h ) {
										echo esc_html( str_pad( absint( $h ), 2, '0', STR_PAD_LEFT ) . ':' );
									}
									if ( ! empty( $m ) ) {
										echo esc_html( str_pad( absint( $m ), 2, '0', STR_PAD_LEFT ) . ':' );
									} else {
										echo '00';
									}
									if ( ! empty( $s ) ) {
										echo esc_html( str_pad( absint( $s ), 2, '0', STR_PAD_LEFT ) );
									} else {
										echo '00';
									}
									echo '</div>';
								}
							}
							?>
						</div>
						<div class="gmr-bigheadline-content">
							<?php

							/* Disable meta data options via customizer */
							$metadata = get_theme_mod( 'gmr_active-metaarchive', 0 );

							/* translators: used between list items, there is a space after the comma */
							$time_string = '<time class="entry-date published updated" ' . bloggingpro_itemprop_schema( 'dateModified' ) . ' datetime="%1$s">%2$s</time>';
							if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
								$time_string = '<time class="entry-date published" ' . bloggingpro_itemprop_schema( 'datePublished' ) . ' datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
							}

							$time_string = sprintf(
								$time_string,
								esc_attr( get_the_date( 'c' ) ),
								esc_html( get_the_date() ),
								esc_attr( get_the_modified_date( 'c' ) ),
								esc_html( get_the_modified_date() )
							);

							$posted_on = sprintf( '%s', $time_string );

							if ( 0 === $metadata ) :
								echo '<div class="gmr-metacontent"><span class="posted-on">' . $posted_on . '</span></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							endif;
							?>
							<div class="gmr-rp-biglink">
								<a href="<?php the_permalink(); ?>" class="gmr-slide-titlelink" title="<?php the_title(); ?>"><?php the_title(); ?></a>
							</div>
							<?php echo gmr_set_custom_excerpt_length( 120 ); /* phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped */ ?>
						</div>
					</div>
					<div class="gmr-owl-bigheadline">
							<?php
							echo '<h3 class="widget-title">';
							$textrelated = get_theme_mod( 'gmr_textrelated' );
							if ( $textrelated ) :
								/* sanitize html output */
								echo esc_html( $textrelated );
							else :
								echo esc_html__( 'Related News', 'bloggingpro' );
							endif;
							echo '</h3>';
							?>
					<div class="gmr-owl-carousel-bigheadline owl-carousel owl-theme">
					<?php } else { ?>
						<div class="gmr-slider-content">
							<?php
							if ( has_post_thumbnail() ) {
								?>
								<div class="other-content-thumbnail thumb-radius">
									<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
										<?php the_post_thumbnail( 'medium' ); ?>
										<?php
										if ( has_post_format( 'gallery' ) ) {
											echo '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 1024 1024"><path d="M864 248H728l-32.4-90.8a32.07 32.07 0 0 0-30.2-21.2H358.6c-13.5 0-25.6 8.5-30.1 21.2L296 248H160c-44.2 0-80 35.8-80 80v456c0 44.2 35.8 80 80 80h704c44.2 0 80-35.8 80-80V328c0-44.2-35.8-80-80-80zm8 536c0 4.4-3.6 8-8 8H160c-4.4 0-8-3.6-8-8V328c0-4.4 3.6-8 8-8h186.7l17.1-47.8l22.9-64.2h250.5l22.9 64.2l17.1 47.8H864c4.4 0 8 3.6 8 8v456zM512 384c-88.4 0-160 71.6-160 160s71.6 160 160 160s160-71.6 160-160s-71.6-160-160-160zm0 256c-53 0-96-43-96-96s43-96 96-96s96 43 96 96s-43 96-96 96z" fill="currentColor"/></svg>';

										} elseif ( has_post_format( 'video' ) ) {
											echo '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 1024 1024"><path fill="currentColor" d="M512 64a448 448 0 1 1 0 896a448 448 0 0 1 0-896zm0 832a384 384 0 0 0 0-768a384 384 0 0 0 0 768zm-48-247.616L668.608 512L464 375.616v272.768zm10.624-342.656l249.472 166.336a48 48 0 0 1 0 79.872L474.624 718.272A48 48 0 0 1 400 678.336V345.6a48 48 0 0 1 74.624-39.936z"/></svg>';
											$h = get_post_meta( $post->ID, '_durh', true );
											$m = get_post_meta( $post->ID, '_durm', true );
											$s = get_post_meta( $post->ID, '_durs', true );
											if ( ! empty( $h ) || ! empty( $m ) || ! empty( $s ) ) {
												echo '<div class="duration">';
												if ( ! empty( $h ) && 0 !== $h ) {
													echo esc_html( str_pad( absint( $h ), 2, '0', STR_PAD_LEFT ) . ':' );
												}
												if ( ! empty( $m ) ) {
													echo esc_html( str_pad( absint( $m ), 2, '0', STR_PAD_LEFT ) . ':' );
												} else {
													echo '00';
												}
												if ( ! empty( $s ) ) {
													echo esc_html( str_pad( absint( $s ), 2, '0', STR_PAD_LEFT ) );
												} else {
													echo '00';
												}
												echo '</div>';
											}
										}
										?>
									</a>
								</div>
							<?php } ?>
							<div class="gmr-rp-link">
							<?php
							/* Disable meta data options via customizer */
							$metadata = get_theme_mod( 'gmr_active-metaarchive', 0 );

							/* translators: used between list items, there is a space after the comma */
							$time_string = '<time class="entry-date published updated" ' . bloggingpro_itemprop_schema( 'dateModified' ) . ' datetime="%1$s">%2$s</time>';
							if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
								$time_string = '<time class="entry-date published" ' . bloggingpro_itemprop_schema( 'datePublished' ) . ' datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
							}

							$time_string = sprintf(
								$time_string,
								esc_attr( get_the_date( 'c' ) ),
								esc_html( get_the_date() ),
								esc_attr( get_the_modified_date( 'c' ) ),
								esc_html( get_the_modified_date() )
							);

							$posted_on = sprintf( '%s', $time_string );

							if ( 0 === $metadata ) :
								echo '<div class="gmr-metacontent"><span class="posted-on">' . $posted_on . '</span></div>';  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							endif;
							?>
								<a href="<?php the_permalink(); ?>" class="gmr-slide-titlelink" title="<?php the_title(); ?>"><?php the_title(); ?></a>
							</div>
						</div>
					<?php } ?>
				<?php
			endforeach;
			wp_reset_postdata();
				echo '</div>';
				echo '</div>';
			echo '</div>';
		}
	}
endif; /* endif bloggingpro_display_modulepopuler */
add_action( 'bloggingpro_display_modulepopuler', 'bloggingpro_display_modulepopuler', 50 );

if ( ! function_exists( 'bloggingpro_recentpost_marque' ) ) :
	/**
	 * This function for display slider in homepage
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function bloggingpro_recentpost_marque() {
		global $post;
		$cat = get_theme_mod( 'gmr_category-marque', 0 );

		$args = array(
			'post_type'              => 'post',
			'cat'                    => $cat,
			'orderby'                => 'date',
			'order'                  => 'desc',
			'showposts'              => 5,
			'post_status'            => 'publish',
			'ignore_sticky_posts'    => 1,
			/**
			 * Make it fast withour update term cache and cache results
			 * https://thomasgriffin.io/optimize-wordpress-queries/
			 */
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
			'no_found_rows'          => true,
		);

		$recent = get_posts( $args );
		foreach ( $recent as $post ) :
			setup_postdata( $post );
			?>
				<a href="<?php the_permalink(); ?>" class="gmr-recent-marquee" title="<?php the_title(); ?>"><?php the_title(); ?></a>
			<?php
		endforeach;
		wp_reset_postdata();
	}
endif; /* endif bloggingpro_recentpost_marque */
add_action( 'bloggingpro_recentpost_marque', 'bloggingpro_recentpost_marque', 50 );
