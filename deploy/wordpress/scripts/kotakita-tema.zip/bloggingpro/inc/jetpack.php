<?php
/**
 * Jetpack Compatibility File.
 *
 * @link https://jetpack.com/
 *
 * @package Bloggingpro
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'gmr_jetpack_setup' ) ) :
	/**
	 * Jetpack setup function.
	 *
	 * @since 1.0.0
	 *
	 * See: https://jetpack.com/support/infinite-scroll/
	 * See: https://jetpack.com/support/responsive-videos/
	 */
	function gmr_jetpack_setup() {
		/* Add theme support for Infinite Scroll. */
		add_theme_support(
			'infinite-scroll',
			array(
				'container' => 'main',
				'render'    => 'gmr_infinite_scroll_render',
				'footer'    => false,
				'wrapper'   => false,
			)
		);
		/* Add theme support for Responsive Videos. */
		add_theme_support( 'jetpack-responsive-videos' );
	}
endif; /* endif gmr_jetpack_setup */
add_action( 'after_setup_theme', 'gmr_jetpack_setup' );

if ( ! function_exists( 'gmr_infinite_scroll_render' ) ) :
	/**
	 * Custom render function for Infinite Scroll.
	 *
	 * @since 1.0.0
	 */
	function gmr_infinite_scroll_render() {
		while ( have_posts() ) {
			the_post();
			get_template_part( 'template-parts/content', get_post_format() );
		}
	}
endif; /* endif gmr_infinite_scroll_render */

if ( ! function_exists( 'gmr_custom_infinite_support' ) ) :
	/**
	 * Support infinite scroll only on post type "post" other post type return false
	 *
	 * @since  1.0.0
	 *
	 * @return bool
	 */
	function gmr_custom_infinite_support() {
		$supported = current_theme_supports( 'infinite-scroll' ) && ( 'post' === get_post_type() );
		return $supported;
	}
endif; /* endif gmr_custom_infinite_support */
add_filter( 'infinite_scroll_archive_supported', 'gmr_custom_infinite_support' );

if ( ! function_exists( 'gmr_remove_jetpack_rp' ) ) :
	/**
	 * Remove jetpack related post and we use functionally using shortcode
	 *
	 * @since 1.0.0
	 * @link https://jetpack.com/support/related-posts/customize-related-posts/#delete
	 */
	function gmr_remove_jetpack_rp() {
		if ( class_exists( 'Jetpack_RelatedPosts' ) ) {
			$jprp     = Jetpack_RelatedPosts::init();
			$callback = array( $jprp, 'filter_add_target_to_dom' );
			remove_filter( 'the_content', $callback, 40 );
		}
	}
endif; /* endif gmr_remove_jetpack_rp */
add_filter( 'wp', 'gmr_remove_jetpack_rp', 20 );

if ( ! function_exists( 'gmr_remove_jetpack_share' ) ) :
	/**
	 * Remove jetpack sharing and we use functionally using add manually via plugin
	 *
	 * @since 1.0.0
	 * @link https://jetpack.com/2013/06/10/moving-sharing-icons/
	 */
	function gmr_remove_jetpack_share() {
		remove_filter( 'the_content', 'sharing_display', 19 );
		remove_filter( 'the_excerpt', 'sharing_display', 19 );
		if ( class_exists( 'Jetpack_Likes' ) ) {
			remove_filter( 'the_content', array( Jetpack_Likes::init(), 'post_likes' ), 30, 1 );
		}
	}
endif; /* endif gmr_remove_jetpack_share */
add_action( 'loop_start', 'gmr_remove_jetpack_share' );

if ( ! function_exists( 'gmr_related_posts_headline' ) ) :
	/**
	 * Change related posts headline
	 *
	 * @since 1.0.0
	 * @param string $headline displaying related post title in jetpack.
	 * @link https://jetpack.com/support/related-posts/customize-related-posts/
	 */
	function gmr_related_posts_headline( $headline ) {
		$headline = sprintf(
			'<h3 class="widget-title">%s</h3>',
			esc_html__( 'Related Posts', 'bloggingpro' )
		);
		return $headline;
	}
endif; /* endif gmr_related_posts_headline */
add_filter( 'jetpack_relatedposts_filter_headline', 'gmr_related_posts_headline' );
