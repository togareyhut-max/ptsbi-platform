<?php
/**
 * Custom template tags for this theme.
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package Bloggingpro
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'gmr_posted_on' ) ) :
	/**
	 * Prints HTML with meta information for the current post-date/time and author.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function gmr_posted_on() {
		global $post;
		$time_string = '<time class="entry-date published updated" ' . bloggingpro_itemprop_schema( 'dateModified' ) . ' datetime="%1$s">%2$s</time>';
		if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
			$time_string = '<time class="entry-date published" ' . bloggingpro_itemprop_schema( 'datePublished' ) . ' datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
		}

		$time_string = sprintf(
			$time_string,
			esc_attr( get_the_date( 'c' ) ),
			esc_html( get_the_date() ),
			esc_attr( get_the_modified_date( 'c' ) ),
			esc_html( get_the_modified_date() )
		);

		$posted_on = sprintf( '%s', $time_string );

		$posted_by = sprintf(
			'%s',
			'<span class="entry-author vcard" ' . bloggingpro_itemprop_schema( 'author' ) . ' ' . bloggingpro_itemtype_schema( 'person' ) . '><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '" title="' . __( 'Permalink to: ', 'bloggingpro' ) . esc_html( get_the_author() ) . '" ' . bloggingpro_itemprop_schema( 'url' ) . '><span ' . bloggingpro_itemprop_schema( 'name' ) . '>' . esc_html( get_the_author() ) . '</span></a></span>'
		);
		if ( is_single() ) {
			echo '<div class="posted-by"> ';
			echo $posted_by; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo '</div>';
			echo '<div class="posted-on">';
			echo $posted_on; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			if ( class_exists( 'Post_Views_Counter' ) ) {
				$number = pvc_get_post_views( $post->ID );
				echo '<span class="meta-view">' . absint( $number ) . ' ' . esc_html__( 'Views', 'bloggingpro' ) . '</spans>';
			} elseif ( function_exists( 'the_views' ) ) {
				echo '<span class="meta-view">';
					the_views();
				echo '</span>';
			}
			echo '</div>';
		}
	}
endif; /* endif gmr_posted_on */

if ( ! function_exists( 'gmr_custom_excerpt_length' ) ) :
	/**
	 * Filter the except length to 20 characters.
	 *
	 * @since 1.0.0
	 *
	 * @param int $length Excerpt length.
	 * @return int (Maybe) modified excerpt length.
	 */
	function gmr_custom_excerpt_length( $length ) {
		$length = get_theme_mod( 'gmr_excerpt_number', '15' );
		/* absint sanitize int non minus */
		return absint( $length );
	}
endif; /* endif gmr_custom_excerpt_length */
add_filter( 'excerpt_length', 'gmr_custom_excerpt_length', 999 );

if ( ! function_exists( 'gmr_set_custom_excerpt_length' ) ) :
	/**
	 * Set excerpt manually
	 *
	 * @since 1.0.2
	 *
	 * @param int $count Excerpt length.
	 */
	function gmr_set_custom_excerpt_length( $count = 60 ) {
		global $post;
		$more = get_theme_mod( 'gmr_read_more' );
		if ( empty( $more ) ) {
			$morebtn = '&nbsp;[&hellip;]';
		} else {
			$morebtn = ' <a class="read-more" href="' . get_permalink( $post->ID ) . '" title="' . get_the_title( $post->ID ) . '" ' . bloggingpro_itemprop_schema( 'url' ) . '>' . esc_html( $more ) . '</a>';
		}
		$excerpt = get_the_content();
		$excerpt = wp_strip_all_tags( $excerpt );
		$excerpt = substr( $excerpt, 0, $count );
		$excerpt = substr( $excerpt, 0, strripos( $excerpt, ' ' ) );
		$excerpt = '<p>' . $excerpt . ' ' . $morebtn . '</p>';
		return $excerpt;
	}
endif; /* endif gmr_set_custom_excerpt_length */

if ( ! function_exists( 'gmr_custom_readmore' ) ) :
	/**
	 * Filter the except length to 20 characters.
	 *
	 * @since 1.0.0
	 *
	 * @param string $more More text.
	 * @return string read more.
	 */
	function gmr_custom_readmore( $more ) {
		$more = get_theme_mod( 'gmr_read_more' );
		if ( empty( $more ) ) {
			return '&nbsp;[&hellip;]';
		} else {
			return ' <a class="read-more" href="' . get_permalink( get_the_ID() ) . '" title="' . get_the_title( get_the_ID() ) . '" ' . bloggingpro_itemprop_schema( 'url' ) . '>' . esc_html( $more ) . '</a>';
		}
	}
endif; /* endif gmr_custom_readmore */
add_filter( 'excerpt_more', 'gmr_custom_readmore' );

if ( ! function_exists( 'bloggingpro_add_link_adminmenu' ) ) :
	/**
	 * Add default menu for fallback top menu
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function bloggingpro_add_link_adminmenu() {
		echo '<ul id="primary-menu">';
			echo '<li><a href="' . esc_url( admin_url( 'nav-menus.php' ) ) . '" style="border: none !important;">' . esc_html__( 'Add a Menu', 'bloggingpro' ) . '</a></li>';
		echo '</ul>';
	}
endif; /* endif bloggingpro_add_link_adminmenu */

if ( ! function_exists( 'gmr_get_pagination' ) ) :
	/**
	 * Retrieve paginated link for archive post pages.
	 *
	 * @since 1.0.0
	 *
	 * @return string
	 */
	function gmr_get_pagination() {
		global $wp_rewrite;
		global $wp_query;
		return paginate_links(
			apply_filters(
				'gmr_get_pagination_args',
				array(
					'base'      => str_replace( '99999', '%#%', esc_url( get_pagenum_link( 99999 ) ) ),
					'format'    => $wp_rewrite->using_permalinks() ? 'page/%#%' : '?paged=%#%',
					'current'   => max( 1, get_query_var( 'paged' ) ),
					'total'     => $wp_query->max_num_pages,
					'prev_text' => '&laquo;',
					'next_text' => '&raquo;',
					'type'      => 'list',
				)
			)
		);
	}
endif; /* endif gmr_get_pagination */

if ( ! function_exists( 'gmr_nav_mobile_close' ) ) :
	/**
	 * This function add close button in mobile menu.
	 *
	 * @since 1.0.0
	 *
	 * @param string $items Item Menu.
	 * @param array  $args Argument Menu.
	 * @param bool   $ajax default false.
	 * @return string
	 */
	function gmr_nav_mobile_close( $items, $args, $ajax = false ) {
		/* Primary Navigation Area Only */
		if ( ( isset( $ajax ) && $ajax ) || ( property_exists( $args, 'theme_location' ) && 'primary' === $args->theme_location ) ) {
			/* Logo Before menu */
			$setting = 'gmr_menu_logo';
			$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

			$beforeitems = '';

			$css_class_logo = 'menu-item menu-item-type-menulogo-btn gmr-menulogo-btn';
			$beforeitems   .= '<li class="' . esc_attr( $css_class_logo ) . '">';
			if ( $mod ) {
				$beforeitems .= '<a href="' . esc_url( home_url( '/' ) ) . '" id="menulogo-button" ' . bloggingpro_itemprop_schema( 'url' ) . ' title="' . get_bloginfo( 'name' ) . '">';
				/* get url image from value gmr_logoimage */
				$image        = esc_url_raw( $mod );
				$beforeitems .= '<img src="' . $image . '" alt="' . get_bloginfo( 'name' ) . '" title="' . get_bloginfo( 'name' ) . '" ' . bloggingpro_itemprop_schema( 'image' ) . ' />';
				$beforeitems .= '</a>';
			}
			$beforeitems .= '</li>';

			$css_class_search        = 'menu-item menu-item-type-search-btn gmr-search-btn pull-right';
			$afteritems              = '<li class="' . esc_attr( $css_class_search ) . '">';
				$afteritems         .= '<a id="search-menu-button" href="#" rel="nofollow">';
				$afteritems         .= '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24"><g fill="none"><path d="M21 21l-4.486-4.494M19 10.5a8.5 8.5 0 1 1-17 0a8.5 8.5 0 0 1 17 0z" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></g></svg>';
				$afteritems         .= '</a>';
				$afteritems         .= '<div class="search-dropdown search" id="search-dropdown-container">';
					$afteritems     .= '<form method="get" class="gmr-searchform searchform" action="' . esc_url( home_url( '/' ) ) . '">';
						$afteritems .= '<input type="text" name="s" id="s" placeholder="' . __( 'Search', 'bloggingpro' ) . '" />';
					$afteritems     .= '</form>';
				$afteritems         .= '</div>';
			$afteritems             .= '</li>';
			$items                   = $beforeitems . $items . $afteritems;
		}
		return apply_filters( 'gmr_nav_close_mobile_filter', $items );
	}
endif; /* endif gmr_nav_mobile_close */
add_filter( 'wp_nav_menu_items', 'gmr_nav_mobile_close', 20, 2 );

if ( ! function_exists( 'bloggingpro_add_menu_attribute' ) ) :
	/**
	 * Add attribute itemprop="url" to menu link
	 *
	 * @since 1.0.0
	 *
	 * @param string $atts Attribute Menu.
	 * @param string $item Item Menu.
	 * @param array  $args Argument Menu.
	 * @return string
	 */
	function bloggingpro_add_menu_attribute( $atts, $item, $args ) {
		$atts['itemprop'] = 'url';
		return $atts;
	}
endif; /* endif bloggingpro_add_menu_attribute */
add_filter( 'nav_menu_link_attributes', 'bloggingpro_add_menu_attribute', 10, 3 );

if ( ! function_exists( 'gmr_move_post_navigation' ) ) :
	/**
	 * Move post navigation in top after content.
	 *
	 * @since 1.0.0
	 * @param string $content Displaying content.
	 * @return string $content
	 */
	function gmr_move_post_navigation( $content ) {
		if ( is_singular() && in_the_loop() ) {
			$pagination = wp_link_pages(
				array(
					'before'      => '<div class="page-links"><span class="page-text">' . esc_html__( 'Pages:', 'bloggingpro' ) . '</span>',
					'after'       => '</div>',
					'link_before' => '<span class="page-link-number">',
					'link_after'  => '</span>',
					'echo'        => 0,
				)
			);
			$content   .= $pagination;
			return $content;
		}
		return $content;
	}
endif; /* endif gmr_move_post_navigation */
add_filter( 'the_content', 'gmr_move_post_navigation', 1 );

if ( ! function_exists( 'gmr_embed_oembed_html' ) ) :
	/**
	 * Add responsive oembed class only for youtube and vimeo.
	 *
	 * @add_filter embed_oembed_html
	 * @class gmr_embed_oembed_html
	 * @param string $html displaying html Format.
	 * @param string $url url ombed like youtube, video.
	 * @param string $attr Attribute Iframe.
	 * @param int    $post_id Post ID.
	 * @link https://developer.wordpress.org/reference/hooks/embed_oembed_html/
	 */
	function gmr_embed_oembed_html( $html, $url, $attr, $post_id ) {
		$classes = array();
		/* Add these classes to all embeds. */
		$classes_all = array(
			'gmr-video-responsive',
		);

		/* Check for different providers and add appropriate classes. */
		if ( false !== strpos( $url, 'vimeo.com' ) ) {
			$classes[] = 'gmr-embed-responsive gmr-embed-responsive-16by9';
		}

		if ( false !== strpos( $url, 'youtube.com' ) ) {
			$classes[] = 'gmr-embed-responsive gmr-embed-responsive-16by9';
		}

		if ( false !== strpos( $url, 'youtu.be' ) ) {
			$classes[] = 'gmr-embed-responsive gmr-embed-responsive-16by9';
		}

		$classes = array_merge( $classes, $classes_all );
		if ( has_block( 'core/embed' ) ) {
			return $html;
		} else {
			return '<div class="' . esc_attr( implode( ' ', $classes ) ) . '">' . $html . '</div>';
		}
	}
endif; /* endif gmr_embed_oembed_html */
add_filter( 'embed_oembed_html', 'gmr_embed_oembed_html', 99, 4 );

if ( ! function_exists( 'bloggingpro_prepend_attachment' ) ) :
	/**
	 * Callback for WordPress 'prepend_attachment' filter.
	 *
	 * Change the attachment page image size to 'large'
	 *
	 * @package WordPress
	 * @category Attachment
	 * @see wp-includes/post-template.php
	 *
	 * @param string $attachment_content the attachment html.
	 * @return string $attachment_content the attachment html
	 */
	function bloggingpro_prepend_attachment( $attachment_content ) {

		$post = get_post();
		if ( wp_attachment_is( 'image', $post ) ) {
			/* set the attachment image size to 'large' */
			$attachment_content = '';

			/* return the attachment content */
			return $attachment_content;

		} else {
			/* return the attachment content */
			return $attachment_content;
		}

	}
endif; /* endif bloggingpro_prepend_attachment */
add_filter( 'prepend_attachment', 'bloggingpro_prepend_attachment' );

if ( ! function_exists( 'bloggingpro_share_default' ) ) :
	/**
	 * Insert social share
	 *
	 * @since 1.0.0
	 * @param string $output Output social share.
	 * @return string @output
	 */
	function bloggingpro_share_default( $output = null ) {
		$socialshare = get_theme_mod( 'gmr_active-socialshare', 0 );
		if ( 0 === $socialshare ) {
			$filter_title = wp_strip_all_tags( rawurlencode( get_the_title() ) );

			$output              = '';
			$output             .= '<ul class="gmr-socialicon-share">';
				$output         .= '<li class="facebook">';
					$output     .= '<a href="https://www.facebook.com/sharer/sharer.php?u=' . rawurlencode( esc_url( get_the_permalink() ) ) . '" rel="nofollow" title="' . __( 'Share this', 'bloggingpro' ) . '">';
						$output .= '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24"><g fill="none"><path d="M9.198 21.5h4v-8.01h3.604l.396-3.98h-4V7.5a1 1 0 0 1 1-1h3v-4h-3a5 5 0 0 0-5 5v2.01h-2l-.396 3.98h2.396v8.01z" fill="currentColor"/></g></svg>';
					$output     .= '</a>';
				$output         .= '</li>';
				$output         .= '<li class="twitter">';
					$output     .= '<a href="https://twitter.com/intent/tweet?url=' . rawurlencode( esc_url( get_the_permalink() ) ) . '&amp;text=' . $filter_title . '" rel="nofollow" title="' . __( 'Tweet this', 'bloggingpro' ) . '">';
						$output .= '<svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" width="1em" height="1em" viewBox="0 0 24 24"><path fill="currentColor" d="M18.901 1.153h3.68l-8.04 9.19L24 22.846h-7.406l-5.8-7.584l-6.638 7.584H.474l8.6-9.83L0 1.154h7.594l5.243 6.932ZM17.61 20.644h2.039L6.486 3.24H4.298Z"/></svg>';
					$output     .= '</a>';
				$output         .= '</li>';
				$output         .= '<li class="telegram">';
					$output     .= '<a href="https://t.me/share/url?url=' . rawurlencode( esc_url( get_the_permalink() ) ) . '&amp;text=' . rawurlencode( wp_strip_all_tags( get_the_title() ) ) . '" target="_blank" rel="nofollow" title="' . esc_html__( 'Telegram Share', 'bloggingpro' ) . '">';
						$output .= '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 48 48"><path d="M41.42 7.309s3.885-1.515 3.56 2.164c-.107 1.515-1.078 6.818-1.834 12.553l-2.59 16.99s-.216 2.489-2.159 2.922c-1.942.432-4.856-1.515-5.396-1.948c-.432-.325-8.094-5.195-10.792-7.575c-.756-.65-1.62-1.948.108-3.463L33.648 18.13c1.295-1.298 2.59-4.328-2.806-.649l-15.11 10.28s-1.727 1.083-4.964.109l-7.016-2.165s-2.59-1.623 1.835-3.246c10.793-5.086 24.068-10.28 35.831-15.15z" fill="#000"/></svg>';
					$output     .= '</a>';
				$output         .= '</li>';
				$output         .= '<li class="whatsapp">';
					$output     .= '<a href="https://api.whatsapp.com/send?text=' . rawurlencode( wp_strip_all_tags( get_the_title() ) ) . ' ' . rawurlencode( esc_url( get_permalink() ) ) . '" rel="nofollow" title="' . __( 'WhatsApp this', 'bloggingpro' ) . '">';
						$output .= '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24"><path d="M12.04 2c-5.46 0-9.91 4.45-9.91 9.91c0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21c5.46 0 9.91-4.45 9.91-9.91c0-2.65-1.03-5.14-2.9-7.01A9.816 9.816 0 0 0 12.04 2m.01 1.67c2.2 0 4.26.86 5.82 2.42a8.225 8.225 0 0 1 2.41 5.83c0 4.54-3.7 8.23-8.24 8.23c-1.48 0-2.93-.39-4.19-1.15l-.3-.17l-3.12.82l.83-3.04l-.2-.32a8.188 8.188 0 0 1-1.26-4.38c.01-4.54 3.7-8.24 8.25-8.24M8.53 7.33c-.16 0-.43.06-.66.31c-.22.25-.87.86-.87 2.07c0 1.22.89 2.39 1 2.56c.14.17 1.76 2.67 4.25 3.73c.59.27 1.05.42 1.41.53c.59.19 1.13.16 1.56.1c.48-.07 1.46-.6 1.67-1.18c.21-.58.21-1.07.15-1.18c-.07-.1-.23-.16-.48-.27c-.25-.14-1.47-.74-1.69-.82c-.23-.08-.37-.12-.56.12c-.16.25-.64.81-.78.97c-.15.17-.29.19-.53.07c-.26-.13-1.06-.39-2-1.23c-.74-.66-1.23-1.47-1.38-1.72c-.12-.24-.01-.39.11-.5c.11-.11.27-.29.37-.44c.13-.14.17-.25.25-.41c.08-.17.04-.31-.02-.43c-.06-.11-.56-1.35-.77-1.84c-.2-.48-.4-.42-.56-.43c-.14 0-.3-.01-.47-.01z" fill="currentColor"/></svg>';
					$output     .= '</a>';
				$output         .= '</li>';
			$output             .= '</ul>';

		}
		return $output;
	}
endif; /* endif bloggingpro_share_default */

if ( ! function_exists( 'bloggingpro_add_share_the_content' ) ) :
	/**
	 * Displaying social share
	 *
	 * @since 1.0.0
	 */
	function bloggingpro_add_share_the_content() {
		$share = '';
		if ( function_exists( 'sharing_display' ) ) {
			$share .= sharing_display( '', false );
		} else {
			$share .= bloggingpro_share_default();
		}

		if ( class_exists( 'Jetpack_Likes' ) ) {
			$custom_likes = new Jetpack_Likes();
			$share       .= $custom_likes->post_likes( '' );
		}
		echo $share;  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
endif; /* endif bloggingpro_add_share_the_content */
add_action( 'bloggingpro_add_share_the_content', 'bloggingpro_add_share_the_content' );

if ( ! function_exists( 'bloggingpro_related_post' ) ) {
	/**
	 * Adding the related post to the end of your single post
	 *
	 * @since 1.0.0
	 * @param string $content Display content.
	 * @return string
	 */
	function bloggingpro_related_post( $content = null ) {
		$relatedposts = get_theme_mod( 'gmr_active-relpost', 0 );
		if ( 0 === $relatedposts ) {
			global $post;
			$numberposts = get_theme_mod( 'gmr_relpost_number', '6' );
			$taxonomy    = get_theme_mod( 'gmr_relpost_taxonomy', 'gmr-category' );

			if ( 'gmr-tags' === $taxonomy ) {
				$tags = wp_get_post_tags( $post->ID );
				if ( $tags ) {
					$tag_ids = array();
					foreach ( $tags as $individual_tag ) {
						$tag_ids[] = $individual_tag->term_id;
					}
					$args = array(
						'tag__in'             => $tag_ids,
						'post__not_in'        => array( $post->ID ),
						'posts_per_page'      => absint( $numberposts ), // phpcs:ignore
						'ignore_sticky_posts' => 1,
					);
				}
			} elseif ( 'gmr-topics' === $taxonomy ) {
				$topics = wp_get_object_terms( absint( $post->ID ), 'newstopic', array( 'fields' => 'ids' ) );
				if ( $topics ) {
					$args = array(
						'post__not_in'        => array( absint( $post->ID ) ),
						'posts_per_page'      => absint( $numberposts ), // phpcs:ignore
						'tax_query'           => array( // phpcs:ignore
							array(
								'taxonomy' => 'newstopic',
								'field'    => 'id',
								'terms'    => $topics,
							),
						),
						'ignore_sticky_posts' => 1,
					);
				}
			} else {
				$categories = get_the_category( $post->ID );
				if ( $categories ) {
					$category_ids = array();
					foreach ( $categories as $individual_category ) {
						$category_ids[] = $individual_category->term_id;
					}
					$args = array(
						'category__in'        => $category_ids,
						'post__not_in'        => array( $post->ID ),
						'posts_per_page'      => absint( $numberposts ), // phpcs:ignore
						'ignore_sticky_posts' => 1,
					);
				}
			}
			if ( ! isset( $args ) ) {
				$args = '';
			}
			$bloggingpro_query = new WP_Query( $args );

			$content = '';
			if ( $bloggingpro_query->have_posts() ) {

				$content .= '<div class="gmr-related-post gmr-box-content gmr-gallery-related">';
				$content .= '<h3 class="widget-title">' . __( 'Related posts', 'bloggingpro' ) . '</h3>';
				$content .= '<ul>';
				while ( $bloggingpro_query->have_posts() ) :
					$bloggingpro_query->the_post();
					$featured_image_url = wp_get_attachment_url( get_post_thumbnail_id( $post->ID ) );
					$content           .= '<li>';
					if ( ! empty( $featured_image_url ) ) :
						$content .= '<div class="other-content-thumbnail">';
						$content .= '<a href="' . get_permalink() . '" class="related-thumbnail thumb-radius" itemprop="url" title="' . the_title_attribute(
							array(
								'before' => __( 'Permalink to: ', 'bloggingpro' ),
								'after'  => '',
								'echo'   => false,
							)
						) . '" rel="bookmark">';
						$content .= get_the_post_thumbnail( $post->ID, 'medium' );
						$content .= '</a>';
						if ( has_post_format( 'gallery' ) ) {
							$content .= '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 1024 1024"><path d="M864 248H728l-32.4-90.8a32.07 32.07 0 0 0-30.2-21.2H358.6c-13.5 0-25.6 8.5-30.1 21.2L296 248H160c-44.2 0-80 35.8-80 80v456c0 44.2 35.8 80 80 80h704c44.2 0 80-35.8 80-80V328c0-44.2-35.8-80-80-80zm8 536c0 4.4-3.6 8-8 8H160c-4.4 0-8-3.6-8-8V328c0-4.4 3.6-8 8-8h186.7l17.1-47.8l22.9-64.2h250.5l22.9 64.2l17.1 47.8H864c4.4 0 8 3.6 8 8v456zM512 384c-88.4 0-160 71.6-160 160s71.6 160 160 160s160-71.6 160-160s-71.6-160-160-160zm0 256c-53 0-96-43-96-96s43-96 96-96s96 43 96 96s-43 96-96 96z" fill="currentColor"/></svg>';
						} elseif ( has_post_format( 'video' ) ) {
							$content .= '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 1024 1024"><path fill="currentColor" d="M512 64a448 448 0 1 1 0 896a448 448 0 0 1 0-896zm0 832a384 384 0 0 0 0-768a384 384 0 0 0 0 768zm-48-247.616L668.608 512L464 375.616v272.768zm10.624-342.656l249.472 166.336a48 48 0 0 1 0 79.872L474.624 718.272A48 48 0 0 1 400 678.336V345.6a48 48 0 0 1 74.624-39.936z"/></svg>';
							$h        = get_post_meta( $post->ID, '_durh', true );
							$m        = get_post_meta( $post->ID, '_durm', true );
							$s        = get_post_meta( $post->ID, '_durs', true );
							if ( ! empty( $h ) || ! empty( $m ) || ! empty( $s ) ) {
								$content .= '<div class="duration">';
								if ( ! empty( $h ) && 0 !== $h ) {
									$content .= esc_html( str_pad( absint( $h ), 2, '0', STR_PAD_LEFT ) . ':' );
								}
								if ( ! empty( $m ) ) {
									$content .= esc_html( str_pad( absint( $m ), 2, '0', STR_PAD_LEFT ) . ':' );
								} else {
									$content .= '00';
								}
								if ( ! empty( $s ) ) {
									$content .= esc_html( str_pad( absint( $s ), 2, '0', STR_PAD_LEFT ) );
								} else {
									$content .= '00';
								}
								$content .= '</div>';
							}
						}
						$content .= '</div>';
					endif;
						$content .= '<p>';
						$content .= '<a href="' . get_permalink() . '" itemprop="url" title="' . the_title_attribute(
							array(
								'before' => __( 'Permalink to: ', 'bloggingpro' ),
								'after'  => '',
								'echo'   => false,
							)
						) . '" rel="bookmark">' . get_the_title() . '</a>';
						$content .= '</p>';
					$content     .= '</li>';
				endwhile;
				wp_reset_postdata();
				$content .= '</ul>';
				$content .= '</div>';
			}
		}

		return $content;
	}
}

if ( ! function_exists( 'bloggingpro_add_related_post' ) ) :
	/**
	 * Displaying social share
	 *
	 * @since 1.0.0
	 */
	function bloggingpro_add_related_post() {
		if ( class_exists( 'Jetpack_RelatedPosts' ) ) {
			$related      = '<div class="gmr-related-post gmr-box-content">';
				$related .= do_shortcode( '[jetpack-related-posts]' );
			$related     .= '</div>';
		} else {
			$related = bloggingpro_related_post();
		}
		echo $related; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
endif; /* endif bloggingpro_add_related_post */
add_action( 'bloggingpro_add_related_post', 'bloggingpro_add_related_post' );

if ( ! function_exists( 'bloggingpro_related_inside_post' ) ) {
	/**
	 * Adding the related post inside posts
	 *
	 * @since 1.0.0
	 * @param string $content Display content.
	 * @return string
	 */
	function bloggingpro_related_inside_post( $content ) {
		$relatedposts = get_theme_mod( 'gmr_active-relpost-inline', 0 );
		if ( 0 === $relatedposts ) {
			if ( is_singular( array( 'post' ) ) && in_the_loop() ) {
				global $post;
				$taxonomy = get_theme_mod( 'gmr_relpost_taxonomy_inlinepost', 'gmr-tags' );

				if ( 'gmr-tags' === $taxonomy ) {
					$tags = wp_get_post_tags( $post->ID );
					if ( $tags ) {
						$tag_ids = array();
						foreach ( $tags as $individual_tag ) {
							$tag_ids[] = $individual_tag->term_id;
						}
						$args = array(
							'tag__in'             => $tag_ids,
							'post__not_in'        => array( $post->ID ),
							'posts_per_page'      => 3,
							'ignore_sticky_posts' => 1,
						);
					}
				} elseif ( 'gmr-topics' === $taxonomy ) {
					$topics = wp_get_object_terms( absint( $post->ID ), 'newstopic', array( 'fields' => 'ids' ) );

					if ( $topics ) {
						$args = array(
							'post__not_in'        => array( absint( $post->ID ) ),
							'posts_per_page'      => 3,
							'tax_query'           => array( // phpcs:ignore
								array(
									'taxonomy' => 'newstopic',
									'field'    => 'id',
									'terms'    => $topics,
								),
							),
							'ignore_sticky_posts' => 1,
						);
					}
				} else {
					$categories = get_the_category( $post->ID );
					if ( $categories ) {
						$category_ids = array();
						foreach ( $categories as $individual_category ) {
							$category_ids[] = $individual_category->term_id;
						}
						$args = array(
							'category__in'        => $category_ids,
							'post__not_in'        => array( $post->ID ),
							'posts_per_page'      => 3,
							'ignore_sticky_posts' => 1,
						);
					}
				}
				if ( ! isset( $args ) ) {
					$args = '';
				}
				$bloggingpro_query = new WP_Query( $args );

				$related = '';
				if ( $bloggingpro_query->have_posts() ) {
					$related .= '<div class="gmr-related-post gmr-gallery-related-insidepost">';
					$related .= '<div class="widget-title"><strong>' . __( 'Read More', 'bloggingpro' ) . '</strong></div>';
					$related .= '<ul>';
					while ( $bloggingpro_query->have_posts() ) :
						$bloggingpro_query->the_post();
						$featured_image_url = wp_get_attachment_url( get_post_thumbnail_id( $post->ID ) );
						$related           .= '<li>';
							$related       .= '<a href="' . get_permalink() . '" itemprop="url" class="thumb-radius" title="' . the_title_attribute(
								array(
									'before' => __( 'Permalink to: ', 'bloggingpro' ),
									'after'  => '',
									'echo'   => false,
								)
							) . '" rel="bookmark">' . get_the_title() . '</a>';
						$related           .= '</li>';
					endwhile;
					wp_reset_postdata();
					$related .= '</ul>';
					$related .= '</div>';
					$related .= bloggingpro_add_banner_inside_content();
					if ( is_singular( array( 'post' ) ) && in_the_loop() ) {
						$numberp = get_theme_mod( 'gmr_relpost_inline_afterpost', 2 );
						return bloggingpro_helper_after_paragraph( $related, absint( $numberp ), $content );
					}
				}
			}
		}

		return $content;
	}
} /* endif bloggingpro_related_inside_post */
add_filter( 'the_content', 'bloggingpro_related_inside_post', 20 );
