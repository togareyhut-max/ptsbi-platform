<?php
/**
 * Custom functions that act independently of the theme templates.
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package Bloggingpro
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'gmr_body_classes' ) ) :
	/**
	 * Adds custom classes to the array of body classes.
	 *
	 * @since 1.0.0
	 *
	 * @param array $classes Classes for the body element.
	 * @return array
	 */
	function gmr_body_classes( $classes ) {
		$classes[] = 'gmr-theme idtheme kentooz';

		$sticky_menu = get_theme_mod( 'gmr_sticky_menu', 'sticky' );

		/* Disable thumbnail options via customizer */
		$thumbnail = get_theme_mod( 'gmr_active-blogthumb', 0 );

		/* Blog layout */
		$layout = get_theme_mod( 'gmr_layout', 'full-layout' );

		if ( 'box-layout' === $layout ) {
			$classes[] = 'gmr-box-layout';
		}

		if ( 'sticky' === $sticky_menu ) {
			$classes[] = 'gmr-sticky';
		} else {
			$classes[] = 'gmr-no-sticky';
		}

		if ( 0 !== $thumbnail ) {
			$classes[] = 'gmr-disable-thumbnail';
		}

		$layout = get_theme_mod( 'gmr_active-sticky-sidebar', 0 );

		if ( 0 !== $layout ) {
			$classes[] = 'gmr-disable-sticky';
		}

		// Adds a class of group-blog to blogs with more than 1 published author.
		if ( is_multi_author() ) {
			$classes[] = 'group-blog';
		}

		// Adds a class of hfeed to non-singular pages.
		if ( ! is_singular() ) {
			$classes[] = 'hfeed';
		}

		return $classes;
	}
endif; /* endif gmr_body_classes */
add_filter( 'body_class', 'gmr_body_classes' );

if ( ! function_exists( 'gmr_remove_hentry' ) ) :
	/**
	 * Remove Remove 'hentry' from post_class()
	 *
	 * @since 1.0.0
	 *
	 * @param array $classes Classes for the article element.
	 * @return array
	 */
	function gmr_remove_hentry( $classes ) {
		if ( is_page() ) {
			$classes = array_diff( $classes, array( 'hentry' ) );
		}

		return $classes;
	}
endif; /* endif gmr_remove_hentry */
add_filter( 'post_class', 'gmr_remove_hentry' );

if ( ! function_exists( 'gmr_pingback_header' ) ) :
	/**
	 * Add a pingback url auto-discovery header for singularly identifiable articles.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function gmr_pingback_header() {
		if ( is_singular() && pings_open() ) {
			echo '<link rel="pingback" href="', bloginfo( 'pingback_url' ), '">';
		}
	}
endif;
add_action( 'wp_head', 'gmr_pingback_header' );

if ( ! function_exists( 'gmr_add_img_title' ) ) :
	/**
	 * Add a image title tag.
	 *
	 * @since 1.0.0
	 * @param array $attr attribute image.
	 * @param array $attachment returning attacment.
	 * @return array
	 */
	function gmr_add_img_title( $attr, $attachment = null ) {
		$attr['title'] = trim( wp_strip_all_tags( $attachment->post_title ) );
		return $attr;
	}
endif;
add_filter( 'wp_get_attachment_image_attributes', 'gmr_add_img_title', 10, 2 );

if ( ! function_exists( 'gmr_add_title_alt_gravatar' ) ) :
	/**
	 * Add a gravatar title and alt tag.
	 *
	 * @since 1.0.0
	 * @param string $text Text attribute gravatar.
	 * @return string
	 */
	function gmr_add_title_alt_gravatar( $text ) {
		$text = str_replace( 'alt=\'\'', 'alt=\'' . __( 'Gravatar Image', 'bloggingpro' ) . '\' title=\'' . __( 'Gravatar', 'bloggingpro' ) . '\'', $text );
		return $text;
	}
endif;
add_filter( 'get_avatar', 'gmr_add_title_alt_gravatar' );

if ( ! function_exists( 'bloggingpro_helper_after_paragraph' ) ) :
	/**
	 * Helper add content after paragprah
	 *
	 * @since 1.0.0
	 * @link http://stackoverflow.com/questions/25888630/place-ads-in-between-text-only-paragraphs
	 * @param string $insertion String Inserting to Posts.
	 * @param int    $paragraph_id Number of paragraph.
	 * @param string $content Content Posts.
	 * @return string
	 */
	function bloggingpro_helper_after_paragraph( $insertion, $paragraph_id, $content ) {
		if ( is_singular( array( 'post' ) ) && in_the_loop() ) {

			$closing_p = '</p>';

			$paragraphs = explode( $closing_p, wptexturize( $content ) );

			$count = count( $paragraphs );

			foreach ( $paragraphs as $index => $paragraph ) {
				$word_count = count( explode( ' ', $paragraph ) );

				if ( trim( $paragraph ) && $index + 1 === $paragraph_id ) {
					$paragraphs[ $index ] .= $closing_p;
				}
				if ( $index + 1 === $paragraph_id && $count >= 4 ) {
					$paragraphs[ $index ] .= $insertion;
				}
			}
		}
		return implode( '', $paragraphs );
	}
endif; /* endif bloggingpro_helper_after_paragraph */

if ( ! function_exists( 'bloggingpro_itemtype_schema' ) ) :
	/**
	 * Figure out which schema tags to apply to the <article> element
	 * The function determines the itemtype: bloggingpro_itemtype_schema( 'CreativeWork' )
	 *
	 * @since 1.0.0
	 * @param string $type Text attributes for scheme.
	 * @return string
	 */
	function bloggingpro_itemtype_schema( $type = 'CreativeWork' ) {
		$schema = 'http://schema.org/';

		/* Get the itemtype */
		$itemtype = apply_filters( 'bloggingpro_article_itemtype', $type );

		/* Print the results */
		$scope = 'itemscope="itemscope" itemtype="' . $schema . $itemtype . '"';
		return $scope;
	}
endif;

if ( ! function_exists( 'bloggingpro_itemprop_schema' ) ) :
	/**
	 * Figure out which schema tags itemprop=""
	 * The function determines the itemprop: bloggingpro_itemprop_schema( 'headline' )
	 *
	 * @since 1.0.0
	 * @param string $type Text attributes for scheme.
	 * @return string
	 */
	function bloggingpro_itemprop_schema( $type = 'headline' ) {
		/* Get the itemprop */
		$itemprop = apply_filters( 'bloggingpro_itemprop_filter', $type );

		/* Print the results */
		$scope = 'itemprop="' . $itemprop . '"';
		return $scope;
	}
endif;

if ( ! function_exists( 'bloggingpro_head_script' ) ) :
	/**
	 * Insert script in head section
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function bloggingpro_head_script() {
		$ampheadscript = get_theme_mod( 'gmr_head_script_amp' );
		$headscript    = get_theme_mod( 'gmr_head_script' );
		if ( bloggingpro_is_amp() ) {
			if ( isset( $ampheadscript ) && ! empty( $ampheadscript ) ) {
				echo $ampheadscript; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
		} else {
			if ( isset( $headscript ) && ! empty( $headscript ) ) {
				echo $headscript; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
		}
	}
endif; /* endif bloggingpro_head_script */
add_action( 'wp_head', 'bloggingpro_head_script' );

if ( ! function_exists( 'bloggingpro_footer_script' ) ) :
	/**
	 * Insert script in footer section
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function bloggingpro_footer_script() {
		$ampfooterscript = get_theme_mod( 'gmr_footer_script_amp' );
		$footerscript    = get_theme_mod( 'gmr_footer_script' );
		if ( bloggingpro_is_amp() ) {
			if ( isset( $ampfooterscript ) && ! empty( $ampfooterscript ) ) {
				echo $ampfooterscript; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
		} else {
			if ( isset( $footerscript ) && ! empty( $footerscript ) ) {
				echo $footerscript; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
		}
	}
endif; /* endif bloggingpro_footer_script */
add_action( 'wp_footer', 'bloggingpro_footer_script' );

if ( ! function_exists( 'bloggingpro_facebook_pixel' ) ) :
	/**
	 * Insert facebook pixel script via wp_head hook
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function bloggingpro_facebook_pixel() {
		$fbpixelid = get_theme_mod( 'gmr_pixel' );
		if ( isset( $fbpixelid ) && ! empty( $fbpixelid ) ) {
			if ( bloggingpro_is_amp() ) {
				echo '<amp-pixel src="https://www.facebook.com/tr?id=' . esc_attr( $fbpixelid ) . '&ev=PageView&noscript=1" layout="nodisplay"></amp-pixel>';
			} else {
				echo '
				<!-- Facebook Pixel -->
				<script>
				!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
				n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
				n.push=n;n.loaded=!0;n.version=\'2.0\';n.queue=[];t=b.createElement(e);t.async=!0;
				t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
				document,\'script\',\'https://connect.facebook.net/en_US/fbevents.js\');

				fbq(\'init\', \'' . esc_attr( $fbpixelid ) . '\');
				fbq(\'track\', "PageView");</script>
				<noscript><img height="1" width="1" style="display:none"
				src="https://www.facebook.com/tr?id=' . esc_attr( $fbpixelid ) . '&ev=PageView&noscript=1"
				/></noscript>';
			}
		}
	}
endif; /* endif bloggingpro_facebook_pixel */
add_action( 'wp_head', 'bloggingpro_facebook_pixel', 10 );

if ( ! function_exists( 'bloggingpro_google_analytic' ) ) :
	/**
	 * Insert google analytics script via wp_footer hook
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function bloggingpro_google_analytic() {
		$analyticid = get_theme_mod( 'gmr_analytic' );
		if ( isset( $analyticid ) && ! empty( $analyticid ) ) {
			if ( bloggingpro_is_amp() ) {
				echo '<amp-analytics type="gtag" data-credentials="include">
				<script type="application/json">
				{
				  "vars" : {
					"gtag_id": "' . esc_attr( $analyticid ) . '",
					"config" : {
					  "' . esc_attr( $analyticid ) . '": { "groups": "default" }
					}
				  }
				}
				</script>
				</amp-analytics>
				';
			} else {
				echo '
				<!-- Google analytics -->
				<script>
					window.dataLayer = window.dataLayer || [];
					function gtag(){dataLayer.push(arguments);}
					gtag(\'js\', new Date());
					gtag(\'config\', \'' . esc_attr( $analyticid ) . '\');
				</script>';
			}
		}
	}
endif; /* endif bloggingpro_google_analytic */
add_action( 'wp_footer', 'bloggingpro_google_analytic', 10 );
