<?php
/**
 * Widget API: Bloggingpro_Mostview class
 *
 * Author: Gian MR - http://www.gianmr.com
 *
 * @package Bloggingpro
 * @subpackage Widgets
 * @since 1.0.0
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Add the Most view widget.
 *
 * @since 1.0.0
 *
 * @see WP_Widget
 */
class Bloggingpro_Mostview extends WP_Widget {
	/**
	 * Sets up a Most view Posts widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function __construct() {
		$widget_ops = array(
			'classname'   => 'bloggingpro-mostview',
			'description' => __( 'Most view posts with thumbnails widget.', 'bloggingpro' ),
		);
		parent::__construct( 'bloggingpro-mostview', __( 'Most view Posts (Bloggingpro)', 'bloggingpro' ), $widget_ops );
	}

	/**
	 * Outputs the content for most view widget.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $args     Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance Settings for most view widget.
	 */
	public function widget( $args, $instance ) {
		global $post;

		/* Base Id Widget */
		$widget_id = $this->id_base . '-' . $this->number;

		/* Category ID */
		$category_ids = ( ! empty( $instance['category_ids'] ) ) ? array_map( 'absint', $instance['category_ids'] ) : array( 0 );

		/* Excerpt Length */
		$number_posts = ( ! empty( $instance['number_posts'] ) ) ? absint( $instance['number_posts'] ) : absint( 5 );

		/* Title Length */
		$title_length = ( ! empty( $instance['title_length'] ) ) ? absint( $instance['title_length'] ) : absint( 40 );

		/* Style */
		$layout_style = ( ! empty( $instance['layout_style'] ) ) ? wp_strip_all_tags( $instance['layout_style'] ) : wp_strip_all_tags( 'style_1' );

		// Link Title.
		$link_title = ( ! empty( $instance['link_title'] ) ) ? esc_url( $instance['link_title'] ) : '';

		/* Popular by date */
		$popular_date = ( isset( $instance['popular_date'] ) ) ? esc_attr( $instance['popular_date'] ) : esc_attr( 'alltime' );

		/* Hide current post */
		$hide_current_post = ( isset( $instance['hide_current_post'] ) ) ? (bool) $instance['hide_current_post'] : false;
		$show_view         = ( isset( $instance['show_view'] ) ) ? (bool) $instance['show_view'] : false;
		$show_thumb        = ( isset( $instance['show_thumb'] ) ) ? (bool) $instance['show_thumb'] : false;

		/* Banner */
		$bannerinfeed = ( ! empty( $instance['bannerinfeed'] ) ) ? $instance['bannerinfeed'] : '';

		/* Title */
		$title = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );

		$layout_style = ( ! empty( $instance['layout_style'] ) ) ? wp_strip_all_tags( $instance['layout_style'] ) : wp_strip_all_tags( 'style_1' );

		echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		if ( $title ) {
			if ( ! empty( $link_title ) ) {
				echo $args['before_title']; /* phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped */
				echo '<a href="' . esc_url( $link_title ) . '" title="' . esc_html__( 'Permalink to: ', 'bloggingpro' ) . esc_html( $title ) . '">';
					echo $title; /* phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped */
				echo '</a>';
				echo $args['after_title']; /* phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped */
			} else {
				echo $args['before_title'] . $title . $args['after_title']; /* phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped */
			}
		}

		/* if 'all categories' was selected ignore other selections of categories */
		if ( in_array( 0, $category_ids, true ) ) {
			$category_ids = array( 0 );
		}

		/* filter the arguments for the Most view widget: */

		/* standard params */
		$query_args = array(
			'posts_per_page'         => $number_posts,
			'no_found_rows'          => true,
			'post_status'            => 'publish',
			/**
			 * Make it fast withour update term cache and cache results
			 * https://thomasgriffin.io/optimize-wordpress-queries/
			 */
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
		);

		$query_args['ignore_sticky_posts'] = true;
		if ( class_exists( 'Post_Views_Counter' ) ) {
			$query_args['orderby'] = 'post_views';
		} else {
			$query_args['orderby']  = 'meta_value_num';
			$query_args['meta_key'] = 'views'; // phpcs:ignore
			$query_args['order']    = 'DESC';
		}

		if ( 'weekly' === $popular_date ) {
			/* Get posts last week */
			$query_args['date_query'] = array(
				array(
					'after' => '1 week ago',
				),
			);
		} elseif ( 'mountly' === $popular_date ) {
			/* Get posts last mount */
			$query_args['date_query'] = array(
				array(
					'after' => '1 month ago',
				),
			);
		} elseif ( 'secondmountly' === $popular_date ) {
			/* Get posts last mount */
			$query_args['date_query'] = array(
				array(
					'after' => '2 months ago',
				),
			);
		} elseif ( 'yearly' === $popular_date ) {
			/* Get posts last mount */
			$query_args['date_query'] = array(
				array(
					'after' => '1 year ago',
				),
			);
		}

		/* add categories param only if 'all categories' was not selected */
		if ( ! in_array( 0, $category_ids, true ) ) {
			$query_args['category__in'] = $category_ids;
		}

		/* exclude current displayed post */
		if ( $hide_current_post ) {
			if ( isset( $post->ID ) && is_singular() ) {
				$query_args['post__not_in'] = array( $post->ID );
			}
		}

		/* run the query: get the latest posts */
		$rp = new WP_Query( apply_filters( 'bloggingpro_mostview_widget_posts_args', $query_args ) );
		if ( 'style_2' === $layout_style ) :
			?>
			<div class="gmr-recentposts-widget">
				<ul>
					<?php
					$count = 0;
					while ( $rp->have_posts() ) :
						$rp->the_post();
						$count++;
						if ( $count <= 1 ) {
							?>
						<li class="listpost-first clearfix">
							<?php
							if ( $show_thumb ) :
								if ( has_post_thumbnail() ) :
									echo '<div class="gmr-rp-image other-content-thumbnail thumb-radius">';
									echo '<a href="' . esc_url( get_permalink() ) . '" itemprop="url" title="';
									the_title_attribute(
										array(
											'before' => __( 'Permalink to: ', 'bloggingpro' ),
											'after'  => '',
										)
									);
									echo '">';
									the_post_thumbnail( 'large' );
									echo '</a>';
									if ( has_post_format( 'gallery' ) ) {
										echo '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 1024 1024"><path d="M864 248H728l-32.4-90.8a32.07 32.07 0 0 0-30.2-21.2H358.6c-13.5 0-25.6 8.5-30.1 21.2L296 248H160c-44.2 0-80 35.8-80 80v456c0 44.2 35.8 80 80 80h704c44.2 0 80-35.8 80-80V328c0-44.2-35.8-80-80-80zm8 536c0 4.4-3.6 8-8 8H160c-4.4 0-8-3.6-8-8V328c0-4.4 3.6-8 8-8h186.7l17.1-47.8l22.9-64.2h250.5l22.9 64.2l17.1 47.8H864c4.4 0 8 3.6 8 8v456zM512 384c-88.4 0-160 71.6-160 160s71.6 160 160 160s160-71.6 160-160s-71.6-160-160-160zm0 256c-53 0-96-43-96-96s43-96 96-96s96 43 96 96s-43 96-96 96z" fill="currentColor"/></svg>';
									} elseif ( has_post_format( 'video' ) ) {
										echo '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 1024 1024"><path fill="currentColor" d="M512 64a448 448 0 1 1 0 896a448 448 0 0 1 0-896zm0 832a384 384 0 0 0 0-768a384 384 0 0 0 0 768zm-48-247.616L668.608 512L464 375.616v272.768zm10.624-342.656l249.472 166.336a48 48 0 0 1 0 79.872L474.624 718.272A48 48 0 0 1 400 678.336V345.6a48 48 0 0 1 74.624-39.936z"/></svg>';
										$h = get_post_meta( $post->ID, '_durh', true );
										$m = get_post_meta( $post->ID, '_durm', true );
										$s = get_post_meta( $post->ID, '_durs', true );
										if ( ! empty( $h ) || ! empty( $m ) || ! empty( $s ) ) {
											echo '<div class="duration">';
											if ( ! empty( $h ) && 0 !== $h ) {
												echo esc_html( str_pad( absint( $h ), 2, '0', STR_PAD_LEFT ) . ':' );
											}
											if ( ! empty( $m ) ) {
												echo esc_html( str_pad( absint( $m ), 2, '0', STR_PAD_LEFT ) . ':' );
											} else {
												echo '00';
											}
											if ( ! empty( $s ) ) {
												echo esc_html( str_pad( absint( $s ), 2, '0', STR_PAD_LEFT ) );
											} else {
												echo '00';
											}
											echo '</div>';
										}
									}
									echo '</div>';
								endif;
							endif;
							?>
							<div class="gmr-rp-content">
								<?php if ( $show_view ) : ?>
									<div class="gmr-metacontent">
										<?php
										/* translators: used between list items, there is a space after the comma */
										$categories_list = get_the_category_list( ', ' );
										$category        = '';
										if ( $categories_list ) {
											$category = '<span class="cat-links-content">' . $categories_list . '</span>';
										}
										echo $category;  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
										if ( class_exists( 'Post_Views_Counter' ) ) {
											$number = pvc_get_post_views( $post->ID );
											echo '<span class="meta-view">' . absint( $number ) . ' ' . esc_html__( 'Views', 'bloggingpro' ) . '</spans>';

										} elseif ( function_exists( 'the_views' ) ) {
											echo '<span class="meta-view">';
												the_views();
											echo '</span>';
										}
										?>
									</div>
								<?php endif; ?>
								<div class="gmr-rp-link">
									<?php
									echo '<a href="' . esc_url( get_permalink() ) . '" itemprop="url" title="';
									the_title_attribute(
										array(
											'before' => __( 'Permalink to: ', 'bloggingpro' ),
											'after'  => '',
										)
									);
									echo '">';
									$post_title = $this->get_the_trimmed_post_title( $title_length );
									if ( $post_title ) {
										echo esc_html( $post_title );
									} else {
										the_title();
									}
									echo '</a>';
									?>
								</div>
							</div>
						</li>
					<?php } else { ?>
						<li class="listpost clearfix">
							<div class="list-table clearfix">
								<div class="table-row">
									<?php
									if ( $show_thumb ) :
										if ( has_post_thumbnail() ) :
											?>
											<div class="table-cell gmr-rp-thumb thumb-radius">
												<?php
												echo '<a href="' . esc_url( get_permalink() ) . '" itemprop="url" title="';
												the_title_attribute(
													array(
														'before' => __( 'Permalink to: ', 'bloggingpro' ),
														'after'  => '',
													)
												);
												echo '">';
												the_post_thumbnail( 'thumbnail' );
												echo '</a>';
												?>
											</div>
											<?php
										endif;
									endif;
									?>
									<div class="table-cell">
										<?php if ( $show_view ) : ?>
											<div class="gmr-metacontent">
												<?php
												/* translators: used between list items, there is a space after the comma */
												$categories_list = get_the_category_list( ', ' );
												$category        = '';
												if ( $categories_list ) {
													$category = '<span class="cat-links-content">' . $categories_list . '</span>';
												}
												echo $category; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
												if ( class_exists( 'Post_Views_Counter' ) ) {
													$number = pvc_get_post_views( $post->ID );
													echo '<span class="meta-view">' . absint( $number ) . ' ' . esc_html__( 'Views', 'bloggingpro' ) . '</spans>';

												} elseif ( function_exists( 'the_views' ) ) {
													echo '<span class="meta-view">';
														the_views();
													echo '</span>';
												}
												?>
											</div>
										<?php endif; ?>
										<div class="gmr-rp-link">
											<?php
											echo '<a href="' . esc_url( get_permalink() ) . '" itemprop="url" title="';
											the_title_attribute(
												array(
													'before' => __( 'Permalink to: ', 'bloggingpro' ),
													'after'  => '',
												)
											);
											echo '">';
											$post_title = $this->get_the_trimmed_post_title( $title_length );
											if ( $post_title ) {
												echo esc_html( $post_title );
											} else {
												the_title();
											}
											echo '</a>';
											?>
										</div>
									</div>
								</div>
							</div>
						</li>
							<?php
							if ( $bannerinfeed ) {
								if ( 1 === $rp->current_post ) {
									echo '<li class="banner">';
										echo do_shortcode( htmlspecialchars_decode( $bannerinfeed ) );
									echo '</li>';

								}
							}
							?>
					<?php } ?>
						<?php
				endwhile;
					wp_reset_postdata();
					?>
				</ul>
			</div>
		<?php elseif ( 'style_3' === $layout_style ) : ?>
			<div class="gmr-recentposts-widget bloggingpro-listnumber thumb-radius">
				<ul>
					<?php
					$count = 0;
					while ( $rp->have_posts() ) :
						$rp->the_post();
						$count++;
						if ( $count <= 1 ) {
							?>
						<li class="listpost-number first clearfix">
							<?php
							if ( $show_thumb ) :
								if ( has_post_thumbnail() ) :
									echo '<div class="gmr-rp-image other-content-thumbnail">';
									echo '<a href="' . esc_url( get_permalink() ) . '" itemprop="url" title="';
									the_title_attribute(
										array(
											'before' => __( 'Permalink to: ', 'bloggingpro' ),
											'after'  => '',
										)
									);
									echo '">';
									the_post_thumbnail( 'large' );
									echo '</a>';

									if ( has_post_format( 'gallery' ) ) {
										echo '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 1024 1024"><path d="M864 248H728l-32.4-90.8a32.07 32.07 0 0 0-30.2-21.2H358.6c-13.5 0-25.6 8.5-30.1 21.2L296 248H160c-44.2 0-80 35.8-80 80v456c0 44.2 35.8 80 80 80h704c44.2 0 80-35.8 80-80V328c0-44.2-35.8-80-80-80zm8 536c0 4.4-3.6 8-8 8H160c-4.4 0-8-3.6-8-8V328c0-4.4 3.6-8 8-8h186.7l17.1-47.8l22.9-64.2h250.5l22.9 64.2l17.1 47.8H864c4.4 0 8 3.6 8 8v456zM512 384c-88.4 0-160 71.6-160 160s71.6 160 160 160s160-71.6 160-160s-71.6-160-160-160zm0 256c-53 0-96-43-96-96s43-96 96-96s96 43 96 96s-43 96-96 96z" fill="currentColor"/></svg>';
									} elseif ( has_post_format( 'video' ) ) {
										echo '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 1024 1024"><path fill="currentColor" d="M512 64a448 448 0 1 1 0 896a448 448 0 0 1 0-896zm0 832a384 384 0 0 0 0-768a384 384 0 0 0 0 768zm-48-247.616L668.608 512L464 375.616v272.768zm10.624-342.656l249.472 166.336a48 48 0 0 1 0 79.872L474.624 718.272A48 48 0 0 1 400 678.336V345.6a48 48 0 0 1 74.624-39.936z"/></svg>';
										$h = get_post_meta( $post->ID, '_durh', true );
										$m = get_post_meta( $post->ID, '_durm', true );
										$s = get_post_meta( $post->ID, '_durs', true );
										if ( ! empty( $h ) || ! empty( $m ) || ! empty( $s ) ) {
											echo '<div class="duration">';
											if ( ! empty( $h ) && 0 !== $h ) {
												echo esc_html( str_pad( absint( $h ), 2, '0', STR_PAD_LEFT ) . ':' );
											}
											if ( ! empty( $m ) ) {
												echo esc_html( str_pad( absint( $m ), 2, '0', STR_PAD_LEFT ) . ':' );
											} else {
												echo '00';
											}
											if ( ! empty( $s ) ) {
												echo esc_html( str_pad( absint( $s ), 2, '0', STR_PAD_LEFT ) );
											} else {
												echo '00';
											}
											echo '</div>';
										}
									}
									echo '</div>';
								endif;
							endif;
							?>
							<div class="rp-number-content">
								<div class="rp-number pull-left"><?php echo esc_html( $count ); ?></div>
								<div class="gmr-rp-content">
									<?php if ( $show_view ) : ?>
										<div class="gmr-metacontent">
											<?php
											/* translators: used between list items, there is a space after the comma */
											$categories_list = get_the_category_list( ', ' );
											$category        = '';
											if ( $categories_list ) {
												$category = '<span class="cat-links-content">' . $categories_list . '</span>';
											}
											echo $category; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

											if ( class_exists( 'Post_Views_Counter' ) ) {
												$number = pvc_get_post_views( $post->ID );
												echo '<span class="meta-view">' . absint( $number ) . ' ' . esc_html__( 'Views', 'bloggingpro' ) . '</spans>';

											} elseif ( function_exists( 'the_views' ) ) {
												echo '<span class="meta-view">';
													the_views();
												echo '</span>';
											}
											?>
										</div>
									<?php endif; ?>
									<div class="gmr-rp-link">
										<?php
										echo '<a href="' . esc_url( get_permalink() ) . '" itemprop="url" title="';
										the_title_attribute(
											array(
												'before' => __( 'Permalink to: ', 'bloggingpro' ),
												'after'  => '',
											)
										);
										echo '">';
										$post_title = $this->get_the_trimmed_post_title( $title_length );
										if ( $post_title ) {
											echo esc_html( $post_title );
										} else {
											the_title();
										}
										echo '</a>';
										?>
									</div>
								</div>
							</div>
						</li>
					<?php } else { ?>
						<li class="listpost-number clearfix">
							<div class="rp-number-content">
								<div class="rp-number pull-left"><?php echo esc_html( $count ); ?></div>
								<div class="gmr-rp-content">
									<?php if ( $show_view ) : ?>
										<div class="gmr-metacontent">
											<?php
											/* translators: used between list items, there is a space after the comma */
											$categories_list = get_the_category_list( ', ' );
											$category        = '';
											if ( $categories_list ) {
												$category = '<span class="cat-links-content">' . $categories_list . '</span>';
											}
											echo $category;  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
											if ( class_exists( 'Post_Views_Counter' ) ) {
												$number = pvc_get_post_views( $post->ID );
												echo '<span class="meta-view">' . absint( $number ) . ' ' . esc_html__( 'Views', 'bloggingpro' ) . '</spans>';

											} elseif ( function_exists( 'the_views' ) ) {
												echo '<span class="meta-view">';
													the_views();
												echo '</span>';
											}
											?>
										</div>
									<?php endif; ?>
									<div class="gmr-rp-link clearfix">
										<?php
										echo '<a href="' . esc_url( get_permalink() ) . '" itemprop="url" title="';
										the_title_attribute(
											array(
												'before' => __( 'Permalink to: ', 'bloggingpro' ),
												'after'  => '',
											)
										);
										echo '">';
										$post_title = $this->get_the_trimmed_post_title( $title_length );
										if ( $post_title ) {
											echo esc_html( $post_title );
										} else {
											the_title();
										}
										echo '</a>';
										?>
									</div>
								</div>
							</div>
						</li>
							<?php
							if ( $bannerinfeed ) {
								if ( 1 === $rp->current_post ) {
									echo '<li class="banner">';
										echo do_shortcode( htmlspecialchars_decode( $bannerinfeed ) );
									echo '</li>';

								}
							}
							?>
					<?php } ?>
						<?php
				endwhile;
					wp_reset_postdata();
					?>
				</ul>
			</div>
		<?php elseif ( 'style_4' === $layout_style ) : ?>
			<div class="gmr-recentposts-widget">
				<ul>
					<?php
					while ( $rp->have_posts() ) :
						$rp->the_post();
						?>
						<li class="listpost-gallery clearfix">
							<div class="gmr-rp-image thumb-radius">
								<?php
								echo '<a href="' . esc_url( get_permalink() ) . '" itemprop="url" title="';
								the_title_attribute(
									array(
										'before' => __( 'Permalink to: ', 'bloggingpro' ),
										'after'  => '',
									)
								);
								echo '">';
								if ( $show_thumb ) :
									if ( has_post_thumbnail() ) :
										the_post_thumbnail( 'large' );
									endif;
								endif;
								echo '<div class="bg-gradient"></div>';
								echo '</a>';
								if ( has_post_format( 'gallery' ) ) {
									echo '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 1024 1024"><path d="M864 248H728l-32.4-90.8a32.07 32.07 0 0 0-30.2-21.2H358.6c-13.5 0-25.6 8.5-30.1 21.2L296 248H160c-44.2 0-80 35.8-80 80v456c0 44.2 35.8 80 80 80h704c44.2 0 80-35.8 80-80V328c0-44.2-35.8-80-80-80zm8 536c0 4.4-3.6 8-8 8H160c-4.4 0-8-3.6-8-8V328c0-4.4 3.6-8 8-8h186.7l17.1-47.8l22.9-64.2h250.5l22.9 64.2l17.1 47.8H864c4.4 0 8 3.6 8 8v456zM512 384c-88.4 0-160 71.6-160 160s71.6 160 160 160s160-71.6 160-160s-71.6-160-160-160zm0 256c-53 0-96-43-96-96s43-96 96-96s96 43 96 96s-43 96-96 96z" fill="currentColor"/></svg>';
								} elseif ( has_post_format( 'video' ) ) {
									echo '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 1024 1024"><path fill="currentColor" d="M512 64a448 448 0 1 1 0 896a448 448 0 0 1 0-896zm0 832a384 384 0 0 0 0-768a384 384 0 0 0 0 768zm-48-247.616L668.608 512L464 375.616v272.768zm10.624-342.656l249.472 166.336a48 48 0 0 1 0 79.872L474.624 718.272A48 48 0 0 1 400 678.336V345.6a48 48 0 0 1 74.624-39.936z"/></svg>';
									$h = get_post_meta( $post->ID, '_durh', true );
									$m = get_post_meta( $post->ID, '_durm', true );
									$s = get_post_meta( $post->ID, '_durs', true );
									if ( ! empty( $h ) || ! empty( $m ) || ! empty( $s ) ) {
										echo '<div class="duration">';
										if ( ! empty( $h ) && 0 !== $h ) {
											echo esc_html( str_pad( absint( $h ), 2, '0', STR_PAD_LEFT ) . ':' );
										}
										if ( ! empty( $m ) ) {
											echo esc_html( str_pad( absint( $m ), 2, '0', STR_PAD_LEFT ) . ':' );
										} else {
											echo '00';
										}
										if ( ! empty( $s ) ) {
											echo esc_html( str_pad( absint( $s ), 2, '0', STR_PAD_LEFT ) );
										} else {
											echo '00';
										}
										echo '</div>';
									}
								}
								?>
								<div class="gmr-rp-content">
									<?php if ( $show_view ) : ?>
										<div class="gmr-metacontent">
											<?php
											/* translators: used between list items, there is a space after the comma */
											$categories_list = get_the_category_list( ', ' );
											$category        = '';
											if ( $categories_list ) {
												$category = '<span class="cat-links-content">' . $categories_list . '</span>';
											}
											echo $category; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
											if ( class_exists( 'Post_Views_Counter' ) ) {
												$number = pvc_get_post_views( $post->ID );
												echo '<span class="meta-view">' . absint( $number ) . ' ' . esc_html__( 'Views', 'bloggingpro' ) . '</spans>';

											} elseif ( function_exists( 'the_views' ) ) {
												echo '<span class="meta-view">';
													the_views();
												echo '</span>';
											}
											?>
										</div>
									<?php endif; ?>
									<div class="gmr-rp-link clearfix">
										<?php
										echo '<a href="' . esc_url( get_permalink() ) . '" itemprop="url" title="';
										the_title_attribute(
											array(
												'before' => __( 'Permalink to: ', 'bloggingpro' ),
												'after'  => '',
											)
										);
										echo '">';
										$post_title = $this->get_the_trimmed_post_title( $title_length );
										if ( $post_title ) {
											echo esc_html( $post_title );
										} else {
											the_title();
										}
										echo '</a>';
										?>
									</div>
								</div>
							</div>
						</li>
						<?php
						if ( $bannerinfeed ) {
							if ( 1 === $rp->current_post ) {
								echo '<li class="banner">';
									echo do_shortcode( htmlspecialchars_decode( $bannerinfeed ) );
								echo '</li>';

							}
						}
					endwhile;
					wp_reset_postdata();
					?>
				</ul>
			</div>

		<?php else : ?>

			<div class="gmr-recentposts-widget">
				<ul>
					<?php
					while ( $rp->have_posts() ) :
						$rp->the_post();
						echo '<li class="listpost clearfix">';
						?>
							<div class="list-table clearfix">
								<div class="table-row">
									<?php
									if ( $show_thumb ) :
										if ( has_post_thumbnail() ) :
											?>
											<div class="table-cell gmr-rp-thumb thumb-radius">
												<?php
												echo '<a href="' . esc_url( get_permalink() ) . '" itemprop="url" title="';
												the_title_attribute(
													array(
														'before' => __( 'Permalink to: ', 'bloggingpro' ),
														'after'  => '',
													)
												);
												echo '">';
												the_post_thumbnail( 'thumbnail' );
												echo '</a>';
												?>
											</div>
											<?php
										endif;
									endif;
									?>
									<div class="table-cell">
										<?php if ( $show_view ) : ?>
											<div class="gmr-metacontent">
												<?php
												/* translators: used between list items, there is a space after the comma */
												$categories_list = get_the_category_list( ', ' );
												$category        = '';
												if ( $categories_list ) {
													$category = '<span class="cat-links-content">' . $categories_list . '</span>';
												}
												echo $category;  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
												if ( class_exists( 'Post_Views_Counter' ) ) {
													$number = pvc_get_post_views( $post->ID );
													echo '<span class="meta-view">' . absint( $number ) . ' ' . esc_html__( 'Views', 'bloggingpro' ) . '</spans>';

												} elseif ( function_exists( 'the_views' ) ) {
													echo '<span class="meta-view">';
														the_views();
													echo '</span>';
												}
												?>
											</div>
										<?php endif; ?>
										<div class="gmr-rp-link">
											<?php
											echo '<a href="' . esc_url( get_permalink() ) . '" itemprop="url" title="';
											the_title_attribute(
												array(
													'before' => __( 'Permalink to: ', 'bloggingpro' ),
													'after'  => '',
												)
											);
											echo '">';
											$post_title = $this->get_the_trimmed_post_title( $title_length );
											if ( $post_title ) {
												echo esc_html( $post_title );
											} else {
												the_title();
											}
											echo '</a>';
											?>
										</div>
									</div>
								</div>
							</div>
						<?php
						echo '</li>';
						if ( $bannerinfeed ) {
							if ( 1 === $rp->current_post ) {
								echo '<li class="banner">';
									echo do_shortcode( htmlspecialchars_decode( $bannerinfeed ) );
								echo '</li>';

							}
						}
					endwhile;
					wp_reset_postdata();
					?>
				</ul>
			</div>
			<?php
		endif;
		echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Handles updating settings for the current most view widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            Bloggingpro_Mostview::form().
	 * @param array $old_instance Old settings for this instance.
	 * @return array Updated settings to save.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance     = $old_instance;
		$new_instance = wp_parse_args(
			(array) $new_instance,
			array(
				'title'             => '',
				'link_title'        => '',
				'category_ids'      => array( 0 ),
				'layout_style'      => 'style_1',
				'number_posts'      => 5,
				'title_length'      => 40,
				'hide_current_post' => false,
				'popular_date'      => 'alltime',
				'show_view'         => false,
				'show_thumb'        => false,
				'bannerinfeed'      => '',
			)
		);
		/* Title */
		$instance['title'] = sanitize_text_field( $new_instance['title'] );

		// Link Title.
		$instance['link_title'] = esc_url( $new_instance['link_title'] );

		/* Category IDs */
		$instance['category_ids'] = array_map( 'absint', $new_instance['category_ids'] );

		/* Style */
		$instance['layout_style'] = wp_strip_all_tags( $new_instance['layout_style'] );

		/* Number posts */
		$instance['number_posts'] = absint( $new_instance['number_posts'] );

		/* Title Length */
		$instance['title_length'] = absint( $new_instance['title_length'] );

		/* Hide current post */
		$instance['hide_current_post'] = (bool) $new_instance['hide_current_post'];

		/* Popular range */
		$instance['popular_date'] = esc_attr( $new_instance['popular_date'] );

		/* Show element */
		$instance['show_view']  = (bool) $new_instance['show_view'];
		$instance['show_thumb'] = (bool) $new_instance['show_thumb'];

		/* In feed banner */
		$instance['bannerinfeed'] = $new_instance['bannerinfeed'];

		/* if 'all categories' was selected ignore other selections of categories */
		if ( in_array( 0, $instance['category_ids'], true ) ) {
			$instance['category_ids'] = array( 0 );
		}
		return $instance;
	}

	/**
	 * Outputs the settings form for the most view widget.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $instance Current settings.
	 */
	public function form( $instance ) {
		$instance = wp_parse_args(
			(array) $instance,
			array(
				'title'             => __( 'Most View', 'bloggingpro' ),
				'link_title'        => '',
				'category_ids'      => array( 0 ),
				'layout_style'      => 'style_1',
				'number_posts'      => 5,
				'title_length'      => 40,
				'hide_current_post' => false,
				'popular_date'      => 'alltime',
				'show_view'         => true,
				'show_thumb'        => true,
				'bannerinfeed'      => '',
			)
		);
		/* Title */
		$title = sanitize_text_field( $instance['title'] );

		// Link Title.
		$link_title = esc_url( $instance['link_title'] );

		/* Category ID */
		$category_ids = array_map( 'absint', $instance['category_ids'] );

		/* Style */
		$layout_style = wp_strip_all_tags( $instance['layout_style'] );

		/* Number posts */
		$number_posts = absint( $instance['number_posts'] );

		/* Title Length */
		$title_length = absint( $instance['title_length'] );

		/* Hide current post */
		$hide_current_post = (bool) $instance['hide_current_post'];

		/* Popular range */
		$popular_date = esc_attr( $instance['popular_date'] );

		/* Show element */
		$show_view  = (bool) $instance['show_view'];
		$show_thumb = (bool) $instance['show_thumb'];

		/* In feed banner */
		$bannerinfeed = $instance['bannerinfeed'];

		/* get categories */
		$categories     = get_categories(
			array(
				'hide_empty'   => 0,
				'hierarchical' => 1,
			)
		);
		$number_of_cats = count( $categories );

		/* get size (number of rows to display) of selection box: not more than 10 */
		$number_of_rows = ( 10 > $number_of_cats ) ? $number_of_cats + 1 : 10;

		/* if 'all categories' was selected ignore other selections of categories */
		if ( in_array( 0, $category_ids, true ) ) {
			$category_ids = array( 0 );
		}

		/* start selection box */
		$selection_category  = sprintf(
			'<select name="%s[]" id="%s" class="cat-select widefat" multiple size="%d">',
			$this->get_field_name( 'category_ids' ),
			$this->get_field_id( 'category_ids' ),
			$number_of_rows
		);
		$selection_category .= "\n";

		/* make selection box entries */
		$cat_list = array();
		if ( 0 < $number_of_cats ) {

			/* make a hierarchical list of categories */
			while ( $categories ) {
				/* if there is no parent */
				if ( 0 === $categories[0]->parent ) {
					/* get and remove it from the categories list */
					$current_entry = array_shift( $categories );
					/* append the current entry to the new list */
					$cat_list[] = array(
						'id'    => absint( $current_entry->term_id ),
						'name'  => esc_html( $current_entry->name ),
						'depth' => 0,
					);
					/* go on looping */
					continue;
				}
				/**
				 * If there is a parent:
				 * try to find parent in new list and get its array index
				 */
				$parent_index = $this->get_cat_parent_index( $cat_list, $categories[0]->parent );
				/* if parent is not yet in the new list: try to find the parent later in the loop */
				if ( false === $parent_index ) {
					/* get and remove current entry from the categories list */
					$current_entry = array_shift( $categories );
					/* append it at the end of the categories list */
					$categories[] = $current_entry;
					/* go on looping */
					continue;
				}
				/**
				 * If there is a parent and parent is in new list:
				 * set depth of current item: +1 of parent's depth
				 */
				$depth = $cat_list[ $parent_index ]['depth'] + 1;
				/* set new index as next to parent index */
				$new_index = $parent_index + 1;
				/* find the correct index where to insert the current item */
				foreach ( $cat_list as $entry ) {
					/* if there are items with same or higher depth than current item */
					if ( $depth <= $entry['depth'] ) {
						/* increase new index */
						$new_index = $new_index++;
						/* go on looping in foreach() */
						continue;
					}
					/**
					 * If the correct index is found:
					 * get current entry and remove it from the categories list
					 */
					$current_entry = array_shift( $categories );

					/* insert current item into the new list at correct index */
					$end_array  = array_splice( $cat_list, $new_index ); /* $cat_list is changed, too */
					$cat_list[] = array(
						'id'    => absint( $current_entry->term_id ),
						'name'  => esc_html( $current_entry->name ),
						'depth' => $depth,
					);
					$cat_list   = array_merge( $cat_list, $end_array );
					/* quit foreach(), go on while-looping */
					break;
				} /* End foreach( cat_list ) */
			} /* End while( categories ) */

			/* make HTML of selection box */
			$selected            = ( in_array( 0, $category_ids, true ) ) ? ' selected="selected"' : '';
			$selection_category .= "\t";
			$selection_category .= '<option value="0"' . $selected . '>' . __( 'All Categories', 'bloggingpro' ) . '</option>';
			$selection_category .= "\n";

			foreach ( $cat_list as $category ) {
				$cat_name            = apply_filters( 'gmr_list_cats', $category['name'], $category );
				$pad                 = ( 0 < $category['depth'] ) ? str_repeat( '&ndash;&nbsp;', $category['depth'] ) : '';
				$selection_category .= "\t";
				$selection_category .= '<option value="' . $category['id'] . '"';
				$selection_category .= ( in_array( $category['id'], $category_ids, true ) ) ? ' selected="selected"' : '';
				$selection_category .= '>' . $pad . $cat_name . '</option>';
				$selection_category .= "\n";
			}
		}

		/* close selection box */
		$selection_category .= "</select>\n";
		?>

		<p>
			<label for="<?php echo esc_html( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'bloggingpro' ); ?></label>
			<input class="widefat" id="<?php echo esc_html( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_html( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_html( $this->get_field_id( 'link_title' ) ); ?>"><?php esc_html_e( 'Link Title:', 'bloggingpro' ); ?></label>
			<input class="widefat" id="<?php echo esc_html( $this->get_field_id( 'link_title' ) ); ?>" name="<?php echo esc_html( $this->get_field_name( 'link_title' ) ); ?>" type="url" value="<?php echo esc_attr( $link_title ); ?>" />
			<br />
			<small><?php esc_html_e( 'Target url for title (example: http://www.domain.com/target), leave blank if you want using title without link.', 'bloggingpro' ); ?></small>
		</p>
		<p>
			<label for="<?php echo esc_html( $this->get_field_id( 'category_ids' ) ); ?>"><?php esc_html_e( 'Selected categories', 'bloggingpro' ); ?></label>
			<?php echo $selection_category;   // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<br />
			<small><?php esc_html_e( 'Click on the categories with pressed CTRL key to select multiple categories. If All Categories was selected then other selections will be ignored.', 'bloggingpro' ); ?></small>
		</p>
		<p>
			<label for="<?php echo esc_html( $this->get_field_id( 'number_posts' ) ); ?>"><?php esc_html_e( 'Number post', 'bloggingpro' ); ?></label>
			<input class="widefat" id="<?php echo esc_html( $this->get_field_id( 'number_posts' ) ); ?>" name="<?php echo esc_html( $this->get_field_name( 'number_posts' ) ); ?>" type="number" value="<?php echo esc_attr( $number_posts ); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_html( $this->get_field_id( 'layout_style' ) ); ?>"><?php esc_html_e( 'Style', 'bloggingpro' ); ?></label>
			<select class="widefat" id="<?php echo esc_html( $this->get_field_id( 'layout_style', 'bloggingpro' ) ); ?>" name="<?php echo esc_html( $this->get_field_name( 'layout_style' ) ); ?>">
				<option value="style_1" <?php echo selected( $instance['layout_style'], 'style_1', false ); ?>><?php esc_html_e( 'List Thumbnail', 'bloggingpro' ); ?></option>
				<option value="style_2" <?php echo selected( $instance['layout_style'], 'style_2', false ); ?>><?php esc_html_e( 'List Thumbnail With 1 Big Thumbnail', 'bloggingpro' ); ?></option>
				<option value="style_3" <?php echo selected( $instance['layout_style'], 'style_3', false ); ?>><?php esc_html_e( 'List Number With 1 Big Thumbnail', 'bloggingpro' ); ?></option>
				<option value="style_4" <?php echo selected( $instance['layout_style'], 'style_4', false ); ?>><?php esc_html_e( 'List Gallery', 'bloggingpro' ); ?></option>
			</select>
		</p>
		<p>
			<label for="<?php echo esc_html( $this->get_field_id( 'popular_date' ) ); ?>"><?php esc_html_e( 'Popular range:', 'bloggingpro' ); ?></label>
			<select class="widefat" id="<?php echo esc_html( $this->get_field_id( 'popular_date', 'bloggingpro' ) ); ?>" name="<?php echo esc_html( $this->get_field_name( 'popular_date' ) ); ?>">
				<option value="alltime" <?php selected( $instance['popular_date'], 'alltime' ); ?>><?php esc_html_e( 'Alltime', 'bloggingpro' ); ?></option>
				<option value="yearly" <?php selected( $instance['popular_date'], 'yearly' ); ?>><?php esc_html_e( '1 Year', 'bloggingpro' ); ?></option>
				<option value="secondmountly" <?php selected( $instance['popular_date'], 'secondmountly' ); ?>><?php esc_html_e( '2 Mounts', 'bloggingpro' ); ?></option>
				<option value="mountly" <?php selected( $instance['popular_date'], 'mountly' ); ?>><?php esc_html_e( '1 Mount', 'bloggingpro' ); ?></option>
				<option value="weekly" <?php selected( $instance['popular_date'], 'weekly' ); ?>><?php esc_html_e( '7 Days', 'bloggingpro' ); ?></option>
			</select>
			<br/>
			<small><?php esc_html_e( 'Select popular by most view.', 'bloggingpro' ); ?></small>
		</p>
		<p>
			<label for="<?php echo esc_html( $this->get_field_id( 'title_length' ) ); ?>"><?php esc_html_e( 'Maximum length of title', 'bloggingpro' ); ?></label>
			<input class="widefat" id="<?php echo esc_html( $this->get_field_id( 'title_length' ) ); ?>" name="<?php echo esc_html( $this->get_field_name( 'title_length' ) ); ?>" type="number" value="<?php echo esc_attr( $title_length ); ?>" />
		</p>
		<p>
			<input class="checkbox" type="checkbox" <?php checked( $hide_current_post ); ?> id="<?php echo esc_html( $this->get_field_id( 'hide_current_post' ) ); ?>" name="<?php echo esc_html( $this->get_field_name( 'hide_current_post' ) ); ?>" />
			<label for="<?php echo esc_html( $this->get_field_id( 'hide_current_post' ) ); ?>"><?php esc_html_e( 'Do not list the current post?', 'bloggingpro' ); ?></label>
		</p>
		<p>
			<input class="checkbox" type="checkbox" <?php checked( $show_view ); ?> id="<?php echo esc_html( $this->get_field_id( 'show_view' ) ); ?>" name="<?php echo esc_html( $this->get_field_name( 'show_view' ) ); ?>" />
			<label for="<?php echo esc_html( $this->get_field_id( 'show_view' ) ); ?>"><?php esc_html_e( 'Show Meta Post?', 'bloggingpro' ); ?></label>
		</p>
		<p>
			<input class="checkbox" type="checkbox" <?php checked( $show_thumb ); ?> id="<?php echo esc_html( $this->get_field_id( 'show_thumb' ) ); ?>" name="<?php echo esc_html( $this->get_field_name( 'show_thumb' ) ); ?>" />
			<label for="<?php echo esc_html( $this->get_field_id( 'show_thumb' ) ); ?>"><?php esc_html_e( 'Show Thumbnail?', 'bloggingpro' ); ?></label>
		</p>
		<p>
			<label for="<?php echo esc_html( $this->get_field_id( 'bannerinfeed' ) ); ?>"><?php esc_html_e( 'Banner After First Post:', 'bloggingpro' ); ?></label>
			<textarea class="widefat" rows="6" id="<?php echo esc_html( $this->get_field_id( 'bannerinfeed' ) ); ?>" name="<?php echo esc_html( $this->get_field_name( 'bannerinfeed' ) ); ?>"><?php echo esc_textarea( $instance['bannerinfeed'] ); ?></textarea>
		</p>
		<?php
	}

	/**
	 * Return the array index of a given ID
	 *
	 * @since 1.0.0
	 * @param array $arr Array.
	 * @param int   $id Post ID.
	 * @access private
	 */
	private function get_cat_parent_index( $arr, $id ) {
		$len = count( $arr );
		if ( 0 === $len ) {
			return false;
		}
		$id = absint( $id );
		for ( $i = 0; $i < $len; $i++ ) {
			if ( $id === $arr[ $i ]['id'] ) {
				return $i;
			}
		}
		return false;
	}

	/**
	 * Returns the shortened post title, must use in a loop.
	 *
	 * @since 1.0.0
	 * @param int    $len Number text to display.
	 * @param string $more Text Button.
	 * @return string.
	 */
	private function get_the_trimmed_post_title( $len = 40, $more = '&hellip;' ) {

		/* get current post's post_title */
		$post_title = get_the_title();

		/* if post_title is longer than desired */
		if ( mb_strlen( $post_title ) > $len ) {
			/* get post_title in desired length */
			$post_title = mb_substr( $post_title, 0, $len );
			/* append ellipses */
			$post_title .= $more;
		}
		/* return text */
		return $post_title;
	}

}

add_action(
	'widgets_init',
	function() {
		register_widget( 'Bloggingpro_Mostview' );
	}
);
