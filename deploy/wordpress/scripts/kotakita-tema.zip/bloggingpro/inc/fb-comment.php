<?php
/**
 * FB comments template file.
 * This replaces the theme's comment template when fb comments are enable
 *
 * @since 1.0.0
 * @package Bloggingpro
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="gmr-box-content">
	<div id="fb-root"></div>
	<div id="comments" class="gmr-fb-comments">
		<div class="fb-comments" data-href="<?php the_permalink(); ?>" data-lazy="true" data-numposts="5" data-width="100%"></div>
	</div>
</div>
