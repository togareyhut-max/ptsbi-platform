<?php
/**
 * Template part for displaying posts.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Bloggingpro
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* Disable thumbnail options via customizer */
$thumbnail = get_theme_mod( 'gmr_active-singlethumb', 0 );

/* Disable meta data options via customizer */
$metadata = get_theme_mod( 'gmr_active-metasingle', 0 );

$postnav = get_theme_mod( 'gmr_active-postnav', 0 );

$socialshare = get_theme_mod( 'gmr_active-socialshare', 0 );

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?> <?php echo bloggingpro_itemtype_schema( 'CreativeWork' ); /* phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped */ ?>>
	<div class="gmr-box-content gmr-single">
		<header class="entry-header">
			<?php
			the_title( '<h1 class="entry-title" ' . bloggingpro_itemprop_schema( 'headline' ) . '>', '</h1>' );
			echo '<div class="list-table clearfix">';
			echo '<div class="table-row">';
			if ( 0 === $metadata ) :
				echo '<div class="table-cell gmr-gravatar-metasingle">';
					$author_id = $post->post_author;
					echo '<a class="url" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '" title="' . esc_html__( 'Permalink to: ', 'bloggingpro' ) . esc_html( get_the_author() ) . '" ' . bloggingpro_itemprop_schema( 'url' ) /* phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped */ . '>';
						echo get_avatar( get_the_author_meta( 'user_email', $author_id ), '40', '', '', array( 'class' => 'img-cicle' ) );
					echo '</a>';
				echo '</div>';
				echo '<div class="table-cell gmr-content-metasingle">';
					gmr_posted_on();
				echo '</div>';
			endif;
			if ( 0 === $socialshare ) {
				echo '<div class="table-cell gmr-content-share">';
					echo '<div class="pull-right">';
						do_action( 'bloggingpro_add_share_the_content' );
					echo '</div>';
				echo '</div>';
			}
			echo '</div>';
			echo '</div>';
			?>
		</header><!-- .entry-header -->

		<?php
		/* custom field using oembed https://codex.wordpress.org/Embeds */
		$oembed = get_post_meta( $post->ID, 'MAJPRO_Oembed', true );
		$iframe = get_post_meta( $post->ID, 'MAJPRO_Iframe', true );

		if ( ! empty( $oembed ) ) {
			echo '<div class="gmr-embed-responsive gmr-embed-responsive-16by9 single-thumbnail">';
			echo wp_oembed_get( $oembed );  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo '</div>';

		} elseif ( ! empty( $iframe ) ) {
			echo '<div class="gmr-embed-responsive gmr-embed-responsive-16by9 single-thumbnail">';
			$var = do_shortcode( $iframe );
			echo $var;  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo '</div>';

		} else {
			if ( 0 === $thumbnail ) :
				if ( has_post_thumbnail() ) {
					?>
					<figure class="wp-caption alignnone single-thumbnail">
						<?php the_post_thumbnail( 'full' ); ?>

						<?php
						$caption = get_post( get_post_thumbnail_id() )->post_excerpt;
						if ( $caption ) :
							?>
							<figcaption class="wp-caption-textmain"><?php echo esc_html( $caption ); ?></figcaption>
						<?php endif; ?>
					</figure>
					<?php
				}
			endif; /* end $thumbnail */
		}
		?>
		<div class="entry-content entry-content-single" <?php echo bloggingpro_itemprop_schema( 'text' ); /* phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped */ ?>>
			<div class="entry-main-single">
			<?php
			the_content();
			?>
			</div>

			<footer class="entry-footer">
				<?php
				/* translators: used between list items, there is a space after the comma */
				$tags_list = get_the_tag_list();
				if ( $tags_list ) {
					echo '<div class="tags-links">';
					echo $tags_list;  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo '</div>';
				}

				echo '<div class="clearfix">';
					echo '<div class="pull-left">';
						$majpro_source = get_post_meta( $post->ID, 'MAJPRO_Source', true );
						$majpro_writer = get_post_meta( $post->ID, 'MAJPRO_Writer', true );
						$majpro_editor = get_post_meta( $post->ID, 'MAJPRO_Editor', true );
				if ( ! empty( $majpro_writer ) ) {
					echo '<div class="gmr-metacontent-writer">';
					echo esc_attr__( 'Writer: ', 'bloggingpro' ) . esc_attr( $majpro_writer );
					echo '</div>';

				}
				if ( ! empty( $majpro_editor ) ) {
					echo '<div class="gmr-metacontent-editor">';
					echo esc_attr__( 'Editor: ', 'bloggingpro' ) . esc_attr( $majpro_editor );
					echo '</div>';

				}
				if ( ! empty( $majpro_source ) ) {
					echo '<div class="gmr-metacontent-source">';
					echo esc_attr__( 'Source: ', 'bloggingpro' ) . '<a href="' . esc_url( $majpro_source ) . '" target="_blank" rel="nofollow">' . esc_url( $majpro_source ) . '</a>';
					echo '</div>';

				}
					echo '</div>';
				if ( 0 === $socialshare ) {
					echo '<div class="pull-right">';
						echo '<div class="share-text">' . esc_html__( 'Share', 'bloggingpro' ) . '</div>';
						do_action( 'bloggingpro_add_share_the_content' );
					echo '</div>';
				}
				echo '</div>';
				if ( 0 === $postnav ) :
					the_post_navigation(
						array(
							'prev_text' => __( '<span>Previous post</span> %title', 'bloggingpro' ),
							'next_text' => __( '<span>Next post</span> %title', 'bloggingpro' ),
						)
					);
				endif;
				?>
			</footer><!-- .entry-footer -->
		</div><!-- .entry-content -->

	</div><!-- .gmr-box-content -->

	<?php do_action( 'bloggingpro_add_related_post' ); ?>

	<?php do_action( 'bloggingpro_banner_after_relpost' ); ?>

</article><!-- #post-## -->
