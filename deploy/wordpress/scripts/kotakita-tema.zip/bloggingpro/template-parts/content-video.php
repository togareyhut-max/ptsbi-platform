<?php
/**
 * Template part for displaying posts.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Bloggingpro
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* Disable thumbnail options via customizer */
$thumbnail = get_theme_mod( 'gmr_active-blogthumb', 0 );

/* Disable meta data options via customizer */
$metadata = get_theme_mod( 'gmr_active-metaarchive', 0 );

/* Disable excerpt options via customizer */
$excerpt_opsi = get_theme_mod( 'gmr_active-excerptarchive', 0 );

$classes = array(
	'item-content',
	'gmr-box-content',
	'item-infinite',
	'gmr-smallthumb',
	'clearfix',
);

?>

<article id="post-<?php the_ID(); ?>" <?php post_class( $classes ); ?> <?php echo bloggingpro_itemtype_schema( 'CreativeWork' ); /* phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped */ ?>>

	<div class="item-article-video clearfix">
		<?php
		/* translators: used between list items, there is a space after the comma */
		$categories_list = get_the_category_list( ', ' );
		$category        = '';
		if ( $categories_list ) {
			$category = '<span class="cat-links-content">' . $categories_list . '</span>';
		}
		$time_string = '<time class="entry-date published updated" ' . bloggingpro_itemprop_schema( 'dateModified' ) . ' datetime="%1$s">%2$s</time>';
		if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
			$time_string = '<time class="entry-date published" ' . bloggingpro_itemprop_schema( 'datePublished' ) . ' datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
		}

		$time_string = sprintf(
			$time_string,
			esc_attr( get_the_date( 'c' ) ),
			esc_html( get_the_date() ),
			esc_attr( get_the_modified_date( 'c' ) ),
			esc_html( get_the_modified_date() )
		);

		$posted_on = sprintf( '%s', $time_string );

		$posted_by = sprintf(
			'%s',
			'<span class="entry-author vcard screen-reader-text" ' . bloggingpro_itemprop_schema( 'author' ) . ' ' . bloggingpro_itemtype_schema( 'person' ) . '><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '" title="' . __( 'Permalink to: ', 'bloggingpro' ) . esc_html( get_the_author() ) . '" ' . bloggingpro_itemprop_schema( 'url' ) . '><span ' . bloggingpro_itemprop_schema( 'name' ) . '>' . esc_html( get_the_author() ) . '</span></a></span>'
		);
		if ( 0 === $metadata ) {
			echo '<div class="gmr-metacontent">' . $category . $posted_by . '<span class="posted-on byline">' . $posted_on . '</span></div>';  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		?>
		<header class="entry-header">
			<h2 class="entry-title" <?php echo bloggingpro_itemprop_schema( 'headline' ); /* phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped */ ?>>
				<?php
				echo '<a href="' . esc_url( get_permalink() ) . '" ' . bloggingpro_itemprop_schema( 'url' ) /* phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped */ . ' title="';
				the_title_attribute(
					array(
						'before' => __( 'Permalink to: ', 'bloggingpro' ),
						'after'  => '',
					)
				);
				echo '" rel="bookmark">' . esc_html( get_the_title() ) . '</a>';
				?>
			</h2>
		</header><!-- .entry-header -->
	</div><!-- .item-article -->

	<?php if ( is_sticky() ) { ?>
		<kbd class="kbd-sticky"><?php esc_html_e( 'Sticky', 'bloggingpro' ); ?></kbd>
	<?php } ?>


	<?php
	if ( 0 === $thumbnail ) :
		$featured_image_url = wp_get_attachment_url( get_post_thumbnail_id( get_the_ID() ) );
		if ( ! empty( $featured_image_url ) ) :
			echo '<div class="content-thumbnail-video thumb-radius">';
				echo '<a href="' . esc_url( get_permalink() ) . '" itemprop="url" title="';
				the_title_attribute(
					array(
						'before' => __( 'Permalink to: ', 'bloggingpro' ),
						'after'  => '',
						'echo'   => false,
					)
				);
				echo '" rel="bookmark">';
						the_post_thumbnail( 'verylarge' );
				echo '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 1024 1024"><path fill="currentColor" d="M512 64a448 448 0 1 1 0 896a448 448 0 0 1 0-896zm0 832a384 384 0 0 0 0-768a384 384 0 0 0 0 768zm-48-247.616L668.608 512L464 375.616v272.768zm10.624-342.656l249.472 166.336a48 48 0 0 1 0 79.872L474.624 718.272A48 48 0 0 1 400 678.336V345.6a48 48 0 0 1 74.624-39.936z"/></svg>';
				$hrs = get_post_meta( $post->ID, '_durh', true );
				$min = get_post_meta( $post->ID, '_durm', true );
				$sec = get_post_meta( $post->ID, '_durs', true );
			if ( ! empty( $hrs ) || ! empty( $min ) || ! empty( $sec ) ) {
				echo '<div class="duration">';
				if ( ! empty( $hrs ) && 0 !== $hrs ) {
					echo esc_html( str_pad( absint( $hrs ), 2, '0', STR_PAD_LEFT ) . ':' );
				}
				if ( ! empty( $min ) ) {
					echo esc_html( str_pad( absint( $min ), 2, '0', STR_PAD_LEFT ) . ':' );
				} else {
					echo '00';
				}
				if ( ! empty( $sec ) ) {
					echo esc_html( str_pad( absint( $sec ), 2, '0', STR_PAD_LEFT ) );
				} else {
					echo '00';
				}
				echo '</div>';
			}
				echo '<div class="bg-gradient"></div>';
				echo '</a>';
			echo '</div>';
		endif; /* end has_post_thumbnail() */
	endif; /* end $thumbnail */
	?>

</article><!-- #post-## -->
