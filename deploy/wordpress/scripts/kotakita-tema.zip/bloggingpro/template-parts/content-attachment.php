<?php
/**
 * Template part for displaying posts.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Bloggingpro
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* Disable thumbnail options via customizer */
$thumbnail = get_theme_mod( 'gmr_active-singlethumb', 0 );

/* Disable meta data options via customizer */
$metadata = get_theme_mod( 'gmr_active-metasingle', 0 );

$socialshare = get_theme_mod( 'gmr_active-socialshare', 0 );

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?> <?php echo bloggingpro_itemtype_schema( 'CreativeWork' ); /* phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped */ ?>>
	<div class="gmr-box-content gmr-single">
		<header class="entry-header">
			<?php
			the_title( '<h1 class="entry-title" ' . bloggingpro_itemprop_schema( 'headline' ) . '>', '</h1>' );
			echo '<div class="list-table clearfix">';
			echo '<div class="table-row">';
			if ( 0 === $metadata ) :
				echo '<div class="table-cell gmr-gravatar-metasingle">';
					$author_id = $post->post_author;
					echo '<a class="url" href="' . esc_url( get_author_posts_url( get_the_author_meta( $author_id ) ) ) . '" title="' . esc_html__( 'Permalink to: ', 'bloggingpro' ) . esc_html( get_the_author() ) . '" ' . bloggingpro_itemprop_schema( 'url' ) /* phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped */ . '>';
						echo get_avatar( get_the_author_meta( 'user_email', $author_id ), '40', '', '', array( 'class' => 'img-cicle' ) );
					echo '</a>';
				echo '</div>';
				echo '<div class="table-cell gmr-content-metasingle">';
					gmr_posted_on();
				echo '</div>';
			endif;
			if ( 0 === $socialshare ) {
				echo '<div class="table-cell gmr-content-share">';
					echo '<div class="pull-right">';
						do_action( 'bloggingpro_add_share_the_content' );
					echo '</div>';
				echo '</div>';
			}
			echo '</div>';
			echo '</div>';
			?>
		</header><!-- .entry-header -->
		<?php
		$attachments = array_values(
			get_children(
				array(
					'post_parent'    => $post->post_parent,
					'post_status'    => 'inherit',
					'post_type'      => 'attachment',
					'post_mime_type' => 'image',
					'order'          => 'ASC',
					'orderby'        => 'menu_order ID',
				)
			)
		);

		foreach ( $attachments as $k => $attachment ) {
			if ( $attachment->ID === $post->ID ) {
				break;
			}
		}
		$k++;
		if ( count( $attachments ) > 1 ) {
			if ( isset( $attachments[ $k ] ) ) {
				$next_attachment_url = get_attachment_link( $attachments[ $k ]->ID );
			} else {
				$next_attachment_url = get_attachment_link( $attachments[0]->ID );
			}
		} else {
			$next_attachment_url = wp_get_attachment_url();
		}

		if ( wp_attachment_is_image( $post->id ) ) {
			?>
			<figure class="wp-caption alignnone single-thumbnail">
				<a href="<?php echo esc_url( $next_attachment_url ); ?>" title="<?php the_title(); ?>" rel="attachment">
					<?php echo wp_get_attachment_image( $post->ID, 'full' ); // filterable image width with, essentially, no limit for image height. ?>
				</a>
				<?php
				$caption = get_post( get_post_thumbnail_id() )->post_excerpt;
				if ( $caption ) :
					?>
					<figcaption class="wp-caption-textmain"><?php echo esc_html( $caption ); ?></figcaption>
				<?php endif; ?>
			</figure>
			<?php
		}
		?>

		<div class="entry-content entry-content-single" <?php echo bloggingpro_itemprop_schema( 'text' ); /* phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped */ ?>>
			<?php
				the_content();
			?>

			<footer class="entry-footer">
				<?php
				/* translators: used between list items, there is a space after the comma */
				$tags_list = get_the_tag_list();
				if ( $tags_list ) {
					echo '<div class="tags-links">';
					echo $tags_list;  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo '</div>';
				}

				if ( 0 === $socialshare ) {
					echo '<div class="clearfix">';
						echo '<div class="pull-right">';
							echo '<div class="share-text">' . esc_html__( 'Share', 'bloggingpro' ) . '</div>';
							do_action( 'bloggingpro_add_share_the_content' );
						echo '</div>';
					echo '</div>';
				}
				?>
			</footer><!-- .entry-footer -->
		</div><!-- .entry-content -->

	</div><!-- .gmr-box-content -->

	<?php do_action( 'bloggingpro_add_related_post' ); ?>

	<?php do_action( 'bloggingpro_banner_after_relpost' ); ?>

</article><!-- #post-## -->
