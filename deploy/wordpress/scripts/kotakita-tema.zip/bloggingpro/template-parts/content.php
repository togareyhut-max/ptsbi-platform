<?php
/**
 * Template part for displaying posts.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Bloggingpro
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* Disable thumbnail options via customizer */
$thumbnail = get_theme_mod( 'gmr_active-blogthumb', 0 );

/* Disable meta data options via customizer */
$metadata = get_theme_mod( 'gmr_active-metaarchive', 0 );

/* Disable excerpt options via customizer */
$excerpt_opsi = get_theme_mod( 'gmr_active-excerptarchive', 0 );

$classes = array(
	'item-content',
	'gmr-box-content',
	'item-infinite',
	'gmr-smallthumb',
	'clearfix',
);

?>

<article id="post-<?php the_ID(); ?>" <?php post_class( $classes ); ?> <?php echo bloggingpro_itemtype_schema( 'CreativeWork' ); /* phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped */ ?>>
	<?php
	/* Add thumnail */
	if ( 0 === $thumbnail ) :
		if ( has_post_thumbnail() ) :
			echo '<div class="pull-left content-thumbnail thumb-radius">';
				echo '<a href="' . esc_url( get_permalink() ) . '" itemprop="url" title="';
				the_title_attribute(
					array(
						'before' => __( 'Permalink to: ', 'bloggingpro' ),
						'after'  => '',
						'echo'   => false,
					)
				);
				echo '" rel="bookmark">';
					the_post_thumbnail( 'medium' );
				echo '</a>';
			echo '</div>';
		endif; /* end has_post_thumbnail() */
	endif; /* end $thumbnail */
	?>
	<div class="item-article">
		<?php
		/* translators: used between list items, there is a space after the comma */
		$categories_list = get_the_category_list( ', ' );
		$category        = '';
		if ( $categories_list ) {
			$category = '<span class="cat-links-content">' . $categories_list . '</span>'; // WPCS: XSS OK.
		}
		$time_string = '<time class="entry-date published updated" ' . bloggingpro_itemprop_schema( 'dateModified' ) . ' datetime="%1$s">%2$s</time>';
		if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
			$time_string = '<time class="entry-date published" ' . bloggingpro_itemprop_schema( 'datePublished' ) . ' datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
		}

		$time_string = sprintf(
			$time_string,
			esc_attr( get_the_date( 'c' ) ),
			esc_html( get_the_date() ),
			esc_attr( get_the_modified_date( 'c' ) ),
			esc_html( get_the_modified_date() )
		);

		$posted_on = sprintf( '%s', $time_string );

		$posted_by = sprintf(
			'%s',
			'<span class="entry-author vcard screen-reader-text" ' . bloggingpro_itemprop_schema( 'author' ) . ' ' . bloggingpro_itemtype_schema( 'person' ) . '><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '" title="' . __( 'Permalink to: ', 'bloggingpro' ) . esc_html( get_the_author() ) . '" ' . bloggingpro_itemprop_schema( 'url' ) . '><span ' . bloggingpro_itemprop_schema( 'name' ) . '>' . esc_html( get_the_author() ) . '</span></a></span>'
		);
		if ( 0 === $metadata ) :
			echo '<div class="gmr-metacontent gmr-metacontent-archive">' . $category . $posted_by . '<span class="posted-on byline">' . $posted_on . '</span></div>';  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		endif;
		?>
		<header class="entry-header">
			<?php the_title( '<h2 class="entry-title" ' . bloggingpro_itemprop_schema( 'headline' ) . '><a href="' . esc_url( get_permalink() ) . '" title="' . the_title_attribute( array( 'echo' => false ) ) . '" rel="bookmark">', '</a></h2>' ); ?>
		</header><!-- .entry-header -->

			<div class="entry-content entry-content-archive" <?php echo bloggingpro_itemprop_schema( 'text' ); /* phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped */ ?>>
				<?php the_excerpt(); ?>
			</div><!-- .entry-content -->

	</div><!-- .item-article -->

	<?php if ( is_sticky() ) { ?>
		<kbd class="kbd-sticky"><?php esc_html_e( 'Sticky', 'bloggingpro' ); ?></kbd>
	<?php } ?>

</article><!-- #post-## -->
