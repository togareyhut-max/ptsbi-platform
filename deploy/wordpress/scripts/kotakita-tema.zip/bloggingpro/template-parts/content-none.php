<?php
/**
 * Template part for displaying a message that posts cannot be found.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Bloggingpro
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<section class="no-results not-found item-content clearfix">
	<div class="gmr-box-content">
		<header class="entry-header">
			<h2 class="nofound-title" <?php echo bloggingpro_itemprop_schema( 'headline' ); /* phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped */ ?>><?php esc_html_e( 'Nothing Found', 'bloggingpro' ); ?></h2>
		</header><!-- .page-header -->

		<div class="entry-content" <?php echo bloggingpro_itemprop_schema( 'text' ); /* phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped */ ?>>
			<?php
			if ( is_home() && current_user_can( 'publish_posts' ) ) :
				?>
				<p>
				<?php printf( esc_html__( 'Ready to publish your first post?', 'bloggingpro' ) ); ?>
				</p>
			<?php elseif ( is_search() ) : ?>
				<p><?php esc_html_e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'bloggingpro' ); ?></p>
				<?php
					get_search_form();
			else :
				?>
				<p><?php esc_html_e( 'It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.', 'bloggingpro' ); ?></p>
				<?php
					get_search_form();
			endif;
			?>
		</div><!-- .page-content -->
	</div><!-- .gmr-box-content -->
</section><!-- .no-results -->
