<?php
/**
 * Custom taxonomy for topic in posts
 *
 * Author: Gian MR - http://www.gianmr.com
 *
 * @since 1.0.0
 * @package Bloggingpro Core
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'bloggingpro_core_create_post_tax' ) ) {
	/**
	 * Add new taxonomy in post
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function bloggingpro_core_create_post_tax() {
		/* Add new taxonomy, NOT hierarchical (like tags) */
		$labels = array(
			'name'                       => _x( 'Topics', 'taxonomy general name', 'bloggingpro-core' ),
			'singular_name'              => _x( 'Topic', 'taxonomy singular name', 'bloggingpro-core' ),
			'search_items'               => __( 'Search Topics', 'bloggingpro-core' ),
			'popular_items'              => __( 'Popular Topics', 'bloggingpro-core' ),
			'all_items'                  => __( 'All Topics', 'bloggingpro-core' ),
			'parent_item'                => null,
			'parent_item_colon'          => null,
			'edit_item'                  => __( 'Edit Topic', 'bloggingpro-core' ),
			'update_item'                => __( 'Update Topic', 'bloggingpro-core' ),
			'add_new_item'               => __( 'Add New Topic', 'bloggingpro-core' ),
			'new_item_name'              => __( 'New Topic Name', 'bloggingpro-core' ),
			'separate_items_with_commas' => __( 'Separate topics with commas', 'bloggingpro-core' ),
			'add_or_remove_items'        => __( 'Add or remove topics', 'bloggingpro-core' ),
			'choose_from_most_used'      => __( 'Choose from the most used topics', 'bloggingpro-core' ),
			'not_found'                  => __( 'No topics found.', 'bloggingpro-core' ),
			'menu_name'                  => __( 'Topics', 'bloggingpro-core' ),
		);

		$args = array(
			'hierarchical'          => false,
			'labels'                => $labels,
			'show_ui'               => true,
			'update_count_callback' => '_update_post_term_count',
			'query_var'             => true,
			'show_in_rest'          => true,
			'rewrite'               => array( 'slug' => 'topic' ),
		);
		register_taxonomy( 'newstopic', array( 'post' ), $args );
		unset( $args );
		unset( $labels );
	}
}
add_action( 'init', 'bloggingpro_core_create_post_tax', 0 );
