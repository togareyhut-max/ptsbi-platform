<?php // phpcs:ignore
/**
 * Plugin Name: Bloggingpro Core
 * Plugin URI: https://www.idtheme.com/bloggingpro/
 * Description: Bloggingpro Core - Core Plugin for Bloggingpro
 * Author: Gian Mokhammad R
 * Version: 1.2.6
 * Author URI:  https://www.idtheme.com/bloggingpro/
 * Text Domain: bloggingpro-core
 * Domain Path: /languages
 * Requires at least: 5.6
 * Requires PHP: 7.0
 *
 * @package Bloggingpro Core
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Bloggingpro_Core_Init' ) ) {
	/**
	 * Main Plugin Class
	 */
	class Bloggingpro_Core_Init {
		/**
		 * Contract
		 *
		 * @since 1.0.0
		 * @access public
		 */
		public function __construct() {
			/* Define */
			define( 'BLOGGINGPRO_CORE_DIRNAME', plugin_dir_path( __FILE__ ) );
			define( 'BLOGGINGPRO_CORE_URL', plugin_dir_url( __FILE__ ) );

			/* This is the URL our updater / license checker pings. This should be the URL of the site */
			define( 'BLOGGINGPRO_API_URL_CHECK', 'https://member.kentooz.com/softsale/api/check-license' );
			define( 'BLOGGINGPRO_API_URL', 'https://member.kentooz.com/softsale/api/activate' );
			define( 'BLOGGINGPRO_API_URL_DEACTIVATED', 'https://member.kentooz.com/softsale/api/deactivate' );
			define( 'BLOGGINGPRO_API_URL_CHECK_ACTIVATION', 'https://member.kentooz.com/softsale/api/check-activation' );

			/* the name of the settings page for the license input to be displayed */
			define( 'BLOGGINGPRO_PLUGIN_LICENSE_PAGE', 'bloggingpro-license' );

			/* Include library */
			include BLOGGINGPRO_CORE_DIRNAME . 'lib/taxonomy.php';

			/* Include Amember HTTP API . Load only if dashboard */
			if ( is_admin() ) {
				include_once BLOGGINGPRO_CORE_DIRNAME . 'lib/lcs.php';
			}

			/* Action */
			add_action( 'plugins_loaded', array( $this, 'bloggingpro_core_load_textdomain' ) );

			/* Other functionally */
			include_once BLOGGINGPRO_CORE_DIRNAME . 'lib/update/plugin-update-checker.php';
			$MyUpdateChecker = PucFactory::buildUpdateChecker( // phpcs:ignore
				'https://www.kentooz.com/files/bloggingpro-core/bloggingprocoreautupdtebos.json',
				__FILE__,
				'bloggingpro-core'
			);

		}

		/**
		 * Activated plugin
		 *
		 * @since 1.0.0
		 * @access public
		 */
		public static function bloggingpro_core_activate() {
			/* nothing to do yet */
		}

		/**
		 * Deativated plugin
		 *
		 * @since 1.0.0
		 * @access public
		 */
		public static function bloggingpro_core_deactivate() {
			/* nothing to do yet */
		}

		/**
		 * Load languange
		 *
		 * @since 1.0.0
		 * @access public
		 */
		public function bloggingpro_core_load_textdomain() {
			load_plugin_textdomain( 'bloggingpro-core', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
		}

	}
}


if ( class_exists( 'Bloggingpro_Core_Init' ) ) {
	/* Installation and uninstallation hooks */
	register_activation_hook( __FILE__, array( 'Bloggingpro_Core_Init', 'bloggingpro_core_activate' ) );
	register_deactivation_hook( __FILE__, array( 'Bloggingpro_Core_Init', 'bloggingpro_core_deactivate' ) );

	/* Initialise Class */
	$bloggingpro_core_init_by_gianmr = new Bloggingpro_Core_Init();

}
